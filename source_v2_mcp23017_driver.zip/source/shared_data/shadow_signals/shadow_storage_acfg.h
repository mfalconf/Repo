#ifndef SHADOW_STORAGE_ACFG_H
#   define SHADOW_STORAGE_ACFG_H
/*===========================================================================*/
/**
 * @file shadow_storage_acfg.h
 *
 * @todo Declaration of storage variables communicated between ipu and J6.
 * 
 * @version 1.0
 * @author  Hernández Juan Manuel
 * @date    18/11/2021
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include <common_definitions.h>

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#define SHADOW_STORAGE_VERSION                "2.1"
#define SHADOW_STORAGE_VERSION_DATE           "6/06/2019"

/*===========================================================================*
 * Exported Preprocessor #define X-MACROS
 *===========================================================================*/

/* Insert the server variables that you want to have a shadow  */
#define SHADOW_SERVER_STORAGE                                        \
/*    Variable id                                       Length */    \
   X( SHADOW_OperationalModeSts,                        1           )\
   X( SHADOW_CmdIgn,                                    2           )\
   X( SHADOW_VehicleSpeedVSOSig,                        4           )\
   X( SHADOW_EngineSts,                                 1           )\
   X( SHADOW_SWCSts,                                    2           )\
   X( SHADOW_TimeDate,                                  7           )\
   X( SHADOW_ReverseGearSts,                            1           )\
   X( SHADOW_ParkBrakeSts,                              1           )\
   X( SHADOW_InternalLight,                             2           )\
   X( SHADOW_MicBiasSts,                                1           )\
   X( SHADOW_AntPwr_FMAM_Sts,                           1           )\
   X( SHADOW_AntPwr_GPS_Sts,                            1           )\
   X( SHADOW_LowFuelWarningSts,                         1           )\
   X( SHADOW_ShiftLeverPosition,                        1           )\
   X( SHADOW_AutonomyDistance,                          2           )\
   X( SHADOW_ExternalTemperatureC,                      2           )\
   X( SHADOW_VIN_Msg,                                   2           )\
   X( SHADOW_VIN_Data,                                  7           )\
   X( SHADOW_ShiftModeSts,                              1           )\
   X( SHADOW_LongAcceleration,                          4           )\
   X( SHADOW_LatAcceleration,                           4           )\
   X( SHADOW_YawRate_BSM,                               2           )\
   X( SHADOW_LanguageSelection,                         1           )\
   X( SHADOW_ParkingActive,                             1           )\
   X( SHADOW_ParkingAssistButton,                       1           )\
   X( SHADOW_ParkingFrontSensors,                       4           )\
   X( SHADOW_ParkingRearSensors,                        4           )\
   X( SHADOW_ASWC_Cfg_Req,                              6           )\
   X( SHADOW_ASWC_Cfg_Req_Ch2,                          6           )\
   X( SHADOW_ValidationTone,                            8           )\
   X( SHADOW_InstConsumption,                           4           )\
   X( SHADOW_Range,                                     2           )\
   X( SHADOW_Kilometerstand,                            4           )\
   X( SHADOW_ReserveRange,                              1           )\
   X( SHADOW_ShortTermConsumption,                      4           )\
   X( SHADOW_ShortTermDistance,                         2           )\
   X( SHADOW_ShortTermTime,                             2           )\
   X( SHADOW_ShortTermAvSpeed,                          2           )\
   X( SHADOW_LongTermConsumption,                       4           )\
   X( SHADOW_LongTermDistance,                          2           )\
   X( SHADOW_LongTermTime,                              2           )\
   X( SHADOW_LongTermAvSpeed,                           2           )\
   X( SHADOW_ChassisNumber,                             18          )\
   X( SHADOW_SteeringWheelAngle,                        4           )\
   X( SHADOW_SteeringWheelAngleChangeRate,              4           )\
   X( SHADOW_SteeringWheelAngleCalibration,             1           )\
   X( SHADOW_RPM,                                       2           )\
   X( SHADOW_OilTemperature,                            4           )\
   X( SHADOW_Gear,                                      8           )\
   X( SHADOW_AudioRepetition_SelectedFrequency,         16          )\
   X( SHADOW_PhoneRepetition_SelectedContact,           1           )\
   X( SHADOW_DirectionWheelFL,                          1           )\
   X( SHADOW_DirectionWheelFR,                          1           )\
   X( SHADOW_DirectionWheelRL,                          1           )\
   X( SHADOW_DirectionWheelRR,                          1           )\
   X( SHADOW_CounterWheelFL,                            2           )\
   X( SHADOW_CounterWheelFR,                            2           )\
   X( SHADOW_CounterWheelRL,                            2           )\
   X( SHADOW_CounterWheelRR,                            2           )\
   X( SHADOW_WheelCircumference,                        2           )\
   X( SHADOW_AntMicTestFinished,                        1           )\
   X( SHADOW_DiagnosticRVC,                             1           )\
   X( SHADOW_InstConsumptionUnit,                       8           )\
   X( SHADOW_RangeUnit,                                 8           )\
   X( SHADOW_KilometerstandUnit,                        8           )\
   X( SHADOW_ShortTermConsumptionUnit,                  8           )\
   X( SHADOW_ShortTermDistanceUnit,                     8           )\
   X( SHADOW_ShortTermAvSpeedUnit,                      8           )\
   X( SHADOW_LongTermConsumptionUnit,                   8           )\
   X( SHADOW_LongTermDistanceUnit,                      8           )\
   X( SHADOW_LongTermAvSpeedUnit,                       8           )\
   X( SHADOW_CarModel,                                  1           )\
   X( SHADOW_OffroadEnable,                             1           )\
   X( SHADOW_TankContents,                              1           )\
   X( SHADOW_PhoneRepetition_SelectedOption,            1           )\


/*

SHADOW_SIGNAL_CmdIgn:
                        byte 1: CmdIgn_FailSts        -> CAN Signal of STATUS_BH_BCM2
                        byte 2: CmdIgnSts             -> CAN Signal of STATUS_BH_BCM2

SHADOW_SIGNAL_InternalLight:
                        byte 1: InternalLightSts      -> CAN Signal of STATUS_BH_BCM2
                        byte 2: InternalLightLevel    -> CAN Signal of STATUS_BH_BCM2

SHADOW_SIGNAL_SWCSts:   
                        Each bit represents a command of CAN message SWS_IGWLIN.
                        the least significant bit is Command_01Sts.


SHADOW_SIGNAL_TimeDate:
                        byte 1: year
                        byte 2: month
                        byte 3: day
                        byte 4: hour
                        byte 5: minute
                        byte 6: seconds
                        byte 7: hr_mode

SHADOW_Dimming:
                        byte 1: mode
                        byte 2: duty
                        byte 3: frequency_hi
                        byte 4: frequency_lo

SHADOW_ValidationTone:
                        byte 1:        Playing Status
                        byte 2:        Volume of the tone
                        bytes 3 to 6:  Duration of the Tone in seconds.
                        bytes 7 to 8:  Frequency of the tone

SHADOW_InstConsumption:
                        float value

SHADOW_Range:
                        uint16_t value, byte 1: LSB, byte 2:MSB

SHADOW_Kilometerstand:
                        uint32_t value, byte 1: LSB, byte 4:MSB

SHADOW_ReserveRange:
                        uint8_t value

SHADOW_ShortTermConsumption:
                        float value

SHADOW_ShortTermDistance:
                        uint16_t value, byte 1: LSB, byte 2:MSB

SHADOW_ShortTermTime:
                        uint16_t value, byte 1: LSB, byte 2:MSB

SHADOW_ShortTermAvSpeed:
                        uint16_t value, byte 1: LSB, byte 2:MSB

SHADOW_LongTermConsumption:
                        float value

SHADOW_LongTermDistance:
                        uint16_t value, byte 1: LSB, byte 2:MSB

SHADOW_LongTermTime:
                        uint16_t value, byte 1: LSB, byte 2:MSB

SHADOW_LongTermAvSpeed:
                        uint16_t value, byte 1: LSB, byte 2:MSB

SHADOW_ChassisNumber:
                        char[18] string

SHADOW_SteeringWheelAngle:
                        float value in °

SHADOW_RPM:
                        uint16_t value in 1/minute

SHADOW_OilTemperature:
                        float value in °C

SHADOW_Gear:
                        char[18] string

SHADOW_AntMicTestFinished:
                        uint8_t value: 1 indicates that the test is complete

SHADOW_DiagnosticRVC:
                        uint8_t value: 0 ok, 1 error, other: not tested yet

SHADOW_InstConsumptionUnit:
                        char[8] string: InstConsumption unit "l/100km" "km/l" "mpg" "kg/100km" "kg/h" "mpkg" or "lph"

SHADOW_RangeUnit:
                        char[8] string: Range unit "km" or ml"

SHADOW_KilometerstandUnit:
                        char[8] string: Kilometerstand unit "km" or ml"

SHADOW_ShortTermConsumptionUnit:
                        char[8] string: ShortTermConsumption unit "l/100km" "km/l" "mpg" "kg/100km" "kg/h" "mpkg" "lph"

SHADOW_ShortTermDistanceUnit:
                        char[8] string: ShortTermDistance unit "km" or ml"

SHADOW_ShortTermAvSpeedUnit:
                        char[8] string: ShortTermAvSpeed unit "km/h" or "mph"

SHADOW_LongTermConsumptionUnit:
                        char[8] string: LongTermConsumption unit "l/100km" "km/l" "mpg" "kg/100km" "kg/h" "mpkg" "lph"

SHADOW_LongTermDistanceUnit:
                        char[8] string: LongTermDistance unit "km" or ml"

SHADOW_LongTermAvSpeedUnit:
                        char[8] string: LongTermAvSpeed unit "km/h" or "mph"
SHADOW_CarModel:
                        uint8_t value: Shadow_CarModel_T enum
SHADOW_OffroadEnable:
                        uint8_t value: 0 disable, 1 enable
*/

#define SHADOW_CLIENT_STORAGE                                                              \
/*    Variable id                                       Length */                          \
   X( SHADOW_Selected_TimeDate,                         7                                 )\
   X( SHADOW_SWC_Mode,                                  1                                 )\
   X( SHADOW_SWC_KeyCfg,                                1                                 )\
   X( SHADOW_SWC_KeyCfg_Ch2,                            1                                 )\
   X( SHADOW_ASWC_Cfg_Rx,                               55                                )\
   X( SHADOW_ASWC_Cfg_Ch2_Rx,                           55                                )\
   X( SHADOW_AudioRepetition_CurrentSource,             1                                 )\
   X( SHADOW_AudioRepetition_UpdatingMetaData,          1                                 )\
   X( SHADOW_AudioRepetition_PlayState,                 1                                 )\
   X( SHADOW_AudioRepetition_TunedFrequency,            16                                )\
   X( SHADOW_AudioRepetition_PresetList,                PRESET_LIST_SIZE                  )\
   X( SHADOW_AudioRepetition_PSN,                       16                                )\
   X( SHADOW_AudioRepetition_RadioText,                 128                               )\
   X( SHADOW_AudioRepetition_SongName,                  128                               )\
   X( SHADOW_AudioRepetition_ArtistName,                128                               )\
   X( SHADOW_AudioRepetition_AlbumName,                 128                               )\
   X( SHADOW_AudioRepetition_RepeatSts,                 1                                 )\
   X( SHADOW_AudioRepetition_ShuffleSts,                1                                 )\
   X( SHADOW_PhoneRepetition_ConnectionStatus,          1                                 )\
   X( SHADOW_PhoneRepetition_ConnectionStatusMessage,   128                               )\
   X( SHADOW_PhoneRepetition_RecentCallsListHeader,     RECENT_CALLS_LIST_HEADER_SIZE     )\
   X( SHADOW_PhoneRepetition_RecentCallsListFooter,     RECENT_CALLS_LIST_FOOTER_SIZE     )\
   X( SHADOW_PhoneRepetition_RecentCallsList,           RECENT_CALLS_LIST_SIZE            )\
   X( SHADOW_PhoneRepetition_CallSts,                   1                                 )\
   X( SHADOW_PhoneRepetition_CallContactMessage,        128                               )\
   X( SHADOW_PhoneRepetition_CallStsMessage,            128                               )\
   X( SHADOW_AudioRepetition_PrivacyModeSts,            1                                 )\
   X( SHADOW_AudioRepetition_MaxVolume,                 1                                 )\
   X( SHADOW_AudioRepetition_CurrentVolume,             2                                 )\
   X( SHADOW_AudioRepetition_MuteSts,                   1                                 )\
   X( SHADOW_Dimming,                                   4                                 )\
   X( SHADOW_RobertitoSyncStatus,                       1                                 )\
   X( SHADOW_AntMicTestStart,                           1                                 )\
   X( SHADOW_PhoneRepetition_MissedCalls,               1                                 )\
   X( SHADOW_PhoneRepetition_CallOptions,               CALL_OPTIONS_LIST_SIZE            )\

/***********************************************************/
/* Example

#define SHADOW_STORAGE_TOTAL_SIZE      19

#undef X
#define SHADOW_STORAGE                               \
   Name                             Length             \
   X( VAR_1,                           4              )\
   X( VAR_2,                           3              )\
   X( VAR_3,                           12             )\

typedef enum aux_shadow_storage_Tag
{
   INITIAL_VALUE  = 0,
   aux_NAME_VAR_1 = 1,
   NAME_VAR_1     = 4,
   aux_NAME_VAR_2 = 5,
   NAME_VAR_2     = 7,
   aux_NAME_VAR_3 = 8,
   NAME_VAR_3     = 19,
   VAR_SYSTEM_MAX = 20
}aux_shadow_storage_T;

typedef enum shadow_storage_offset_Tag
{
   VAR_1_OFFSET   = 0,
   VAR_2_OFFSET   = 4,
   VAR_3_OFFSET   = 7,
}shadow_storage_offset_T;

typedef enum shadow_storage_id_Tag
{
   VAR_1    = 0;
   VAR_2    = 1;
   VAR_3    = 2;
   NUM_VAR  = 3;
}shadow_storage_id_T;

static const shadow_storage_T shadow_storage_offset[3]={  {0,4},{4,3},{7,12} };
static uint8_t shadow_storage_data[19];

*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/** @} doxygen end group */

#endif                          /* SHADOW_STORAGE_ACFG_H */


