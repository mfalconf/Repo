#ifndef COMMON_DEFINITIONS_H
#   define COMMON_DEFINITIONS_H
/*===========================================================================*/
/**
 * @file common_definitions.h
 *
 * @todo Declaration of constant values for the storage variables shared
 *       between ipu and J6.
 * 
 * @version 1.0
 * @author  Robles Lisandro
 * @date    05/04/2022
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/* SHADOW_AudioRepetition_PresetList */

/* Max. number of presets available for the User */
#define NUM_MAX_PRESETS             18
/* Max size in bytes of a string representing a frequency
 * e.g. 910, 970, 1050, 108000 */
#define FREQUENCY_STRING_BYTE_SIZE  12
/* Size in bytes of the token delimiter
 * e.g. 910|970|1080*/
#define DELIMITER_TOKEN_SIZE        2
/* Delimiter used in preset list */
#define PRESET_LIST_DELIMITER       "|"
/* Max size needed for the preset list
 * e.g 108000|99000|87500 */
//#define PRESET_LIST_SIZE                    (FREQUENCY_STRING_BYTE_SIZE*NUM_MAX_PRESETS) + (DELIMITER_TOKEN_SIZE*(NUM_MAX_PRESETS -1))
#define PRESET_LIST_SIZE                    250

/* SHADOW_PhoneRepetition_RecentCallsList  */

/* Max. number of in the recent calls list */
#define RECENT_CALLS_LIST_NUM_MAX_ELEMENTS  40
/* Max size in bytes of an element of the recent call list */
#define RECENT_CALLS_LIST_ELEMENT_MAX_SIZE  24
/* Size in bytes of the token delimiter */
#define RECENT_CALLS_DELIMITER_TOKEN_SIZE   2
/* Delimiter used in recent calls list */
#define RECENT_CALLS_LIST_DELIMITER         "|"
/* Max size needed for the preset list recent calls list*/
//#define RECENT_CALLS_LIST_SIZE            (RECENT_CALLS_LIST_ELEMENT_MAX_SIZE*RECENT_CALLS_LIST_NUM_MAX_ELEMENTS) + (RECENT_CALLS_DELIMITER_TOKEN_SIZE*(RECENT_CALLS_LIST_NUM_MAX_ELEMENTS -1))
#define RECENT_CALLS_LIST_SIZE              1038 // 40 calls
/* Recent calls list header size */
#define RECENT_CALLS_LIST_HEADER_SIZE       RECENT_CALLS_LIST_ELEMENT_MAX_SIZE
/* Recent calls list footer size */
#define RECENT_CALLS_LIST_FOOTER_SIZE       RECENT_CALLS_LIST_ELEMENT_MAX_SIZE

/* SHADOW_PhoneRepetition_CallOptions  */

/* Max. number of options in call options list */
#define CALL_OPTIONS_LIST_NUM_MAX_ELEMENTS  5
/* Max size in bytes of an element of the call options list*/
#define CALL_OPTIONS_LIST_ELEMENT_MAX_SIZE  24
/* Size in bytes of the token delimiter */
#define CALL_OPTIONS_DELIMITER_TOKEN_SIZE   2
/* Delimiter used in call options list */
#define CALL_OPTIONS_LIST_DELIMITER         "|"
/* Max size needed for the call options list*/   
//#define CALL_OPTIONS_LIST_SIZE            (CALL_OPTIONS_LIST_ELEMENT_MAX_SIZE*CALL_OPTIONS_LIST_NUM_MAX_ELEMENTS) + (CALL_OPTIONS_DELIMITER_TOKEN_SIZE*(CALL_OPTIONS_LIST_NUM_MAX_ELEMENTS -1))
#define CALL_OPTIONS_LIST_SIZE              128 // 5 options

/*===========================================================================*
 * Exported Preprocessor #define X-MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/* SHADOW_LanguageSelection */

typedef enum
{
    HU_NO_LANG = 0,
    HU_ENGLISH,
    HU_SPANISH,
    HU_PORTUGUES,
    HU_NUM_LANGS
}Shadow_LangSel_T;


/* SHADOW_AudioRepetition_CurrentSource */

typedef enum
{
    HU_SRC_IDLE,
    HU_SRC_TUNER_AM,
    HU_SRC_TUNER_FM,
    HU_SRC_AUX,
    HU_SRC_USB,
    HU_SRC_BTA,
    HU_SRC_ANDROID_AUTO,
    HU_SRC_CARPLAY,
    HU_NUM_SRC
}Shadow_AudioRep_CurrSrc_T;

/* SHADOW_AudioRepetition_PlayState */

typedef enum
{
    HU_PLAY_STATE_IDLE,
    HU_PLAY_STATE_STOP,
    HU_PLAY_STATE_PAUSE,
    HU_PLAY_STATE_PLAY,
    HU_NUM_PLAY_STATE
}Shadow_AudioRep_PlayState_T;


/* SHADOW_AudioRepetition_RepeatSts */

typedef enum
{
    HU_REPEAT_STS_OFF,
    HU_REPEAT_STS_ONE,
    HU_REPEAT_STS_ALL,
    HU_REPEAT_STS_GROUP,
    HU_NUM_REPEAT_STS
}Shadow_AudioRep_RepeatSts_T;

/* SHADOW_AudioRepetition_ShuffleSts */

typedef enum
{
    HU_SHUFFLE_STS_OFF,
    HU_SHUFFLE_STS_ALL,
    HU_SHUFFLE_STS_GROUP,
    HU_NUM_SHUFFLE_STS
}Shadow_AudioRep_ShuffleSts_T;

/* SHADOW_CarModel */
/* IMPORTANT TO KEEP IN SYNC WITH VehicleManager.CarModel*/
typedef enum
{
	CAR_MODEL_INVALID,
	CAR_MODEL_VW_AMAROK,
	CAR_MODEL_VW_POLO,
	CAR_MODEL_VW_SAVEIRO,
	CAR_MODEL_VW_SAVEIRO_DOUBLE_CABIN,
} Shadow_CarModel_T;

/** @} doxygen end group */

#endif                          /* COMMON_DEFINITIONS_H */
