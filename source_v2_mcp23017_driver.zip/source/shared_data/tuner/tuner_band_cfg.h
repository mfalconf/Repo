#ifndef TUNER_BAND_CFG_H
#define TUNER_BAND_CFG_H 1

#define RADIO_REGION_SYSTEM_PROPERTY "persist.system_properties.radio_region"

#define RADIO_REGIONS                                                                                                                                           \
/*            Region  FM:ant lowerl upperl num spacing  deemphasis     stereo        rds       ta      af     ea   AM:ant lowerl upperl num spacing stereo */   \
 RADIO_REGION(ITU2,   true, 87500, 107900, 1, 200, RADIO_DEEMPHASIS_75, true, RADIO_RDS_NONE, false, false, false, true, 530,    1710,  1,   10,    true)       \
 RADIO_REGION(BRAZIL, true, 76100, 107900, 1, 200, RADIO_DEEMPHASIS_75, true, RADIO_RDS_NONE, false, false, false, true, 530,    1710,  1,   10,    true)       \
 RADIO_REGION(ITU1,   true, 87500, 107900, 1, 100, RADIO_DEEMPHASIS_75, true, RADIO_RDS_NONE, false, false, false, true, 530,    1710,  1,   10,    true)

/* Enum regions*/
#undef RADIO_REGION
#define RADIO_REGION(region,fm_ant,fm_lower_limit,fm_upper_limit,fm_num_spacings,fm_spacings,  \
        fm_deemphasis,fm_stereo,fm_rds,fm_ta,fm_af,fm_ea,am_ant,am_lower_limit,am_upper_limit, \
        am_num_spacings,am_spacings,am_stereo) RADIO_REGION_##region,

typedef enum radio_regions
{
   RADIO_REGIONS    //example: RADIO_REGION_ITU1 = 0,
   RADIO_REGIONS_LENGTH
}radio_regions_T;
#undef RADIO_REGION

#define RADIO_REGION_DEFAULT RADIO_REGION_ITU1

#define MAX_2(x,y) ( (x) > (y) ? (x) : (y) )
#define MIN_2(x,y) ( (x) < (y) ? (x) : (y) )


#undef RADIO_REGION
#define RADIO_REGION(region,fm_ant,fm_lower_limit,fm_upper_limit,fm_num_spacings,fm_spacings,  \
        fm_deemphasis,fm_stereo,fm_rds,fm_ta,fm_af,fm_ea,am_ant,am_lower_limit,am_upper_limit, \
        am_num_spacings,am_spacings,am_stereo) RADIO_REGION_##region##_FM_LOWER_LIMIT = fm_lower_limit,

typedef enum radio_fm_lower_limit
{
   RADIO_REGIONS    //example: RADIO_REGION_ITU1 = 0,
}radio_fm_lower_limit_T;

#undef RADIO_REGION
#define RADIO_REGION(region,fm_ant,fm_lower_limit,fm_upper_limit,fm_num_spacings,fm_spacings,  \
        fm_deemphasis,fm_stereo,fm_rds,fm_ta,fm_af,fm_ea,am_ant,am_lower_limit,am_upper_limit, \
        am_num_spacings,am_spacings,am_stereo) RADIO_REGION_##region##_FM_UPPER_LIMIT = fm_upper_limit,

typedef enum radio_fm_upper_limit
{
   RADIO_REGIONS    //example: RADIO_REGION_ITU1 = 0,
}radio_fm_upper_limit_T;

#undef RADIO_REGION
#define RADIO_REGION(region,fm_ant,fm_lower_limit,fm_upper_limit,fm_num_spacings,fm_spacings,  \
        fm_deemphasis,fm_stereo,fm_rds,fm_ta,fm_af,fm_ea,am_ant,am_lower_limit,am_upper_limit, \
        am_num_spacings,am_spacings,am_stereo) RADIO_REGION_##region##_AM_LOWER_LIMIT = am_lower_limit,

typedef enum radio_am_lower_limit
{
   RADIO_REGIONS    //example: RADIO_REGION_ITU1 = 0,
}radio_am_lower_limit_T;

#undef RADIO_REGION
#define RADIO_REGION(region,fm_ant,fm_lower_limit,fm_upper_limit,fm_num_spacings,fm_spacings,  \
        fm_deemphasis,fm_stereo,fm_rds,fm_ta,fm_af,fm_ea,am_ant,am_lower_limit,am_upper_limit, \
        am_num_spacings,am_spacings,am_stereo) RADIO_REGION_##region##_AM_UPPER_LIMIT = am_upper_limit,

typedef enum radio_am_upper_limit
{
   RADIO_REGIONS    //example: RADIO_REGION_ITU1 = 0,
}radio_am_upper_limit_T;

#define RADIO_FM_LOWER_LIMIT    MIN_2(RADIO_REGION_BRAZIL_FM_LOWER_LIMIT,RADIO_REGION_ITU1_FM_LOWER_LIMIT)
#define RADIO_FM_UPPER_LIMIT    MAX_2(RADIO_REGION_BRAZIL_FM_UPPER_LIMIT,RADIO_REGION_ITU1_FM_UPPER_LIMIT)

#define RADIO_AM_LOWER_LIMIT    MIN_2(RADIO_REGION_BRAZIL_AM_LOWER_LIMIT,RADIO_REGION_ITU1_AM_LOWER_LIMIT)
#define RADIO_AM_UPPER_LIMIT    MAX_2(RADIO_REGION_BRAZIL_AM_UPPER_LIMIT,RADIO_REGION_ITU1_AM_UPPER_LIMIT)


#endif /* TUNER_BAND_CFG_H */