/*
 * Copyright (c) 2014-2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/** ============================================================================
 *  @file       UART_v1.h
 *
 *  @brief      UART DMA and non-DMA driver implementation for IP V1 UART controller
 *
 *
 *  ============================================================================
 */

#ifndef ti_drivers_uart_UARTv1__include
#define ti_drivers_uart_UARTv1__include
//#include <drv/uart/UART.h>
#include "UART.h"

#ifdef __cplusplus
extern "C" {
#endif



/* UART function table pointer */
extern const UART_FxnTable UART_FxnTable_v1;

/*!
 *  @brief      UART_V1 Object
 *
 *  The application must not access any member variables of this structure!
 */
typedef struct UART_V1_Object_s
{
    /* UART control variables */
    UART_Params          params;           /* Configured UART parameters */

    /* UART SYS/BIOS objects */
    void*               hwi; /* Hwi object */
    void*               writeSem;         /* UART write semaphore*/
    void*               readSem;          /* UART read semaphore */
    /* UART write variables */
    const void          *writeBuf;         /* Buffer data pointer */
    size_t               writeCount;       /* Number of Chars sent */
    size_t               writeSize;        /* Chars remaining in buffer */
    uint32_t         writeCR;          /* Write a return character */

    /* UART receive variables */
    void                *readBuf;          /* Buffer data pointer */
    size_t               readCount;        /* Number of Chars read */
    size_t               readSize;         /* Chars remaining in buffer */

    uint32_t         isOpen;           /* flag to indicate module is open */
    
    uint32_t             edmaLinkChPhyAddr;
    uint32_t             edmaLinkChId;
    uint32_t             txTcc;
    UART_Transaction    *readTrans;    /* Pointer to the current read transaction */
    UART_Transaction    *writeTrans;   /* Pointer to the current write transaction */
    uint32_t             rxTimeoutCnt; /* Receive timeout error count */
    uint32_t             txDataSent;   /* flag to indicate all the data are
                                          written to the TX FIFO */

}UART_V1_Object, *UART_V1_Handle;

/**
 *
 * \brief   UART Rx Trigger Level Param
 * IMP: The enum values should not be changed since it represents the
 *          actual register configuration values used to configure the UART in
 *          this SoC by the UART driver
 */
typedef enum
{
    UART_RXTRIGLVL_8 = 8,
    /**< Trigger Level 8    */
    UART_RXTRIGLVL_16 = 16,
    /**< Trigger Level 16   */
    UART_RXTRIGLVL_56 = 56,
    /**< Trigger Level 56   */
    UART_RXTRIGLVL_60 = 60
                        /**< Trigger Level 60   */
} UART_RxTrigLvl;

/**
 *
 * \brief   UART Tx Trigger Level Param
 * IMP: The enum values should not be changed since it represents the
 *      actual register configuration values used to configure the UART in
 *      this SoC by the UART driver
 */
typedef enum
{
    UART_TXTRIGLVL_8 = 8,
    /**< Trigger Level 8    */
    UART_TXTRIGLVL_16 = 16,
    /**< Trigger Level 16   */
    UART_TXTRIGLVL_32 = 32,
    /**< Trigger Level 32   */
    UART_TXTRIGLVL_56 = 56
                        /**< Trigger Level 56   */
} UART_TxTrigLvl;

typedef struct UART_HWAttrs {
    /*UART Peripheral's base address */
    uint32_t      baseAddr;
    /*UART Interrupt number */
    uint32_t      intNum;
    /*UART EventID */
    uint32_t      eventId;
    /*UART Input frequency */
    uint32_t      frequency;

    /*EDMA related Hardware configuration details*/
    uint32_t      rxDmaEventNumber;
    /**< EDMA event number of Receiver*/
    uint32_t      txDmaEventNumber;
    /**< EDMA event number of Transmitter*/
    uint32_t      edmaTxTCC;
    /**< EDMA Transfer Controller No.of TX channel*/
    uint32_t      edmaRxTCC;
    /**< EDMA Transfer Controller No.of Rx channel*/
    uint32_t      edmaTxTC;
    /**< EDMA Transfer Controller No.of TX channel*/
    uint32_t      edmaRxTC;
    /**< EDMA Transfer Controller No.of Rx channel*/
    uint32_t      version;
    void*         edmaHandle;
    UART_RxTrigLvl  rxTrigLvl;
    /**< refer #UART_RxTrigLvl for valid values        */
    UART_TxTrigLvl  txTrigLvl;
    /**< refer #UART_TxTrigLvl for valid values        */
    uint32_t      dmaMode;
    /**< flag to indicate in DMA mode */
    uint32_t      loopback;
    /**< flag to indicate in loopback mode */

    /**< flag to enable interrupt */
    uint32_t      enableInterrupt;
} UART_HwAttrs;

#ifdef __cplusplus
}
#endif

#endif /* ti_drivers_uart_UARTv1__include */
