#ifndef BOARD_H_
#define BOARD_H_
/*===========================================================================*/
/**
 * @file BOARD.h
 *
 * Function definitions for the board dependant functions.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include <ti/csl/soc.h>
#include "comm_pmic_65919.h"

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#define ANT_FMAM_PWR_GPIO_ADDR       SOC_GPIO2_BASE + L4_REGISTER_ADDRESS_OFFSET
#define ANT_FMAM_PWR_GPIO_PIN        2

#define ANT_GPS_PWR_GPIO_ADDR        SOC_GPIO2_BASE + L4_REGISTER_ADDRESS_OFFSET
#define ANT_GPS_PWR_GPIO_PIN         1

#define ANT_SENSE_EN_GPIO_ADDR       SOC_GPIO2_BASE + L4_REGISTER_ADDRESS_OFFSET
#define ANT_SENSE_EN_GPIO_PIN        4

#define MICBIAS_CTRL_GPIO_ADDR       SOC_GPIO4_BASE + L4_REGISTER_ADDRESS_OFFSET
#define MICBIAS_CTRL_GPIO_PIN        30

#define DIMM_ENC2_CTRL_GPIO_ADDR     SOC_GPIO7_BASE + L4_REGISTER_ADDRESS_OFFSET
#define DIMM_ENC2_CTRL_GPIO_PIN      15

#define DIMM_DISP_CTRL_GPIO_ADDR     SOC_GPIO4_BASE + L4_REGISTER_ADDRESS_OFFSET
#define DIMM_DISP_CTRL_GPIO_PIN      2

#define ES_PARK_DET_GPIO_ADDR        SOC_GPIO1_BASE + L4_REGISTER_ADDRESS_OFFSET
#define ES_PARK_DET_GPIO_PIN         17

#define ES_REVERSE_DET_GPIO_ADDR     SOC_GPIO1_BASE + L4_REGISTER_ADDRESS_OFFSET
#define ES_REVERSE_DET_GPIO_PIN      16

#define ES_DIMMING_GPIO_ADDR         SOC_GPIO1_BASE + L4_REGISTER_ADDRESS_OFFSET
#define ES_DIMMING_GPIO_PIN          5

#define ES_IGNITION_DET_GPIO_ADDR    SOC_GPIO1_BASE + L4_REGISTER_ADDRESS_OFFSET
#define ES_IGNITION_DET_GPIO_PIN     4

#define VIDEO_CAMERA_PDN_GPIO_ADDR   (L4_REGISTER_ADDRESS_OFFSET + SOC_GPIO6_BASE)
#define VIDEO_CAMERA_PDN_GPIO_PIN    (8)

#define VIDEO_CAMERA_RST_GPIO_ADDR   (L4_REGISTER_ADDRESS_OFFSET + SOC_GPIO6_BASE)
#define VIDEO_CAMERA_RST_GPIO_PIN    (20)

#define VIDEO_LVDS_EN_GPIO_ADDR      (L4_REGISTER_ADDRESS_OFFSET + SOC_GPIO4_BASE)
#define VIDEO_LVDS_EN_GPIO_PIN       (8)

#define CAN_ENABLE_GPIO_ADDR         SOC_GPIO2_BASE + L4_REGISTER_ADDRESS_OFFSET
#define CAN_ENABLE_GPIO_PIN          7

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
void Board_Init (void);
void Board_CheckDimmingClock (void);
void Board_SetOperatingVoltages (void);

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file BOARD.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 06-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* BOARD_H_ */
