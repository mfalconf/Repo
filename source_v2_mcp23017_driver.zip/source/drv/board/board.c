/*===========================================================================*/
/**
 * @file BOARD.h
 *
 * Function definitions for the board dependant functions.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <board.h>
#include <standard.h>
#include "console.h"

#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>
#include <ti/csl/csl_gpio.h>

#include <ti/drv/vps/include/osal/bsp_osal.h>

#include "comm_protocol.h"

#include "rsc_table_famp_vw_ipu.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define PMIC_VOLT_MIN_mV   500
#define PMIC_VSTEP_mV      10

/* Constants used for enabling weak PullUD in DCAN1 Tx                          */
/* For this constants there is an incongruity between the TRM and the values    */
/* given by the PDK.                                                            */
/*                                                                              */
/*                                                                              */
/* From J6 TRM, Table 18-1484. CTRL_CORE_PAD_DCAN1_TX:                          */
/*                                                                              */
/* 16 DCAN1_TX_PULLUDENABLE RW          0x0: Enables weak Pull Up/Down          */
/*                                       0x1: Disables weak Pull Up/Down        */
/*                                                                              */
/* Whereas the PDK define this constants:                                       */
/*                                                                              */
/*  #define CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_PULLUDENABLE_ENABLE     (1U)        */
/*  #define CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_PULLUDENABLE_DISABLE    (0U)        */
/*                                                                              */
/* This is the reason why the PDK constants are still used but swapped          */
#define CTRL_CORE_PAD_DCAN1_TX_PULLUDENABLE_ENABLE     CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_PULLUDENABLE_DISABLE
#define CTRL_CORE_PAD_DCAN1_TX_PULLUDENABLE_DISABLE    CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_PULLUDENABLE_ENABLE

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/** Initialize TVP related pins */
static void Board_Init_TVP(void)
{
  /* Video decoder (TVP) power down and reset GPIOs */
  #define GPIO6_8_REG   (L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_MCASP2_AXR2)
  #define GPIO6_20_REG  (L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_XREF_CLK3)
  uint32_t aux_reg;

  /* CAM_PDN (camera power down) is routed at mcasp2_axr2/gpio6_8 */
  aux_reg = HW_RD_REG32(GPIO6_8_REG) &
            (~(CTRL_CORE_PAD_MCASP2_AXR2_MCASP2_AXR2_MUXMODE_MASK | CTRL_CORE_PAD_MCASP2_AXR2_MCASP2_AXR2_PULLTYPESELECT_MASK));

  // Enable GPIO mode
  aux_reg |= CTRL_CORE_PAD_MCASP2_AXR2_MCASP2_AXR2_MUXMODE_GPIO6_8_14 << CTRL_CORE_PAD_MCASP2_AXR2_MCASP2_AXR2_MUXMODE_SHIFT;
  // Disable receiver mode
  aux_reg &= ~CTRL_CORE_PAD_MCASP2_AXR2_MCASP2_AXR2_INPUTENABLE_MASK;

  HW_WR_REG32(GPIO6_8_REG, aux_reg);

  /* CAM_RST (camera reset) is routed at xref_clk3/gpio6_20 */
  aux_reg = HW_RD_REG32(GPIO6_20_REG) &
            (~(CTRL_CORE_PAD_XREF_CLK3_XREF_CLK3_MUXMODE_MASK | CTRL_CORE_PAD_XREF_CLK3_XREF_CLK3_PULLTYPESELECT_MASK));

  // Enable GPIO mode
  aux_reg |= CTRL_CORE_PAD_XREF_CLK3_XREF_CLK3_MUXMODE_GPIO6_20_14 << CTRL_CORE_PAD_XREF_CLK3_XREF_CLK3_MUXMODE_SHIFT;
  // Disable receiver mode
  aux_reg &= ~CTRL_CORE_PAD_XREF_CLK3_XREF_CLK3_INPUTENABLE_MASK;

  HW_WR_REG32(GPIO6_20_REG, aux_reg);
}

/** Initialize LVDS related pins */
static void Board_Init_LVDS(void)
{
  /* LVDS Enable GPIO */
  #define GPIO_4_8_REG  (L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_VIN2A_D7)
  uint32_t aux_reg;

  /* LVDS_EN (LVDS enable) is routed at vin2a_d7/gpio4_8 */
  aux_reg = HW_RD_REG32(GPIO_4_8_REG) &
            (~(CTRL_CORE_PAD_VIN2A_D7_VIN2A_D7_MUXMODE_MASK | CTRL_CORE_PAD_VIN2A_D7_VIN2A_D7_PULLTYPESELECT_MASK));

  // Enable GPIO mode
  aux_reg |= CTRL_CORE_PAD_VIN2A_D7_VIN2A_D7_MUXMODE_GPIO4_8_14 << CTRL_CORE_PAD_VIN2A_D7_VIN2A_D7_MUXMODE_SHIFT;
  // Disable receiver mode
  aux_reg &= ~CTRL_CORE_PAD_VIN2A_D7_VIN2A_D7_INPUTENABLE_MASK;

  HW_WR_REG32(GPIO_4_8_REG, aux_reg);
}

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
*
* @fn         Board_Init_FAMP_Common
*
* @brief      Board FAMP Common dependant initialization function
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void Board_Init_FAMP_Common (void)
{
    /***************************************************************************//**
    * pwmOnKey
    ******************************************************************************/
    /* PWM Pad configurations - VIN2A_D17 -> EHRPWM3A */
    uint32_t pwmOnKey = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE +  CTRL_CORE_PAD_VIN2A_D17) & (~(CTRL_CORE_PAD_VIN2A_D17_VIN2A_D17_MUXMODE_MASK));
    pwmOnKey |= CTRL_CORE_PAD_VIN2A_D17_VIN2A_D17_MUXMODE_EHRPWM3A_10;
    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_VIN2A_D17, pwmOnKey);

    /* Enable PRCM for PWMSS3 */
    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE + CM_L4PER2_PWMSS3_CLKCTRL, 0x2);
    while ((HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE + CM_L4PER2_PWMSS3_CLKCTRL) & (0x00030000)) != 0x0) ;

    /***************************************************************************//**
    * pwmCpBtn
    ******************************************************************************/
    /* PWM Pad configurations - VIN2A_D18 -> EHRPWM3B */
    uint32_t pwmCpBtn = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE +  CTRL_CORE_PAD_VIN2A_D18) & (~(CTRL_CORE_PAD_VIN2A_D18_VIN2A_D18_MUXMODE_MASK));
    pwmCpBtn |= CTRL_CORE_PAD_VIN2A_D18_VIN2A_D18_MUXMODE_EHRPWM3B_10;
    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_VIN2A_D18, pwmCpBtn);

    /* Enable PRCM for PWMSS3 */
    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE + CM_L4PER2_PWMSS3_CLKCTRL, 0x2);
    while ((HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE + CM_L4PER2_PWMSS3_CLKCTRL) & (0x00030000)) != 0x0) ;

    /***************************************************************************//**
    * DIMM_ENC2_CTRL
    ******************************************************************************/
    /* Enable PRCM for the GPIO7 */
    uint32_t reg;
    reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE +  CM_L4PER_GPIO7_CLKCTRL) & (~(CM_L4PER_GPIO7_CLKCTRL_MODULEMODE_MASK));
    reg |= CM_L4PER_GPIO7_CLKCTRL_MODULEMODE_AUTO;
    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE + CM_L4PER_GPIO7_CLKCTRL, reg);

    /***************************************************************************//**
    * I2C1
    ******************************************************************************/
    /* We need to enable the clock for the I2C1 --> CTRL_CORE_SMA_SW_0 enable I2C1_CLK_EN --> 0x4A0023FC */
    HW_WR_REG32( (0x20000000 + SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE + CTRL_CORE_SMA_SW_0), HW_RD_REG32(0x20000000 + SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE + CTRL_CORE_SMA_SW_0) | 0x00000008);
    /* There is no muxing for I2C1 but we need to enable the INPUT_ENABLE*/
    /* I2C1_SDA */
    HW_WR_REG32(0x20000000 + (SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_I2C1_SDA), 0x00060000);
    /* I2C1_SCL */
    HW_WR_REG32(0x20000000 + (SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_I2C1_SCL), 0x00060000);

    /***************************************************************************//**
    * Dcan_WkupAON_Clkctrl
    ******************************************************************************/
    HW_WR_FIELD32(0x20000000 + SOC_WKUPAON_CM_BASE + CM_WKUPAON_DCAN1_CLKCTRL,
                  CM_WKUPAON_DCAN1_CLKCTRL_MODULEMODE,
                  CM_WKUPAON_DCAN1_CLKCTRL_MODULEMODE_ENABLE);

    while ((HW_RD_FIELD32(  0x20000000 + SOC_WKUPAON_CM_BASE + CM_WKUPAON_DCAN1_CLKCTRL,
                            CM_WKUPAON_DCAN1_CLKCTRL_IDLEST)) ==
                            CM_WKUPAON_DCAN1_CLKCTRL_IDLEST_DISABLE);

    /***************************************************************************//**
    * Dcan_PinMux
    ******************************************************************************/
    /* GPIO1 remains to the same Clock Domain that DCAN1 PRCM already configured */
    /* Configure MuxMode - DCAN1_TX -> GPIO1_14 */
    /* Configure Weak Pull U/D      -> Enable   */
    /* Configure Pull U/D type      -> Pull up  */
    reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE +  CTRL_CORE_PAD_DCAN1_TX) &
    (~(CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_PULLTYPESELECT_MASK | CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_PULLUDENABLE_MASK | CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_MUXMODE_MASK));

    reg |= CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_MUXMODE_DCAN1_TX_0       << CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_MUXMODE_SHIFT;
    reg |= CTRL_CORE_PAD_DCAN1_TX_PULLUDENABLE_ENABLE               << CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_PULLUDENABLE_SHIFT;
    reg |= CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_PULLTYPESELECT_PULL_UP   << CTRL_CORE_PAD_DCAN1_TX_DCAN1_TX_PULLTYPESELECT_SHIFT;

    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_DCAN1_TX, reg);

    /* GPIO1 remains to the same Clock Domain that DCAN1 PRCM already configured */
    /* Configure MuxMode - DCAN1_RX -> GPIO1_15 */
    /* Configure Weak Pull U/D      -> Disable   */
    reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE +  CTRL_CORE_PAD_DCAN1_RX) &
    (~(CTRL_CORE_PAD_DCAN1_RX_DCAN1_RX_PULLUDENABLE_MASK | CTRL_CORE_PAD_DCAN1_RX_DCAN1_RX_MUXMODE_MASK));

    reg |= CTRL_CORE_PAD_DCAN1_RX_DCAN1_RX_MUXMODE_DCAN1_RX_0   << CTRL_CORE_PAD_DCAN1_RX_DCAN1_RX_MUXMODE_SHIFT;
    reg |= CTRL_CORE_PAD_DCAN1_RX_DCAN1_RX_PULLUDENABLE_DISABLE << CTRL_CORE_PAD_DCAN1_RX_DCAN1_RX_PULLUDENABLE_SHIFT;

    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_DCAN1_RX, reg);

    /***************************************************************************//**
    * CAN ENABLE
    ******************************************************************************/
    /* Configure MuxMode - GPMC_A17 -> GPIO2_7 */
    /* Configure Weak Pull U/D      -> Enable   */
    /* Configure Pull U/D type      -> Pull down  */
    reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE +  CTRL_CORE_PAD_GPMC_A17) &
    (~(CTRL_CORE_PAD_GPMC_A17_GPMC_A17_PULLTYPESELECT_MASK | CTRL_CORE_PAD_GPMC_A17_GPMC_A17_PULLUDENABLE_MASK | CTRL_CORE_PAD_GPMC_A17_GPMC_A17_MUXMODE_MASK));

    reg |= CTRL_CORE_PAD_GPMC_A17_GPMC_A17_PULLTYPESELECT_PULL_DOWN << CTRL_CORE_PAD_GPMC_A17_GPMC_A17_PULLTYPESELECT_SHIFT;
    reg |= CTRL_CORE_PAD_GPMC_A17_GPMC_A17_PULLUDENABLE_ENABLE      << CTRL_CORE_PAD_GPMC_A17_GPMC_A17_PULLUDENABLE_SHIFT;
    reg |= CTRL_CORE_PAD_GPMC_A17_GPMC_A17_MUXMODE_GPIO2_7_14       << CTRL_CORE_PAD_GPMC_A17_GPMC_A17_MUXMODE_SHIFT;

    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_GPMC_A17, reg);

    /***************************************************************************//**
    * ES_PARK_DET
    ******************************************************************************/
    /* GPIO1 remains to the same Clock Domain that DCAN1 PRCM already configured */
    /* Configure MuxMode - UART2_RTSN -> GPIO1_17 */
    uint32_t es_reg;
    es_reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE +  CTRL_CORE_PAD_UART2_RTSN) &
            (~(CTRL_CORE_PAD_UART2_RTSN_UART2_RTSN_MUXMODE_MASK));

    es_reg |= CTRL_CORE_PAD_UART2_RTSN_UART2_RTSN_MUXMODE_GPIO1_17_14 << CTRL_CORE_PAD_UART2_RTSN_UART2_RTSN_MUXMODE_SHIFT;
    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_UART2_RTSN, es_reg);

    /***************************************************************************//**
    * ES_REVERSE_DET
    ******************************************************************************/
    /* GPIO1 remains to the same Clock Domain that DCAN1 PRCM already configured */
    /* Configure MuxMode - UART2_CTSN -> GPIO1_17 */
    es_reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE +  CTRL_CORE_PAD_UART2_CTSN) &
            (~(CTRL_CORE_PAD_UART2_CTSN_UART2_CTSN_MUXMODE_MASK | CTRL_CORE_PAD_UART2_CTSN_UART2_CTSN_PULLTYPESELECT_MASK));

    es_reg |= CTRL_CORE_PAD_UART2_CTSN_UART2_CTSN_MUXMODE_GPIO1_16_14 << CTRL_CORE_PAD_UART2_CTSN_UART2_CTSN_MUXMODE_SHIFT;
    es_reg |= CTRL_CORE_PAD_UART2_CTSN_UART2_CTSN_PULLTYPESELECT_PULL_UP << CTRL_CORE_PAD_UART2_CTSN_UART2_CTSN_PULLTYPESELECT_SHIFT;
    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_UART2_CTSN, es_reg);

    /***************************************************************************//**
    * ES_DIMMING
    ******************************************************************************/
    /* GPIO1 remains to the same Clock Domain that DCAN1 PRCM already configured */
    /* Configure MuxMode - MCASP2_AXR7 -> GPIO1_5 */
    es_reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE +  CTRL_CORE_PAD_MCASP2_AXR7) &
            (~(CTRL_CORE_PAD_MCASP2_AXR7_MCASP2_AXR7_MUXMODE_MASK | CTRL_CORE_PAD_MCASP2_AXR7_MCASP2_AXR7_PULLTYPESELECT_MASK));

    es_reg |= CTRL_CORE_PAD_MCASP2_AXR7_MCASP2_AXR7_MUXMODE_GPIO1_5_14 << CTRL_CORE_PAD_MCASP2_AXR6_MCASP2_AXR6_MUXMODE_SHIFT;
    es_reg |= CTRL_CORE_PAD_MCASP2_AXR7_MCASP2_AXR7_PULLTYPESELECT_PULL_UP << CTRL_CORE_PAD_MCASP2_AXR7_MCASP2_AXR7_PULLTYPESELECT_SHIFT;
    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_MCASP2_AXR7, es_reg);

    /***************************************************************************//**
    * ES_IGNITION_DET
    ******************************************************************************/
    /* GPIO1 remains to the same Clock Domain that DCAN1 PRCM already configured */
    /* Configure MuxMode - MCASP2_AXR4 -> GPIO1_4 */
    es_reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE +  CTRL_CORE_PAD_MCASP2_AXR4) &
            (~(CTRL_CORE_PAD_MCASP2_AXR4_MCASP2_AXR4_MUXMODE_MASK | CTRL_CORE_PAD_MCASP2_AXR4_MCASP2_AXR4_PULLTYPESELECT_MASK));

    es_reg |= CTRL_CORE_PAD_MCASP2_AXR4_MCASP2_AXR4_MUXMODE_GPIO1_4_14 << CTRL_CORE_PAD_MCASP2_AXR4_MCASP2_AXR4_MUXMODE_SHIFT;
    es_reg |= CTRL_CORE_PAD_MCASP2_AXR4_MCASP2_AXR4_PULLTYPESELECT_PULL_UP << CTRL_CORE_PAD_MCASP2_AXR4_MCASP2_AXR4_PULLTYPESELECT_SHIFT;
    HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_PAD_IO_REGISTERS_BASE + CTRL_CORE_PAD_MCASP2_AXR4, es_reg);

    Board_Init_TVP();
    Board_Init_LVDS();
}

/***************************************************************************//**
*
* @fn         Board_CheckDimmingClock
*
* @brief      Check if the clocks used by the dimming are enable
*
* @param [in] channel
*
* @return     None
*
******************************************************************************/
void Board_CheckDimmingClock (void)
{
    uint32_t reg;

//    if (!(CTRL_CORE_CONTROL_IO_2_PWMSS1_TBCLKEN_MASK & clkReg)) {
//        LOG_PRINT_ERR(DEBUG_BOARD, "Dimming clock PWSS1 was not enabled, enable it");
//        /* Time base clock for PWMSS1 module */
//        HW_WR_FIELD32(
//            L4_REGISTER_ADDRESS_OFFSET+ SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE + CTRL_CORE_CONTROL_IO_2,
//            CTRL_CORE_CONTROL_IO_2_PWMSS1_TBCLKEN,
//            1);
//    }

    /* Enable PRCM for the GPIO7 */
    reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE + CM_L4PER_GPIO7_CLKCTRL);
    if (!(CM_L4PER_GPIO7_CLKCTRL_IDLEST_MASK & reg))
    {
        LOG_PRINT_ERR(DEBUG_BOARD, "GPIO7 clkctrl was not enabled, enable it\n");
        reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE +  CM_L4PER_GPIO7_CLKCTRL) & (~(CM_L4PER_GPIO7_CLKCTRL_MODULEMODE_MASK));
        reg |= CM_L4PER_GPIO7_CLKCTRL_MODULEMODE_AUTO;
        HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE + CM_L4PER_GPIO7_CLKCTRL, reg);
    }

    /* Enable PRCM for PWMSS3 */
    reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE + CM_L4PER2_PWMSS3_CLKCTRL);
    if (!(CM_L4PER2_PWMSS3_CLKCTRL_IDLEST_MASK & reg))
    {
        LOG_PRINT_ERR(DEBUG_BOARD, "PWMSS3 clkctrl was not enabled, enable it\n");
        reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE +  CM_L4PER2_PWMSS3_CLKCTRL) & (~(CM_L4PER2_PWMSS3_CLKCTRL_MODULEMODE_MASK));
        reg |= CM_L4PER2_PWMSS3_CLKCTRL_MODULEMODE_ENABLE;
        HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_L4PER_CM_CORE_BASE + CM_L4PER2_PWMSS3_CLKCTRL, reg);
    }

    reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE + CTRL_CORE_CONTROL_IO_2);
    if (!(CTRL_CORE_CONTROL_IO_2_PWMSS3_TBCLKEN_MASK & reg))
    {
        LOG_PRINT_ERR(DEBUG_BOARD, "Dimming clock PWSS3 was not enabled, enable it\n");
        /* Time base clock for PWMSS3 module */
        HW_WR_FIELD32(
            L4_REGISTER_ADDRESS_OFFSET + SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE + CTRL_CORE_CONTROL_IO_2,
            CTRL_CORE_CONTROL_IO_2_PWMSS3_TBCLKEN,
            1);
    }
}

/***************************************************************************//**
*
* @fn         Board_Init_FAMP_Common
*
* @brief      Board FAMP Common dependant initialization function
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void Board_SetOperatingVoltages (void)
{
    uint8_t vsel_smps1;
    uint8_t vsel_smps3;
    uint32_t vdd_core;
    uint32_t vdd_dsp;

    /***************************************************************************//**
    * AVS Class 0 voltages
    ******************************************************************************/
    vdd_core = 0x000FFF & HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE + CTRL_CORE_STD_FUSE_OPP_VMIN_CORE_2);
    vdd_dsp = 0x000FFF & HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE + CTRL_CORE_STD_FUSE_OPP_VMIN_DSPEVE_2);

    LOG_PRINT(DEBUG_BOARD, "vdd_core: %d\r\n", vdd_core);
    LOG_PRINT(DEBUG_BOARD, "vdd_dsp: %d\r\n", vdd_dsp);

    if(vdd_core <= 1650)
    {
        /* Convert voltage to VSEL */
        vsel_smps1 = (uint8_t) ( ((vdd_core - PMIC_VOLT_MIN_mV) / PMIC_VSTEP_mV) + 6 );
    }

    if(vdd_dsp <= 1650)
    {
        /* Convert voltage to VSEL */
        vsel_smps3 = (uint8_t) ( ((vdd_dsp - PMIC_VOLT_MIN_mV) / PMIC_VSTEP_mV) + 6 );
    }
    
    PMIC_65919_SetOperatingVoltages (vsel_smps1, vsel_smps3);
}

static void Board_XbarConfig(void)
{
    UInt32 cookie;
    /* Disable interrupts when updating control module registers shared between
     * different modules. This will protect only simultaneous accesses within
     * core. If they have to be updated for simultanious accesses across
     * different cores, application is expected to call these APIs with access
     * protection.
     */
    cookie = BspOsal_disableInterrupt();
    /* XBAR VIP1_IRQ1 to IPU1_27 */
    BspOsal_irqXbarConnect(CSL_XBAR_INST_IPU1_IRQ_27, CSL_XBAR_VIP1_IRQ);
    /* XBAR VPE1_IRQ1 to IPU1_30 */
    BspOsal_irqXbarConnect(CSL_XBAR_INST_IPU1_IRQ_30, CSL_XBAR_VPE_IRQ);
    /* XBAR DISPC_IRQ at IPU1_23 */
    BspOsal_irqXbarConnect(CSL_XBAR_INST_IPU1_IRQ_23, CSL_XBAR_DISPC_IRQ);
    /* XBAR_EDMA_TPCC_IRQ_REGION1 at IPU1_34 */
    BspOsal_irqXbarConnect(CSL_XBAR_INST_IPU1_IRQ_34, CSL_XBAR_EDMA_TPCC_IRQ_REGION1);
    /* XBAR_EDMA_TPCC_IRQ_REGION1 at IPU1_34 */
    BspOsal_irqXbarConnect(CSL_XBAR_INST_IPU1_IRQ_35, CSL_XBAR_EDMA_TPCC_IRQ_ERR);

    /* XBAR_UART1_IRQ at IPU1 */
    //BspOsal_irqXbarConnect(CSL_XBAR_INST_IPU1_IRQ_67, CSL_XBAR_UART1_IRQ);


    BspOsal_restoreInterrupt(cookie);

    return;
}

/***************************************************************************//**
*
* @fn         Board_Init
*
* @brief      Board dependant initialization function
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void Board_Init (void)
{
    Board_XbarConfig();
    Board_Init_FAMP_Common();
}
