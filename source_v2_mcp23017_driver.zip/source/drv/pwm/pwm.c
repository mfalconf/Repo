/*===========================================================================*/
/**
 * @file pwm.c
 *
 * PWM driver
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <drv/pwm/pwm.h>


/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void PWM_TimebaseModuleCfg (uint32_t baseAddr, uint32_t pwmFuncClk, CSL_EpwmTimebaseCfg_t *pTbCfg);
static void PWM_CounterComparatorCfg (uint32_t baseAddr, CSL_EpwmCounterCmpCfg_t *pCcCfg);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/***************************************************************************//**
*
* @fn         PWM_ChannelConfig
*
* @brief      This API configures the ePWM module
*
* @param [in] pObj - pointer to the ePwm object data structure.
*
* @return     None
*
******************************************************************************/
void PWM_ChannelConfig (PWM_Obj_t *pObj)
{
    uint32_t baseAddr = pObj->instAddr;
    uint32_t pwmCh    = pObj->pwmCh;
    uint32_t pwmFuncClk = pObj->funcClk;
    PWM_Cfg_t *pPwmCfg = &pObj->pwmCfg;

    /* Configure the Time base Sub-Module */
    PWM_TimebaseModuleCfg(baseAddr, pwmFuncClk, &pPwmCfg->tbCfg);

    /* Counter-Comparator Sub-Module Configuration */
    PWM_CounterComparatorCfg(baseAddr, &pPwmCfg->ccCfg);

    /* Configure Action Qualifier */
    CSL_epwmAqActionOnOutputCfg(baseAddr, pwmCh, &pPwmCfg->aqCfg);

    /* Dead band sub-module configuration */
    if (TRUE == pObj->enableDeadband)
    {
       /* Enable and configure dead band sub module */
       CSL_epwmDeadbandCfg(baseAddr, &pPwmCfg->dbCfg);
    }
    else
    {
        /* Bypass dead band sub module */
        CSL_epwmDeadbandBypass(baseAddr);
    }

    /* Chopper sub-module configuration */
    if (TRUE == pObj->enableChopper)
    {
        /* Configure chopper sub - module */
        CSL_epwmChopperCfg(baseAddr, &pPwmCfg->chpCfg);

        /* Enable Chopper */
        CSL_epwmChopperEnable(baseAddr, TRUE);
    }
    else
    {
        /* Disable Chopper */
        CSL_epwmChopperEnable(baseAddr, FALSE);
    }

    /* Trip Zone Sub-Module Configuration */
    if (TRUE == pObj->enableTripZone)
    {
        /* Configure the Trip action */
        CSL_epwmTzTriggerTripAction(
            baseAddr, CSL_EPWM_TZ_TRIP_ACTION_HIGH, pwmCh);

        /* Enable the Trip event */
        CSL_epwmTzTripEventEnable(
            baseAddr, pPwmCfg->tzCfg.tripEvtType, pPwmCfg->tzCfg.tripPin);
    }
    else
    {
        /* Disable trip zone event handling and ignore all trip zone events */
        CSL_epwmTzTripEventDisable(
            baseAddr, CSL_EPWM_TZ_EVENT_ONE_SHOT, pPwmCfg->tzCfg.tripPin);
        CSL_epwmTzTripEventDisable(
            baseAddr, CSL_EPWM_TZ_EVENT_CYCLE_BY_CYCLE, pPwmCfg->tzCfg.tripPin);
    }

    /* Event trigger sub - module configuration */
    if (TRUE == pObj->enableEventTrigger)
    {
        /* Configure the Event trigger processing */
        CSL_epwmEtIntrCfg(
            baseAddr, pPwmCfg->etCfg.intrEvtSource, pPwmCfg->etCfg.intrPrd);
        CSL_epwmEtIntrEnable(baseAddr);
    }
    else
    {
        /* Disable Event trigger interrupts */
        CSL_epwmEtIntrDisable(baseAddr);
    }

    /**
     * High resolution feature is supported only on PWM A channel. If channel
     * is A then proceed with High Resolution processing.
     */
    if (CSL_EPWM_OUTPUT_CH_A == pwmCh)
    {
        if (TRUE == pObj->enableHighResolution)
        {
            /* configure high resolution feature */
            CSL_epwmHighResolutionCfg(
                baseAddr,
                pPwmCfg->hrCfg.delayBusSelect,
                pPwmCfg->hrCfg.delayMode);

            if (CSL_EPWM_HR_DELAY_BUS_SEL_CMPAHR ==
               pPwmCfg->hrCfg.delayBusSelect)
            {
                /* Load comparator A High-resolution counter value */
                CSL_epwmHrLoadCmpAHrValue(
                    baseAddr,
                    pPwmCfg->hrCfg.cmpAHighResVal,
                    CSL_EPWM_HR_REG_ACT_LOAD_CNT_ZRO_PULSE);
            }
            else  /* CSL_EPWM_HR_DELAY_BUS_SEL_TBPHSHR */
            {
                /* Load Timebase phase high resolution value */
                CSL_epwmHrLoadTbPhaseHrValue(
                    baseAddr, pPwmCfg->hrCfg.tbPhaseHighResVal);
            }
        }
        else
        {
            /* Disable High Resolution Feature */
            CSL_epwmHighResolutionDisable(baseAddr);
        }
    }

    return;
}

/***************************************************************************//**
*
* @fn         PWM_ChannelStart
*
* @brief      This API enable clocks
*
* @param [in] pObj - pointer to the ePwm object data structure.
*
* @return     None
*
******************************************************************************/
void PWM_ChannelStart (PWM_Obj_t *pObj)
{
    CSL_epwmClockEnable(pObj->instAddr);        /* Enable clocks */
}

/***************************************************************************//**
*
* @fn         PWM_ChannelStop
*
* @brief      This API disable clocks
*
* @param [in] pObj - pointer to the ePwm object data structure.
*
* @return     None
*
******************************************************************************/
void PWM_ChannelStop (PWM_Obj_t *pObj)
{
    CSL_epwmClockDisable(pObj->instAddr);        /* Disable clocks */
}

/***************************************************************************//**
*
* @fn         PWM_TimebaseModuleCfg
*
* @brief      This API configures the Timebase Sub-module.
*
* @param [in] baseAddr     Base address of PWMSS instance used
* @param [in] pwmFuncClk   PWM functional clock value in Hz
* @param [in] pTbCfg       Pointer to the Time base sub-module configuration
*                          data structure
* @return     None
*
******************************************************************************/
static void PWM_TimebaseModuleCfg (uint32_t baseAddr, uint32_t pwmFuncClk, CSL_EpwmTimebaseCfg_t *pTbCfg)
{
    /* Configure Time base clock */
    CSL_epwmTbTimebaseClkCfg(baseAddr, pTbCfg->tbClk, pwmFuncClk);

    /* Configure PWM time base counter frequency and direction */
    CSL_epwmTbPwmFreqCfg(
        baseAddr,
        pTbCfg->tbClk,
        pTbCfg->pwmtbCounterFreqPrd,
        pTbCfg->tbCntrDirection,
        CSL_EPWM_SHADOW_REG_CTRL_ENABLE);

    if (TRUE == pTbCfg->enableSynchronization)
    {
        /* Enable Synchronization */
        CSL_epwmTbSyncEnable(
            baseAddr, pTbCfg->phsCountAfterSync, pTbCfg->cntDirAfterSync);
    }
    else
    {
        /* Disable Synchronization */
        CSL_epwmTbSyncDisable(baseAddr);
    }

    /* Configure Sync out signal */
    CSL_epwmTbSetSyncOutMode(baseAddr, pTbCfg->syncOutSrc);

    /* Configure the emulation behaviour */
    CSL_epwmTbSetEmulationMode(baseAddr, EPWM_TB_EMU_MODE_FREE_RUN);

    return;
}

/***************************************************************************//**
*
* @fn         PWM_CounterComparatorCfg
*
* @brief      This API configures the Counter-Comparator Sub-module.
*
* @param [in] baseAddr     Base address of PWMSS instance used
* @param [in] pCcCfg       Pointer to the Counter-Comparator Sub-module
 *                         configuration data structure
* @return     None
*
******************************************************************************/
static void PWM_CounterComparatorCfg (uint32_t baseAddr, CSL_EpwmCounterCmpCfg_t *pCcCfg)
{
    /* Counter Comparator A configuration */
    CSL_epwmCounterComparatorCfg(
        baseAddr,
        CSL_EPWM_CC_CMP_A,
        pCcCfg->cmpAValue,
        CSL_EPWM_SHADOW_REG_CTRL_ENABLE,
        CSL_EPWM_CC_CMP_LOAD_MODE_CNT_EQ_ZERO,
        TRUE);

    /* Counter Comparator B configuration */
    CSL_epwmCounterComparatorCfg(
        baseAddr,
        CSL_EPWM_CC_CMP_B,
        pCcCfg->cmpBValue,
        CSL_EPWM_SHADOW_REG_CTRL_ENABLE,
        CSL_EPWM_CC_CMP_LOAD_MODE_CNT_EQ_ZERO,
        TRUE);

    return;
}
