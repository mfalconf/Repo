#ifndef PWM_H_
#define PWM_H_
/*===========================================================================*/
/**
 * @file PWM.h
 *
 * Function definitions for the PWM interface module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <stdint.h>
#include <ti/csl/csl_types.h>
#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>
#include <ti/csl/arch/csl_arch.h>
#include <ti/csl/csl_epwm.h>

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
/** \brief Structure holding the EPWM configuration parameters. */
typedef struct PWM_Cfg_Tag
{
    CSL_EpwmTimebaseCfg_t       tbCfg;
    /**< Timebase Sub-module configuration data structure. */
    CSL_EpwmCounterCmpCfg_t     ccCfg;
    /**< Counter comparator values . */
    CSL_EpwmAqActionCfg_t       aqCfg;
    /**< Action Qualifier Sub-module configuration data structure. */
    CSL_EpwmDeadbandCfg_t       dbCfg;
    /**< Dead band Sub-module configuration data structure. */
    CSL_EpwmChopperCfg_t        chpCfg;
    /**< Chopper sub-module configuration data structure. */
    CSL_EpwmTripzoneCfg_t       tzCfg;
    /**< Trip-zone sub-module configuration data structure. */
    CSL_EpwmEtCfg_t             etCfg;
    /**< Event Trigger sub-module configuration data structure. */
    CSL_EpwmHighResolutionCfg_t hrCfg;
    /**< High Resolution sub-module configuration data structure. */
} PWM_Cfg_t;

/**< \brief Structure holding the EPWM object data structure. */
typedef struct PWM_Obj
{
    uint32_t                pwmCh;
    /**< EPWM channel [A or B]. */
    uint32_t                instAddr;
    /**< EPWM instance address. */
    uint32_t                funcClk;
    /**< Functional clock(in Hz) input to the PWMSS. */
    uint32_t                enableDeadband;
    /**< Enable dead band sub-module processing. */
    uint32_t                enableChopper;
    /**< Enable chopper sub-module processing. */
    uint32_t                enableTripZone;
    /**< Enable Trip zone processing. */
    uint32_t                enableEventTrigger;
    /**< Enable Event trigger. */
    uint32_t                enableHighResolution;
    /**< Enable High resolution pwm feature. */
    PWM_Cfg_t               pwmCfg;
    /**< EPWM configuration data structure. */
} PWM_Obj_t;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
void PWM_ChannelConfig (PWM_Obj_t *pObj);
void PWM_ChannelStart (PWM_Obj_t *pObj);
void PWM_ChannelStop (PWM_Obj_t *pObj);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file PWM.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 26-Jun-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* PWM_H_ */
