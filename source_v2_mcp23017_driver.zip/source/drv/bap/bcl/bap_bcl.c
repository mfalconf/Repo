/******************************************************************
 *
 *     Copyright (c) 2004 Volkswagen AG, D-38436 Wolfsburg
 *
 ******************************************************************
 *
 * Projekt:    BAP (P0674)
 * Komponente: BCL
 *
 * $Archive: /dev/BAP/bcl/bap_bcl.c $
 * $Revision: 792 $
 * $Modtime: 3.05.05 14:44 $
 * $Author: AchimL $
 *
 * Ersteller:
 * Klaus Neubert, Kopf GmbH, D-Landau/Pfalz
 *
 ******************************************************************
 *
 * Beschreibung
 *
 *  Diese Datei enthaelt die Implementierung der BCL Schicht im BAP
 *  Projekt.
 *
 *  Diese C-Datei enthaelt nicht die Funktionen BAP_BCL_Received
 *  und BAP_BCL_ErrorIndication, da diese von der BPL Schicht
 *  implementiert werden.
 *
 ******************************************************************
 *
 * Versionsgeschichte (ohne SCM)
 *
 * Datum        Version     Autor       Beschreibung
 * ----------------------------------------------------------------
 * 2014-03-24	1.7.1		WWU			MISRA-2004 fix: Funktion-Like Makros fuer BAP_BCL_Start wurde entfernt.
 * 2014-03-21	1.7.1		WWU			CCB-664 und CCB-1731: Alignment problem.
 * 2013-01-30	1.7.0		WWU			MISRA-2004 fix
 * 2012-10-15	1.6.5.1		WWU			Korrektur der Misra-98 Abweichungen
 * 2011-05-02   1.6         HWA         Bugfix Endlosschleife durch Compiler (LB BAP1.6 A-10) 
 * 2006-06-07   1.4         ALA         Falls ein Status verzoegert gesendet wird bleibt der Opcode erhalten, falls
 *                                      das Senden eines Heartbeats angetriggert wird.
 * 2006-04-12   1.4         ALA         Unterstuetzung fuer neue HB-Trigger.
 * 2006-04-12   1.4         ALA         Unterstuetzung fuer BAP_ROM_DATA_FAR.
 * 2005-04-29   1.3         ALA         Entfernung von Dummy-Code. Doppelte Abfrage (nun in bclcan) des Lsg-Zustands entfernt.
 * 2005-04-15   1.3         ALA         Reduzierung der CPU-Last bei Busruhe
 * 2005-04-13   1.3         CRI         ASG&FSG zusammen
 * 2005-04-08   1.3         ALA         Anpassung an neue Datenstrukturen, Optimierung Parameteruebergabe
 * 2005-03-14   1.2.1       CRI         BCL_Start hinzugefuegt
 * 2005-03-14   1.2.1       CRI         Errors & Nachrichten wenn nicht mehr an BPL
 *                                      uebergeben, wenn Zustand nicht running ist
 * 2004-11-17   1.2         ALA         Behandlung fuer Antwort auf GetAll als Einzelnachrichten oder
 *                                      Block hinzugefuegt.
 * 2004-11-04   1.2         ALA         BAP_BCL_SendError Funktion hinzugefuegt.
 * 2004-09-17   1.1.1       ALA         Out-Of-Bounds-Check in BAP_BCL_GeneralSend hinzugefuegt
 * 2004-06-07   1.1         JOK         Compilerschalter fuer SG-Typen zur Optimierung
 *                                      des ROM-Bedarfs eingefuegt
 * 2004-06-07   1.1         JOK         Die verschiedenen Send-Funktionen (BufferSet, Send, Abort,
 *                                      Resend, ResendWithOpcode) zu einer allgemeinen Funktion
 *                                      BAP_BCL_GeneralSend() zusammengefasst.
 * 2004-06-07   1.1         JOK         BAP_BCL_Start() und BAP_BCL_Shutdown() entfernt (siehe bap_bcl.h)
 ******************************************************************/


/* Systemincludes mit <...> */
#include <string.h>

/* Bibliotheken von externen Herstellen mit <...> */

/* Eigene Header-Dateien "..." */
#include "bap_types.h"
#include "bap_config.h"
#include "bap_privatetypes.h"
#include "bap_bcl.h"
#include "bap_bclutil.h"
#include "bap_bclbus.h"
#include "bap_util.h"
#include "bap_debug.h"
#include "bap_balconfig.h"

#include <console.h>

#ifdef BAP_RUNTIME_TEST
#include "sw_timer.h"
#endif /* BAP_RUNTIME_TEST */

/* Externe globale Variablen-Definitionen */

/* Diese Variable ist in bap_bcl.h dokumentiert */
#ifdef BAP_TASKTIME_LIMIT
uint16_t BAP_u16TaskTimeCounter;
#endif /* #ifdef BAP_TASKTIME_LIMIT */

/* Interne Makro-Definitionen */

/* Interne Typ-Definitionen */
typedef enum BapSendType_t
{
    /** Kennung fuer einen Sendeauftrag durch BAP_BCL_Send() */
    BapSendType_Send,
#if defined (BAP_ASG) || defined(WIRD_NIE_GEBRAUCHT)
    /** Kennung fuer einen Sendeauftrag durch BAP_BCL_AbortSend() */
    BapSendType_Abort,
#endif /* #if defined (BAP_ASG) || defined(WIRD_NIE_GEBRAUCHT) */
#ifdef BAP_ASG
    /** Kennung fuer einen Sendeauftrag durch BAP_BCL_Resend() */
    BapSendType_Resend,
#endif /* #ifdef BAP_ASG */
#ifdef BAP_FSG
    /** Kennung fuer einen Sendeauftrag durch BAP_BCL_BufferSet() */
    BapSendType_BufferSet,
    /** Kennung fuer einen Sendeauftrag durch BAP_BCL_SendError() */
    BapSendType_SendError,
    /** Kennung fuer einen Sendeauftrag durch BAP_BCL_ResendWithOpcode() */
    BapSendType_ResendWithOpcode,
#endif /* #ifdef BAP_FSG */
    /*lint -esym(749, BapSendType_t::BapSendType_Unused) */
    /** Diese Kennung wird nicht verwendet. Dient als Abschluss fuer das Komma abhaengig vom Steuergeratetyp */
    BapSendType_Unused
} BapSendType_et;

/* Interne Const Deklarationen */

/* Interne statische Variablen */


/* Vorwaerts-Deklarationen von statischen Funktionen */

static BAP_IMPL_FAR void
BAP_BCL_GeneralSend(BapInternalParameters_cpot apoPars
    , DBGVAR BapSendType_et aeSendType);

#ifdef BAP_USES_SEGMENTATION
static BAP_IMPL_FAR void
BAP_BCL_SingleRxNotify(BapInternalParameters_pot apoPars);
#endif /* #ifdef BAP_USES_SEGMENTATION */

#ifdef BAP_FSG
static BAP_IMPL_FAR void
BAP_BCL_SendStatusAll(BapInternalParameters_cpot apoPars);
#endif /* #ifdef BAP_FSG */

/* Definition (Implementierung) von statischen Funktionen */

/**
 *  Allgemeine Funktion zum Senden von Nachrichten. Je nach Parameterwert von aeSendType
 *  werden die entsprechenden spezialisierten Funktionen ausgefuehrt.
 *
 *  @param apoPars  Struktur mit den benoetigten Parametern:<br>
 *                  -\>poLsgRomRow - Zeigt auf das den Sendeauftrag betreffende LSG oder NULL, falls kein LSG zugeordnet werden kann<br>
 *                  -\>poFctRomRow - Zeigt auf die den Sendeauftrag betreffende FCT oder NULL, falls die gesuchte FCT nicht existiert<br>
 *                  -\>pData       - Zeigt auf die  zu sendenden Daten<br>
 *                  -\>u16Length   - Enthaelt die Laenge der zu sendenden Daten<br>
 *                  -\>eOpCode     - Enthaelt den zu sendenden OpCode
 *
 *  @param aeSendType  Typ der speziellen Sendeanforderung
 */
static BAP_IMPL_FAR void
BAP_BCL_GeneralSend(BapInternalParameters_cpot apoPars
    , DBGVAR BapSendType_et aeSendType)
{
    /*lint -esym(613,apoPars) */
    DBGVAR uint8_t u8TxTableIdx;
    BapFctRomRow_pot poFctRomRow = apoPars->poFctRomRow;
    DBGVAR bool_t bFlag = BAP_TRUE;
    DBGVAR uint16_t u16Length = apoPars->u16Length;

#ifdef BAP_TASKTIME_LIMIT
    apoPars->poLsgRomRow->poLsgRamRow->fState.fTxFlag = BAP_TRUE;
#endif /* #ifdef BAP_TASKTIME_LIMIT */

    for (u8TxTableIdx=(uint8_t)0; (NULL != poFctRomRow) && (u8TxTableIdx < poFctRomRow->u8TxTableSize); u8TxTableIdx++)
    {
        BapBusIndirectionTxRomRow_pot  const poBusTxRomRow
            = &(BAP_BusIndTxTable[poFctRomRow->u16BusTxTableIndex + (uint16_t)u8TxTableIdx]);
        BapBclTxRamRow_pot  const poBclTxRamRow
            = poBusTxRomRow->poBclTxRamRow;

        if(BapIft_None != poBusTxRomRow->eInterfaceType)
        {
            switch(aeSendType)
            {
/* Im folgenden keine Fallunterscheidungen fuer das Kombigeraet noetig */
/* da Types nur in bestimmten SGs auftreten koennen, @see BapSendType_t */
#if defined(BAP_ASG) || defined(WIRD_NIE_GEBRAUCHT)
                case BapSendType_Abort:
#ifdef BAP_USES_SEGMENTATION
                    poBusTxRomRow->poBclTxRamRow->flags.fTxInProgressFlag = (uint8_t)0;
#endif /* #ifdef BAP_USES_SEGMENTATION */
                    poBusTxRomRow->poBclTxRamRow->flags.fTxRequestFlag = BAP_FALSE;

#ifdef BAP_USES_ACKNOWLEDGE
                    poBclTxRamRow->flags.fTxRequestNeedsAckFlag = BAP_FALSE;
#endif /* #ifdef BAP_USES_ACKNOWLEDGE */

                    break;
#endif /* #if defined(BAP_ASG) || defined(WIRD_NIE_GEBRAUCHT) */
#ifdef BAP_FSG
                case BapSendType_BufferSet:
#endif /* #ifdef BAP_FSG */
                case BapSendType_Send:
                    /* Opcode in Buffer schreiben */
                    poBclTxRamRow->eOpCode = apoPars->eOpCode;

                    /* Wert ist unzulaessig ? */
                    if (u16Length > poBusTxRomRow->u16BufferSize)
                    {
                        /* Was zuviel ist abschneiden */
                        u16Length = poBusTxRomRow->u16BufferSize;
                    }

                    /* Setze Datengroesse des Sendepuffers und kopiere die Daten */
                    poBclTxRamRow->oBufferWithLength.u16Length = u16Length;
                    MEMCPY(poBclTxRamRow->oBufferWithLength.paru8Buffer, apoPars->pData, u16Length);

#ifdef BAP_FSG
#if defined(BAP_ASG) && defined(BAP_FSG)
                    if (BapSG_FSG == apoPars->poLsgRomRow->eSGType)
#endif /* defined(BAP_ASG) && defined(BAP_FSG) */
                    {
                        poBclTxRamRow->flags.fTxInitializedFlag = BAP_TRUE;
                        /* Setze Tx Flags bei Send und loesche Sie bei BufferSet */
                        bFlag = (const bool_t) ((BapSendType_BufferSet != aeSendType) ? BAP_TRUE : BAP_FALSE);
                    }
#endif /* #ifdef BAP_FSG */
#ifdef BAP_USES_SEGMENTATION
                    poBusTxRomRow->poBclTxRamRow->flags.fTxInProgressFlag = (uint8_t)0;
#endif /* #ifdef BAP_USES_SEGMENTATION */
                    poBusTxRomRow->poBclTxRamRow->flags.fTxRequestFlag = bFlag;

#ifdef BAP_USES_ACKNOWLEDGE
                    poBclTxRamRow->flags.fTxRequestNeedsAckFlag = bFlag;
#endif /* #ifdef BAP_USES_ACKNOWLEDGE */
                    break;
#ifdef BAP_FSG
                case BapSendType_SendError:
                    /* Fehlerwert in Spezialpuffer speichern */
                    poBclTxRamRow->eErrorCode = (BapError_et) *apoPars->pData;
                    /* TX Flag setzen, damit Fehler ausgesendet wird */
                    poBclTxRamRow->flags.fTxErrorFlag = BAP_TRUE;

#if defined(BAP_FSG) && defined(BAP_USES_ACKNOWLEDGE)
                    poBclTxRamRow->flags.fTxErrorNeedsAckFlag = BAP_TRUE;
#endif /* #if defined(BAP_FSG) && defined(BAP_USES_ACKNOWLEDGE) */

                    /* Durch das Loeschen des Progress-Flags wird zuerst der Fehler gesendet (Prioritaet).
                       Falls zuvor eine Wertuebertragung lief, wird diese nach dem Aussenden des Fehlers neu begonnen.
                       Somit geht der Werte-Request nicht verloren, aber der Fehler wird zuerst gemeldet.
                       Ein Aussenden des Fehlers bei eingeschalteter Segmentierung zwischendurch haette sonst die Wirkung,
                       dass die Start-Botschaft (des Fehlers) dazwischen im ASG zu Sequenzfehlern fuehren wuerde,
                       da keine weiteren Segmente mehr erwartet wuerden.
                    */
#if defined(BAP_FSG) && defined(BAP_USES_SEGMENTATION)
                    if (poBclTxRamRow->flags.fTxInProgressFlag)
                    {
                        poBclTxRamRow->flags.fTxRequestFlag = BAP_TRUE;
                        poBclTxRamRow->flags.fTxInProgressFlag = BAP_FALSE;
                    }
#endif /* #if defined(BAP_FSG) && defined(BAP_USES_SEGMENTATION) */

                    break;
                case BapSendType_ResendWithOpcode:
#if defined(BAP_FSG) && defined(BAP_USES_ACKNOWLEDGE)
                    /* Fuehre kein ResendWithOpcode durch, falls gewoehnliches Senden noch nicht erfolgt */
                    if( BAP_FALSE == (bool_t)(poBclTxRamRow->flags.fTxRequestNeedsAckFlag) )
#endif /* #if defined(BAP_FSG) && defined(BAP_USES_ACKNOWLEDGE) */
                    {
#if defined(BAP_FSG) && defined(BAP_USES_ACKNOWLEDGE)
                        poBclTxRamRow->flags.fTxRequestNeedsAckFlag = BAP_FALSE;
#endif /* #if defined(BAP_FSG) && defined(BAP_USES_ACKNOWLEDGE) */

                        /*  Aendere den OpCode ab */
                        poBclTxRamRow->eOpCode = apoPars->eOpCode;

#ifdef BAP_USES_SEGMENTATION
                        poBusTxRomRow->poBclTxRamRow->flags.fTxInProgressFlag = (uint8_t)0;
#endif /* #ifdef BAP_USES_SEGMENTATION */
                        poBusTxRomRow->poBclTxRamRow->flags.fTxRequestFlag = BAP_TRUE;

                    }
                    break;
#endif /* #ifdef BAP_FSG */
#ifdef BAP_ASG
                case BapSendType_Resend:
#ifdef BAP_USES_SEGMENTATION
                	poBusTxRomRow->poBclTxRamRow->flags.fTxInProgressFlag = (uint8_t)0;
#endif /* #ifdef BAP_USES_SEGMENTATION */
                	poBusTxRomRow->poBclTxRamRow->flags.fTxRequestFlag = BAP_TRUE;
                    /* Falls noch ein Acknowledge aussteht, nichts dran aendern */
                    break;
#endif /* #ifdef BAP_ASG */
                default:
                    break;
            }
        }
    }   /* for (u8TxTableIdx... */
    return;
    /*lint +esym(613,apoPars) */
}


#ifdef BAP_USES_SEGMENTATION
/**
 *  Diese Funktion prueft, ob ein Datenelement oder ein Fehlerwert empfangen wurde
 *  und ruft ggfs. die entsprechende Callback-Funktion auf.
 *
 *  @see BAP_BCL_ErrorIndication, BAP_BCL_DataReceived
 *
 *  @param apoPars  benoetigt die Parameter lsgId und fctId sowie die Zeiger auf die entsprechenden ROM-Zeilen.
 *
 *  @remarks: Diese Funktion veraendert apoPars->eOpCode, apoPars->pData und apoPars->u16Length
 */
static BAP_IMPL_FAR void
BAP_BCL_SingleRxNotify(BapInternalParameters_pot apoPars)
{
    /*lint -esym(613,apoPars) */
    DBGVAR uint8_t u8BusRomRowIdx;
    DBGVAR uint8_t u8BusTableSize = apoPars->poFctRomRow->u8RxTableSize;
    DBGVAR uint16_t u16BusRxTableIdx = apoPars->poFctRomRow->u16BusRxTableIndex;

#ifdef BAP_RUNTIME_TEST
    BAP_RUNTIME_TEST_INDBS_START();
    BAP_RUNTIME_TEST_INDALL_START();
#endif /* BAP_RUNTIME_TEST */

    /* Durchsuche alle Empfangsmoeglichkeiten fuer die jeweilige FunctionId */
    for(u8BusRomRowIdx = (uint8_t)0; u8BusRomRowIdx < u8BusTableSize; u8BusRomRowIdx++)
    {
        BapBclRxRamRow_pot  const poBclRxRamRow = BAP_BusIndRxTable[u16BusRxTableIdx + (uint16_t)u8BusRomRowIdx].poBclRxRamRow;

        /* wenn kein Rx-Puffer vorhanden, dann wurde der Empfang direkt gemeldet, z.B. in BAP_CAN_RxUnsegmented */
        if (NULL != poBclRxRamRow)
        {
            /* Wurde ein Fehler empfangen? */
            if(poBclRxRamRow->flags.fRxErrorFlag)
            {
#ifdef BAP_TASKTIME_LIMIT
                BAP_u16TaskTimeCounter += BAP_IND_RX_TIME + (uint16_t)sizeof(BapError_et);
                apoPars->poLsgRomRow->poLsgRamRow->fState.fRxFlag = BAP_TRUE;
#endif /* #ifdef BAP_TASKTIME_LIMIT */

                /* BPL benachrichten */
                BAP_BCL_ErrorIndication(apoPars->lsgId
                    , apoPars->fctId
                    , poBclRxRamRow->eErrorCode);

                /* Loesche RxError Flag */
                poBclRxRamRow->flags.fRxErrorFlag = BAP_FALSE;
            }

            /* Wurde das Datenelement vollstaendig empfangen? */
            if(poBclRxRamRow->flags.fRxCompleteFlag)
            {
                apoPars->eOpCode   = poBclRxRamRow->eOpCode;
               apoPars->pData     =   *(poBclRxRamRow->oBufferWithLength.paru8Buffer);
                apoPars->u16Length = poBclRxRamRow->oBufferWithLength.u16Length;

#ifdef BAP_TASKTIME_LIMIT
                BAP_u16TaskTimeCounter = (uint16_t)(BAP_u16TaskTimeCounter + BAP_IND_RX_TIME + apoPars->u16Length);
                apoPars->poLsgRomRow->poLsgRamRow->fState.fRxFlag = BAP_TRUE;
#endif /* #ifdef BAP_TASKTIME_LIMIT */

                /* BPL benachrichtigen */
                BAP_BCL_DataReceived(apoPars);

                /* Loesche RxComplete Flag */
                poBclRxRamRow->flags.fRxCompleteFlag = BAP_FALSE;
            }
        }
    }

#ifdef BAP_RUNTIME_TEST
    BAP_RUNTIME_TEST_INDBS_STOP();
    BAP_RUNTIME_TEST_INDALL_STOP();
#endif /*BAP_RUNTIME_TEST */

    return;
    /*lint +esym(613,apoPars) */
}
#endif /* #ifdef BAP_USES_SEGMENTATION */

#ifdef BAP_FSG
/**
 *  Diese Funktion behandelt eine GetAll Anfrage und sendet entwender einzelne Heartbeat-Statusnachrichten
 *  oder einen StatusAll-Block als Antwort auf die GetAll Anfrage.
 *
 *  @param apoPars Struktur mit den benoetigten Parametern:<br>
 *                 -\>poLsgRomRow - Zeigt auf das den Sendeauftrag betreffende LSG oder NULL, falls kein LSG zugeordnet werden kann <br>
 *                 -\>poFctRomRow - Zeigt auf die den Sendeauftrag betreffende FCT oder NULL, falls die gesuchte FCT nicht existiert
 *
 *  @remarks
 *  Bei Small FSG wird immer mit einzelnen Heartbeat Status Nachrichten geantwortet.
 *  Bei Large FSG wird nur dann mit einzelnen Heartbeat Status Nachrichten geantwortet, wenn kein Sendepuffer vorgesehen ist.
 */
static BAP_IMPL_FAR void
BAP_BCL_SendStatusAll(BapInternalParameters_cpot apoPars)
{
    DBGVAR uint8_t u8FctIdMask = (uint8_t)0x20;  /* FctId 0 (reserviert) und 1 (Cache) brauchen nicht ausgewertet zu werden */

    uint8_t u8Counter;
    DBGVAR uint8_t u8FctListSeg;
#ifdef BAP_USES_STATUS_ALL
    BapBufferWithLength_pot poGetAllBufferWithLength = NULL;
#endif /* BAP_USES_STATUS_ALL */

    /*lint -esym(613, apoPars) */
    BAP_ASSERT(apoPars != NULL );

    BAP_InitInternalParameters(&oPars);
    oPars.eOpCode = BapOp_PropHeartbeatStatus;

#ifdef BAP_USES_STATUS_ALL
    if ((uint16_t)65535 != apoPars->poFctRomRow->u16BusTxTableIndex)
    {
        poGetAllBufferWithLength = &((BAP_BusIndTxTable[apoPars->poFctRomRow->u16BusTxTableIndex].poBclTxRamRow)->oBufferWithLength);

        /* Versenden des StatusAll-Blocks beim naechsten BAP_Task Aufruf, OpCode and Flags werden hiermit initialisiert. */
        BAP_BCL_GeneralSend(apoPars, BapSendType_Send);
    }
    else
    {
        /* Nutze Einzelbeantwortung */
    }
#endif /* BAP_USES_STATUS_ALL */

    oPars.lsgId = apoPars->lsgId;
    oPars.poLsgRomRow = apoPars->poLsgRomRow;
    u8FctListSeg = apoPars->poLsgRomRow->poLsgRamRow->BAP_aru8FunctionList[0];

    /* Suche alle Properties, in denen ein Bit in der FunctionList gesetzt ist */
    for (u8Counter = (uint8_t)BAP_FCTID_BAPCONFIG; u8Counter < (uint8_t)64; u8Counter++) /*lint !e650 enums haben mindestens 8 bit */
    {
    	oPars.fctId = (fctId_t)u8Counter;
    	/* Wechsel zum naechstes Byte (falls FctId % 8 == 0)? */
        if ( (uint8_t)0 == (BINARY_ID(oPars.fctId) & (uint8_t)0x07))
        {
            u8FctIdMask = (uint8_t)0x80;

            /* Hole dieses Element aus dem Array mit Index (FctId / 8) */
            u8FctListSeg = oPars.poLsgRomRow->poLsgRamRow->BAP_aru8FunctionList[BINARY_ID(oPars.fctId)>>3];
        }

        /* Ist Bit gesetzt? */
        if(u8FctListSeg & u8FctIdMask)
        {
            oPars.poFctRomRow = BAP_GetLsgFctRomRow(oPars.poLsgRomRow, oPars.fctId);

            if ( BapFctCls_Property != oPars.poFctRomRow->eFunctionClass )
            {
                /* Nur Properties werden bei StatusAll versendet */
            }
            else
#ifdef BAP_USES_STATUS_ALL
            if (NULL != poGetAllBufferWithLength)
            {
                /* ja, dann fuege diese Nachricht zum Sendepuffer hinzu, falls einer konfiguiert ist */

                /* Hole Nachricht, die hinzugefuegt werden muss */
                BapBufferWithLength_pot poCurrentBufferWithLength = &((BAP_BusIndTxTable[oPars.poFctRomRow->u16BusTxTableIndex].poBclTxRamRow)->oBufferWithLength);
                oPars.pData =  *(poCurrentBufferWithLength->paru8Buffer);

                /* Laenge voranstellen, falls erforderlich */
                if ( BAP_BusIndTxTable[oPars.poFctRomRow->u16BusTxTableIndex].bDataTypeSupportsVarLength)
                {
                    oPars.u16Length = poCurrentBufferWithLength->u16Length;

                    /* Untere 8 Bit der Laenge setzen */
                    (*poGetAllBufferWithLength->paru8Buffer)[poGetAllBufferWithLength->u16Length] = (uint8_t) (oPars.u16Length);

                    /* Obere 8 Bit der Laenge setzen */
                   ( *poGetAllBufferWithLength->paru8Buffer)[poGetAllBufferWithLength->u16Length+(uint16_t)1u] = (uint8_t) (oPars.u16Length >> 8);

                    poGetAllBufferWithLength->u16Length += (uint16_t)2u;

                    /* Daten kopieren */
                    MEMCPY( &(*poGetAllBufferWithLength->paru8Buffer)[poGetAllBufferWithLength->u16Length]
                        , oPars.pData
                        , oPars.u16Length );

                    /* Laenge der aktuellen Nachricht zur Gesamtnachricht hinzufuegen */
                    poGetAllBufferWithLength->u16Length = (uint16_t)(poGetAllBufferWithLength->u16Length + oPars.u16Length);
                }
                else
                { /* bei fixer Laenge steht diese im ROM */
                    oPars.u16Length = BAP_BusIndTxTable[oPars.poFctRomRow->u16BusTxTableIndex].u16BufferSize;

                    /* Daten kopieren */
                    MEMCPY( &(*poGetAllBufferWithLength->paru8Buffer)[poGetAllBufferWithLength->u16Length]
                        , oPars.pData
                        , oPars.u16Length );

                    /* Laenge der aktuellen Nachricht zur Gesamtnachricht hinzufuegen */
                    poGetAllBufferWithLength->u16Length = (uint16_t)(poGetAllBufferWithLength->u16Length + oPars.u16Length);
                }
            }
            else /* falls kein Sendepuffer fuer GetAll, dann nutze Einzelbeantwortung */
#endif /* BAP_USES_STATUS_ALL */
            {
                /* ja, dann ResendWithOpCode, Aufruf von GeneralSend vermeidet Rekursion */
                BAP_BCL_GeneralSend(&oPars, BapSendType_ResendWithOpcode);
            }
        }
        else
        {
            /* Diese Funktion nicht versenden */
        }
        u8FctIdMask /= (uint8_t) 2u;
    }

    /*lint +esym(613, apoPars) */
}
#endif /* #ifdef BAP_FSG */


/* Definition (Implementierung) von globalen Funktionen */

#if defined (BAP_ASG) || defined(WIRD_NIE_GEBRAUCHT)
/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_AbortSend(BapInternalParameters_cpot apoPars)
{
    /*lint -esym(613,apoPars) */
    BAP_BCL_GeneralSend(apoPars, BapSendType_Abort);
    return;
    /*lint +esym(613,apoPars) */
}
#endif /* #if defined (BAP_ASG) || defined(WIRD_NIE_GEBRAUCHT)  */


#ifdef BAP_FSG
/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_SendError(BapInternalParameters_cpot apoPars)
{
    /*lint -esym(613,apoPars) */
    BAP_BCL_GeneralSend(apoPars, BapSendType_SendError);
    return;
    /*lint +esym(613,apoPars) */
}
#endif /* #ifdef BAP_FSG */


/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_Send(BapInternalParameters_cpot apoPars)
{
    /*lint -esym(613,apoPars) */
    BAP_BCL_GeneralSend(apoPars, BapSendType_Send);
    return;
    /*lint +esym(613,apoPars) */
}


#ifdef BAP_ASG
/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_Resend(BapInternalParameters_cpot apoPars)
{
    /*lint -esym(613,apoPars) */
    BAP_BCL_GeneralSend(apoPars, BapSendType_Resend);
    return;
    /*lint +esym(613,apoPars) */
}
#endif /* #ifdef BAP_ASG */


#ifdef BAP_FSG
/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_ResendWithOpCode(BapInternalParameters_cpot apoPars)
{
    /*lint -esym(613,apoPars) */
    if (BAP_FCTID_GETALL == apoPars->fctId)
    {
        /* Sonderbehandlung fuer Funktionsklasse Cache */
        BAP_BCL_SendStatusAll(apoPars);
    }
    else
    {
        BAP_BCL_GeneralSend(apoPars, BapSendType_ResendWithOpcode);
    }
    return;
    /*lint +esym(613,apoPars) */
}
#endif /* #ifdef BAP_FSG */


#ifdef BAP_FSG
/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_BufferSet(BapInternalParameters_cpot apoPars)
{
    /*lint -esym(613,apoPars) */
    BAP_BCL_GeneralSend(apoPars, BapSendType_BufferSet);
    return;
    /*lint +esym(613,apoPars) */
}
#endif /* #ifdef BAP_FSG */


/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_Init(BapLsgRomRow_pot apoLsgRomRow)
{
    /*lint -esym(613,apoLsgRomRow)*/
    BAP_ASSERT(apoLsgRomRow);

    /* Initialisierung aller dem LSG gehoerenden BCL RAM Bereiche */
    BAP_BCL_InitLsgRamAreas(apoLsgRomRow);
    /* Initialisierung des Vector CAN Treibers fuer den BAP Tx Pfad */
    BAP_BCL_InitCanDrvTxCfmFlags(apoLsgRomRow);

    return;
    /*lint +esym(613,apoLsgRomRow)*/
}

BAP_IMPL_FAR DBGVAR void
BAP_BCL_Shutdown(BapLsgRomRow_pot apoLsgRomRow)
{
	BAP_BCL_Init(apoLsgRomRow);
	return;
}


/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR BapError_et
BAP_BCL_Start(BapLsgRomRow_pot apoLsgRomRow)
{
    DBGVAR BapError_et eResult = BapErr_OK;
#ifdef BAP_FSG
    DBGVAR uint8_t u8FctRomRowIdx;
    DBGVAR uint8_t u8BusTxIdx;

    /*lint -esym(613,apoLsgRomRow)*/
    BAP_ASSERT(apoLsgRomRow);

#if defined(BAP_ASG) && defined(BAP_FSG)
    if (BapSG_FSG == apoLsgRomRow->eSGType)
#endif /* defined(BAP_ASG) && defined(BAP_FSG) */
    {
        /* Teste, ob alle Sendepuffer initialisiert sind */
        for (u8FctRomRowIdx=(uint8_t)0; (u8FctRomRowIdx<apoLsgRomRow->u8FctRomTableSize) && (BapErr_OK == eResult); u8FctRomRowIdx++)
        {
            BapFctRomRow_pot poFctRomRow = &BAP_FctRomTables[apoLsgRomRow->u16FctRomIndex + u8FctRomRowIdx];

            for(u8BusTxIdx=(uint8_t)0; u8BusTxIdx<poFctRomRow->u8TxTableSize; u8BusTxIdx++)
            {
                BapBusIndirectionTxRomRow_pot  const poBusTxRow = &(BAP_BusIndTxTable[poFctRomRow->u16BusTxTableIndex + (uint16_t)u8BusTxIdx]);
                if (/* Nur falls Werte versendet werden koennen ist eine Initialisierung erforderlich */
                    ( poBusTxRow->u16BufferSize > (uint16_t)0)
                    /* Nur Properties muessen vorbelegt werden */
                    && (BapFctCls_Property == poFctRomRow->eFunctionClass)
                    /* Wert nicht initialisiert? */
                    && (BAP_FALSE == (bool_t)poBusTxRow->poBclTxRamRow->flags.fTxInitializedFlag )
                    /* Funktion muss in Funktionsliste sein */
                    && ((uint8_t)0 != (apoLsgRomRow->poLsgRamRow->BAP_aru8FunctionList[BINARY_ID(poFctRomRow->fctId) / (uint8_t)8] & ((uint8_t)0x80 >> (BINARY_ID(poFctRomRow->fctId) % (uint8_t)8))))
                   )
                {
                    eResult = BapErr_SendBufferNotInitialized;
                }
            }
        }
    }
#endif /* #ifdef BAP_FSG */

    return eResult;
    /*lint +esym(613,apoLsgRomRow)*/

}


/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_TaskSend(void)
{
    /* Verwalte die Inhibit Timer */
    BAP_BCL_InhibitTimerTask();

    /* Aufruf CAN Sende Task */
#ifdef BAP_RUNTIME_TEST
    BAP_RUNTIME_TEST_CANSENDTASK_START();
#endif /* BAP_RUNTIME_TEST */ 
   
    BAP_BCL_CanSendTask();

#ifdef BAP_RUNTIME_TEST
    BAP_RUNTIME_TEST_CANSENDTASK_STOP();
#endif /* BAP_RUNTIME_TEST */ 

    return;
}


/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_ReadRingbuffer(void)
{
    /* Hole die Daten aus den Ringpuffern ab */
    BAP_BCL_CanReceiveTask();

    return;
}


#ifdef BAP_USES_SEGMENTATION
/*  Diese Funktion ist in bap_bcl.h dokumentiert */
BAP_IMPL_FAR void
BAP_BCL_TaskRxNotify(void)
{
    DBGVAR uint8_t u8LsgRomRowIdx;

    BAP_InitInternalParameters(&oPars);

    oPars.eOpCode = BapOp_Invalid;
    oPars.pData = NULL;
    oPars.u16Length = (uint16_t)0;

    /* Verwalte die InterTelegram Timer */
    BAP_BCL_InterTelegramTimerTask();

    /* Fuer alle Lsgs: Durchsuche, ob in deren BCL Puffern vollstaendig
     * empfangene Datenelemente oder Fehlerwerte enthalten sind
     */
    for ( u8LsgRomRowIdx = (uint8_t)0; u8LsgRomRowIdx < BAP_P_LSG_ROM_TABLE_ROWS; u8LsgRomRowIdx++)
    {
        DBGVAR uint8_t u8FctRomRowIdx;
        DBGVAR uint8_t u8FctRomTableSize;

        oPars.poLsgRomRow = BAP_pLsgRomTable[u8LsgRomRowIdx];
        oPars.lsgId = oPars.poLsgRomRow->lsgId;
        u8FctRomTableSize = oPars.poLsgRomRow->u8FctRomTableSize;


#ifdef BAP_TASKTIME_LIMIT
        if ( (BAP_TRUE == (bool_t)(oPars.poLsgRomRow->poLsgRamRow->fState.fRxFlag))
            && (BAP_u16TaskTimeCounter<BAP_MAX_TASK_TIME)
           )
#endif /* #ifdef BAP_TASKTIME_LIMIT */
        {
#ifdef BAP_TASKTIME_LIMIT
            oPars.poLsgRomRow->poLsgRamRow->fState.fRxFlag = BAP_FALSE;
#endif /* #ifdef BAP_TASKTIME_LIMIT */

            for (u8FctRomRowIdx = (uint8_t)0;
#ifdef BAP_TASKTIME_LIMIT
                 (BAP_u16TaskTimeCounter<BAP_MAX_TASK_TIME) &&
#endif /* #ifdef BAP_TASKTIME_LIMIT */
                 (u8FctRomRowIdx < u8FctRomTableSize);
                 u8FctRomRowIdx++)
            {
                oPars.poFctRomRow = &BAP_FctRomTables[oPars.poLsgRomRow->u16FctRomIndex + u8FctRomRowIdx];
                oPars.fctId = oPars.poFctRomRow->fctId;

                BAP_BCL_SingleRxNotify(&oPars);
            }
        }
    }
#ifdef BAP_TASKTIME_LIMIT
    if (BAP_u16TaskTimeCounter>=BAP_MAX_TASK_TIME)
    {
        BAP_DBG_TaskTimeLimitEvent();
    }
#endif /* #ifdef BAP_TASKTIME_LIMIT */
    return;
}
#endif /* #ifdef BAP_USES_SEGMENTATION */
