/******************************************************************
 *
 *     Copyright (c) 2004 Volkswagen AG, D-38436 Wolfsburg
 *
 ******************************************************************
 *
 * Projekt:    BAP (P0263)
 * Komponente: BAL
 *
 * $Archive: /dev/BAP/util/bap_util.h $
 * $Revision: 792 $
 * $Modtime: 05-04-25 17:52 $
 * $Author: AchimL $
 *
 * Dr. Jochen Kreuzinger, Xcc Software AG, D-76137 Karlsruhe
 *
 ******************************************************************
 *
 * Beschreibung
 *
 *  Diese Datei enthaelt Hilfsfunktionen fuer alle Schichten im
 *  BAP Projekt. Die Hilfsfunktionen umfassen auch den Zugriff auf 
 *  die Konfigurationstabellen.
 *
 ******************************************************************
 *
 * Versionsgeschichte (ohne SCM)
 *
 * Datum        Version     Autor       Beschreibung
 * ----------------------------------------------------------------
 * 2013-01-30	1.7			WWU			MISRA-2004 fix
 * 2007-09-13   1.5         ALI         Einige Macros nach bap_user_stdtypes.h verschoben
 * 2006-04-12   1.4         ALA         Unterstuetzung von symbolischen IDs in der Konfiguration.
 * 2006-04-12   1.4         ALA         Unterstuetzung fuer BAP_ROM_DATA_FAR.
 * 2005-07-07   1.3.1       ALA         #include "bap_config.h" hinzugefuegt (wg. BapInternalParameters_t)
 * 2004-11-17   1.2         JOK         #include "bap_types.h" eingefuegt
 * 2004-11-17   1.2         JOK         struct BapLsgRomRow_t* mit const versehen
 ******************************************************************/

#ifndef BAP_UTIL_H
#define BAP_UTIL_H

#ifdef __cplusplus
extern "C" {
#endif

/* Systemincludes mit <...> */

/* Bibliotheken von externen Herstellen mit <...> */

/* Eigene Header-Dateien "..." */
#include "bap_types.h"
#include "bap_config.h"

/* Makro-Definitionen */

#ifdef BAP_USES_NAMED_IDS
#define BINARY_ID    (uint8_t)
#else
#define BINARY_ID
#endif



/* Typ-Definitionen */

/* Const Deklarationen */

/* Externe globale Variablen */
/* @WWU:
 * MISRA-2004 fix: oPars wird als interne Objekt in ganzen BAP Verwendet
 * Definiere oPars als globale Variable */
extern BapInternalParameters_ot oPars;
extern BapInternalParameters_ot oPars_fctlist;
/* Deklarationen von Funktionen */
/**
 *  Diese Funktion gibt den Eintrag in der FCT-ROM-Tabelle des adressierten
 *  LSG und der adressierten FCT zurueck.
 *
 *  @param aLsgId bezeichnet das logische Steuergeraet
 *  @param aFctId bezeichnet die Funktion
 *
 *  @returns
 *      Falls diese Funktion existiert einen Zeiger auf den Eintrag in der Tabelle
 *      und sonst NULL.
 */
BapFctRomRow_pot BAP_IMPL_FAR
BAP_GetFctRomRow(DBGVAR lsgId_t aLsgId, DBGVAR fctId_t aFctId);

/**
 *  Diese Funktion gibt den Eintrag in der LSG-ROM-Tabelle des adressierten
 *  LSG zurueck.
 *
 *  @param aLsgId bezeichnet das logische Steuergeraet.
 *
 *  @returns 
 *      Falls der Eintrag existiert ein Zeiger auf den Eintrag in der LSG-ROM-Tabelle 
 *      und sonst NULL.
 *
 */
BapLsgRomRow_pot BAP_IMPL_FAR 
BAP_GetLsgRomRow(DBGVAR lsgId_t aLsgId);  
/*lint -sem(BAP_GetLsgRomRow ,r_null) Funktion kann NULL-Zeiger zurueckliefern */

/**
 *  Diese Funktion gibt den Eintrag in der FCT-ROM-Tabelle des adressierten
 *  LSG und der adressierten FCT zurueck
 *
 *  @param apoLsgRomRow bezeichnet das logische Steuergeraet (darf NULL sein)
 *  @param aFctId bezeichnet die Funktion
 *
 *  @returns
 *      Falls diese Funktion existiert einen Zeiger auf den Eintrag in der Tabelle
 *      und sonst NULL.
 *
 *  @remarks
 *      liefert NULL falls apoLsgRomRow NULL ist.
 */
BapFctRomRow_pot BAP_IMPL_FAR 
BAP_GetLsgFctRomRow(BapLsgRomRow_pot apoLsgRomRow, DBGVAR fctId_t aFctId);
/*lint -sem(BAP_GetLsgFctRomRow ,r_null) Funktion kann NULL-Zeiger zurueckliefern */


BapFctRomRow_pot BAP_IMPL_FAR
BAP_GetLsgFctRomRow_SpecialCases(BapLsgRomRow_pot apoLsgRomRow, DBGVAR fctId_t aFctId);

#ifndef BAP_ROM_DATA_FAR_EMPTY
/**
 *  Diese Funktion ersetzt die Bibliotheksfunktion memcpy, um BAP_ROM_DATA_FAR Konstanten ins RAM zu kopieren.
 *
 *  @param dest Pointer auf den Zielspeicher
 *  @param source Pointer auf den Quellspeicher
 *  @param length Laenge der Daten die kopiert werden sollen
 */
BAP_IMPL_FAR void 
BAP_RomToRamMemCpy(DBGVAR void * dest, DBGVAR BAP_ROM_DATA_FAR const void * source, DBGVAR const size_t length);
#endif /* #ifndef BAP_ROM_DATA_FAR_EMPTY */


/**
 *  Fuehrt ein MEMSET(apoPars, 0, sizeof(*apoPars)) durch.
 *
 *  @param apoPars - Zeiger auf die zu initialisierende Struktur
 */
BAP_IMPL_FAR void 
BAP_InitInternalParameters(BapInternalParameters_pot apoPars);

#ifdef __cplusplus
}
#endif

#endif      /* #ifndef BAP_UTIL_H */

