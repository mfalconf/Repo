/******************************************************************
 *
 *     Copyright (c) 2004 Volkswagen AG, D-38436 Wolfsburg
 *
 ******************************************************************
 *
 * Projekt:    BAP (P0263)
 * Komponente: Integrationssupport fuer Zulieferer
 *
 * $Archive: /dev/BAP/integration/initialization.c $
 * $Revision: 32 $
 * $Modtime: 06-06-06 06:06 $
 * $Author: Andreasl $
 *
 * Ersteller:
 * Andreas Laag, Xcc Software AG, D-76137 Karlsruhe
 *
 ******************************************************************
 *
 * Beschreibung
 *
 *  Diese Datei enthaelt Code welcher das Initialisiern der RAM-
 *  Elemente des BAP Stacks vornimmt falls dies nicht von der
 *  C-Library im Startup-Code vorgenommen wird.
 *
 *  @remarks
 *  Es wird nicht fuer Vollstaendigkeit und/oder Korrektheit
 *  dieses Codes garantiert.
 *
 ******************************************************************
 *
 * Versionsgeschichte (ohne SCM)
 *
 * Datum        Version     Autor       Beschreibung
 * ----------------------------------------------------------------
 * 2006_08_01   1.5         SHU         Define Integrationsbeispiel
 * 2006-06-06   1.4         ALA         Initiale Version
 ******************************************************************/

/* Systemincludes mit <...> */
#include <string.h>

/* Bibliotheken von externen Herstellen mit <...> */

/* Eigene Header-Dateien "..." */
#include "bap_types.h"
#include "bap_privatetypes.h"
#include "bap_balconfig.h"
#include "bap_bplconfig.h"
#include "bap_bclconfig.h"
#include "bap_config.h"
#include "bap.h"

/* Externe globale Variablen-Definitionen */

/* Interne Typ-Definitionen */

/* Interne Const Deklarationen */

/* Interne statische Variablen */

/* Vorwaerts-Deklarationen von statischen Funktionen */

/* Definition (Implementierung) von statischen Funktionen */

/* Definition (Implementierung) von globalen Funktionen */

/**
 * Diese Funktion muss vor dem Aufruf von BAP_Init aufgerufen werden,
 * falls der C-Startup-Code nicht das Initialiseren des RAMS
 * mit den Default-Werten aus der generierten C-Datei uebernimmt.
 *
 * @remarks
 * Diese Funktion ist ungetestet.
 * Verwendung dieser Funktion auf eigene Gefahr!
 */
void BAP_IMPL_FAR 
Intialize_BAP_RAM(void)
{  
    uint16_t u16LsgCounter;      /* Zaehler fuer Zeilen in der ROM-Tabelle */
    uint16_t u16pLsgCounter = 0; /* Zaehler fuer Zeilen in der RAM-Tabelle */
    lsgId_t lsgId = 0;           /* dieses Lsg gibt es nicht */

    /* Initialisiere Zustaende der logischen Steuergeraete */
    for(u16LsgCounter = 0; u16LsgCounter < BAP_LSG_ROM_TABLE_ROWS; u16LsgCounter++)
    {
        (void) memset( BAP_LsgRomTables[u16LsgCounter].poLsgRamRow 
            , 0
            , sizeof(*BAP_LsgRomTables[u16LsgCounter].poLsgRamRow) );
    }

    /* Initialisiere Intertelegramzeitueberwachung */
    (void) memset (BAP_u16InterTelegramTimerTable
        , 0
        , sizeof(BAP_u16InterTelegramTimerTable[0]) * BAP_INTER_TELEGRAM_TIMER_ROWS );
   
    /* Initialisiere Segmentierungskanaele */
    (void) memset (BAP_CanTxSegmentationChannels
        , 0
        , sizeof(BAP_CanTxSegmentationChannels[0]) * BAP_CAN_TX_SEGMENTATION_CHANNELS );
    (void) memset (BAP_CanRxSegmentationChannels
        , 0
        , sizeof(BAP_CanRxSegmentationChannels[0]) * BAP_CAN_RX_SEGMENTATION_CHANNELS );

    /* Initialisiere Ringpuffer */
    BAP_u8CanRxRingBufferReadOffset = 0;
    BAP_u8CanRxRingBufferWriteOffset = 0;
    
    /* Initialisiere Inhibit-Timer */
    (void) memset (BAP_InhibitRamTable
        , 0
        , sizeof(BAP_InhibitRamTable[0]) * BAP_INHIBIT_ROWS);
    
    /* Initialisiere Tabelle mit Zeigern auf die ausgewaehlte Lsg-Konfiguration */
    for(u16LsgCounter = 0; u16LsgCounter < BAP_LSG_ROM_TABLE_ROWS; u16LsgCounter++)
    {
        /* Waehle immer die erste inkompatible Konfiguration eines Lsgs als Default aus */
        if (lsgId != BAP_LsgRomTables[u16LsgCounter].lsgId)
        {
            lsgId = BAP_LsgRomTables[u16LsgCounter].lsgId;
            BAP_pLsgRomTable[u16pLsgCounter] = &BAP_LsgRomTables[u16LsgCounter];
            u16pLsgCounter++;
        }
    }
}

/*  Callback-Funktionen */

