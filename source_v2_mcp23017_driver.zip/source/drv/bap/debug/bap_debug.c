/******************************************************************
 *
 *     Copyright (c) 2004 Volkswagen AG, D-38436 Wolfsburg
 *
 ******************************************************************
 *
 * Projekt:    BAP (P0674)
 * Komponente: Debug/Diagnose
 *
 * $Archive: /dev/BAP/debug/bap_debug.c $
 * $Revision: 792 $
 * $Modtime: 3.05.05 12:48 $
 * $Author: AchimL $
 *
 * Ersteller:
 * Andreas Laag, Xcc Software AG, D-76137 Karlsruhe
 *
 ******************************************************************
 *
 * Beschreibung
 *
 *  Diese Datei enthaelt die Implementierung der Debug/Diagnose-
 *  Komponente im BAP-Projekt.
 *
 *  Diese C-Datei enthaelt nicht die Funktionen, welche die
 *  Anbindung an die Kommunikationschicht vornehmen.
 *
 ******************************************************************
 *
 * Versionsgeschichte (ohne SCM)
 *
 * Datum        Version     Autor       Beschreibung
 * ----------------------------------------------------------------
 * 2014-03-25	1.7.1		WWU			Misra-2004 fix: Function-like Macros.
 * 2013-04-17	1.7.0		FST			Get+Set-Funktionen fuer gDebugLsgId erstellt fuer debug-Zugriff
 * 2013-02-06	1.7.0		WWU			Funktionsname Umbenannt, wegen Misra : Identifier exceeds 31 characters,
 * 										bugfix in BAP_ProcessDebugControl
 * 2012-10-15	1.6.5.1		WWU			Korrektur der Misra-98 Abweichungen
 * 2012-02-02   1.6.3       NQU         Lint Warnung wegen Enum->Int Cast behoben
 * 2007-09-03   1.5         ALI         BAP_DBG_SetBalState um Zustand InvalidConfig erweitert
 * 2007-08-22   1.5         SHU         Aenderung der BAP-Debug-Botschaften mit Byte0+1 als BAP-Header
 * 2006-04-12   1.4         ALA         Unterstuetzung fuer BAP_ROM_DATA_FAR.
 * 2005-04-20   1.3         ALA         Funktion BAP_DBG_SetBplState entfernt, da gemeinsamer Zustand fuer alle Schichten.
 * 2005-04-06   1.3         ALA         Funktion BAP_DBG_RequestTimeoutError() und BAP_DBG_DataLostError() eingebaut
 * 2004-11-17   1.2         JOK         Funktion BAP_DBG_GetAllMessageCorruptedError() eingebaut
 * 2004-06-07   1.1         JOK         Compilerschalter fuer SG-Typen zur Optimierung
 *                                      des ROM-Bedarfs eingefuegt
 * 2004-06-07   1.1         JOK         Funktion BAP_DBG_SetBclState() entfernt
 ******************************************************************/


/* Systemincludes mit <...> */

/* Bibliotheken von externen Herstellen mit <...> */

/* Eigene Header-Dateien "..." */
#include "bap_debug.h"
#include "bap_util.h"
#include "bap_balconfig.h"
#include "bap_bplconfig.h"
#include "bap_bclconfig.h"

/* Externe globale Variablen-Definitionen */

/* Interne Makro-Definitionen */

/* Interne Typ-Definitionen */

/* Interne Const Deklarationen */

/* Interne statische Variablen */

#if defined(BAP_DBG_PER_LSG) || defined(BAP_DBG_ON_OFF)
/**
 *  Speichert, fuer welche Lsg gerade Debug-Betrieb aktiv ist.
 */
static DBGVAR lsgId_t gDebugLsgId = (lsgId_t)0;
#endif /* defined(BAP_DBG_PER_LSG) || defined(BAP_DBG_ON_OFF) */

#if defined(BAP_DBG_PER_LSG) || defined(BAP_DBG_ON_OFF)
/**
 *  Speichert die aktuelle Debug-Information.
 */
DBGVAR uint8_t BAP_DBG_DebugInfoTable[8];
#endif /* defined(BAP_DBG_PER_LSG) || defined(BAP_DBG_ON_OFF) */

/* Vorwaerts-Deklarationen von statischen Funktionen */

/* Definition von statischen Funktionen */

/* Definition von global sichtbaren Funktionen */

/**************************************************/
/*         Debug-Flags der BAL-Schicht            */
/**************************************************/

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_SetBalState(lsgId_t aLsgId
    , BapLayerLsgStatus_et aeState)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 1, Bit 2^6 und 2^7 */
        BAP_DBG_DebugInfoTable[2] &= (uint8_t)0x3F;  /* loeschen, weil kein Ereignis */
        BAP_DBG_DebugInfoTable[2] |= (uint8_t)(((uint8_t)aeState) << (uint8_t)6);
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_SetCacheValidState(lsgId_t aLsgId
    , bool_t abValid)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 1, Bit 2^5 */
        BAP_DBG_DebugInfoTable[2] &= (uint8_t)0xDF;  /* loeschen, weil kein Ereignis */
        BAP_DBG_DebugInfoTable[2] |= (abValid & (uint8_t)1) << (uint8_t)5;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_GetAllMsgCorruptedErr(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 1, Bit 2^0 */
        BAP_DBG_DebugInfoTable[2] |= (uint8_t)0x01;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_InvalidStateError(lsgId_t aLsgId)
{
    if (gDebugLsgId == aLsgId)
    {
        /* Byte 2, Bit 2^7 */
        BAP_DBG_DebugInfoTable[3] |= (uint8_t)0x80;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_CacheInvalidError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 2, Bit 2^6 */
        BAP_DBG_DebugInfoTable[3] |= (uint8_t)0x40;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_CacheNotAvailableError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 2, Bit 2^5 */
        BAP_DBG_DebugInfoTable[3] |= (uint8_t)0x20;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_InvalidArgError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 2, Bit 2^4 */
        BAP_DBG_DebugInfoTable[3] |= (uint8_t)0x10;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_ProtocolVersionError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 2, Bit 2^3 */
        BAP_DBG_DebugInfoTable[3] |= (uint8_t)0x08;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_DataDefinitionError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 2, Bit 2^2 */
        BAP_DBG_DebugInfoTable[3] |= (uint8_t)0x04;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_FSG
#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_GetAllEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 2, Bit 2^1 */
        BAP_DBG_DebugInfoTable[3] |= (uint8_t)0x02;
    }
}
#endif /* BAP_DBG_PER_LSG */
#endif /* BAP_FSG */

#if defined(BAP_DBG_PER_LSG)
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_IncomingMessageEvent(lsgId_t aLsgId,
                             fctId_t aFctId,
                             BapOpCodes_et aeOpCode)
{
    if (aLsgId == gDebugLsgId)
    {
        /*Loeschen des BAP-Headers*/
        BAP_DBG_DebugInfoTable[0] = (uint8_t)0;
        BAP_DBG_DebugInfoTable[1] = (uint8_t)0;

        /* Byte 3, Bit 2^0 */
        BAP_DBG_DebugInfoTable[3] |= (uint8_t)0x01;

        /* BAP-Header fuer unsegmentierte Botschaft
                     Byte0         Byte1
                OpCode   LSG-ID    FCT-ID
               0  000   XXXX | XX  000000 | */
        /*BAP_DBG_DebugInfoTable[0] = (aru8DebugCtrl[0] & (uint8_t)0x3Cu) >> 2;
        BAP_DBG_DebugInfoTable[1] = (aru8DebugCtrl[0] & (uint8_t)0x03u) << 6; */

        /*OpCode*/
        BAP_DBG_DebugInfoTable[0] |= ((uint8_t)aeOpCode & (uint8_t)0x07) << (uint8_t)4;
        /*LSG-ID*/
        BAP_DBG_DebugInfoTable[0] = (uint8_t)(((uint8_t)aLsgId & (uint8_t)0x3Cu) >> (uint8_t)2);
        BAP_DBG_DebugInfoTable[1] = (uint8_t)(((uint8_t)aLsgId & (uint8_t)0x03u) << (uint8_t)6);

        /*FCT-ID*/
        BAP_DBG_DebugInfoTable[1] |= ((uint8_t)aFctId & (uint8_t)0x3F);
    }
}
#elif defined(BAP_DBG_ON_OFF)
BAP_IMPL_FAR void
BAP_DBG_IncomingMessageEvent(lsgId_t aLsgId,
                             fctId_t aFctId,
                             BapOpCodes_et aeOpCode)
{
	BAP_DBG_DebugInfoTable[0] |= ((uint8_t)(aeOpCode) & (uint8_t)0x07) << (uint8_t)4;
	BAP_DBG_DebugInfoTable[1] |= ((uint8_t)(aFctId) & (uint8_t)0x3F);
	BAP_DBG_DebugInfoTable[3] |= (uint8_t)0x01u;
}
#endif /* #if defined(BAP_DBG_PER_LSG) || defined(BAP_DBG_ON_OFF) */

/**************************************************/
/*         Debug-Flags der BPL-Schicht            */
/**************************************************/


#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_SetHeartbeatState(lsgId_t aLsgId
    , bool_t bHeartbeatOn)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 3, Bit 2^5 */
        BAP_DBG_DebugInfoTable[4] &= (uint8_t)0xDF;  /* loeschen, weil kein Ereignis */
        BAP_DBG_DebugInfoTable[4] |= (bHeartbeatOn &(uint8_t) 0x01) << (uint8_t)5;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_ASG
#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RequestTimeoutError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 3, Bit 2^2 */
        BAP_DBG_DebugInfoTable[4] |= (uint8_t)0x04;
    }
}
#endif /* BAP_DBG_PER_LSG */
#endif /* BAP_ASG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RetryTimeoutError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 3, Bit 2^1 */
        BAP_DBG_DebugInfoTable[4] |= (uint8_t)0x02;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_FSG
#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_HeartbeatLoopEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 3, Bit 2^0 */
        BAP_DBG_DebugInfoTable[4] |= (uint8_t)0x01;
    }
}
#endif /* BAP_DBG_PER_LSG */
#endif /* BAP_FSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_HeartbeatProcessedEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 4, Bit 2^7 */
        BAP_DBG_DebugInfoTable[5] |= (uint8_t)0x80;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_HeartbeatTimeoutError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 4, Bit 2^6 */
        BAP_DBG_DebugInfoTable[5] |= (uint8_t)0x40;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RetryMntStartedEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 4, Bit 2^5 */
        BAP_DBG_DebugInfoTable[5] |= (uint8_t)0x20;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RetryProvokedEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 4, Bit 2^4 */
        BAP_DBG_DebugInfoTable[5] |= (uint8_t)0x10;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RetryAnsweredEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 4, Bit 2^3 */
        BAP_DBG_DebugInfoTable[5] |= (uint8_t)0x08;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RetryRetriggeredEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 4, Bit 2^2 */
        BAP_DBG_DebugInfoTable[5] |= (uint8_t)0x04;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RetryStoppedEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 4, Bit 2^1 */
        BAP_DBG_DebugInfoTable[5] |= (uint8_t)0x02;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RetryBusyError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 4, Bit 2^0 */
        BAP_DBG_DebugInfoTable[5] |=(uint8_t) 0x01;
    }
}
#endif /* BAP_DBG_PER_LSG */


/**************************************************/
/*         Debug-Flags der BPL-Schicht            */
/**************************************************/

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_TaskTimeLimitEvent(void)
{
    if (gDebugLsgId)
    {
        /* Byte 5, Bit 2^4 */
        BAP_DBG_DebugInfoTable[6] |= (uint8_t)0x10;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_BadDataLengthError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 5, Bit 2^3 */
        BAP_DBG_DebugInfoTable[6] |= (uint8_t)0x08;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_DataLostError(void)
{
    if (gDebugLsgId)
    {
        /* Byte 5, Bit 2^2 */
        BAP_DBG_DebugInfoTable[6] |= (uint8_t)0x04;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_TxStartMsgEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 5, Bit 2^1 */
        BAP_DBG_DebugInfoTable[6] |= (uint8_t)0x02;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RxStartMsgEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 5, Bit 2^0 */
        BAP_DBG_DebugInfoTable[6] |= (uint8_t)0x01;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_TxSegMsgCompleteEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 6, Bit 2^7 */
        BAP_DBG_DebugInfoTable[7] |= (uint8_t)0x80;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RxSegMsgCompleteEvent(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 6, Bit 2^6 */
        BAP_DBG_DebugInfoTable[7] |= (uint8_t)0x40;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_IntertelegramTmoutErr(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 6, Bit 2^5 */
        BAP_DBG_DebugInfoTable[7] |= (uint8_t)0x20;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_MsgOversizeError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 6, Bit 2^4 */
        BAP_DBG_DebugInfoTable[7] |= (uint8_t)0x10;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_SequenceError(lsgId_t aLsgId)
{
    if (aLsgId == gDebugLsgId)
    {
        /* Byte 6, Bit 2^3 */
        BAP_DBG_DebugInfoTable[7] |= (uint8_t)0x08;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RxDataPurgedEvent(void)
{
    if (gDebugLsgId)
    {
        /* Byte 6, Bit 2^2 */
        BAP_DBG_DebugInfoTable[7] |= (uint8_t)0x04;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_TxEvent(void)
{
    if (gDebugLsgId)
    {
        /* Byte 6, Bit 2^1 */
        BAP_DBG_DebugInfoTable[7] |= (uint8_t)0x02;
    }
}
#endif /* BAP_DBG_PER_LSG */

#ifdef BAP_DBG_PER_LSG
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_RxEvent(void)
{
    if (gDebugLsgId)
    {
        /* Byte 6, Bit 2^0 */
        BAP_DBG_DebugInfoTable[7] |= (uint8_t)0x01;
    }
}
#endif /* BAP_DBG_PER_LSG */


#if defined(BAP_DBG_PER_LSG) || defined(BAP_DBG_ON_OFF)
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_DBG_Task(void)
{
    if (gDebugLsgId)
    {
        /* Ist ein Ereignis oder Fehler aufgetreten? */
        if ( (BAP_DBG_DebugInfoTable[2] & (uint8_t)0x1F) |
             (BAP_DBG_DebugInfoTable[3]) |
             (BAP_DBG_DebugInfoTable[4] & (uint8_t)0xDF) |
             (BAP_DBG_DebugInfoTable[5]) |
             (BAP_DBG_DebugInfoTable[6] & (uint8_t)0x3F) |
             (BAP_DBG_DebugInfoTable[7]))
        {
            /* Versende Botschaft */
            DBGVAR BapError_et bapErr = BAP_SendDebugInfo(BAP_DBG_DebugInfoTable);

            /* Nach erfolgreichem Versenden */
            if (BapErr_OK == bapErr)
            {
                /* Loeschen von Fct-Id und OpCode im BAP-Header */
                BAP_DBG_DebugInfoTable[0] &= (uint8_t)0x0F;
                BAP_DBG_DebugInfoTable[1] &= (uint8_t)0xC0;
                /* Loesche Ereignisbits */
                BAP_DBG_DebugInfoTable[2] &= (uint8_t)0xE0;
                BAP_DBG_DebugInfoTable[3] = (uint8_t)0u;
                BAP_DBG_DebugInfoTable[4] &= (uint8_t)0x20;
                BAP_DBG_DebugInfoTable[5] = (uint8_t)0u;
                BAP_DBG_DebugInfoTable[6] &= (uint8_t)0xC0;
                BAP_DBG_DebugInfoTable[7] = (uint8_t)0u;
            }
        }
    }
}
#endif /* defined(BAP_DBG_PER_LSG) || defined(BAP_DBG_ON_OFF) */


/**
 * Diese Funktion bietet externen Zugriff auf die Variable gDebugLsgId
 * (notwendig fuer CUnit-Tests).
 */
BAP_IMPL_FAR lsgId_t
BAP_DBG_GetDebugLsgId(void)
{
    return gDebugLsgId;
}


/**
 * Diese Funktion bietet externen Aenderungsmoeglichkeiten fuer die Variable gDebugLsgId
 * (notwendig fuer CUnit-Tests).
 */
BAP_IMPL_FAR void
BAP_DBG_SetDebugLsgId(lsgId_t LsgId)
{
    gDebugLsgId = LsgId;
}

#if defined(BAP_DBG_PER_LSG) || defined(BAP_DBG_ON_OFF)
/* Diese Funktion ist in bap_debug.h dokumentiert */
BAP_IMPL_FAR void
BAP_ProcessDebugControl(const uint8_t aru8DebugCtrl[2])
{
    BapLsgRomRow_pot poLsgRomRow;
    if (aru8DebugCtrl)
    {
        poLsgRomRow = BAP_GetLsgRomRow((lsgId_t)((uint8_t)aru8DebugCtrl[0] & (uint8_t)0x3Fu));

        if (poLsgRomRow)
        {
            if ( (uint8_t)0 == aru8DebugCtrl[1])
            {
                gDebugLsgId = (lsgId_t)0;
            }
            else
            {
                gDebugLsgId = (lsgId_t) (aru8DebugCtrl[0] & (uint8_t)0x3Fu);

                /* BAP-Header fuer unsegmentierte Botschaft
                             Byte0         Byte1
                        OpCode   LSG-ID    FCT-ID
                       0  000   XXXX | XX  000000 | */
                BAP_DBG_DebugInfoTable[0] = (uint8_t)((aru8DebugCtrl[0] & (uint8_t)0x3Cu) >> (uint8_t)2);
                BAP_DBG_DebugInfoTable[1] = (uint8_t)((aru8DebugCtrl[0] & (uint8_t)0x03u) << (uint8_t)6);

                BAP_DBG_DebugInfoTable[2] = (uint8_t)0u;
                BAP_DBG_DebugInfoTable[3] = (uint8_t)0u;
                BAP_DBG_DebugInfoTable[4] = (uint8_t)0u;
                BAP_DBG_DebugInfoTable[5] = (uint8_t)0u;
                BAP_DBG_DebugInfoTable[6] = (uint8_t)0u;
                BAP_DBG_DebugInfoTable[7] = (uint8_t)0u;

                /* Die richtigen Anfangszustaende setzen */
                BAP_DBG_SetBalState(gDebugLsgId, poLsgRomRow->poLsgRamRow->eLsgStatus);

#ifdef BAP_ASG
#if defined(BAP_ASG) && defined(BAP_FSG)
                if (BapSG_ASG == poLsgRomRow->eSGType)
#endif /* defined(BAP_ASG) && defined(BAP_FSG) */
                {
                    BAP_DBG_SetCacheValidState(gDebugLsgId
                        , (bool_t)poLsgRomRow->poLsgRamRow->fState.fCacheValid);
                }
#endif /* #ifdef BAP_ASG */
                BAP_DBG_SetHeartbeatState(gDebugLsgId
                    , ((poLsgRomRow->poLsgRamRow->eHeartbeatStatus == BapBplStat_OK) ? BAP_TRUE : BAP_FALSE) );

                /* Nach dem Einschalten gleich die Botschaft versenden */
                (void) BAP_SendDebugInfo(BAP_DBG_DebugInfoTable);
            }
        }
    }
}
#endif /* defined(BAP_DBG_PER_LSG) || defined(BAP_DBG_ON_OFF) */

