#include "standard.h"

#include <drv/board/board.h>
#include <drv/can/can.h>
#include <can_appl.h>
#if (USE_CAN_VOLKSWAGEN == 1)
    #include <can_appl_volkswagen.h>
#elif (USE_CAN_MOPAR == 1)
    #include <can_appl_mopar.h>
#else
    #include <can_appl_mopar.h>
#endif
#include <can_tp.h>
#include <can_diag.h>


#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Semaphore.h>

//#include <ti/csl/soc.h>
#include <ti/csl/csl_gpio.h>
#include <ti/csl/hw_types.h>

#include <ti/csl/src/ip/dcan/V0/dcan.h>
//#include <ti/csl/src/ip/dcan/V0/cslr_dcan.h>

//#include <ti/csl/src/ip/l4fw/V0/l4fw.h>

//#define DEBUG_CAN

#ifdef DEBUG_CAN
#define CAN_PRINTF                  System_printf
#else
#define CAN_PRINTF(fmt, arg...)
#endif

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

//#define CSL_DCAN1_REGS                  (0x4ae3e000U)
#define CSL_DCAN1_REGS                  (0x4ae3c000U)
#define CSL_DCAN1_SIZE                  (0x220U)

#define CSL_DCAN2_REGS                  (0x48480000U)
#define CSL_DCAN2_SIZE                  (0x220U)


#define DCAN1_BASE                      CSL_DCAN1_REGS + 0x20000000
#define DCAN2_BASE                      CSL_DCAN2_REGS + 0x20000000

#define DCAN1_USED                      0
#define DCAN2_USED                      1

#define DCAN_TX_IF_REG                  (DCAN_IF_REG_NUM_1)
#define DCAN_RX_IF_REG                  (DCAN_IF_REG_NUM_2)

#define DCAN_TX_MSG_OBJECT              1

#define DCAN_RX_MSG_OBJECT              2


#define DCAN_FIRST_RX_MSG_OBJECTS       1
#define DCAN_LAST_RX_MSG_OBJECTS        32
#define DCAN_FIRST_TX_MSG_OBJECTS       (DCAN_LAST_RX_MSG_OBJECTS + 1 )
#define DCAN_LAST_TX_MSG_OBJECTS        64


/* Total No. of message objects available in the DCAN message RAM */
#define CAN_NUMBERS_OF_MSG_OBJECTS      (64u)


//#define SOC_L4_WKUP_AP_BASE             (0x4ae00000U)


// Config CAN BaudRate (DCAN_BTR = 0x4AE3C000)
// fclock = 19,2 Mhz
#define CAN_BAUDRATE_125Kbps_75         1
#define CAN_BAUDRATE_102Kbps_72         2
#define CAN_BAUDRATE_100Kbps_81         3

#define SIZE_BUFFER_CAN_RX_MESSAGE      100

#define STB_GPIO_PIN                    20

#define TX_CAN_EVENT_IMMEDIATELY        TRUE

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#undef X
#define X(a,b,c,d,e)     a,
typedef enum Name_Can_Rx_Msg_tag
{
    CAN_RX_MESSAGE_TABLE
    NUM_CAN_RX_MESSAGE
}Name_Can_Rx_Msg_t;

#undef X
#define X(a,b,c,d,e)     a,
typedef enum Name_Can_Tx_Msg_tag
{
    CAN_TX_MESSAGE_TABLE
    NUM_CAN_TX_MESSAGE
}Name_Can_Tx_Msg_t;

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef struct Can_Rx_Msg_Tag
{
    uint32_t    id;
    uint8_t     id_format;
    uint8_t     dlc;
}Can_Rx_Msg_T;

typedef struct Can_Tx_Msg_Tag
{
    uint32_t    id;
    uint8_t     id_format;
    uint8_t     dlc;
    uint16_t    cnt;
    uint8_t     data[8];
}Can_Tx_Msg_T;

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static uint32_t baseAddr;
static uint32_t timeOut = 100U;
static uint32_t count_tick_periodic_can_timeout = 0;

/* CAN CONFIG */
static dcanBitTimeParams_t      CanBitTimeParams = {0};
static dcanCfgParams_t          CanCfgPrms = {0};

/* CAN NETWORK ACTIVE STS */
bool_t CanNetworkActiveSts = false;

#undef X
#define X(a,b,c,d,e)      {b,c,d},
static Can_Rx_Msg_T CanRxMsg[NUM_CAN_RX_MESSAGE] = { CAN_RX_MESSAGE_TABLE };

#if(ENABLE_CAN_TX)
#undef X
#define X(a,b,c,d,e)      {b,c,d,e,{0}},
static Can_Tx_Msg_T CanTxMsg[NUM_CAN_TX_MESSAGE] = { CAN_TX_MESSAGE_TABLE };

#undef X
#define X(a,b,c,d,e)      e,
static const uint16_t CanTxMsgPeriodicCntr[NUM_CAN_TX_MESSAGE] = { CAN_TX_MESSAGE_TABLE };
#endif

#if(ENABLE_CAN_TX)
static Semaphore_Handle can_sem = NULL;
#endif

/* CAN INITIALIZED FLAG */
static bool_t flag_can_initialized = false;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

//static void Can_Task_Theard_Shutdown(void);
static void Can_Task_Thread(UArg arg0, UArg arg1);
static void Can_Init(uint32_t can_used);
static void Dcan_GetCanBitTimeParamas(uint32_t canBaudrate, dcanBitTimeParams_t *CanBitTimeParams);

static void Dcan_Variables_Init(void);

static void Dcan_Set_baseAddr(uint32_t can_used);
static void Dcan_WkupAON_Clkctrl(uint32_t can_used);
static void Dcan_PinMux(uint32_t can_used);
static void Dcan_OperatingMode_Init(void);
static void Dcan_MessageRamInit(uint32_t can_used);
static void Dcan_WaitForIfReg(uint32_t baseAddr, uint32_t ifRegNum);
static void Dcan_Invalidate_AllMsgObjs(uint32_t baseAddr);
static void Dcan_InitCfgParams(dcanCfgParams_t *pDcanCfgPrms);
static void Dcan_AutoRetransmitDisable(dcanCfgParams_t *pDcanCfgPrms, bool_t disable);
static void Dcan_Config_TxMsgObjs(uint32_t baseAddr);
static void Dcan_Config_RxMsgObjs(uint32_t baseAddr);

static void Can_Enable_Transceiver(void);
static void Can_Task_Tx(void);
static void Can_Task_Rx(void);

/* CAN TX */
#if(ENABLE_CAN_TX)
static void Dcan_InitCanTxCfgPrms(  dcanMsgObjCfgParams_t *pCanTxCfgPrms,
                                    uint32_t id,
                                    uint8_t id_format
                                    );
#endif

/* CAN RX */
static void Dcan_InitCanRxCfgPrms(  dcanMsgObjCfgParams_t *pCanRxCfgPrms,
                                    uint32_t id,
                                    uint8_t id_format
                                    );


uint8_t stackCan[0x1000];

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         Can_Task_Init
 *
 * @brief      Initialization of Can Task Thread
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Can_Task_Init(void)
{
#if (USE_CAN == 1)
    Error_Block eb;
    Task_Params taskParams;
    Task_Handle task_h;

    CAN_PRINTF("Can task initialization...\n");

    Error_init(&eb);

    /* create main thread (interrupts not enabled in main on BIOS) */
    Task_Params_init(&taskParams);
    taskParams.instance->name = "can_task";
    taskParams.arg0 = NULL;
    taskParams.arg1 = NULL;
    taskParams.stack = stackCan;
    taskParams.stackSize = 0x1000;
    taskParams.affinity = APP_CORE_NUM;
    task_h = Task_create(Can_Task_Thread, &taskParams, &eb);
    if (NULL == task_h)
    {
       CAN_PRINTF("Couldn't create Can task\n");
    }
    else
    {
       CAN_PRINTF("Can thread created successfully\n");
    }
#endif
}


/*
static void Can_Task_Theard_Shutdown(void)
{

}
*/

/***************************************************************************//**
 *
 * @fn         Can_Task_Thread
 *
 * @brief      Can Task Thread
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void Can_Task_Thread(UArg arg0, UArg arg1)
{
    bool_t running = true;

    CAN_PRINTF("Can_Task_Thread entry\n");

    // Init can
    Can_Init(DCAN1_USED);

    while(running)
    {
        Task_sleep(10000 / Clock_tickPeriod); // 10 ms

        TP_Periodic_Task();

        DiagTask();

        /* Can_Task_Tx() each 10 ms */
        Can_Task_Tx();

        /* Can_Task_Rx() each 10 ms */
        Can_Task_Rx();

        /* CanAppl_Timeout() each 100 ms */
        if( count_tick_periodic_can_timeout < 10 )
        {
            count_tick_periodic_can_timeout++;
        }
        else
        {
            count_tick_periodic_can_timeout = 0;
            CanAppl_Timeout();
        }
        
        /* TODO: Check why we can't send all threads to sleep. The ipu1 crashes if we try it
         * We should call 
         * running = MN_Keep_Running();
         */
    }

    //Can_Task_Theard_Shutdown();
}

/***************************************************************************//**
 *
 * @fn         Can_Init
 *
 * @brief      Can Init
 *
 * @param [in] uint32_t can_used
 *
 * @return     void
 *
 ******************************************************************************/
static void Can_Init(uint32_t can_used)
{
    CAN_PRINTF("Can_Init v 14 (3/7/2018) .....\n");

    /* Initialization of variables */
    Dcan_Variables_Init();

    /* Select can baseAddr */
    Dcan_Set_baseAddr(can_used);

    /* WakeUp On for dcan */
    Dcan_WkupAON_Clkctrl(can_used);

    /* pin mux for dcan */
    Dcan_PinMux(can_used);

    /* Init Operating Mode (pin STB of TJA1042) */
    Dcan_OperatingMode_Init();

    /* Set Operting mode in Normal */
    Dcan_OperatingMode_Normal();

    /* DCANMsgRAMInit */
    Dcan_MessageRamInit(can_used);

    /* Reset the DCAN module */
    DCANReset(baseAddr, timeOut);

    /* Start Initialization */
    DCANSetMode(baseAddr, DCAN_MODE_INIT);

    /* Configure CAN Bit Timing */
    #if (USE_CAN_VOLKSWAGEN == 1)
        Dcan_GetCanBitTimeParamas(CAN_BAUDRATE_100Kbps_81, &CanBitTimeParams);
    #endif
    #if (USE_CAN_MOPAR == 1)
        Dcan_GetCanBitTimeParamas(CAN_BAUDRATE_125Kbps_75, &CanBitTimeParams);
    #endif

    DCANSetBitTime(baseAddr, &CanBitTimeParams);

    /* Invalidate all message objects in the message RAM */
    Dcan_Invalidate_AllMsgObjs(baseAddr);

    /* Configure DCAN controller */
    Dcan_InitCfgParams(&CanCfgPrms);
    DCANConfig(baseAddr, &CanCfgPrms);

    /* Configure TX Message Objects */
    Dcan_Config_TxMsgObjs(baseAddr);

    /* Configure RX Message Objects */
    Dcan_Config_RxMsgObjs(baseAddr);

    /* Finish Initialization */
    DCANSetMode(baseAddr, DCAN_MODE_NORMAL);

    /* Enable CAN Transceiver */
    Can_Enable_Transceiver();

    #if(ENABLE_CAN_TX)

    can_sem = Semaphore_create(1, NULL, NULL);

    if(can_sem != NULL)
    {
        flag_can_initialized = true;
    }

    #endif
}

/***************************************************************************//**
 *
 * @fn         Can_Init
 *
 * @brief      Can Init
 *
 * @param [in] uint32_t can_used
 *
 * @return     void
 *
 ******************************************************************************/
static void Can_Enable_Transceiver(void)
{
    /* GPIO_2_7 CAN_EN */
    GPIOModuleEnable(CAN_ENABLE_GPIO_ADDR);
    GPIODirModeSet(CAN_ENABLE_GPIO_ADDR, CAN_ENABLE_GPIO_PIN, GPIO_DIR_OUTPUT);
    GPIOPinWrite(CAN_ENABLE_GPIO_ADDR, CAN_ENABLE_GPIO_PIN, GPIO_PIN_HIGH);
}

/***************************************************************************//**
 *
 * @fn         Can_Initialized
 *
 * @brief      Return true if can initialization finished
 *
 * @param [in] void
 *
 * @return     bool_t
 *
 ******************************************************************************/
bool_t Can_Initialized(void)
{
    return flag_can_initialized;
}

#if(ENABLE_CAN_TX)
/***************************************************************************//**
 *
 * @fn         Can_Tx
 *
 * @brief      Tx a CAN message using the microcontroller CAN driver
 *
 * @param [in] CanTxMsgIdx
 *
 * @return     void
 *
 ******************************************************************************/
static void Can_Tx(uint8_t CanTxMsgIdx)
{
    dcanTxParams_t CanTxPrms;

    /* Clear TX structure */
    memset(&CanTxPrms, 0, sizeof (CanTxPrms));

    /* Use a callback to prepare the data to send */
    if(true == CanAppl_PrepareMsgToSend(CanTxMsg[CanTxMsgIdx].id, CanTxMsg[CanTxMsgIdx].data))
    {
        /* Prepare the CanTxPrms structure */
        memcpy(CanTxPrms.msgData, CanTxMsg[CanTxMsgIdx].data, CanTxMsg[CanTxMsgIdx].dlc);
        CanTxPrms.dataLength = CanTxMsg[CanTxMsgIdx].dlc;

        Dcan_WaitForIfReg(baseAddr,DCAN_TX_IF_REG);  /* Wait for interface to become free */
        DCANTransmitData(baseAddr, DCAN_FIRST_TX_MSG_OBJECTS + CanTxMsgIdx, DCAN_TX_IF_REG, &CanTxPrms, timeOut);
        Dcan_WaitForIfReg(baseAddr,DCAN_TX_IF_REG);  /* Wait for config to be copied to internal message RAM */

        /* Wait for transmit interrupt */
        while (DCANIsTxMsgPending(baseAddr, DCAN_TX_MSG_OBJECT)==TRUE);
    }

}
#endif

/***************************************************************************//**
 *
 * @fn         Can_Task_Tx
 *
 * @brief      Can Task Tx
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void Can_Task_Tx(void)
{
#if(ENABLE_CAN_TX)

    uint8_t CanTxMsgIdx;
    bool_t  CanCurrentNetworkActiveSts = false;
    bool_t  CanAutoRetransmitDisable = false;

    Semaphore_pend(can_sem, BIOS_WAIT_FOREVER);

    CanCurrentNetworkActiveSts = CanAppl_GetNetworkActive_Status();

    if(CanCurrentNetworkActiveSts != CanNetworkActiveSts)
    {
        /*
         * - If network is inactive: Disable automatic retransmission
         * in case of error
         * - If network is active: Enable automatic retransmission
         */
        CanAutoRetransmitDisable = (!CanCurrentNetworkActiveSts) ? true : false;
        Dcan_AutoRetransmitDisable(&CanCfgPrms,CanAutoRetransmitDisable);
        DCANConfig(baseAddr, &CanCfgPrms);
    }

    /* Check if CAN network is active before sending messages */
    if(CanCurrentNetworkActiveSts)
    {
        /* Check for periodic messages */
        for (CanTxMsgIdx=0; CanTxMsgIdx<NUM_CAN_TX_MESSAGE; CanTxMsgIdx++)
        {
            if(CanTxMsg[CanTxMsgIdx].cnt>0)
            {
                CanTxMsg[CanTxMsgIdx].cnt--;
                if (0 == CanTxMsg[CanTxMsgIdx].cnt)
                {
                    Can_Tx(CanTxMsgIdx);

                    /* Prepare the counter for the next round */
                    CanTxMsg[CanTxMsgIdx].cnt = CanTxMsgPeriodicCntr[CanTxMsgIdx];
                }
            }
        }
    }

    CanNetworkActiveSts = CanCurrentNetworkActiveSts;

    Semaphore_post(can_sem);
#endif
}

/***************************************************************************//**
 *
 * @fn         Can_Tx_Message
 *
 * @brief      Send a CAN message
 *
 * @param [in] id
 * @param [in] data
 *
 * @return     void
 *
 ******************************************************************************/
void Can_Tx_Message (uint32_t id, uint8_t *data, uint8_t length)
{
#if(ENABLE_CAN_TX)
    uint8_t CanTxMsgIdx;

    for (CanTxMsgIdx=0; CanTxMsgIdx<NUM_CAN_TX_MESSAGE; CanTxMsgIdx++)
    {
        if(CanTxMsg[CanTxMsgIdx].id == id)
        {
            Semaphore_pend(can_sem, BIOS_WAIT_FOREVER);
            memcpy(CanTxMsg[CanTxMsgIdx].data, data, length);
            CanTxMsg[CanTxMsgIdx].dlc = length;
            #if (TX_CAN_EVENT_IMMEDIATELY)
                Can_Tx(CanTxMsgIdx);
            #else
                CanTxMsg[CanTxMsgIdx].cnt = 1;   /* The next time we call the Can_Task_Tx the message will be sent */
            #endif
            Semaphore_post(can_sem);
            return;
        }
    }
#endif
}

/***************************************************************************//**
 *
 * @fn         Can_Task_Rx
 *
 * @brief      Can Task Rx
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void Can_Task_Rx(void)
{
    uint8_t i;
    uint8_t msgObj;
    dcanRxParams_t CanRxPrms;

    /* Wait for receive interrupt */
    //while (DCANHasRxMsgArrived(baseAddr, DCAN_RX_MSG_OBJECT)==FALSE) ;

    for( i = 0; i < NUM_CAN_RX_MESSAGE; i++)
    {
        msgObj = i + DCAN_FIRST_RX_MSG_OBJECTS;

        if( ( msgObj >= DCAN_FIRST_RX_MSG_OBJECTS )&&( msgObj <= DCAN_LAST_RX_MSG_OBJECTS) )
        {

            if( DCANHasRxMsgArrived(baseAddr, msgObj) == TRUE )
            {
                /* Clear RX structure */
                memset(&CanRxPrms, 0, sizeof (CanRxPrms));

                /* Wait for interface to become free */
                Dcan_WaitForIfReg(baseAddr,DCAN_RX_IF_REG);  /* Wait for interface to become free */
                DCANGetData(baseAddr, msgObj, DCAN_RX_IF_REG, &CanRxPrms, timeOut);
                Dcan_WaitForIfReg(baseAddr,DCAN_RX_IF_REG);  /* Wait for interface to become free */

                CanAppl_ProcessMsg(CanRxPrms);
            }
        }
    }

}

/***************************************************************************//**
 *
 * @fn         Dcan_Variables_Init
 *
 * @brief      Dcan Variables Init
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_Variables_Init(void)
{
#if(0)
    /* Clear bufCanRxMsg structure */
    memset( &bufCanRxMsg[0], 0, sizeof(bufCanRxMsg) );

    i_wr = 0;
    i_rd = 0;
#endif

    CanAppl_Init();

    CanAppl_Timeout_Init();

    TP_Init();

    Diag_Init();
}

/***************************************************************************//**
 *
 * @fn         Dcan_Set_baseAddr
 *
 * @brief      Dcan Set baseAddr
 *
 * @param [in] uint32_t can_used
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_Set_baseAddr(uint32_t can_used)
{
    if( can_used == DCAN1_USED )
    {
        baseAddr = DCAN1_BASE;
    }
    else if( can_used == DCAN2_USED )
    {
        baseAddr = DCAN2_BASE;
    }
}

/***************************************************************************//**
 *
 * @fn         Dcan_WkupAON_Clkctrl
 *
 * @brief      Dcan WkupAON Clkctrl
 *
 * @param [in] uint32_t can_used
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_WkupAON_Clkctrl(uint32_t can_used)
{

}

/***************************************************************************//**
 *
 * @fn         Dcan_PinMux
 *
 * @brief      Dcan PinMux
 *
 * @param [in] uint32_t can_used
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_PinMux(uint32_t can_used)
{

}

/***************************************************************************//**
 *
 * @fn         Dcan_OperatingMode_Init
 *
 * @brief      Dcan_OperatingMode_Init
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_OperatingMode_Init(void)
{
    // Set STB GPIO as output pin
    GPIODirModeSet(0x20000000 + SOC_GPIO2_BASE, STB_GPIO_PIN, GPIO_DIR_OUTPUT);
}

/***************************************************************************//**
 *
 * @fn         Dcan_OperatingMode_Normal
 *
 * @brief      Dcan_OperatingMode_Normal
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
extern void Dcan_OperatingMode_Normal(void)
{
    // gpio2_20 (CAN_STBY) = High -> TJA1042.STB = Low
    // The transceiver can transmit and receive data via the bus lines CANH and CANL
    GPIOPinWrite(0x20000000 + SOC_GPIO2_BASE, STB_GPIO_PIN, GPIO_PIN_HIGH);
}

/***************************************************************************//**
 *
 * @fn         Dcan_OperatingMode_Standby
 *
 * @brief      Dcan_OperatingMode_Standby
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
extern void Dcan_OperatingMode_Standby(void)
{
    // gpio2_20 (CAN_STBY) = Low -> TJA1042.STB = High
    // The transceiver is not able to transmit or correctly receive data via the bus lines
    GPIOPinWrite(0x20000000 + SOC_GPIO2_BASE, STB_GPIO_PIN, GPIO_PIN_LOW);
}

/***************************************************************************//**
 *
 * @fn         Dcan_MessageRamInit
 *
 * @brief      Dcan_MessageRamInit
 *
 * @param [in] uint32_t can_used
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_MessageRamInit(uint32_t can_used)
{
    uint32_t status = 0U;

    switch (can_used)
    {
        case 0U:
            /* Clear the start bit so that pulse is generated
             * when run second time */
            HW_WR_FIELD32(
                (uint32_t) SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE +
                CTRL_CORE_CONTROL_IO_2 + 0x20000000,
                CTRL_CORE_CONTROL_IO_2_DCAN1_RAMINIT_START,
                CTRL_CORE_CONTROL_IO_2_DCAN1_RAMINIT_START_CLEAR);
            /* Set the start bit so that pulse is generated
             * when run second time.
             * CTRL_CORE_CONTROL_IO_2_DCAN1_RAMINIT_START_SET
             * causes Init pulse to happen and SW not needed to write */
            HW_WR_FIELD32(
                (uint32_t) SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE +
                CTRL_CORE_CONTROL_IO_2 + 0x20000000,
                CTRL_CORE_CONTROL_IO_2_DCAN1_RAMINIT_START,
                CTRL_CORE_CONTROL_IO_2_DCAN1_RAMINIT_START_SET);
            status =
                ((uint32_t) 0x1 <<
                 CTRL_CORE_CONTROL_IO_2_DCAN1_RAMINIT_DONE_SHIFT) &
                CTRL_CORE_CONTROL_IO_2_DCAN1_RAMINIT_DONE_MASK;

            while (status !=
                   ((status &
                     HW_RD_REG32(SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE +
                                 CTRL_CORE_CONTROL_IO_2 + 0x20000000))))
            {
                ;
            }

            /* Write one to clear done bit */
            HW_WR_FIELD32(
                (uint32_t) SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE +
                CTRL_CORE_CONTROL_IO_2 + 0x20000000,
                CTRL_CORE_CONTROL_IO_2_DCAN1_RAMINIT_DONE,
                CTRL_CORE_CONTROL_IO_2_DCAN1_RAMINIT_DONE_CLEAR);
            break;

        case 1U:
            /* Clear the start bit so that pulse is generated
             * when run second time */
            HW_WR_FIELD32(
                (uint32_t) SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE +
                CTRL_CORE_CONTROL_IO_2 + 0x20000000,
                CTRL_CORE_CONTROL_IO_2_DCAN2_RAMINIT_START,
                CTRL_CORE_CONTROL_IO_2_DCAN2_RAMINIT_START_CLEAR);
            /* Set the start bit so that pulse is generated
             * when run second time.
             * CTRL_CORE_CONTROL_IO_2_DCAN2_RAMINIT_START_SET
             * causes Init pulse to happen and SW not needed to write */
            HW_WR_FIELD32(
                (uint32_t) SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE +
                CTRL_CORE_CONTROL_IO_2 + 0x20000000,
                CTRL_CORE_CONTROL_IO_2_DCAN2_RAMINIT_START,
                CTRL_CORE_CONTROL_IO_2_DCAN2_RAMINIT_START_SET);
            status =
                ((uint32_t) 0x1 <<
                 CTRL_CORE_CONTROL_IO_2_DCAN2_RAMINIT_DONE_SHIFT) &
                CTRL_CORE_CONTROL_IO_2_DCAN2_RAMINIT_DONE_MASK;

            while (status !=
                   ((status &
                     HW_RD_REG32(SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE +
                                 CTRL_CORE_CONTROL_IO_2 + 0x20000000))))
            {
                ;
            }

            /* Write one to clear done bit */
            HW_WR_FIELD32(
                (uint32_t) SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE +
                CTRL_CORE_CONTROL_IO_2 + 0x20000000,
                CTRL_CORE_CONTROL_IO_2_DCAN2_RAMINIT_DONE,
                CTRL_CORE_CONTROL_IO_2_DCAN2_RAMINIT_DONE_CLEAR);
            break;

        default:
            break;
    }
}

/***************************************************************************//**
 *
 * @fn         Dcan_WaitForIfReg
 *
 * @brief      Dcan_WaitForIfReg
 *
 * @param [in] uint32_t baseAddr
 *             uint32_t ifRegNum
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_WaitForIfReg(uint32_t baseAddr, uint32_t ifRegNum)
{
    do
    {
        if (TRUE != DCANIsIfRegBusy(baseAddr, ifRegNum))
        {
            break;
        }
    }
    while (1);
}

/***************************************************************************//**
 *
 * @fn         Dcan_Invalidate_AllMsgObjs
 *
 * @brief      Dcan_Invalidate_AllMsgObjs
 *
 * @param [in] uint32_t baseAddr
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_Invalidate_AllMsgObjs(uint32_t baseAddr)
{
    uint8_t index   = 0;
    uint32_t regVal = 0;

    for(index = 1; index <= CAN_NUMBERS_OF_MSG_OBJECTS; index++)
    {
        Dcan_WaitForIfReg(baseAddr,DCAN_TX_IF_REG);  /* Wait for interface to become free */
        HW_WR_FIELD32((baseAddr + DCAN_IFARB(DCAN_TX_IF_REG)), DCAN_IFARB_MSGVAL, FALSE); /* Invalidate the message object */

        Dcan_WaitForIfReg(baseAddr,DCAN_TX_IF_REG);  /* Wait for interface to become free */

        regVal = 0x00A00000;
        regVal |= index;

        /* Now transfer from IF to RAM */
        HW_WR_REG32(baseAddr + DCAN_IFCMD(DCAN_TX_IF_REG), regVal);
    }

}

/***************************************************************************//**
 *
 * @fn         Dcan_GetCanBitTimeParamas
 *
 * @brief      Dcan_GetCanBitTimeParamas
 *
 * @param [in] uint32_t canBaudrate
 *             dcanBitTimeParams_t *CanBitTimeParams
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_GetCanBitTimeParamas(uint32_t canBaudrate, dcanBitTimeParams_t *CanBitTimeParams)
{
    switch(canBaudrate)
    {
        case CAN_BAUDRATE_100Kbps_81:
            // BaudRate:100Kbps; Sample Point: 81.3 %
            // BRP = 12
            // TSEG1 = 12
            // TSEG2 = 3
            // SJW = 3
            CanBitTimeParams->baudRatePrescalerExt  = 0;
            CanBitTimeParams->baudRatePrescaler     = 11;
            CanBitTimeParams->timeSegment1          = 11;
            CanBitTimeParams->timeSegment2          = 2;
            CanBitTimeParams->syncJumpWidth         = 2;
            break;

        case CAN_BAUDRATE_102Kbps_72:
            // BaudRate:102Kbps; Sample Point: 72.73 %
            // BRP = 17
            // TSEG1 = 7
            // TSEG2 = 3
            // SJW = 4
            CanBitTimeParams->baudRatePrescalerExt  = 0;
            CanBitTimeParams->baudRatePrescaler     = 16;
            CanBitTimeParams->timeSegment1          = 6;
            CanBitTimeParams->timeSegment2          = 2;
            CanBitTimeParams->syncJumpWidth         = 3;
            break;
		case CAN_BAUDRATE_125Kbps_75:
        default:
            // BaudRate:125Kbps; Sample Point: 75 %
            CanBitTimeParams->baudRatePrescalerExt  = 0;
            CanBitTimeParams->baudRatePrescaler     = 13;
            CanBitTimeParams->timeSegment1          = 6;
            CanBitTimeParams->timeSegment2          = 2;
            CanBitTimeParams->syncJumpWidth         = 3;
            break;

    }
}

/***************************************************************************//**
 *
 * @fn         Dcan_InitCfgParams
 *
 * @brief      Dcan_InitCfgParams
 *
 * @param [in] dcanCfgParams_t *pDcanCfgPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_InitCfgParams(dcanCfgParams_t *pDcanCfgPrms)
{
    pDcanCfgPrms->parityEnable          = FALSE;                 // DCAN_CTL_PMD
    // pDcanCfgPrms->eccModeEnable = FALSE;         ---> This is used only for TDA3xx platform  */
    // pDcanCfgPrms->eccDiagModeEnable;             ---> This is used only for TDA3xx platform  */
    // pDcanCfgPrms->sbeEventEnable;                ---> This is used only for TDA3xx platform  */
    pDcanCfgPrms->intrLine0Enable       = FALSE;                // DCAN_CTL_IE0
    pDcanCfgPrms->intrLine1Enable       = FALSE;                // DCAN_CTL_IE1
    pDcanCfgPrms->stsChangeIntrEnable   = FALSE;                // DCAN_CTL_SIE
    pDcanCfgPrms->errIntrEnable         = FALSE;                // DCAN_CTL_EIE
    pDcanCfgPrms->if1DmaEnable          = FALSE;                // DCAN_CTL_DE1
    pDcanCfgPrms->if2DmaEnable          = FALSE;                // DCAN_CTL_DE2
    pDcanCfgPrms->if3DmaEnable          = FALSE;                // DCAN_CTL_DE3
    pDcanCfgPrms->autoRetransmitDisable = FALSE;                // DCAN_CTL_DAR
    pDcanCfgPrms->autoBusOnEnable       = FALSE;                // DCAN_CTL_ABO
    pDcanCfgPrms->autoBusOnTimerVal     = 0;                    // DCAN_ABOTR_ABO_TIME
    pDcanCfgPrms->testModeEnable        = FALSE ;               // DCAN_CTL_TEST
    pDcanCfgPrms->testMode              = DCAN_TEST_MODE_NONE;  //  DCAN_TEST_MODE_LPBACK |||| DCAN_TEST_MODE_NONE |||| DCAN_TEST_MODE_SILENT ||||
    pDcanCfgPrms->ramAccessEnable       = 0;                    // DCAN_TEST_RDA
}

/***************************************************************************//**
 *
 * @fn         Dcan_InitCfgParams
 *
 * @brief      Dcan_InitCfgParams
 *
 * @param [in] dcanCfgParams_t *pDcanCfgPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_AutoRetransmitDisable(dcanCfgParams_t *pDcanCfgPrms, bool_t disable)
{
    pDcanCfgPrms->autoRetransmitDisable = disable;                 // DCAN_CTL_DAR
}

/***************************************************************************//**
 *
 * @fn         Dcan_Config_TxMsgObjs
 *
 * @brief      Dcan_Config_TxMsgObjs
 *
 * @param [in] uint32_t baseAddr
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_Config_TxMsgObjs(uint32_t baseAddr)
{
#if(ENABLE_CAN_TX)
    dcanMsgObjCfgParams_t    CanTxCfgPrms = {0};
    uint8_t i;
    uint8_t msgObj;

    for( i = 0; i < NUM_CAN_TX_MESSAGE; i++)
    {
        msgObj = i + DCAN_FIRST_TX_MSG_OBJECTS;

        Dcan_WaitForIfReg(baseAddr,DCAN_TX_IF_REG);  /* Wait for interface to become free */
        Dcan_InitCanTxCfgPrms(&CanTxCfgPrms, CanTxMsg[i].id, CanTxMsg[i].id_format);
        DCANConfigMsgObj(baseAddr, msgObj, DCAN_TX_IF_REG, &CanTxCfgPrms);
        Dcan_WaitForIfReg(baseAddr,DCAN_TX_IF_REG);  /* Wait for config to be copied to internal message RAM */
    }
#endif
}

/***************************************************************************//**
 *
 * @fn         Dcan_Config_RxMsgObjs
 *
 * @brief      Dcan_Config_RxMsgObjs
 *
 * @param [in] uint32_t baseAddr
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_Config_RxMsgObjs(uint32_t baseAddr)
{
    dcanMsgObjCfgParams_t    CanRxCfgPrms = {0};
    uint8_t i;
    uint8_t msgObj;

    for( i = 0; i < NUM_CAN_RX_MESSAGE; i++)
    {
        msgObj = i + DCAN_FIRST_RX_MSG_OBJECTS;

        Dcan_WaitForIfReg(baseAddr,DCAN_RX_IF_REG);  /* Wait for interface to become free */
        Dcan_InitCanRxCfgPrms(&CanRxCfgPrms, CanRxMsg[i].id, CanRxMsg[i].id_format);
        DCANConfigMsgObj(baseAddr, msgObj, DCAN_RX_IF_REG, &CanRxCfgPrms);
        Dcan_WaitForIfReg(baseAddr,DCAN_RX_IF_REG);  /* Wait for config to be copied to internal message RAM */

        //CAN_PRINTF("id =  %x  \n",CanRxMsg[i].id);
    }
}



/* CAN TX */
#if(ENABLE_CAN_TX)
/***************************************************************************//**
 *
 * @fn         Dcan_InitCanTxCfgPrms
 *
 * @brief      Dcan_InitCanTxCfgPrms
 *
 * @param [in] dcanMsgObjCfgParams_t *pCanTxCfgPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_InitCanTxCfgPrms(  dcanMsgObjCfgParams_t *pCanTxCfgPrms,
                                    uint32_t id,
                                    uint8_t id_format
                                    )
{
    pCanTxCfgPrms->direction            = DCAN_DIR_TX;

    pCanTxCfgPrms->xIdFlagMask          = 0x1;              // DCAN_IFMSK_MXTD          /* Valid only for RX */
    pCanTxCfgPrms->dirMask              = 0x1;              // DCAN_IFMSK_MDIR          /* Valid only for RX */
    pCanTxCfgPrms->msgIdentifierMask    = 0x1FFFFFFF;       // DCAN_IFMSK_MSK           /* Valid only for RX */

    if( id_format == CAN_EXTENDED )
    {
        pCanTxCfgPrms->xIdFlag              = DCAN_XID_29_BIT;  // DCAN_IFARB_XTD
        pCanTxCfgPrms->msgIdentifier        = id;               // DCAN_IFARB_MSGID

    }else
    {
        pCanTxCfgPrms->xIdFlag              = DCAN_XID_11_BIT;      // DCAN_IFARB_XTD
        pCanTxCfgPrms->msgIdentifier        = (id << 18 );          // DCAN_IFARB_MSGID
    }

    pCanTxCfgPrms->msgValid             = TRUE;             // DCAN_IFARB_MSGVAL

    pCanTxCfgPrms->uMaskUsed            = FALSE;            // DCAN_IFMCTL_UMASK
    pCanTxCfgPrms->intEnable            = FALSE;            // DCAN_IFMCTL_TXIE ; DCAN_IFMCTL_RXIE
    pCanTxCfgPrms->remoteEnable         = FALSE;            // DCAN_IFMCTL_RMTEN
    pCanTxCfgPrms->fifoEOBFlag          = TRUE;             // DCAN_IFMCTL_EOB

}
#endif

/* CAN RX */
/***************************************************************************//**
 *
 * @fn         Dcan_InitCanRxCfgPrms
 *
 * @brief      Dcan_InitCanRxCfgPrms
 *
 * @param [in] dcanMsgObjCfgParams_t *pCanRxCfgPrms
 * @param [in] uint32_t id
 * @param [in] uint8_t id_format
 *
 * @return     void
 *
 ******************************************************************************/
static void Dcan_InitCanRxCfgPrms(  dcanMsgObjCfgParams_t *pCanRxCfgPrms,
                                    uint32_t id,
                                    uint8_t id_format
                                    )
{
    pCanRxCfgPrms->direction            = DCAN_DIR_RX;

    pCanRxCfgPrms->xIdFlagMask          = 0x1;              // DCAN_IFMSK_MXTD          /* Valid only for RX */
    pCanRxCfgPrms->dirMask              = 0x1;              // DCAN_IFMSK_MDIR          /* Valid only for RX */
    pCanRxCfgPrms->msgIdentifierMask    = 0x1FFFFFFF;       // DCAN_IFMSK_MSK           /* Valid only for RX */

    if( id_format == CAN_EXTENDED )
    {
        pCanRxCfgPrms->xIdFlag              = DCAN_XID_29_BIT;  // DCAN_IFARB_XTD
        pCanRxCfgPrms->msgIdentifier        = id;               // DCAN_IFARB_MSGID

    }else
    {
        pCanRxCfgPrms->xIdFlag              = DCAN_XID_11_BIT;      // DCAN_IFARB_XTD
        pCanRxCfgPrms->msgIdentifier        = (id << 18 );          // DCAN_IFARB_MSGID
    }

    pCanRxCfgPrms->msgValid             = TRUE;             // DCAN_IFARB_MSGVAL

    pCanRxCfgPrms->uMaskUsed            = FALSE;            // DCAN_IFMCTL_UMASK
    pCanRxCfgPrms->intEnable            = FALSE;            // DCAN_IFMCTL_TXIE ; DCAN_IFMCTL_RXIE
    pCanRxCfgPrms->remoteEnable         = FALSE;            // DCAN_IFMCTL_RMTEN
    pCanRxCfgPrms->fifoEOBFlag          = TRUE;             // DCAN_IFMCTL_EOB

}
