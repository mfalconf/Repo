#ifndef __SAR_RAM_HPP__
#define __SAR_RAM_HPP__

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include <stdbool.h>
#include <stdint.h>

#include <common_definitions.h>

#if defined(IPU_1_BUILD)
#include <xdc/std.h>
#endif /*  */

#define   SAR_RAM_VERSION_DIFFERS_ERROR     (-1024)

#define   SAR_RAM_INVALID_TOUCH_PRESS_X     (0xFFFF)
#define   SAR_RAM_INVALID_TOUCH_PRESS_Y     (0xFFFF)
#define   SAR_RAM_IS_TOUCH_VALID(x, y)      ((x != SAR_RAM_INVALID_TOUCH_PRESS_X) && (y != SAR_RAM_INVALID_TOUCH_PRESS_Y))

/** Reusing definition of car models in shared data module */
typedef Shadow_CarModel_T sar_ram_car_model_en;

/**
 * @brief Initialize the SAR RAM module
 * @note Possible return codes:
 *  - EACCESS -> SAR RAM module has already been initialized
 *  - SAR_RAM_VERSION_DIFFERS_ERROR -> SAR RAM module has different version between IPU 1 and A15 cores
 *  - Others -> Some internal error from linux methods
 * 
 * @return int On success 0 is returned, otherwise an error code is returned
 */
int sar_ram_init(void);

/**
 * @brief Deinitialize the SAR RAM module
 * @note Possible return codes:
 *  - EACCESS -> SAR RAM module has already been deinitialized
 *  - Others -> Some internal error from linux methods
 * 
 * @return int On success 0 is returned, otherwise an error code is returned
 */
int sar_ram_deinit(void);

/**
 * @brief Get the current RVC state of the vehicle
 * @note The value returned by this method has already debounced the RVC
 * signal and the RVC layout at this point, if returned true, is already
 * being shown on the display, so it is safe to use this signal as a trigger
 * point to inhibit the touch of the display when active
 * 
 * @return true RVC is active
 * @return false RVC is not active
 */
bool sar_ram_get_pdc_key_state(void);

/**
 * @brief Get the current hatch state of the vehicle
 * 
 * @return true Hatch is opened
 * @return false Hatch is not opened
 */
bool sar_ram_get_hatch_opened(void);

/**
 * @brief Get the current speed of the vehicle
 * 
 * @return uint32_t Current speed of the vehicle in Km/h
 */
uint32_t sar_ram_get_speed(void);

/**
 * @brief Get the current stop splash state
 * 
 * @return true A15 core signaled that splash needs to be stopped
 * @return false A15 core signaled that splash does not need to be stopped
 */
bool sar_ram_get_stop_splash(void);

/**
 * @brief Get the current touch inhibited state
 * 
 * @return true Touch is currently being inhibited by the A15 core
 * @return false Touch is currently not being inhibited by the A15 core
 */
bool sar_ram_get_touch_inhibited(void);

/**
 * @brief Check if the RVC service has already started
 * 
 * @return true The RVC service in the A15 core is available
 * @return false The RVC service in the A15 core is not available yet
 */
bool sar_ram_get_rvc_service_started(void);

/**
 * @brief Set the shared RAM coordinates for the pressed button
 * 
 * @param x X coordinate
 * @param y Y coordinate
 */
void sar_ram_set_touch_press(uint16_t x, uint16_t y);

/**
 * @brief Get the shared RAM coordinates for the pressed button
 * 
 * @param x Pointer to X coordinate
 * @param y Pointer to Y coordinate
 */
void sar_ram_get_touch_press(uint16_t *x, uint16_t *y);

/**
 * @brief Get the detected car model
 * 
 * @return sar_ram_car_model_en Detected car model
 */
sar_ram_car_model_en sar_ram_get_car_model(void);

#if defined(IPU_1_BUILD)

/**
 * @brief Get the *simulated* RVC CAN signal
 * 
 * @return true Simulated RVC is active
 * @return false Simulated RVC is inactive
 */
bool sar_ram_dbg_get_rvc_can(void);

/**
 * @brief Get the *simulated* PDC CAN signal
 * 
 * @return true Simulated PDC is active
 * @return false Simulated PDC is inactive
 */
bool sar_ram_dbg_get_pdc_can(void);

/**
 * @brief Get the enable flag of simulated parking sensors
 * @note If this method returns true, the HMI shall use the information
 * of the parking sensors from the method @a sar_ram_dbg_get_parking_sensors
 * to get the *simulated* parking sensors
 * 
 * @return true Simulated parking sensors enabled
 * @return false Simulated parking sensors disabled
 */
bool sar_ram_dbg_get_simulated_parking_sensors(void);

/**
 * @brief Get the enable flag of simulated speed via SAR RAM
 * @note If this method returns true, the HMI shall use the information
 * of the vehicle speed from the method @a sar_ram_dbg_get_speed to get
 * the *simulated* vehicle speed
 * 
 * @return true Simulated speed enabled
 * @return false Simulated speed disabled
 */
bool sar_ram_dbg_get_simulated_speed_enable(void);

/**
 * @brief Obtain the simulated parking sensors
 * 
 * @param front_sensors Array to place the front parking sensors information
 * @param rear_sensors Array to place the rear parking sensors information
 */
void sar_ram_dbg_get_parking_sensors(UInt8 *front_sensors, UInt8 *rear_sensors);

/**
 * @brief Set a new RVC active state
 * 
 * @param rvc_state Desired RVC active state
 */
void sar_ram_set_rvc_active(bool rvc_state);

/**
 * @brief Set a new hatch opened state
 * 
 * @param hatch_state Desired hatch opened state
 */
void sar_ram_set_hatch_opened(bool hatch_state);

/**
 * @brief Set a new PDC key state
 * 
 * @param speed Desired PDC key state
 */
void sar_ram_set_pdc_key_state(bool pdc_key_state);

/**
 * @brief Set a new speed
 * 
 * @param speed Desired speed
 */
void sar_ram_set_speed(uint32_t speed);

/**
 * @brief Set the information of the parking sensors
 * 
 * @param front_sensors Information of the front parking sensors
 * @param rear_sensors Information of the rear parking sensors
 */
void sar_ram_set_parking_sensors(UInt8 *front_sensors, UInt8 *rear_sensors);

/**
 * @brief Set the detected car model
 * 
 * @param car_model Detected car model
 */
void sar_ram_set_car_model(sar_ram_car_model_en car_model);

#else

/* A15 only functions */

/**
 * @brief Set a new stop splash state
 * 
 * @param stop_splash Desired stop splash state
 */
void sar_ram_set_stop_splash(bool stop_splash);

/**
 * @brief Set a new touch inhibited state
 * 
 * @param touch_inhibited Desired touch inhibited state
 */
void sar_ram_set_touch_inhibited(bool touch_inhibited);

/** Signal that the RVC service in the A15 core has started */
void sar_ram_set_rvc_service_started();

#endif /* IPU_1_BUILD */

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif // __SAR_RAM_HPP__
