#include <sar_ram.h>

#include <errno.h>
#include <stddef.h>

#if defined(IPU_1_BUILD)

#include <xdc/std.h>
#include <ti/csl/hw_types.h>

#else

#include <fcntl.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#endif /* IPU_1_BUILD */

/* Module definition to avoid miss-syncrhonized issues between A15 and IPU compilations */
// IMPORTANT: Remember to modify this version with each modification of this module
// NOTE: The highes byte in this macro is defined as "5A" only to try to avoid the possibility
// of RAM being initialized at the same value as the version
#define   SAR_RAM_MODULE_VERSION            (0x5A000005)

#define   SAR_RAM_IPU_1_WRITE_REG_AMOUNT    (4)
#define   SAR_RAM_A15_WRITE_REG_AMOUNT      (4)

/* Available registers for SAR RAM module */
#define   SAR_RAM_VERSION_REG               (0x4AE2600C)
#define   SAR_RAM_IPU_1_WRITE_REG_0         (0x4AE26010)
  #define   SAR_RAM_RVC_REG                   (0)
  #define   SAR_RAM_RVC_MASK                  (0x80000000)
  #define   SAR_RAM_HATCH_REG                 (0)
  #define   SAR_RAM_HATCH_MASK                (0x40000000)
  #define   SAR_RAM_PDC_KEY_REG               (0)
  #define   SAR_RAM_PDC_KEY_MASK              (0x20000000)
  #define   SAR_RAM_CAR_MODEL_REG             (0)
  #define   SAR_RAM_CAR_MODEL_BIT_OFFSET      (8)
  #define   SAR_RAM_CAR_MODEL_MASK            (0x000000FF << SAR_RAM_CAR_MODEL_BIT_OFFSET)
  #define   SAR_RAM_SPEED_REG                 (0)
  #define   SAR_RAM_SPEED_BIT_OFFSET          (0)
  #define   SAR_RAM_SPEED_MASK                (0x000000FF << SAR_RAM_SPEED_BIT_OFFSET)
// The following SAR RAM register is used to simulate certain CAN signals
// to the IPU 1. Use only in DEBUG mode
#define   SAR_RAM_IPU_1_WRITE_REG_1         (0x4AE26014)
  #define   SAR_RAM_RVC_CAN_REG               (1)
  #define   SAR_RAM_RVC_CAN_MASK              (0x00000001)
  #define   SAR_RAM_PDC_CAN_REG               (1)
  #define   SAR_RAM_PDC_CAN_MASK              (0x00000002)
  #define   SAR_RAM_PARKING_SIMULATED_REG     (1)
  #define   SAR_RAM_PARKING_SIMULATED_MASK    (0x00000004)
  #define   SAR_RAM_SPEED_SIMULATED_REG       (1)
  #define   SAR_RAM_SPEED_SIMULATED_MASK      (0x00000008)
// The following two registers are multipurpouse, depending on the flags of the above register
#define   SAR_RAM_IPU_1_WRITE_REG_2         (0x4AE26018)
  #define   SAR_RAM_FRONT_PARKING_REG         (2)
#define   SAR_RAM_IPU_1_WRITE_REG_3         (0x4AE2601C)
  #define   SAR_RAM_REAR_PARKING_REG          (3)

#define   SAR_RAM_A15_WRITE_REG_0           (0x4AE26020)
  #define   SAR_RAM_STOP_SPLASH_REG           (0)
  #define   SAR_RAM_STOP_SPLASH_MASK          (0x00000001)
  #define   SAR_RAM_TOUCH_INHIBITED_REG       (0)
  #define   SAR_RAM_TOUCH_INHIBITED_MASK      (0x00000002)
  #define   SAR_RAM_RVC_AVAILABLE_REG         (0)
  #define   SAR_RAM_RVC_AVAILABLE_MASK        (0x00000004)
#define   SAR_RAM_A15_WRITE_REG_1           (0x4AE26024)
#define   SAR_RAM_A15_WRITE_REG_2           (0x4AE26028)
#define   SAR_RAM_A15_WRITE_REG_3           (0x4AE2602C)

#define   SAR_RAM_SHARED_TOUCH_PRESSED_REG  (0x4AE26030)
  #define   SAR_RAM_TOUCH_X_MASK            (0xFFFF)
  #define   SAR_RAM_TOUCH_X_OFFSET          (0)
  #define   SAR_RAM_TOUCH_Y_MASK            (0xFFFF)
  #define   SAR_RAM_TOUCH_Y_OFFSET          (16)

#define   SAR_RAM_PARKING_SENSORS_NUM       (4)

#define   SAR_RAM_INVALID_TOUCH_PRESS       ((SAR_RAM_INVALID_TOUCH_PRESS_X << SAR_RAM_TOUCH_X_OFFSET) | (SAR_RAM_INVALID_TOUCH_PRESS_Y << SAR_RAM_TOUCH_Y_OFFSET))

/* Macro definitions */
#if defined(IPU_1_BUILD)

#define   IPU_L4_OFFSET                     (0x20000000)
#define   SAR_RAM_READ_REG(reg)             (uint32_t)(HW_RD_REG32(IPU_L4_OFFSET + (uint32_t) (reg)))
#define   SAR_RAM_WRITE_REG(reg, value)     HW_WR_REG32(IPU_L4_OFFSET + (uint32_t) (reg), value)

#else

#define   SAR_RAM_READ_REG(reg)             (uint32_t)((*((uint32_t *) (reg))))
#define   SAR_RAM_WRITE_REG(reg, value)     (*((uint32_t *) (reg))) = (uint32_t) (value)

#endif /* IPU_1_BUILD */

/** Flag to mark if module was initialized or not */
static bool __initialized = false;

/** Pointer to module version register */
static void *__sar_ram_module_version_register;

/** Pointers to the IPU 1 write registers */
static void *__sar_ram_ipu_1_write_regs[SAR_RAM_IPU_1_WRITE_REG_AMOUNT];

/** Pointers to the A15 write registers */
static void *__sar_ram_a15_write_regs[SAR_RAM_A15_WRITE_REG_AMOUNT];

/** Pointer to the shared touch press register */
static void *__sar_ram_shared_touch_press_reg;

/**
 * @brief Set a mask (set ones of mask) of a register
 * @note This is kind of a "bit/s set"
 * 
 * @param reg Desired register
 * @param mask Desired mask
 */
static void __sar_ram_set_register_mask(void *reg, uint32_t mask)
{
  SAR_RAM_WRITE_REG(reg, SAR_RAM_READ_REG(reg) | mask);
}

/**
 * @brief Clear a mask (clear ones of mask) of a register
 * @note This is kind of a "bit/s clear"
 * 
 * @param reg Desired register
 * @param mask Desired mask
 */
static void __sar_ram_clear_register_mask(void *reg, uint32_t mask)
{
  SAR_RAM_WRITE_REG(reg, SAR_RAM_READ_REG(reg) & ~mask);
}

#if !defined(IPU_1_BUILD)

#define MEMORY_DEVICE       "/dev/mem"

#define SHARED_MAP_SIZE     (4096UL)
#define SHARED_MAP_MASK     (SHARED_MAP_SIZE - 1)

/** Shared memory file descriptor */
static int __shared_mem_fd;

/** Base address for the memory mapping */
static void *__map_base;

/**
 * @brief Shared memory initialization for A15 core
 * 
 * @return int On success 0 is returned, respective error number
 * is returned otherwise
 */
static int __ipu_shared_mem_init(void)
{
  off_t target = SAR_RAM_VERSION_REG;
  
  __shared_mem_fd = open(MEMORY_DEVICE, O_RDWR | O_SYNC);
  if (__shared_mem_fd < 0)
  {
      return -errno;
  }

  __map_base = mmap(0, SHARED_MAP_SIZE, PROT_READ | PROT_WRITE, 
                  MAP_SHARED, __shared_mem_fd, target & ~SHARED_MAP_MASK);
  if (__map_base == (void *) -1)
  {
      close(__shared_mem_fd);
      return -errno;
  }

  __sar_ram_module_version_register = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_VERSION_REG & SHARED_MAP_MASK));
  
  __sar_ram_ipu_1_write_regs[0] = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_IPU_1_WRITE_REG_0 & SHARED_MAP_MASK));
  __sar_ram_ipu_1_write_regs[1] = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_IPU_1_WRITE_REG_1 & SHARED_MAP_MASK));
  __sar_ram_ipu_1_write_regs[2] = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_IPU_1_WRITE_REG_2 & SHARED_MAP_MASK));
  __sar_ram_ipu_1_write_regs[3] = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_IPU_1_WRITE_REG_3 & SHARED_MAP_MASK));
  
  __sar_ram_a15_write_regs[0] = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_A15_WRITE_REG_0 & SHARED_MAP_MASK));
  __sar_ram_a15_write_regs[1] = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_A15_WRITE_REG_1 & SHARED_MAP_MASK));
  __sar_ram_a15_write_regs[2] = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_A15_WRITE_REG_2 & SHARED_MAP_MASK));
  __sar_ram_a15_write_regs[3] = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_A15_WRITE_REG_3 & SHARED_MAP_MASK));

  __sar_ram_shared_touch_press_reg = (void *)(((uint8_t *)(__map_base)) + (SAR_RAM_SHARED_TOUCH_PRESSED_REG & SHARED_MAP_MASK));

  return 0;
}

/**
 * @brief Shared memory deinitialization for A15 core
 * 
 * @return int On success 0 is returned, respective error number
 * is returned otherwise
 */
static int __ipu_shared_mem_deinit(void)
{
  int ret, error = 0;

  if (__map_base > 0)
  {
      ret = munmap(__map_base, SHARED_MAP_SIZE);
      if (ret < 0)
      {
          error = -1;
      }
  }

  if (__shared_mem_fd > 0)
  {
      ret = close(__shared_mem_fd);
      if (ret < 0)
      {
          error = -1;
      }
  }

  __sar_ram_module_version_register = NULL;

  __sar_ram_ipu_1_write_regs[0] = NULL;
  __sar_ram_ipu_1_write_regs[1] = NULL;
  __sar_ram_ipu_1_write_regs[2] = NULL;
  __sar_ram_ipu_1_write_regs[3] = NULL;

  __sar_ram_a15_write_regs[0] = NULL;
  __sar_ram_a15_write_regs[1] = NULL;
  __sar_ram_a15_write_regs[2] = NULL;
  __sar_ram_a15_write_regs[3] = NULL;

  __sar_ram_shared_touch_press_reg = NULL;

  return error;
}

#endif /* ! IPU_1_BUILD */

int sar_ram_init(void)
{
  uint32_t i, ret = 0;

  if (__initialized)
    return -EACCES;

  /* Pre-initialize all internal pointer to NULL */
  for (i = 0; i < sizeof(__sar_ram_ipu_1_write_regs) / sizeof(__sar_ram_ipu_1_write_regs[0]); i++)
    __sar_ram_ipu_1_write_regs[i] = NULL;
  
  for (i = 0; i < sizeof(__sar_ram_a15_write_regs) / sizeof(__sar_ram_a15_write_regs[0]); i++)
    __sar_ram_a15_write_regs[i] = NULL;

#if defined(IPU_1_BUILD)

  __sar_ram_module_version_register = (void *) (SAR_RAM_VERSION_REG);

  __sar_ram_ipu_1_write_regs[0] = (void *) (SAR_RAM_IPU_1_WRITE_REG_0);
  __sar_ram_ipu_1_write_regs[1] = (void *) (SAR_RAM_IPU_1_WRITE_REG_1);
  __sar_ram_ipu_1_write_regs[2] = (void *) (SAR_RAM_IPU_1_WRITE_REG_2);
  __sar_ram_ipu_1_write_regs[3] = (void *) (SAR_RAM_IPU_1_WRITE_REG_3);

  __sar_ram_a15_write_regs[0] = (void *) (SAR_RAM_A15_WRITE_REG_0);
  __sar_ram_a15_write_regs[1] = (void *) (SAR_RAM_A15_WRITE_REG_1);
  __sar_ram_a15_write_regs[2] = (void *) (SAR_RAM_A15_WRITE_REG_2);
  __sar_ram_a15_write_regs[3] = (void *) (SAR_RAM_A15_WRITE_REG_3);

  __sar_ram_shared_touch_press_reg = (void *) (SAR_RAM_SHARED_TOUCH_PRESSED_REG);

  /* The IPU 1 MUST write the module version in the corresponding register in order for the A15 to check it */
  SAR_RAM_WRITE_REG(__sar_ram_module_version_register, SAR_RAM_MODULE_VERSION);

  /* Clean all the registers */
  SAR_RAM_WRITE_REG(__sar_ram_ipu_1_write_regs[0], 0x00000000);
  SAR_RAM_WRITE_REG(__sar_ram_ipu_1_write_regs[1], 0x00000000);
  SAR_RAM_WRITE_REG(__sar_ram_ipu_1_write_regs[2], 0x00000000);
  SAR_RAM_WRITE_REG(__sar_ram_ipu_1_write_regs[3], 0x00000000);

  SAR_RAM_WRITE_REG(__sar_ram_a15_write_regs[0], 0x00000000);
  SAR_RAM_WRITE_REG(__sar_ram_a15_write_regs[1], 0x00000000);
  SAR_RAM_WRITE_REG(__sar_ram_a15_write_regs[2], 0x00000000);
  SAR_RAM_WRITE_REG(__sar_ram_a15_write_regs[3], 0x00000000);

  SAR_RAM_WRITE_REG(__sar_ram_shared_touch_press_reg, SAR_RAM_INVALID_TOUCH_PRESS);

#else

  ret = __ipu_shared_mem_init();

  if (0 == ret)
  {
    uint32_t version_reg = SAR_RAM_READ_REG(__sar_ram_module_version_register);

    if (version_reg != SAR_RAM_MODULE_VERSION)
      ret = SAR_RAM_VERSION_DIFFERS_ERROR;
  }

#endif /* IPU_1_BUILD */
  
  if (0 == ret)
    __initialized = true;

  return ret;
}

int sar_ram_deinit(void)
{
  int i, ret = 0;

  if (!__initialized)
    return -EACCES;

#if defined(IPU_1_BUILD)

  __sar_ram_module_version_register = NULL;

  __sar_ram_ipu_1_write_regs[0] = NULL;
  __sar_ram_ipu_1_write_regs[1] = NULL;
  __sar_ram_ipu_1_write_regs[2] = NULL;
  __sar_ram_ipu_1_write_regs[3] = NULL;

  __sar_ram_a15_write_regs[0] = NULL;
  __sar_ram_a15_write_regs[1] = NULL;
  __sar_ram_a15_write_regs[2] = NULL;
  __sar_ram_a15_write_regs[3] = NULL;

  __sar_ram_shared_touch_press_reg = NULL;

#else

  ret = __ipu_shared_mem_deinit();

#endif /* IPU_1_BUILD */
  
  if (0 == ret)
    __initialized = false;

  return ret;
}

bool sar_ram_get_rvc_active(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_RVC_REG])  & SAR_RAM_RVC_MASK) == SAR_RAM_RVC_MASK;
}

bool sar_ram_get_hatch_opened(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_HATCH_REG])  & SAR_RAM_HATCH_MASK) == SAR_RAM_HATCH_MASK;
}

bool sar_ram_get_pdc_key_state(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_PDC_KEY_REG])  & SAR_RAM_PDC_KEY_MASK) == SAR_RAM_PDC_KEY_MASK;
}

uint32_t sar_ram_get_speed(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_SPEED_REG])  & SAR_RAM_SPEED_MASK) >> SAR_RAM_SPEED_BIT_OFFSET;
}

bool sar_ram_get_stop_splash(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_a15_write_regs[SAR_RAM_STOP_SPLASH_REG])  & SAR_RAM_STOP_SPLASH_MASK) == SAR_RAM_STOP_SPLASH_MASK;
}

bool sar_ram_get_touch_inhibited(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_a15_write_regs[SAR_RAM_TOUCH_INHIBITED_REG])  & SAR_RAM_TOUCH_INHIBITED_MASK) == SAR_RAM_TOUCH_INHIBITED_MASK;
}

bool sar_ram_get_rvc_service_started(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_a15_write_regs[SAR_RAM_RVC_AVAILABLE_REG])  & SAR_RAM_RVC_AVAILABLE_MASK) == SAR_RAM_RVC_AVAILABLE_MASK;
}

void sar_ram_set_touch_press(uint16_t x, uint16_t y)
{
  SAR_RAM_WRITE_REG(__sar_ram_shared_touch_press_reg, (x << SAR_RAM_TOUCH_X_OFFSET) | (y << SAR_RAM_TOUCH_Y_OFFSET));
}

void sar_ram_get_touch_press(uint16_t *x, uint16_t *y)
{
  uint32_t reg = SAR_RAM_READ_REG(__sar_ram_shared_touch_press_reg);
  *x = (reg & (SAR_RAM_TOUCH_X_MASK << SAR_RAM_TOUCH_X_OFFSET)) >> SAR_RAM_TOUCH_X_OFFSET;
  *y = (reg & (SAR_RAM_TOUCH_Y_MASK << SAR_RAM_TOUCH_Y_OFFSET)) >> SAR_RAM_TOUCH_Y_OFFSET;
}

sar_ram_car_model_en sar_ram_get_car_model(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_CAR_MODEL_REG])  & SAR_RAM_CAR_MODEL_MASK) >> SAR_RAM_CAR_MODEL_BIT_OFFSET;
}

#if defined(IPU_1_BUILD)

bool sar_ram_dbg_get_rvc_can(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_RVC_CAN_REG])  & SAR_RAM_RVC_CAN_MASK) == SAR_RAM_RVC_CAN_MASK;
}

bool sar_ram_dbg_get_pdc_can(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_PDC_CAN_REG])  & SAR_RAM_PDC_CAN_MASK) == SAR_RAM_PDC_CAN_MASK;
}

bool sar_ram_dbg_get_simulated_parking_sensors(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_PARKING_SIMULATED_REG]) & SAR_RAM_PARKING_SIMULATED_MASK) == SAR_RAM_PARKING_SIMULATED_MASK;
}

bool sar_ram_dbg_get_simulated_speed_enable(void)
{
  return (SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_SPEED_SIMULATED_REG]) & SAR_RAM_SPEED_SIMULATED_MASK) == SAR_RAM_SPEED_SIMULATED_MASK;
}

void sar_ram_dbg_get_parking_sensors(UInt8 *front_sensors, UInt8 *rear_sensors)
{
  int i;
  UInt32 front_reg = SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_FRONT_PARKING_REG]);
  UInt32 rear_reg = SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_REAR_PARKING_REG]);

  for (i = 0; i < SAR_RAM_PARKING_SENSORS_NUM; i++)
  {
    front_sensors[i] = (front_reg & (0xFF << (i * 8))) >> (i * 8);
    rear_sensors[i] = (rear_reg & (0xFF << (i * 8))) >> (i * 8);
  }
}

/* IPU 1 only functions */

void sar_ram_set_rvc_active(bool rvc_state)
{
  rvc_state ? __sar_ram_set_register_mask(__sar_ram_ipu_1_write_regs[SAR_RAM_RVC_REG], SAR_RAM_RVC_MASK) : 
              __sar_ram_clear_register_mask(__sar_ram_ipu_1_write_regs[SAR_RAM_RVC_REG], SAR_RAM_RVC_MASK);
}

void sar_ram_set_hatch_opened(bool hatch_state)
{
  hatch_state ? __sar_ram_set_register_mask(__sar_ram_ipu_1_write_regs[SAR_RAM_HATCH_REG], SAR_RAM_HATCH_MASK) : 
                __sar_ram_clear_register_mask(__sar_ram_ipu_1_write_regs[SAR_RAM_HATCH_REG], SAR_RAM_HATCH_MASK);
}

void sar_ram_set_pdc_key_state(bool pdc_key_state)
{
  pdc_key_state ? __sar_ram_set_register_mask(__sar_ram_ipu_1_write_regs[SAR_RAM_PDC_KEY_REG], SAR_RAM_PDC_KEY_MASK) : 
                  __sar_ram_clear_register_mask(__sar_ram_ipu_1_write_regs[SAR_RAM_PDC_KEY_REG], SAR_RAM_PDC_KEY_MASK);
}

void sar_ram_set_speed(uint32_t speed)
{
  uint32_t reg = SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_SPEED_REG]);
  reg &= ~SAR_RAM_SPEED_MASK;
  reg |= (speed & (SAR_RAM_SPEED_MASK >> SAR_RAM_SPEED_BIT_OFFSET)) << SAR_RAM_SPEED_BIT_OFFSET;
  SAR_RAM_WRITE_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_SPEED_REG], reg);
}

void sar_ram_set_parking_sensors(UInt8 *front_sensors, UInt8 *rear_sensors)
{
  UInt32 front = 0, rear = 0;
  UInt32 i;

  for (i = 0; i < SAR_RAM_PARKING_SENSORS_NUM; i++)
  {
    front |= front_sensors[i] << (8 * i);
    rear |= rear_sensors[i] << (8 * i);
  }
}

void sar_ram_set_car_model(sar_ram_car_model_en car_model)
{
  if (car_model == CAR_MODEL_INVALID)
  {
    return;
  }

  uint32_t reg = SAR_RAM_READ_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_CAR_MODEL_REG]);
  reg &= ~SAR_RAM_CAR_MODEL_MASK;
  reg |= (car_model & (SAR_RAM_CAR_MODEL_MASK >> SAR_RAM_CAR_MODEL_BIT_OFFSET)) << SAR_RAM_CAR_MODEL_BIT_OFFSET;
  SAR_RAM_WRITE_REG(__sar_ram_ipu_1_write_regs[SAR_RAM_CAR_MODEL_REG], reg);
}

#else

/* A15 only functions */

void sar_ram_set_stop_splash(bool stop_splash)
{
  stop_splash ? __sar_ram_set_register_mask(__sar_ram_a15_write_regs[SAR_RAM_STOP_SPLASH_REG], SAR_RAM_STOP_SPLASH_MASK) : 
                __sar_ram_clear_register_mask(__sar_ram_a15_write_regs[SAR_RAM_STOP_SPLASH_REG], SAR_RAM_STOP_SPLASH_MASK);
}

void sar_ram_set_touch_inhibited(bool touch_inhibited)
{
  touch_inhibited ? __sar_ram_set_register_mask(__sar_ram_a15_write_regs[SAR_RAM_TOUCH_INHIBITED_REG], SAR_RAM_TOUCH_INHIBITED_MASK) : 
                __sar_ram_clear_register_mask(__sar_ram_a15_write_regs[SAR_RAM_TOUCH_INHIBITED_REG], SAR_RAM_TOUCH_INHIBITED_MASK);
}

void sar_ram_set_rvc_service_started()
{
  __sar_ram_set_register_mask(__sar_ram_a15_write_regs[SAR_RAM_RVC_AVAILABLE_REG], SAR_RAM_RVC_AVAILABLE_MASK);
}

#endif /* IPU_1_BUILD */
