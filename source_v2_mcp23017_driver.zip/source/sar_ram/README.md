# SAR RAM module

This project is intended to provide fast communication between the A15 core and the IPU 1 core, by using certain SAR RAM registers that both cores can access to. Depending in which core the project is being built, some functions will be accessible and others will not.