/*
 * famp_pm.h
 *
 *  Created on: May 9, 2018
 *      Author: ggabriel
 */

#ifndef PM_INCLUDE_LOG_DEBUG_H_
#define PM_INCLUDE_LOG_DEBUG_H_

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

/* package header files */
#include <ti/ipc/Ipc.h>
#include <ti/ipc/MessageQ.h>
#include <ti/ipc/MultiProc.h>

#include <standard.h>

//#include "famp_com.h"
#include "famp_pm_messages.h"
#include "famp_queue_manager.h"
#include "famp_pm_types.h"

#include "comm_pmic_65919_types.h"
#include "battery_monitor.h"

#include "console.h"

void FAMP_PM_Force_Cold_Start (void);
bool_t FAMP_PM_Is_IgnitionOn (void);
bool_t FAMP_PM_Is_IpuRunning(void);
void FAMP_PM_Task_Init (void);

void FAMP_PM_Inform_RvcPdc_View_On(bool_t state);
void FAMP_PM_Turn_On_Screen(void);
void FAMP_PM_Turn_Off_Screen(void);

/* Function to know if ipu1 and A15 core finished their sync process*/
bool FAMP_PM_isSyncFinished (void);
pmIgnitionLineState_t getIgnitionLine (void);
pmCanState_t getIgnitionCan (void);

#endif /* PM_INCLUDE_LOG_DEBUG_H_ */
