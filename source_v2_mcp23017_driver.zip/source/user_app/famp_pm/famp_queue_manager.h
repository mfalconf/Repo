/*
 * pm_queue_manager.h
 *
 *  Created on: May 29, 2018
 *      Author: ggabriel
 */

#ifndef SOURCE_INC_FAMP_QUEUE_MANAGER_H_
#define SOURCE_INC_FAMP_QUEUE_MANAGER_H_

#include "famp_pm_types.h"

#define PM_MESSAGE_SERVER_QUEUE_NAME   "pm_queue_M4_server"
#define PM_MESSAGE_CLIENT_QUEUE_NAME   "pm_queue_A15_server"

void PM_QUEUE_Init();
int32_t PM_QUEUE_PutMsg (MessageQ_QueueId msgQId, uint16_t heapId, uint16_t id,  int8_t* data, uint32_t length);
int PM_QUEUE_Init_Server();
int PM_QUEUE_Init_Client();
void PM_QUEUE_ShutDown();
pmQueueStatus_t PM_QEUEUE_ReceiveMessage_Server(pSBMsg_t *pRxMsg);
void PM_QUEUE_SendMessage_Client(char * msg, int len);
int PM_QUEUE_Wait_For_A15();
int PM_QUEUE_Init_A15();
void PM_QEUEUE_FreeMessage(SBMsg *pRxMsg);


#endif /* SOURCE_INC_FAMP_QUEUE_MANAGER_H_ */
