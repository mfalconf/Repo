/*
 * pm_queue_manager.c
 *
 *  Created on: May 28, 2018
 *      Author: ggabriel
 */

#include <stdio.h>
#include <stdlib.h>
#include <standard.h>
#include <errno.h>
#include <string.h>

#include "famp_pm.h"
#include "crc.h"
#include "console.h"

#ifdef CORE_M4
#include <ti/ipc/remoteproc/Resource.h>
#include <ti/ipc/remoteproc/rsc_types.h>
#include <ti/ipc/ipcmgr/IpcMgr.h>
#endif

/* IPC Headers */
#ifdef CORE_A15
#include <ti/ipc/Std.h>
#include <ti/ipc/Ipc.h>
#include <ti/ipc/MessageQ.h>
#include <ti/ipc/MultiProc.h>
#endif



#define SERVER_HEAPID       0

#define SB_MAX_CLIENTS      1

#ifdef CORE_A15
    #define pm_queue_sleep_ms(x) usleep(x * 1000);
#endif

//TODO: change this!
#ifdef CORE_M4
    #define pm_queue_sleep_ms(x) Task_sleep(x);
#endif

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static uint16_t heapId;

static MessageQ_Handle  serverQHndl; /* user by server */
static MessageQ_QueueId serverQId; /* used by client */

uint8_t pm_queue_client_initialized;
uint8_t pm_queue_server_initialized;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

#define MessageQ_payload(m) ((void *)((char *)(m) + sizeof(MessageQ_MsgHeader)))

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
* @fn         openMsgQ
* @brief
* @param [in]
* @return
******************************************************************************/
static int32_t PM_QUEUE_openMsgQ (char* name, MessageQ_QueueId* msgQId)
{
    return (MessageQ_open(name, msgQId));
}

/***************************************************************************//**
* @fn         createMsgQ
* @brief
* @param [in]
* @return
******************************************************************************/
static MessageQ_Handle PM_QUEUE_createMsgQ (char *name)
{
    MessageQ_Handle messageQ;
    MessageQ_Params  msgQParams;
    MessageQ_Params_init(&msgQParams);

    messageQ = MessageQ_create(name, &msgQParams);

    if (messageQ == NULL) {
        LOG_PRINT_ERR(DEBUG_PM_QUEUE, "MessageQ_creation failed\n");
    } else {
        LOG_PRINT_ERR(DEBUG_PM_QUEUE, "MessageQ_creation OK!\n");
    }

    return (messageQ);
}

#if(0)
/***************************************************************************//**
* @fn         allocateHeap
* @brief
* @param [in]
* @return
******************************************************************************/
static int32_t PM_QUEUE_allocateHeap (uint16_t heapId)
{
    return (MessageQ_registerHeap(NULL, heapId));
}
#endif

/***************************************************************************//**
* @fn         freeHeap
* @brief
* @param [in]
* @return
******************************************************************************/
static int32_t PM_QUEUE_freeHeap (uint16_t heapId)
{
    return (MessageQ_unregisterHeap(heapId));
}

/***************************************************************************//**
* @fn         putMsg
* @brief
* @param [in]
* @return
******************************************************************************/
int32_t PM_QUEUE_putMsg (MessageQ_QueueId msgQId, uint16_t heapId, uint16_t id,  int8_t* data, uint32_t length)
{
    SBMsg *pTxMsg;
    uint32_t crc;
    uint32_t i;

    /* Allocating a Message */
    
    LOG_PRINT_START_FUNC(DEBUG_PM_QUEUE);
    
    crc = crc32(0, data, length);    
    LOG_PRINT_SVER(DEBUG_PM_QUEUE, "crc is %d\r\n", crc);
    LOG_PRINT_SVER(DEBUG_PM_QUEUE, "len is %d\r\n", length);

    for (i = 0; i < length; i++)
    {
        LOG_PRINT_SVER(DEBUG_PM_QUEUE, "[%d] = %d ",i, data[i]);
    }    
    LOG_PRINT_SVER(DEBUG_PM_QUEUE, "\r\n");
    
    pTxMsg = (SBMsg*)MessageQ_alloc(heapId, sizeof(MessageQ_MsgHeader) + sizeof(pTxMsg->crc32) + sizeof(pTxMsg->len) + length);

    if (pTxMsg == NULL)
    {
        LOG_PRINT_ERR(DEBUG_PM_QUEUE, "Alloc Failed\r\n");
        return (MessageQ_E_FAIL);
    }
    
    pTxMsg->header.msgId = id;
////    pTxMsg->header.msgSize = length; DOES NOT WORK
    pTxMsg->crc32 = crc;
    pTxMsg->len = length;
    memcpy(pTxMsg->data, data, length);

    if (MessageQ_put(msgQId, (MessageQ_Msg) pTxMsg) < 0)
    {
        LOG_PRINT_ERR(DEBUG_PM_QUEUE, "Put failed\r\n");
        return (MessageQ_E_FAIL);
    }

    return (MessageQ_S_SUCCESS);
}

/* Initialize a queue, NON BLOCKING */
int PM_QUEUE_Init_Server()
{
    if (false == pm_queue_server_initialized) {

        LOG_PRINT_START_FUNC(DEBUG_PM_QUEUE);
        /* Creating a MessageQ Object */
        serverQHndl = PM_QUEUE_createMsgQ(PM_MESSAGE_SERVER_QUEUE_NAME);

        LOG_PRINT_INFO(DEBUG_PM_QUEUE, "queue id is %d\r\n", MessageQ_getQueueId(serverQHndl));

        LOG_PRINT_VER(DEBUG_PM_QUEUE, "Waiting for incoming connections...\n");

        pm_queue_server_initialized = true;
    }

    return 0;
}

/* Initialize a queue, NON BLOCKING */
int PM_QUEUE_Init_Client()
{
    /* If it is already initialized we return 0, since we are not on error */
    Int32 status = 0;

	/* Opening the client Message Queue */
	if (false == pm_queue_client_initialized) {
        status = PM_QUEUE_openMsgQ(PM_MESSAGE_CLIENT_QUEUE_NAME, &serverQId);
        if (0 <= status) {
            LOG_PRINT_INFO(DEBUG_PM_QUEUE, "Client opened server queue, we can now send messages\r\n");
            pm_queue_client_initialized = true;
        } else {
            LOG_PRINT_ERR(DEBUG_PM_QUEUE, "Failed to open queue, error %d\r\n", status);
        }
	}
	//TODO: change returning value
    return status;
}

void PM_QUEUE_ShutDown()
{
    PM_QUEUE_freeHeap(heapId);
    MessageQ_delete(&serverQHndl);
}

static int PM_QEUEUE_getMsg(pSBMsg_t * pRxMsg, MessageQ_Handle msgQHandle, uint32_t timeout)
{
    return MessageQ_get(msgQHandle, (MessageQ_Msg*) pRxMsg, timeout);
}

void PM_QUEUE_SendMessage_Client(char * msg, int len)
{
    LOG_PRINT_START_FUNC(DEBUG_PM_QUEUE);

    if (false == pm_queue_client_initialized) {
        LOG_PRINT_VER(DEBUG_PM_QUEUE, "Client not initialized\r\n");
        return;
    }

	if ((PM_QUEUE_putMsg(serverQId, SERVER_HEAPID, 1, (int8_t *) msg, len)) == MessageQ_E_FAIL)
	{
	    LOG_PRINT_ERR(DEBUG_PM_QUEUE, "MessageQ_put was not successful\r\n");
	} else {
    	LOG_PRINT_VER(DEBUG_PM_QUEUE, "Send message ok\r\n");
	}
}

/* Receive one message, NON BLOCKING
 *
 * The argument is a pointer to a pointer.
 * We have to fill the pointer to the shared space with the message
 * so we need to receive a pointer to the pointer
 * */
pmQueueStatus_t PM_QEUEUE_ReceiveMessage_Server(pSBMsg_t *ppRxMsg)
{
    int status;
    uint32_t *params;
    uint32_t crc;
    uint32_t len;
    pSBMsg_t pRxMsgaux; //Pointer to the message
    /* Init the external point as NULL */
    *ppRxMsg = NULL;
    pmQueueStatus_t result = PM_NO_MESSAGE;

    LOG_PRINT_START_FUNC(DEBUG_PM_QUEUE);

    if (false == pm_queue_server_initialized) {
        LOG_PRINT_SVER(DEBUG_PM_QUEUE, "server not initialized\r\n");
        return PM_NO_MESSAGE;
    }

    status = PM_QEUEUE_getMsg(&pRxMsgaux, serverQHndl, 0 /*MessageQ_FOREVER*/); /* No timeout */

    params = MessageQ_payload(pRxMsgaux);
    crc = params[0];
    len = params[1];

    if (MessageQ_S_SUCCESS == status) {
        int i;
        LOG_PRINT_SVER(DEBUG_PM_QUEUE, "crc is %d\r\n", crc);
        LOG_PRINT_SVER(DEBUG_PM_QUEUE, "len is %d\r\n", len);
        for (i = 0; i < len; i++)
        {
            LOG_PRINT_SVER(DEBUG_PM_QUEUE, "[%d] = %d ", i, pRxMsgaux->data[i]);
        }
        LOG_PRINT_SVER(DEBUG_PM_QUEUE, "\r\n");
        LOG_PRINT_VER(DEBUG_PM_QUEUE, "Message received\n");
        if (crc == crc32(0, pRxMsgaux->data, len)) {
            LOG_PRINT_VER(DEBUG_PM_QUEUE, "CRC Ok\r\n");
            *ppRxMsg = pRxMsgaux; /* Fill the external pointer */
            result = PM_MESSAGE_RECEIVED;
        } else {
            LOG_PRINT_ERR(DEBUG_PM_QUEUE, "CRC error\r\n");
            result = PM_CRC_INVALID;
        }
    } else {
        LOG_PRINT_SVER(DEBUG_PM_QUEUE, "NO Message received\n");
        result = PM_NO_MESSAGE;
    }

    if (PM_CRC_INVALID == result) {
        /* Free the message if there was an error */
        MessageQ_free((MessageQ_Msg)(pRxMsgaux));
        result = PM_NO_MESSAGE;
    }

    return result;
}


/* Free a received message */
void PM_QEUEUE_FreeMessage(SBMsg *pRxMsg)
{
    LOG_PRINT_START_FUNC(DEBUG_PM_QUEUE);
    if (NULL != pRxMsg) {
        MessageQ_free((MessageQ_Msg)(pRxMsg));
    } else {
        LOG_PRINT_ERR(DEBUG_PM_QUEUE, "Pointer is null, this should not happen\n");
    }
}

void PM_QUEUE_Init()
{
    pm_queue_client_initialized = false;
    pm_queue_server_initialized = false;
}

#ifdef CORE_A15

int PM_QUEUE_Init_A15()
{
    int status;

    LOG_PRINT_START_FUNC(DEBUG_PM_QUEUE);

    /* configure the transport factory */
    Ipc_transportConfig(&TransportRpmsg_Factory);

    /*
     *  initialize the ipc layer
     */
    status = Ipc_start();
//    if ( (Ipc_S_SUCCESS != status) || (Ipc_S_ALREADYSETUP != status) ) {
    if (status < 0) {
        LOG_PRINT_ERR(DEBUG_PM_QUEUE, "IPC start init FAILED = %d!\r\n", status);
        return -1;
    } else {
        LOG_PRINT_INFO(DEBUG_PM_QUEUE, "IPC start ok\r\n");
    }
    return 0;
}
#endif

#ifdef CORE_M4

Char hostStatus = 0;

int PM_QUEUE_Wait_For_A15()
{
    if (hostStatus == 0) {
        hostStatus = Resource_getVdevStatus(VIRTIO_ID_RPMSG);

        LOG_PRINT_SVER(DEBUG_PM_QUEUE, "Waiting start of RPMSG: %d\n", hostStatus);

        if (hostStatus != 0) {
            IpcMgr_ipcStartup();
            LOG_PRINT_VER(DEBUG_PM_QUEUE, "IpcMgr_ipcStartup\n");
        }
    }
    return (hostStatus);
}

void PM_QUEUE_Connect_To_IPU2()
{
    int status;
    Ipc_start();
    do {
        status = Ipc_attach(MultiProc_getId("IPU2"));
        pm_queue_sleep_ms(1);
        LOG_PRINT_SVER(DEBUG_PM_QUEUE, "Waiting attach to IPU1\n");
    } while (status < 0);
}
#endif
