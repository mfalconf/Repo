#include <standard.h>
#include "sar_ram_definitions.h"

#include <drv/can/can.h>
#include <dimming.h>
#include <famp_pm.h>
#include <comm_protocol.h>
#include <sharedbus_server.h>
#include <external_signals.h>
#include <can_appl.h>
#include <timedate.h>
///#include <comm_pmic_65919.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>

#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>
#include "clock_utils.h"

#include <hmi_manager.h>

#define PM_TIMED_TIMEOUT            1800000 //30 minutes
#define PM_EXTENDED_TIMED_TIMEOUT   900000  //15 minutes
#define PM_SCREEN_MSG_SYNC_TIMEOUT  1000
#define PM_GOING_STANDBY_TIMEOUT    1000

/*
 * PM_NO_CAN_ACTIVITY_TIMEOUT set to 2 minutes.
 * Beware, this will affect validation on/off cycles times.
 */
#define PM_NO_CAN_ACTIVITY_TIMEOUT  120000

#define PM_REFLASH_TIMEOUT          600000  //10 minutes

#define FAMP_PM_US_TO_MS            1000

#define REAL_PROGRAM
//#define SLOW_STATE_MACHINE
//#define REMOTE_PROC
//#define DEBUG_WHILE
//#define TEST_REMOTE_PROC

/* to use the seconds timer */
//#define PM_USE_SECONDS_TIMER



/* Task sleep time in uS */
#define FAMP_PM_TASK_SLEEP_FIRST_STAGE_US  50000
#define FAMP_PM_TASK_SLEEP_NORMAL_STAGE_US 250000

#define REFLASHING_MAGIC_NUMBER   (0xAA55AA55)
#define NO_REFLASHING             (0x00000000UL)

#ifdef DEBUG_WHILE
#include <ti/ipc/remoteproc/Resource.h>
#include <ti/ipc/remoteproc/rsc_types.h>
#include <ti/ipc/ipcmgr/IpcMgr.h>
#undef FAMP_PM_TASK_SLEEP_FIRST_STAGE_US
#undef FAMP_PM_TASK_SLEEP_NORMAL_STAGE_US
#define FAMP_PM_TASK_SLEEP_FIRST_STAGE_US  5000000
#define FAMP_PM_TASK_SLEEP_NORMAL_STAGE_US 500000
#endif


#ifdef SLOW_STATE_MACHINE
/* for debug */
#undef FAMP_PM_TASK_SLEEP_FIRST_STAGE_US
#undef FAMP_PM_TASK_SLEEP_NORMAL_STAGE_US
#define FAMP_PM_TASK_SLEEP_FIRST_STAGE_US  5000000
#define FAMP_PM_TASK_SLEEP_NORMAL_STAGE_US 5000000
#endif

#if defined( REMOTE_PROC) || defined(TEST_REMOTE_PROC)
#undef FAMP_PM_TASK_SLEEP_FIRST_STAGE_US
#undef FAMP_PM_TASK_SLEEP_NORMAL_STAGE_US
#define FAMP_PM_TASK_SLEEP_FIRST_STAGE_US  1000000
#define FAMP_PM_TASK_SLEEP_NORMAL_STAGE_US 100000
#endif

#define MAX_RETRIES_FOR_SAVING_TO_MSP   3

// ToDo: Move this logs implementation to other module (maybe console.h)

/* To avoid loosing important log events, that may be overwritted for by new newer logs
 * (remember that our logs buffer is a ring buffer)
 */
//#define KEEP_TRACKING_OLD_ERRORS

#if defined (KEEP_TRACKING_OLD_ERRORS)
char bufferOldError[128];
uint8_t oldErrorStored = 0;
uint32_t oldErrorTimerCount;
#define OLD_ERROR_TIME_MS               5000
#endif

typedef enum {
   PM_POWER_BUTTON,
   PM_IGNITION,
   PM_CAN,
   PM_NUMBER_OF_INPUTS
}pmInputs_t;

typedef enum {
    PM_RVC_NO_REPORT,
    PM_RVC_REPORT_OFF,
    PM_RVC_REPORT_REAL_VALUE,
}pm_rvcReport_t;

typedef struct {
    pmPowerButtonStates_t currentState;
    pmPowerButtonStates_t latchedPressedState;
    uint8_t newPowerButtonValue;
}pmPowerButton_t;

/*****function like macros*************************************/
#define pm_powerOnByPowerButton()   (WAKE_UP_POWERUP_CONDITION_POWERBTN == pmOnByPowerButton)

#define pm_getIgnitionLine()        (pmIgnitionLineState)
#define pm_ignitionLine()           (PM_IGNITION_LINE_ON == pmIgnitionLineState)
#define pm_noIgnitionLine()         (!pm_ignitionLine())
#define pm_updateIgnitionLine(x)    (pmIgnitionLineState = x)

#define pm_getLastOperationalModeStatus()             (pmLastOperationalModeStatus)
#define pm_updateLastOperationalModeStatus(x)         (pmLastOperationalModeStatus = x)

#define pm_getIgnitionCanState()    (pmIgnitionCanState)
#define pm_setIgnitionCanState()    (pmIgnitionCanState = PM_IGNITION_CAN_ON)
#define pm_clrIgnitionCanState()    (pmIgnitionCanState = PM_IGNITION_CAN_OFF)
#define pm_IgnitionCan()            (PM_IGNITION_CAN_ON == pmIgnitionCanState)
#define pm_noIgnitionCan()          (!pm_IgnitionCan())

#define pm_insertCanKeyStatus()     (pmCanKeyStatus = PM_CAN_KEY_INSERTED)
#define pm_removeCanKeyStatus()     (pmCanKeyStatus = PM_CAN_KEY_REMOVED)
#define pm_isCanKeyStatusRemoved()  (PM_CAN_KEY_REMOVED == pmCanKeyStatus)
#define pm_isCanKeyStatusInserted() (PM_CAN_KEY_INSERTED == pmCanKeyStatus)
#define pm_getCanKeyStatus()        (pmCanKeyStatus)

#define pm_isTransportModeOn()      (TRANSPORT_MODE_ON == pmTransportMode)

#define pm_isSwitchOffOn()          (pmSwitchOffOn == PM_SWITCHON_ON)

#define pm_getScreen()              (pmScreenStatus)
#define pm_clrScreenOn()            (pmScreenStatus = PM_PROPERTY_SCREEN_IS_OFF)
#define pm_setScreenOn()            (pmScreenStatus = PM_PROPERTY_SCREEN_IS_ON)
#define pm_clrScreenOff()           (pmScreenStatus = PM_PROPERTY_SCREEN_IS_ON)
#define pm_setScreenOff()           (pmScreenStatus = PM_PROPERTY_SCREEN_IS_OFF)
#define pm_isScreenOn()             (PM_PROPERTY_SCREEN_IS_ON == pmScreenStatus)
#define pm_isScreenOff()            (PM_PROPERTY_SCREEN_IS_OFF == pmScreenStatus)
#define pm_updateScreen(x)          (pmScreenStatus = x)

#define pm_getSplashState()         (pmSplashState)
#define pm_clrSplashState()         (pmSplashState = SPLASH_OFF)
#define pm_setSplashState()         (pmSplashState = SPLASH_ON)
#define pm_isSplashOn()             (SPLASH_ON == pmSplashState)
#define pm_isSplashOff()            (SPLASH_OFF == pmSplashState)
#define pm_isSplashUnkown()         (SPLASH_UNKOWN == pmSplashState)
#define pm_updateSplashState(x)     (pmSplashState = x)

#define pm_getEndFirstStage()       (pmEndFirstStage)
#define pm_clrEndFirstStage()       (pmEndFirstStage = false)
#define pm_setEndFirstStage()       (pmEndFirstStage = true)
#define pm_isEndFirstStage()        (true == pmEndFirstStage)
#define pm_updateEndFirstStage(x)   (pmEndFirstStage = x)

#define pm_getInFirstStage()        (pmInFirstStage)
#define pm_clrInFirstStage()        (pmInFirstStage = false)
#define pm_setInFirstStage()        (pmInFirstStage = true)
#define pm_isInFirstStage()         (true == pmInFirstStage)
#define pm_updateInFirstStage(x)    (pmInFirstStage = x)

#define pm_getCanActivity()         (pmCanActivity)
#define pm_clrCanActivity()         (pmCanActivity = PM_CAN_BUS_IDLE)
#define pm_setCanActivity()         (pmCanActivity = PM_CAN_BUS_WITH_ACTIVITY)
#define pm_isCanActivity()          (PM_CAN_BUS_WITH_ACTIVITY == pmCanActivity)
#define pm_updateCanActivity(x)     (pmCanActivity = x)

#define pm_getCallInProgress()      (pmCallInProgress)
#define pm_clrCallInProgress()      (pmCallInProgress = false)
#define pm_setCallInProgress()      (pmCallInProgress = true)
#define pm_isCallInProgress()       (true == pmCallInProgress)
#define pm_updateCallInProgress(x)  (pmCallInProgress = x)

#define pm_getIpuRunning()         (pmIpuRunning)
#define pm_clrIpuRunning()         (pmIpuRunning = false)
#define pm_setIpuRunning()         (pmIpuRunning = true)
#define pm_isIpuRunning()          (true == pmIpuRunning)
#define pm_updateIpuRunning(x)     (pmIpuRunning = x)

#define pm_getRvcReport()           (pm_rvcReport)
#define pm_isRvcReport(x)           (x == pm_rvcReport)
#define pm_updateRvcReport(x)       (pm_rvcReport = x)

#define pm_isPdcRvcViewOn()         (true == informedPdcRvcView)
#define pm_isPdcRvcViewOff()        (false == informedPdcRvcView)
#define pm_updatePdcRvcViewOn(x)    (informedPdcRvcView = x)

#define pm_savedTimeReason(x)            (pmTimedReason = x)
#define pm_isTimedReasonCan()           (PM_TIMED_REASON_CAN_IGNITION == pmTimedReason)
#define pm_isTimedReasonPowerButton()   (PM_TIMED_REASON_POWER_BUTTON == pmTimedReason)

#define pm_getEngModeStatus()               (pmEngModeStatus)
#define pm_clrEngModeStatus()               (pmEngModeStatus = false)
#define pm_setEngModeStatus()               (pmEngModeStatus = true)
#define pm_isEngModeStatus()                (true == pmEngModeStatus)
#define pm_updateEngModeStatus(x)           (pmEngModeStatus = x)

#if (0)
#define pm_getGetSwitchOnError()    (pmGetSwitchOnError)
#define pm_clrGetSwitchOnError()    (pmGetSwitchOnError = false)
#define pm_setGetSwitchOnError()    (pmGetSwitchOnError = true)
#define pm_isGetSwitchOnError()     (true == pmGetSwitchOnError)

#define pm_getGetWakeUpReasonError()   (pmGetWakeUpReasonError)
#define pm_clrGetWakeUpReasonError()   (pmGetWakeUpReasonError = false)
#define pm_setGetWakeUpReasonError()   (pmGetWakeUpReasonError = true)
#define pm_isGetWakeUpReasonError()    (true == pmGetWakeUpReasonError)
#endif

#define pm_updatePmInternalTimerValue(x) (pm_timerCount = (pm_getCurrentTime() + x))

bmVoltageState_t batteryMonitor = BM_UNKNOWN;

// state machine current state
pmMachineStates_t pmCurrentOperativePmState;
/* State machine of the first stage */
pmFirstStageMachineStates_t pmCurrentFirstStagePmState;
/* The state when the sync message was received, we will use it
 * to transition from the firstStage power machine to the
 * normal power machine
 */
pmFirstStageMachineStates_t pmLastFirstStageState;
// ignition current state
pmIgnitionLineState_t pmIgnitionLineState;
/* The state of the power button */
pmPowerButton_t powerButtonState;
/* The state of the ignition signal in the can network */
pmCanState_t pmIgnitionCanState;
/* Local variable to save the last operational mode status from CAN so we only process it after it changes */
uint8_t pmLastOperationalModeStatus = IGN_SNA;
/* The status of the car key received by CAN */
pmCanKeyStatus_t pmCanKeyStatus = PM_CAN_KEY_REMOVED;
/* True if there is can activity in the bus.
 * This takes into account any transition in the line,
 * it doesn't even check for valid messages */
pmCanBusActivity_t pmCanActivity;
/* Power button current logical state.
 * True if the radio is ON because a power button
 */
uint8_t pmOnByPowerButton;
/* Signals if there is a call in progress */
bool pmCallInProgress;
/* If true the ipu is running, when this changes to false it is shutting down and is non-reversible */
bool pmIpuRunning = true;
/* The reason we went to timed, it will change the condition that we use to exit it */
pmTimedReason_t pmTimedReason;

/* The state of the Transport Mode.
 * This variable is loaded with the last transport mode stored in the shared memory if we are
 * in a WarmStart, and is loaded with a persistent property in the A15 side if it's a ColdStart.
 * Anyway, this value is overwritted with new CAN messages.
 */
pmTransportMode_t   pmTransportModeRecoveredByMSP   = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;
pmTransportMode_t   pmTransportModeRecoveredByA15   = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;
pmTransportMode_t   pmTransportModeState_By_CAN     = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;
pmTransportMode_t   pmTransportMode                 = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;

bool                pmTransportModeWasInitiallyOn       = false;
bool                recoveringTransportModeFromA15      = false;
bool                waitingTransportModeStateFromA15    = false;

pmSwitchOn_t pmSwitchOffOn = PM_SWITCHON_ON;

bool pmInReflashNow = false;

uint32_t pm_timerCount;

pmPropertyScreen_t pmScreenStatus;
/* The state of the splash right now */
pmSplashState_t pmSplashState;
/* Pointer to message received form the queue */
static SBMsg * pmRxMsg;
/* Status variable to signal that android is up and the first stage can be finished */
uint8_t pmEndFirstStage;
/* internal variable to track if we are in the first stage or not */
uint8_t pmInFirstStage;

static uint8_t stack[0x1000];

static uint8_t pmQueueSyncFinished;

static uint8_t pmSendTimeAndDateRequest;

static bool_t pmSendCanBusActiveMessage;

/* The report of the RVC we have to make */
static pm_rvcReport_t pm_rvcReport;

bool_t isColdStart;

static bool_t desiredScreenState = false;

static bool_t informedPdcRvcView = false;

/* If we are in eng mode we dont wait in timed state. We assumed by default we are not since is the normal use */
static bool_t pmEngModeStatus = false;

#if (0)
/* There was an error when requesting the switch on value, we have to ask again */
static bool pmGetSwitchOnError;
/* There was an error when requesting the wake up reason, we have to ask again */
static bool pmGetWakeUpReasonError;
#endif

/******************************************************
 * Prototypes
 *****************************************************/
static uint32_t pm_getCurrentTime();
static void pm_goToTimed(pmTimedReason_t reason);
static void pm_goToExtendedTimed();
static void pm_goToHmiOn();
static void pm_goToHmiOff();
static void pm_goToStandby();
bool pm_timerElapsed();
static void pm_powerModdingStateMachine();
static void pm_setSwitchOnValue(pmSwitchOn_t switchOn);
static pmTransportMode_t pm_getTransportMode_MSP(void);
static void pm_updateTransportMode_MSP(pmTransportMode_t transportMode);
static void pm_sendStartingPowerCondition(uint32_t newPowerStatus);
static void pm_sendPowerStateMessage(bool secondState);
static void pm_Check_Transport_Mode (void);
static void pm_sendTransportModeQueryMessage(void);
static void pm_sendTransportModeSendMessage(pmTransportMode_t);
static void pm_sendCanBusStateMessage(void);

static void pm_refreshScreen()
{
    //LOG_PRINT_START_FUNC(DEBUG_PM);
    //LOG_PRINT_SVER(DEBUG_PM, "Refresh value of the enable lines to avoid problem with hibernation\r\n");

    LOG_PRINT_START_FUNC(DEBUG_TRANSPORT_MODE);
    LOG_PRINT_SVER(DEBUG_TRANSPORT_MODE, "Refresh value of the enable lines to avoid problem with hibernation\r\n");

    HmiManager_set_desired_screen_state(desiredScreenState);
    DIMMING_Refresh_Level(DIM_USER_A, DIM_ONKEY);
    DIMMING_Refresh_Level(DIM_USER_A, DIM_CPBTN);
}

static void pm_turnOnScreen()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    HmiManager_set_desired_screen_state(true);
    desiredScreenState = true;
}

static void pm_turnOffScreen()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    HmiManager_set_desired_screen_state(false);
    desiredScreenState = false;
}

static void pm_turnOnLights()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    DIMMING_SetChannelOn(DIM_USER_A, DIM_CPBTN);
}

static void pm_turnOffLights()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    DIMMING_SetChannelOff(DIM_USER_A, DIM_CPBTN);
}

static void pm_turnOnKeyOn()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    DIMMING_SetChannelOn(DIM_USER_A, DIM_ONKEY);
}

static void pm_turnOffKeyOn()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    DIMMING_SetChannelOff(DIM_USER_A, DIM_ONKEY);
}

static void pm_initPowerButtonLocal()
{
    powerButtonState.newPowerButtonValue = false;
    powerButtonState.currentState = PM_POWER_BUTTON_RELEASED;
    powerButtonState.latchedPressedState = PM_POWER_BUTTON_RELEASED;
}

static bool pm_isPowerButtonPressed()
{
    bool result = false;
    if ( (true == powerButtonState.newPowerButtonValue) && (PM_POWER_BUTTON_PRESSED == powerButtonState.latchedPressedState) ) {
        powerButtonState.newPowerButtonValue = false;
        result = true;
    }
    return result;
}

static void pm_turnOnAllLights()
{
    pm_turnOnScreen();
    pm_turnOnLights();
    pm_turnOnKeyOn();
}

static void pm_turnOffAllLights()
{
    pm_turnOffScreen();
    pm_turnOffLights();
    pm_turnOffKeyOn();
}

static void pm_turnOnOnlyKeyOn()
{
    pm_turnOffScreen();
    pm_turnOffLights();
    pm_turnOnKeyOn();
}

static uint32_t pm_getCurrentTime()
{
   uint64_t timeMs;
   LOG_PRINT_START_FUNC(DEBUG_PM);
#ifdef PM_USE_SECONDS_TIMER
   return Seconds_get();
#else
   timeMs = ClockUtils_Get_Time();
   return timeMs;
#endif
}

pmIgnitionLineState_t getIgnitionLine (void) {
    return pmIgnitionLineState;
}

pmCanState_t getIgnitionCan (void) {
    return pmIgnitionCanState;
}

static void pm_goToTimed(pmTimedReason_t reason)
{
   pmCurrentOperativePmState = PM_HMI_GOING_TIMED;
   pm_updatePmInternalTimerValue(PM_TIMED_TIMEOUT);
   LOG_PRINT_VER(DEBUG_PM, "go to timed, starting timer of %d milliseconds\r\n", PM_TIMED_TIMEOUT);
   pm_turnOnAllLights();
   pm_updateRvcReport(PM_RVC_REPORT_OFF);
   pm_savedTimeReason(reason);
}

static void pm_goToExtendedTimed()
{
   pmCurrentOperativePmState = PM_GOING_EXTENDED_TIMED;
   pm_updatePmInternalTimerValue(PM_EXTENDED_TIMED_TIMEOUT);
   LOG_PRINT_VER(DEBUG_PM, "go to extended timed, starting timer of %d milliseconds\r\n", PM_EXTENDED_TIMED_TIMEOUT);
   pm_turnOnAllLights();
   pm_updateRvcReport(PM_RVC_REPORT_OFF);
}

static void pm_goToHmiOn()
{
   LOG_PRINT_START_FUNC(DEBUG_PM);
   pmCurrentOperativePmState = PM_HMI_GOING_ON;
   pm_updatePmInternalTimerValue(PM_SCREEN_MSG_SYNC_TIMEOUT);
   LOG_PRINT_VER(DEBUG_PM, "go to hmi on, starting timer of %d milliseconds\r\n", PM_SCREEN_MSG_SYNC_TIMEOUT);
   /* We are now listening the power events */
   ///int rc = pm_execProg(pm_cmd_start);
   LOG_PRINT_VER(DEBUG_PM, "go to hmi on\r\n");

   #if (USE_TOUCHSCREEN_AS_PWRBTN == 1)
       pm_sendPowerStateMessage(true);
   #endif

   pm_setSwitchOnValue(PM_SWITCHON_ON);
   pm_turnOnAllLights();
   pm_updateRvcReport(PM_RVC_REPORT_REAL_VALUE);
}

static void pm_goToHmiOff()
{
   LOG_PRINT_START_FUNC(DEBUG_PM);
   pmCurrentOperativePmState = PM_HMI_GOING_OFF;
   pm_updatePmInternalTimerValue(PM_SCREEN_MSG_SYNC_TIMEOUT);
   LOG_PRINT_VER(DEBUG_PM, "go to hmi off, starting timer of %d milliseconds\r\n", PM_SCREEN_MSG_SYNC_TIMEOUT);
   /* We are now listening the power events */
   ///int rc = pm_execProg(pm_cmd_stop);
   LOG_PRINT_VER(DEBUG_PM, "go to hmi off\r\n");
   pm_turnOnOnlyKeyOn();
   pm_setSwitchOnValue(PM_SWITCHON_OFF);
   pm_updateRvcReport(PM_RVC_REPORT_REAL_VALUE);
}

static void pm_goToTransportModeFromSecondStage() {

   pmCurrentOperativePmState = PM_GOING_STANDBY;
   pm_updatePmInternalTimerValue(PM_GOING_STANDBY_TIMEOUT);
   LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Go to off and then to transport mode in %d milliseconds\r\n", PM_GOING_STANDBY_TIMEOUT);
   pm_updateRvcReport(PM_RVC_REPORT_OFF);
}

static void pm_goToStandby()
{
   LOG_PRINT_START_FUNC(DEBUG_PM);
   pmCurrentOperativePmState = PM_GOING_STANDBY;
   pm_updatePmInternalTimerValue(PM_GOING_STANDBY_TIMEOUT);
   LOG_PRINT_VER(DEBUG_PM, "go to off, starting timer of %d milliseconds\r\n", PM_GOING_STANDBY_TIMEOUT);
   pm_updateRvcReport(PM_RVC_REPORT_OFF);
}

bool pm_timerElapsed()
{
   LOG_PRINT_START_FUNC(DEBUG_PM);
   LOG_PRINT_SVER(DEBUG_PM, "%u %u\r\n", pm_timerCount, pm_getCurrentTime());
   if (pm_timerCount == pm_getCurrentTime()) {
      LOG_PRINT_VER(DEBUG_PM, "Timer elapsed\r\n");
   }
   return (pm_timerCount <= pm_getCurrentTime());
}

static bool pm_isColdStart()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    return COMM_Protocol_IsColdStart();
}

static void pm_saveWarmStartCondition()
{
    uint8_t retries = 0;
    bool done = false;
    bool   readStartCondition;

    LOG_PRINT_START_FUNC(DEBUG_PM);

    while ( false == done ) {
        
        COMM_Protocol_SaveWarmStartCondition();

        readStartCondition = pm_isColdStart();

        if ( false == readStartCondition ) {
            done = 1;
        }
        else {

            retries++;
            
            if ( retries >= MAX_RETRIES_FOR_SAVING_TO_MSP ) {

                /* Something went wrong, and we can't save the start condition to MSP.
                 * We'll log this ugly situation.
                 */
                LOG_PRINT_VER(DEBUG_PM, "Warm start couldn't be saved in MSP after %d attempts. Won't try again\r\n", MAX_RETRIES_FOR_SAVING_TO_MSP);

                #if defined (KEEP_TRACKING_OLD_ERRORS)
                strcpy(bufferOldError, (const char*) "Warm start couldn't be saved\r\n");
                oldErrorStored = 1;
                #endif
                
                done = 1;
            }
            else {
                LOG_PRINT_VER(DEBUG_PM, "Failed saving warm condition in MSP. Attempt %d. We'll try again\r\n", retries);
            }
        }
    }
    LOG_PRINT_VER(DEBUG_PM, "Warm Condition saved in MSP\r\n");
}


static void pm_getSwitchOnValue()
{
    pmSwitchOn_t switchOn;
    LOG_PRINT_START_FUNC(DEBUG_PM);

    #if (0)
    pm_setGetSwitchOnError();
    #endif

    switchOn = COMM_Protocol_GetSwitchOn();
    if (PM_SWITCHON_ON == switchOn) {
        pmSwitchOffOn = PM_SWITCHON_ON;
        #if (0)
        pm_clrGetSwitchOnError();
        #endif
    } else if (PM_SWITCHON_OFF == switchOn) {
        pmSwitchOffOn = PM_SWITCHON_OFF;
        #if (0)
        pm_clrGetSwitchOnError();
        #endif
    } else {
        LOG_PRINT_ERR(DEBUG_PM, "Error in get switch on command received, received %d\r\n", switchOn);
        pmSwitchOffOn = PM_SWITCHON_ON;
    }

    LOG_PRINT_VER(DEBUG_PM, "Switch on value is %d\r\n", pmSwitchOffOn);
}

static void pm_setSwitchOnValue(pmSwitchOn_t switchOn) {

    uint8_t retries = 0;
    bool done = false;
    pmSwitchOn_t readSwitch;

    LOG_PRINT_START_FUNC(DEBUG_PM);

    while ( false == done ) {
        
        pmSwitchOffOn = switchOn;
        COMM_Protocol_SetSwitchOn(pmSwitchOffOn);

        readSwitch = COMM_Protocol_GetSwitchOn();

        if (readSwitch == switchOn) {
            done = 1;
        }
        else {

            retries++;
            
            if ( retries >= MAX_RETRIES_FOR_SAVING_TO_MSP ) {

                /* Something went wrong, and we can't save the switch value to MSP.
                 * We'll log this ugly situation.
                 */
                LOG_PRINT_VER(DEBUG_PM, "Switch value couldn't be saved in MSP after %d attempts. Won't try again\r\n", MAX_RETRIES_FOR_SAVING_TO_MSP);

                #if defined (KEEP_TRACKING_OLD_ERRORS)
                strcpy(bufferOldError, (const char*) "Switch value couldn't be saved\r\n");
                oldErrorStored = 1;
                #endif
                
                done = 1;
            }
            else {
                LOG_PRINT_VER(DEBUG_PM, "Failed saving switch value in MSP. Attempt %d. We'll try again\r\n", retries);
            }
        }
    }
    LOG_PRINT_VER(DEBUG_PM, "Set Switch on value is %d\r\n", pmSwitchOffOn);
    HmiManager_set_switch_on(pmSwitchOffOn == PM_SWITCHON_ON);
}

static pmTransportMode_t pm_getTransportMode_MSP() {
    return(COMM_Protocol_GetTransportModeStatus());    
}

/***********************************************************************************
*
* @fn         pm_updateTransportMode_MSP
*
* @brief      Send the new transport mode to MSP430 (using I2C communication) in
*             order to get this state saved for further Warm inits.
*
* @param [in] transportMode     New state to be saved.
*
* @return     void
*
***********************************************************************************/
static void pm_updateTransportMode_MSP(pmTransportMode_t transportMode) {

    uint8_t retries = 0;
    bool done = false;
    pmTransportMode_t readTransportMode;

    LOG_PRINT_START_FUNC(DEBUG_TRANSPORT_MODE);

    while(false == done) {

        // Try to save the new Transport Mode State in MSP
        COMM_Protocol_SetTransportModeStatus(transportMode);

        // Read the sent value to verify if transfer was ok
        readTransportMode = pm_getTransportMode_MSP();

        // Verify that the sent value and the read value are the same. If both are the same we are done.
        if ( readTransportMode == transportMode ) {
            done = 1;
        }
        else {

            /* Ooops. There was an error, because value sent wasn't verified. We'll
             * try to send it again, up to MAX_RETRIES_FOR_SAVING_TO_MSP times.
             */
            retries++;

            if ( retries >= MAX_RETRIES_FOR_SAVING_TO_MSP ) {

                /* Something went wrong, and we can't save the new transport mode in MSP.
                 * We'll log this ugly situation.
                 */
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Transport Mode couldn't be saved in MSP after %d attempts. Won't try again\r\n", MAX_RETRIES_FOR_SAVING_TO_MSP);

                #if defined (KEEP_TRACKING_OLD_ERRORS)
                strcpy(bufferOldError, (const char*) "Transport Mode couldn't be saved\r\n");
                oldErrorStored = 1;
                #endif
                
                done = 1;
            }
            else {
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Failed saving Transport Mode in MSP. Attempt %d. We'll try again\r\n", retries);
            }
        }
    }
}


static void pm_getWakeUpReason()
{
    pmWakeUpCondition_t powerOnCondition;
    LOG_PRINT_START_FUNC(DEBUG_PM);

    #if (0)
    pm_setGetWakeUpReasonError();
    #endif

    powerOnCondition = COMM_Protocol_GetPowerupCondition();
    if (WAKE_UP_ERROR == powerOnCondition) {
        LOG_PRINT_ERR(DEBUG_PM, "Error in get power up condition command received, received %d\r\n", powerOnCondition);
        powerOnCondition = WAKE_UP_POWERDOWN;
    } else {
        #if (0)
        pm_clrGetWakeUpReasonError();
        #endif
    }

    pmOnByPowerButton = ( WAKE_UP_POWERUP_CONDITION_POWERBTN == powerOnCondition)?true:false;
    LOG_PRINT_VER(DEBUG_PM, "power on by powerButton is %d\r\n", pmOnByPowerButton);
}

/**
 * Erase the reflash flag, it will be set by the recovery if we are reflashing
 *
 * IMPORTANT NOTE: This must happen BEFORE the recovery changes it, otherwise
 * we will have an unwanted behavior
 *
 */
static void pm_eraseReflashingFlag()
{
    unsigned long reflashFlag = NO_REFLASHING;
    HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_PM, reflashFlag);
}

static void pm_CheckIfReflashing()
{
    unsigned long reflashMem = HW_RD_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_PM);
    if ( (reflashMem == REFLASHING_MAGIC_NUMBER) && (false == pmInReflashNow) ) {
        pmInReflashNow = true;
        HmiManager_update_reflashing_state(true);
        LOG_PRINT_INFO(DEBUG_PM, "value read in reflash mem %d, HU is in reflash\r\n", reflashMem);
    } else if ((reflashMem != REFLASHING_MAGIC_NUMBER) && (true == pmInReflashNow)) {
        pmInReflashNow = false;
        HmiManager_update_reflashing_state(false);
        LOG_PRINT_INFO(DEBUG_PM, "value read in reflash mem %d, HU is not in reflash anymore\r\n", reflashMem);
    }
}

static void pm_Check_Transport_Mode (void) {

    static pmTransportMode_t lastStateJustForDebug = TRANSPORT_MODE_ERROR;
    
    // First step. Determine the transport mode state based on actual inputs.
    if (pmTransportModeState_By_CAN != TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE) {
        
        /* If we received some valid state from CAN, we don't need anymore the A15 persistent value. */
        recoveringTransportModeFromA15 = false;
        pmTransportMode = pmTransportModeState_By_CAN;
        HmiManager_update_transport_mode(pm_isTransportModeOn());
    }

    /* Check if we are still waiting for the first transport mode state by A15 */
    else if ( true == recoveringTransportModeFromA15 ) {
        
        /* Check if the message with the value was received */
        if (false == waitingTransportModeStateFromA15 ) {
            pmTransportMode = pmTransportModeRecoveredByA15;
            recoveringTransportModeFromA15 = false;
            LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Transport mode finally recovered from A15. New value: %d\r\n", pmTransportMode);
            HmiManager_update_transport_mode(pm_isTransportModeOn());
        }
    }
    
    // Second step. Check if we need to save the transport mode in some of the persistent spaces
    if ( pmTransportModeRecoveredByMSP != pmTransportMode ) {
        if (pmTransportMode != TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE) {
            pmTransportModeRecoveredByMSP = pmTransportMode;
            pm_updateTransportMode_MSP(pmTransportMode);        
            LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Update persistent value of transport mode in MSP. New value: %d\r\n", pmTransportMode);
        }
    }

    if ( pmTransportModeRecoveredByA15 != pmTransportMode ) {
        
        if (pmTransportMode != TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE) {

            /* This value can be updated only if ipu1 and A15 are synchronized. So, we need to check
             * an additonal condition.
            */
            if ( true == pmQueueSyncFinished ) {
                pmTransportModeRecoveredByA15 = pmTransportMode;
                pm_sendTransportModeSendMessage(pmTransportMode);
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Update persistent value of transport mode in A15. New value: %d\r\n", pmTransportMode);
            }    
        }    
    }

    if ( lastStateJustForDebug != pmTransportMode ) {
        lastStateJustForDebug = pmTransportMode;        
        LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "New Transport mode value: %d\r\n", pmTransportMode);
    }
}


#if 0 /* Remove warning */
/**
 * Retry if there are an early failed request
 */
static void pm_retryFailedRequests()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    if (pm_isGetSwitchOnError()) {
        pm_getSwitchOnValue();
    }

    if (pm_isGetWakeUpReasonError()) {
        pm_getWakeUpReason();
    }
}
#endif

static void pm_readIgnitionLineState()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    pmIgnitionLineState_t ignitionLineState = COMM_Protocol_GetCurrentIgnitionState();

    if (ignitionLineState != pm_getIgnitionLine()) {
        LOG_PRINT_VER(DEBUG_PM, "New ignition line state %d\r\n", ignitionLineState);
        if (PM_IGNITION_LINE_OFF == ignitionLineState) {
            pm_updateIgnitionLine(PM_IGNITION_LINE_OFF);
        } else if (PM_IGNITION_LINE_ON == ignitionLineState) {
            pm_updateIgnitionLine(PM_IGNITION_LINE_ON);
        } else {
            LOG_PRINT_ERR(DEBUG_PM, "Error in ignition command received, received %d\r\n", ignitionLineState);
        }
    }

    LOG_PRINT_SVER(DEBUG_PM, "ignition line state %d\r\n", ignitionLineState);
}

static void pm_readCanBusStatus()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    pmCanBusActivity_t canBusActivity = COMM_Protocol_GetCanBusState();

    if (canBusActivity != pm_getCanActivity()) {
        LOG_PRINT_SVER(DEBUG_PM, "New can bus activity %d\r\n", canBusActivity);
        if (PM_CAN_BUS_IDLE == canBusActivity) {
            pm_updateCanActivity(PM_CAN_BUS_IDLE);
        } else if (PM_CAN_BUS_WITH_ACTIVITY == canBusActivity) {
            pm_updateCanActivity(PM_CAN_BUS_WITH_ACTIVITY);
        } else {
            LOG_PRINT_ERR(DEBUG_PM, "Error in can bus state received, received %d\r\n", canBusActivity);
        }
    }

    LOG_PRINT_SVER(DEBUG_PM, "can bus state %d\r\n", canBusActivity);
}

static void pm_readCanIgnitionSignal()
{
    uint8_t currentCanStatus;
    uint8_t canKeyStatus;
    LOG_PRINT_START_FUNC(DEBUG_PM);
    currentCanStatus = CanAppl_GetOperationalMode_Status();

    if (currentCanStatus != pm_getLastOperationalModeStatus()) {
        pm_updateLastOperationalModeStatus(currentCanStatus);
        LOG_PRINT_SVER(DEBUG_PM, "New can ignition signal value %d\n", currentCanStatus);
        if ( (IGN_ON == currentCanStatus) || (IGN_PRESTART == currentCanStatus) ||
                (IGN_START == currentCanStatus) || (IGN_CRANKING == currentCanStatus) ||
                (IGN_ON_ENGINE_ON == currentCanStatus) ) {
            if (pm_noIgnitionCan()) {
                LOG_PRINT_VER(DEBUG_PM, "Can Ignition set\r\n");
            }
            pm_setIgnitionCanState();
        } else {
            if (pm_IgnitionCan()) {
                LOG_PRINT_VER(DEBUG_PM, "Can Ignition clear\r\n");
            }
            pm_clrIgnitionCanState();
        }
    }

    canKeyStatus = CanAppl_GetKey_Status();
    if (canKeyStatus != pm_getCanKeyStatus()) {
        if (CAN_KEY_REMOVED == canKeyStatus) {     
            pm_removeCanKeyStatus();
            LOG_PRINT_VER(DEBUG_PM, "Can key removed\r\n");
        } else {
            pm_insertCanKeyStatus();
            LOG_PRINT_VER(DEBUG_PM, "Can key inserted\r\n");
        }
    }
}


static void pm_readCanTransportModeSignal()
{
    pmTransportMode_t currentCanTransportModeState = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;

    // Get the last known state from CAN
    //currentCanTransportModeState = (pmTransportMode_t) CanAppl_GetTransportMode_Status();
    pmTransportModeState_By_CAN = (pmTransportMode_t) CanAppl_GetTransportMode_Status();
    
    /* If we received some update for this signal from the CAN bus, we
     * don't need to know the transport mode from A15, so, if didn't ask
     * yet, forget it.
     */
    if ( true == waitingTransportModeStateFromA15 ) {
        if  ( currentCanTransportModeState == TRANSPORT_MODE_ON || currentCanTransportModeState == TRANSPORT_MODE_OFF) {
            LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Forget about asking the A15's tranport mode. Current CAN = %d \r\n", currentCanTransportModeState);
            waitingTransportModeStateFromA15 = false;
        }
    }
}



static void pm_readPowerButtonState()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    pmPowerButtonStates_t currentState = COMM_Protocol_GetCurrentPowerButtonState();

    if (PM_POWER_BUTTON_RELEASED == currentState) {
        powerButtonState.currentState = PM_POWER_BUTTON_RELEASED;
    } else if (PM_POWER_BUTTON_PRESSED == currentState) {
        powerButtonState.currentState = PM_POWER_BUTTON_PRESSED;
    } else {
        LOG_PRINT_ERR(DEBUG_PM, "Error in power button command received, received %d\r\n", currentState);
    }

    if ( (PM_POWER_BUTTON_RELEASED == powerButtonState.latchedPressedState) &&  (PM_POWER_BUTTON_PRESSED == powerButtonState.currentState) ) {
        powerButtonState.latchedPressedState = PM_POWER_BUTTON_PRESSED;
        powerButtonState.newPowerButtonValue = true;
        LOG_PRINT_VER(DEBUG_PM, "powerButton new state %d\r\n", powerButtonState.latchedPressedState);
    } else if ( (PM_POWER_BUTTON_PRESSED == powerButtonState.latchedPressedState) &&  (PM_POWER_BUTTON_RELEASED == powerButtonState.currentState) ) {
        powerButtonState.latchedPressedState = PM_POWER_BUTTON_RELEASED;
        powerButtonState.newPowerButtonValue = true;
        LOG_PRINT_VER(DEBUG_PM, "powerButton new state %d\r\n", powerButtonState.latchedPressedState);
    }
}

static void pm_sendStartingPowerCondition(uint32_t newPowerStatus)
{
    char buffer[sizeof(pmMessagePower)];
    LOG_PRINT_START_FUNC(DEBUG_PM);
    LOG_PRINT_VER(DEBUG_PM, "Send power message %d\r\n", newPowerStatus);
    pmMessagePower * messagePower = (pmMessagePower *) buffer;
    messagePower->messageCode = PM_M4_TO_ANDROID_POWER_BUTTON;
    messagePower->powerOn = newPowerStatus;
    PM_QUEUE_SendMessage_Client( (char *) messagePower, sizeof(pmMessagePower));
}

static void pm_sendIpu1Sync()
{
    char buffer[sizeof(pmIpu1Sync)];
    LOG_PRINT_START_FUNC(DEBUG_PM);
    LOG_PRINT_VER(DEBUG_PM, "Send M4 sync %d\r\n", );
    pmIpu1Sync * messageIpu1Sync = (pmIpu1Sync *) buffer;
    messageIpu1Sync->messageCode = PM_M4_TO_ANDROID_SYNC;
    PM_QUEUE_SendMessage_Client( (char *) messageIpu1Sync, sizeof(pmIpu1Sync));
}

static void pm_sendGoToStandby()
{
    char buffer[sizeof(pmGoToStandby)];
    LOG_PRINT_START_FUNC(DEBUG_PM);
    LOG_PRINT_VER(DEBUG_PM, "Send go to standby\r\n");
    pmGoToStandby * messageGoToStandby = (pmGoToStandby *) buffer;
    messageGoToStandby->messageCode = PM_M4_TO_ANDROID_GO_TO_STANDBY;
    PM_QUEUE_SendMessage_Client( (char *) messageGoToStandby, sizeof(pmGoToStandby));
}

static void pm_sendShutdownMessage()
{
    char buffer[sizeof(pmMessageShutDown)];
    LOG_PRINT_VER(DEBUG_PM, "Send shutdown message \r\n");
    pmMessageShutDown * messageShutDown = (pmMessageShutDown *) buffer;
    messageShutDown->messageCode = PM_M4_TO_ANDROID_SHUT_DOWN;
    PM_QUEUE_SendMessage_Client( (char *) messageShutDown, sizeof(pmMessageShutDown));
}

static void pm_sendTransportModeSendMessage (pmTransportMode_t newState) {
    
    char buffer[sizeof(pmMessageSendTransportStateForSaving)];
    LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Send Transport Mode update to A15. Value: %d\r\n", newState);
    pmMessageSendTransportStateForSaving * message = (pmMessageSendTransportStateForSaving *) buffer;
    message->messageCode = PM_M4_TO_ANDROID_SEND_TRANSPORT_MODE_FOR_SAVING;
    message->newTransportModeState = (uint32_t) newState;
    PM_QUEUE_SendMessage_Client( (char *) message, sizeof(pmMessageSendTransportStateForSaving));
}

static void pm_sendTransportModeQueryMessage()
{
    char buffer[sizeof(pmMessageQueryTransportMode)];
    LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Send Transport Mode Query\r\n");
    pmMessageQueryTransportMode * messageQueryTransportMode = (pmMessageQueryTransportMode *) buffer;
    messageQueryTransportMode->messageCode = PM_M4_TO_ANDROID_QUERY_TRANSPORT_MODE;
    PM_QUEUE_SendMessage_Client( (char *) messageQueryTransportMode, sizeof(pmMessageQueryTransportMode));
}

static bool pm_isInTimed()
{
    return ( (PM_TIMED == pmCurrentOperativePmState) || (PM_GOING_EXTENDED_TIMED == pmCurrentOperativePmState) ||
                (PM_HMI_GOING_TIMED == pmCurrentOperativePmState) || (PM_EXTENDED_TIMED == pmCurrentOperativePmState) );
}

static bool pm_isInFullOperation()
{
    return ( (PM_HMI_ON == pmCurrentOperativePmState) || (PM_HMI_GOING_ON == pmCurrentOperativePmState) );
}

static void pm_sendPowerStateMessage(bool secondState)
{
    char buffer[sizeof(pmCurrentPowerState)];
    pmCurrentPowerState * messageCurrentPowerState = (pmCurrentPowerState *) buffer;
    messageCurrentPowerState->messageCode = PM_M4_TO_ANDROID_CURRENT_POWER_STATE;

    if (false == secondState) {
        /* First state, send off */
        messageCurrentPowerState->currentState = PM_POWER_STATE_OFF;
        LOG_PRINT_VER(DEBUG_PM, "Send current power state off from first state\r\n");
    } else {
        if (true == pm_isInTimed() ) {
            messageCurrentPowerState->currentState = PM_POWER_STATE_TIMED;
            LOG_PRINT_VER(DEBUG_PM, "Send current power state timed\r\n");
        } else if (true == pm_isInFullOperation())  {
            messageCurrentPowerState->currentState = PM_POWER_STATE_FO;
            LOG_PRINT_VER(DEBUG_PM, "Send current power state full operation\r\n");
        } else {
            messageCurrentPowerState->currentState = PM_POWER_STATE_OFF;
            LOG_PRINT_VER(DEBUG_PM, "Send current power state off from second state\r\n");
        }
    }
    PM_QUEUE_SendMessage_Client( (char *) messageCurrentPowerState, sizeof(pmCurrentPowerState));
}

static void pm_sendTimeDateInfo()
{
    char buffer[sizeof(pmMessageTimeAndDate)];
    TD_TimeDate_T timeDate;

    LOG_PRINT_VER(DEBUG_TD, "Send time and date info\r\n");
    pmMessageTimeAndDate * messageTimeAndDate = (pmMessageTimeAndDate *) buffer;
    messageTimeAndDate->messageCode = PM_M4_TO_ANDROID_TIME_AND_DATE;
    TD_GetTimeAndDate(&timeDate);
    memcpy(messageTimeAndDate->timeAndDate, &timeDate, sizeof(messageTimeAndDate->timeAndDate));
    PM_QUEUE_SendMessage_Client( (char *) messageTimeAndDate, sizeof(pmMessageTimeAndDate));
}

static void pm_sendCanBusStateMessage()
{
    char buffer[sizeof(pmCanBusState)];
    LOG_PRINT_VER(DEBUG_PM, "Send Can bus state\r\n");
    pmCanBusState * messageCanBusState = (pmCanBusState *) buffer;
    messageCanBusState->messageCode = PM_M4_TO_ANDROID_CAN_BUS_STATE;
    PM_QUEUE_SendMessage_Client( (char *) messageCanBusState, sizeof(pmCanBusState));
}

static void pm_readInputs()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);

    #if (USE_TOUCHSCREEN_AS_PWRBTN == 1)
        if (pm_isPdcRvcViewOff()) {
            pm_readPowerButtonState();
        }
    #else
        /* we only need to read this in the first stage, after thatm android takes care of the power button */
        /* note that we aren't reading the power button state if the PDC signal is active */
        if (pm_isInFirstStage() && pm_isPdcRvcViewOff()) {
            pm_readPowerButtonState();
        }
    #endif

    /* get the state of the can bus from the MSP */
    pm_readCanBusStatus();

    /* Read the ignition line */
    pm_readIgnitionLineState();

    /* Get the state of the can signal */
    pm_readCanIgnitionSignal();

    /* Get the state of the Transport Mode can signal */
    pm_readCanTransportModeSignal();

}

/* The return value indicates if there is a message available */
static pmQueueStatus_t pm_readQueue()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    return PM_QEUEUE_ReceiveMessage_Server(&pmRxMsg);
}

static void pm_processNewMessage()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    switch (pmRxMsg->data[0]) { /*TODO: find a better way to use this */
        case PM_ANDROID_TO_M4_SYNC:
        {
            /* We are not doing anything with this for now */
            /*pmMessageSync * message = (pmMessageSync *) pmRxMsg->data;*/
            LOG_PRINT_INFO(DEBUG_PM, "Message SYNC received\r\n");
        }
        break;

        case PM_ANDROID_TO_M4_FIRST_STAGE_BOOT_COMPLETED:
        {
            /*pmMessageFirstStageCompleted * message = (pmMessageFirstStageCompleted *) pmRxMsg->data;*/
            LOG_PRINT_INFO(DEBUG_PM, "Message First Stage Boot Completed received\r\n");
            pm_setEndFirstStage();
        }
        break;

        case PM_ANDROID_TO_M4_SCREEN_STATUS:
        {
            pmMessageScreenStatus * message = (pmMessageScreenStatus *) pmRxMsg->data;
            LOG_PRINT_VER(DEBUG_PM, "Message SCREEN STATUS received with screen status %d\r\n", message->screenStatus);

            if (message->screenStatus != pm_getScreen()) {
                /*pm_updateScreen(message->screenStatus);*/
                LOG_PRINT_VER(DEBUG_PM, "New screen status %d\r\n", message->screenStatus);
            }

            if (PM_PROPERTY_SCREEN_IS_ON == message->screenStatus) {
                pm_setScreenOn();
            } else {
                pm_setScreenOff();
                LOG_PRINT_SVER(DEBUG_PM, "command set screen off\r\n");
            }
        }
        break;

        case PM_ANDROID_TO_M4_CALL_IN_PROGRESS:
        {
            pmMessageCallInProgressStatus * message = (pmMessageCallInProgressStatus *)  pmRxMsg->data;
            LOG_PRINT_VER(DEBUG_PM, "Message call in progress received with call in progress status %d\r\n", message->callInProgress);

            if (false == message->callInProgress) {
                pm_clrCallInProgress();
            } else {
                pm_setCallInProgress();
            }
        }
        break;

        case PM_ANDROID_TO_M4_REPORT_TRANSPORT_MODE:
        {
            pmMessageReportTransportMode * message = (pmMessageReportTransportMode *) pmRxMsg->data;
            
            if ( (message->reportedTransportMode) == (pmTransportMode_t) TRANSPORT_MODE_ON ) {
                pmTransportModeRecoveredByA15 = TRANSPORT_MODE_ON;
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Transport Mode ON recovered from A15\r\n");
            } 
            else if ( (message->reportedTransportMode) == (pmTransportMode_t) TRANSPORT_MODE_OFF ) {
                pmTransportModeRecoveredByA15 = TRANSPORT_MODE_OFF;
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Transport Mode OFF recovered from A15\r\n");
            }
            else {
                pmTransportModeRecoveredByA15 = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Transport Mode SNA recovered from A15\r\n");
            }
            waitingTransportModeStateFromA15 = false;                    
        }
        break;

        case PM_ANDROID_TO_M4_ENG_MODE_STATUS:
        {
            pmMessageEngModeStatus * message = (pmMessageEngModeStatus *) pmRxMsg->data;
            
            if (true == (message->engModeStatus)) {
                pm_setEngModeStatus();
                LOG_PRINT_VER(DEBUG_PM, "Engineer mode is enabled\r\n");
            } 
            else 
            {
                pm_clrEngModeStatus();
                LOG_PRINT_VER(DEBUG_PM, "Engineer mode is not enabled\r\n");
            }
        }
        break;

        default:
            LOG_PRINT_ERR(DEBUG_PM, "Unknown message received\r\n");

    }
}

static void pm_freeMessage()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
    PM_QEUEUE_FreeMessage(pmRxMsg);
}


static pmSplashState_t pm_firstStageGoingToOn()
{
    pmCurrentFirstStagePmState = PM_FIRST_STAGE_ON;
    LOG_PRINT_VER(DEBUG_PM, "Set splash on\r\n");
    pm_setSwitchOnValue(PM_SWITCHON_ON);
    HmiManager_start();
    pm_turnOnAllLights();
    pm_updateRvcReport(PM_RVC_REPORT_REAL_VALUE);
    return SPLASH_ON;
}

static pmSplashState_t pm_firstStageGoingToTransportMode() {
    pmCurrentFirstStagePmState = PM_FIRST_STAGE_TRANSPORT_MODE;
    LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Entering to TM/RM from first stage PM\r\n");
    pm_setSwitchOnValue(PM_SWITCHON_OFF);

    pm_turnOffAllLights();

    pm_updateRvcReport(PM_RVC_REPORT_OFF);
    pm_updatePmInternalTimerValue(PM_NO_CAN_ACTIVITY_TIMEOUT);
    return SPLASH_OFF;
}

static pmSplashState_t pm_firstStageGoingToIdle()
{
    pmCurrentFirstStagePmState = PM_FIRST_STAGE_IDLE;
    LOG_PRINT_VER(DEBUG_PM, "Set splash off\r\n");
    pm_setSwitchOnValue(PM_SWITCHON_OFF);
    pm_turnOnOnlyKeyOn();
    pm_updateRvcReport(PM_RVC_REPORT_REAL_VALUE);
    return SPLASH_OFF;
}

static pmSplashState_t pm_firstStageGointToTimed()
{
    pmCurrentFirstStagePmState = PM_FIRST_STAGE_TIMED;
    LOG_PRINT_VER(DEBUG_PM, "Set splash on\r\n");
    HmiManager_start();
    pm_turnOnAllLights();
    pm_updateRvcReport(PM_RVC_REPORT_OFF);
    return SPLASH_ON;
}

static pmSplashState_t pm_firstStageGoingToOff()
{
    pmCurrentFirstStagePmState = PM_FIRST_STAGE_OFF;
    LOG_PRINT_VER(DEBUG_PM, "No ignition and can, set splash off\r\n");
    pm_turnOffAllLights();
    pm_updatePmInternalTimerValue(PM_NO_CAN_ACTIVITY_TIMEOUT);
    pm_updateRvcReport(PM_RVC_REPORT_OFF);
    return SPLASH_OFF;
}

static void pm_firstStageEndFirstStage(pmFirstStageMachineStates_t fromState)
{
    pmCurrentFirstStagePmState = PM_FIRST_STAGE_END;
    /* If splash is off then the initial power condition of the A15 is OFF */
    pm_sendStartingPowerCondition((SPLASH_ON == pm_getSplashState())?true:false);
    pmLastFirstStageState = fromState;
    pm_updateRvcReport(PM_RVC_NO_REPORT);
}

static void pm_firstStageGoingToShutDown()
{
    pmCurrentFirstStagePmState = PM_FIRST_STAGE_SHUT_DOWN;
    LOG_PRINT_SVER(DEBUG_PM, "Going to shutdown\r\n");
    pm_updateRvcReport(PM_RVC_REPORT_OFF);
}

static void pm_firstStageGoingToReflash()
{
    pmCurrentFirstStagePmState = PM_FIRST_STAGE_REFLASHING;
    LOG_PRINT_SVER(DEBUG_PM, "Going to reflash\r\n");
    pm_updatePmInternalTimerValue(PM_REFLASH_TIMEOUT);
    pm_turnOnAllLights();
    pm_updateRvcReport(PM_RVC_REPORT_OFF);
}

/*
 * We go back to the first stage!
 */
static void pm_restartFirstStage()
{
    /* We have to take care of the power button again, delete any old value since
     * it was never read in this state
     */
    pm_initPowerButtonLocal();
    pm_setInFirstStage();
    pmCurrentFirstStagePmState = PM_FIRST_STAGE_RESTARTING; /* TODO: pasar a funcion */
    pm_updateRvcReport(PM_RVC_NO_REPORT);
}

static void pm_firstStagePowerModdingStateMachine()
{
    pmSplashState_t newSplashState = pm_getSplashState();
    pmFirstStageMachineStates_t oldState = pmCurrentFirstStagePmState;
    LOG_PRINT_START_FUNC(DEBUG_PM);
    LOG_PRINT_SVER(DEBUG_PM, "Entering first stage power modding state machine, current state is %d\r\n", pmCurrentFirstStagePmState);

    static uint8_t spacerForStandbyMessages = 0;
    static uint8_t wasInTransportMode = false;

    switch(pmCurrentFirstStagePmState) {


        case PM_FIRST_STAGE_STARTING:

            LOG_PRINT_VER(DEBUG_PM, "New first stage PM state %d\r\n", PM_FIRST_STAGE_STARTING);
            /* Before arriving here, make sure the powerOnRease is already set,
             * because it is not checked after this.
             */

            if (pmTransportModeWasInitiallyOn) {
                newSplashState = pm_firstStageGoingToTransportMode();
            }
            else if ( pm_ignitionLine() || pm_IgnitionCan() ) {

                /* We have can or ignition line, check SwitchOn to see where we go */
                if (pm_isSwitchOffOn()) {
                    newSplashState = pm_firstStageGoingToOn();
                } else {
                    newSplashState = pm_firstStageGoingToIdle();
                }
            } else if ( pm_powerOnByPowerButton()) {
                /* we woke up by power button, go to timed */
                newSplashState = pm_firstStageGointToTimed();
            } else {
                /* No reason to woke up, go to off
                 * NOTE: If we woke up because a can signal
                 *      it may be that the can module hasn't still
                 *      read the ignition signal.
                 * */
                newSplashState = pm_firstStageGoingToOff();
            }
            /* Reset the variable  */
            pm_clrEndFirstStage();
            break;

        case PM_FIRST_STAGE_RESTARTING:
            /* We are here because the A15 is going back to the standby state
             * so we have to check for the power button and can signals again.
             * This ensures there is no sound and BT.
             */
            LOG_PRINT_VER(DEBUG_PM, "New first stage PM state %d\r\n", PM_FIRST_STAGE_RESTARTING);
                
            if ( pm_isTransportModeOn() || BM_In_Restricted_Mode() ) {
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Going to TM/RM from PM_FIRST_STAGE_RESTARTING\r\n");
                newSplashState = pm_firstStageGoingToTransportMode();
            }
            else if ( pm_ignitionLine() || pm_IgnitionCan() ) {
                /* We have can or ignition line, check SwitchOn to see where we go */
                if (pm_isSwitchOffOn()) {
                    newSplashState = pm_firstStageGoingToOn();
                } else {
                    newSplashState = pm_firstStageGoingToIdle();
                }
            } else {
                /*
                 * NOTE: If we woke up because a can signal
                 *      it may be that the can module hasn't still
                 *      read the ignition signal.
                 * */
                newSplashState = pm_firstStageGoingToOff();
            }
            /* Reset the variable  */
            pm_clrEndFirstStage();
            break;

        case PM_FIRST_STAGE_ON:
            
            if ( pm_isTransportModeOn() || BM_In_Restricted_Mode() ) {
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Going to TM/RM from PM_FIRST_STAGE_ON\r\n");
                newSplashState = pm_firstStageGoingToTransportMode();
            }

            /* If there are no ignition and no can, go to off (we can't go to time from here) */            
            else if ( pm_noIgnitionLine() && pm_noIgnitionCan() ) {
                newSplashState = pm_firstStageGoingToOff();
            } /*else if (pm_isPowerButtonPressed()) {  //This is to avoid turning off the screen with a gesture while is booting
                newSplashState = pm_firstStageGoingToIdle();
            }*/
             else if (pm_isEndFirstStage()) {
                pm_firstStageEndFirstStage(PM_FIRST_STAGE_ON);
            }
            break;

        case PM_FIRST_STAGE_IDLE:
            if ( pm_isTransportModeOn() || BM_In_Restricted_Mode() ) {
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Going to TM/RM from FIRST_STAGE_IDLE\r\n");
                newSplashState = pm_firstStageGoingToTransportMode();
            }

            /* If there are no ignition and no can, go to off (we can't go to time from here) */
            else if ( pm_noIgnitionLine() && pm_noIgnitionCan() ) {
                newSplashState = pm_firstStageGoingToOff();
            } else if (pm_isPowerButtonPressed()) {
                /* Check if the power button is pressed */
                newSplashState = pm_firstStageGoingToOn();
            } /* We don't check for first stage end here, only when we
               * have to turn on the screen
               */
            else {
                if (pm_isPdcRvcViewOn()) {
                    pm_turnOnScreen();
                } else {
                    pm_turnOffScreen();
                }
            }
            break;

        case PM_FIRST_STAGE_TIMED:
            if ( pm_isTransportModeOn() || BM_In_Restricted_Mode() ) {
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Going to TM/RM from FIRST_STAGE_TIMED\r\n");
                newSplashState = pm_firstStageGoingToTransportMode();
            }
            else if ( pm_ignitionLine() || pm_IgnitionCan() ) {
                
                /* Now we have can or ignition line, check SwitchOn to see where we go */
                if (pm_isSwitchOffOn()) {
                    newSplashState = pm_firstStageGoingToOn();
                } else {
                    newSplashState = pm_firstStageGoingToIdle();
                }
            }/* else if (pm_isPowerButtonPressed()) {  //This is to avoid turning off the screen with a gesture while is booting
                newSplashState = pm_firstStageGoingToOff();
            }*/
             else if (pm_isEndFirstStage()) {
                    pm_firstStageEndFirstStage(PM_FIRST_STAGE_TIMED);
            }
            break;

        case PM_FIRST_STAGE_OFF:
        
            if ( pm_isTransportModeOn() || BM_In_Restricted_Mode() ) {
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Going to TM/RM from FIRST_STAGE_OFF\r\n");
                newSplashState = pm_firstStageGoingToTransportMode();
            }
            else if ( pm_ignitionLine() || pm_IgnitionCan() ) {
                /* Now we have can or ignition line, check SwitchOn to see where we go */
                if (pm_isSwitchOffOn()) {
                    newSplashState = pm_firstStageGoingToOn();
                } else {
                    newSplashState = pm_firstStageGoingToIdle();
                }
            } else if (pm_isPowerButtonPressed()) {
                newSplashState = pm_firstStageGointToTimed();
            } else if (pm_isCanActivity()) {
                pm_updatePmInternalTimerValue(PM_NO_CAN_ACTIVITY_TIMEOUT);
            } else if (pm_timerElapsed()) {
                pm_sendShutdownMessage();
                pm_firstStageGoingToShutDown();
                /* Turn on CAN */
                Dcan_OperatingMode_Standby();
            }
            /* We don't check for first stage end here, only when we
             * have to turn on the screen
             */
            break;

        case PM_FIRST_STAGE_SHUT_DOWN:
        {
           /* We stay here until the shutdown command goes through, then we just wait for the inevitable power off */
           uint32_t counter = 0;
           while(pm_isIpuRunning()) {
               bool shutdown_message_ok = COMM_Protocol_Shut_Down(10);
               LOG_PRINT_INFO(DEBUG_PM, "IPU 1 running, sending shutdown command to msp number %d with result \n\r", ++counter, shutdown_message_ok);
               pm_updateIpuRunning(!shutdown_message_ok); /* ipu_running should go to false if message was delivered ok */
               Task_sleep(100000 / Clock_tickPeriod);
           }
           counter = 0;
           /* Stay here forever */
           while(1) {
               Task_sleep(1000000 / Clock_tickPeriod);
               LOG_PRINT_INFO(DEBUG_PM, "Famp_pm still going but waiting for shutdown iteration counter\n\r", ++counter);
            }
        }
        case PM_FIRST_STAGE_END:
            /* Advance to the next stage */
            pm_clrInFirstStage();
            /* Start the machine in the first state */
            pmCurrentOperativePmState = PM_NORMAL_INIT;
            /* At this point the screen has to keep the splash state */
            if (pm_isSplashOn()) {
                pm_setScreenOn();
            } else {
                pm_setScreenOff();
            }
            LOG_PRINT_VER(DEBUG_PM, "End first stage\r\n");
            break;

        case PM_FIRST_STAGE_REFLASHING:
            if (false == pmInReflashNow) {
                /*
                 * Something happened and the reflash was not successful
                 * go back to normal mode
                 *
                 */
                LOG_PRINT_VER(DEBUG_PM, "Reflash failed shutting down\r\n");
                ////pm_firstStageGoingToShutDown();
                pmCurrentFirstStagePmState = PM_FIRST_STAGE_STARTING; /* TODO: pasar a funcion */
            } else if (pm_timerElapsed()) {
                /*
                 * The system should reset itself after the reflash is complete
                 * If we reach this point, something happened, erase the flag and
                 * go back to normal
                 *
                 */
                LOG_PRINT_VER(DEBUG_PM, "Reflash timeout shutting down\r\n");
                pm_eraseReflashingFlag();
                ///pm_firstStageGoingToShutDown();
                pmCurrentFirstStagePmState = PM_FIRST_STAGE_STARTING; /* TODO: pasar a funcion */
            }
            break;

        case PM_FIRST_STAGE_TRANSPORT_MODE:

            pmTransportModeWasInitiallyOn = false;

            /* Just mark that TM was on, in order to send the TM off message
             * to A15 when finishing it
             */
            if (pm_isTransportModeOn()) {
                wasInTransportMode = true;
            }

            if ( !pm_isTransportModeOn() && !BM_In_Restricted_Mode() ) {
                if (wasInTransportMode) {
                    pm_sendTransportModeSendMessage(pmTransportMode);                          
                    LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Leaving TM\n");
                }
                else {
                    LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Leaving RM\n");
                }
                newSplashState = pm_firstStageGoingToOn();
            }
            else if (pm_isCanActivity()) {
                pm_updatePmInternalTimerValue(PM_NO_CAN_ACTIVITY_TIMEOUT);
            } 
            else if ( pm_timerElapsed() ) {
                    
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "No CAN signals while in TM/RM -> Go to sleep\r\n");
                
                pm_sendShutdownMessage();
                pm_firstStageGoingToShutDown();
                /* Turn on CAN */
                Dcan_OperatingMode_Standby();
            }

            /* Following section is needed to avoid the disclaimer screen on if RVC camera and transport
             * mode are turned on while HU is in sleep.
             */
            if (pm_isScreenOn()) {
                pm_turnOffAllLights();

                if (pm_isEndFirstStage()) {
                    
                    spacerForStandbyMessages++;
                    spacerForStandbyMessages %= 10;
                    if (!spacerForStandbyMessages ) {
                        pm_sendGoToStandby();
                    }
                }
            }
            break;

    }

    if (newSplashState != pm_getSplashState()) {
        pm_updateSplashState(newSplashState);
        /*TODO: send request to IPU-2 */
        LOG_PRINT_SVER(DEBUG_PM, "New splash state %d\r\n", pmSplashState);
    }

    /*
     * Checking the state here is dirty but we prefer this instead of checking it in every state.
     * We only want to enter in this function once
     */
    if ( (true == pmInReflashNow) && (PM_FIRST_STAGE_REFLASHING != pmCurrentFirstStagePmState) ) {
        LOG_PRINT_INFO(DEBUG_PM, "We are now reflashing\r\n");
        pm_firstStageGoingToReflash();
    }

    /* For debug */
    if (oldState != pmCurrentFirstStagePmState) {
        LOG_PRINT_VER(DEBUG_PM, "New first stage PM state %d\r\n", pmCurrentFirstStagePmState);
        pm_sendPowerStateMessage(false);
    }

    /* NOTE: There is a problem when restoring context from hibernation, the
     * GPIOs values are also restored even when the are managed by the M4.
     * So we need to refresh the GPIO state with the correct value.
     * A glitch can be seen when measuring with an oscilloscope, but there is
     * no visual effect.
     */
    pm_refreshScreen();

}

static void pm_powerModdingStateMachine()
{
    pmMachineStates_t oldState = pmCurrentOperativePmState;
    LOG_PRINT_START_FUNC(DEBUG_PM);
    LOG_PRINT_SVER(DEBUG_PM, "Entering power modding state machine, current state is %d\r\n", pmCurrentOperativePmState);
    switch(pmCurrentOperativePmState) {

        case PM_NORMAL_INIT:
            /* We wait some time to synchronize the screen time in case there is
             * a change from the first stage state machine
             */
            pmCurrentOperativePmState = PM_GOING_TO_START;
            pm_updatePmInternalTimerValue(PM_SCREEN_MSG_SYNC_TIMEOUT);
            pm_updateRvcReport(PM_RVC_NO_REPORT);
            break;

        case PM_GOING_TO_START:
            
            if (pm_timerElapsed()) {
                pmCurrentOperativePmState = PM_START;
            }
            pm_updateRvcReport(PM_RVC_NO_REPORT);
            break;

        case PM_START:
            /* We start where the first stage left us and then we go from there
             * TODO: Check what happens with a POWER_BUTTON key press when
             * we are changing machines. Does it
             */
            switch(pmLastFirstStageState) {
                
                case PM_FIRST_STAGE_ON:
                    pm_goToHmiOn();
                    break;
                case PM_FIRST_STAGE_IDLE:
                    pm_goToHmiOff();
                    break;
                case PM_FIRST_STAGE_TIMED:
                    pm_goToTimed(PM_TIMED_REASON_POWER_BUTTON);
                    break;
                case PM_FIRST_STAGE_OFF:
                case PM_FIRST_STAGE_END:
                case PM_FIRST_STAGE_STARTING:
                default:
                    pm_goToStandby();
            }
            break;

        case PM_HMI_GOING_ON:
            if (pm_timerElapsed()) {
                pmCurrentOperativePmState = PM_HMI_ON;
            }
            break;

        case PM_HMI_ON:
            if ( pm_isTransportModeOn() || BM_In_Restricted_Mode() ) {
                pm_goToTransportModeFromSecondStage();
            } else if (pm_ignitionLine() || pm_IgnitionCan()) {
                if (pm_isScreenOff()) {
                    /* If the power button was pressed,
                     * then go to hmi off
                     */
                    pm_goToHmiOff();
                }
            } else {
                /* No can and no ignition, check if we have the key inserted to go to timed */
                if (pm_isCanKeyStatusInserted()) {
                    pm_goToTimed(PM_TIMED_REASON_CAN_IGNITION);
                } else {
                    /* No key inserted, go to off */
                    pm_goToStandby();
                }
            }
            break;

        case PM_HMI_GOING_TIMED:
            /* No need to add a buffer time */
            pmCurrentOperativePmState = PM_TIMED;
            break;

        case PM_TIMED:
            if ( pm_isTransportModeOn() || BM_In_Restricted_Mode() ) {
                pm_goToTransportModeFromSecondStage();   
            }
            /* Timed always has hmi on */
            else if (pm_ignitionLine() || pm_IgnitionCan()) {
                /* We have ignition or can, go to hmi on */
                pm_goToHmiOn();
            } else if (pm_isScreenOff()) {
                /* Power button pressed, go to off */
                pm_goToStandby();
            } else if (pm_isEngModeStatus()) {
                /* If we are in eng then we dont go to timed state, we go directly to standby */
                pm_goToStandby();
            } else if (pm_isTimedReasonCan() && pm_isCanKeyStatusRemoved()) {
                /* Key removed and came from hmi_on, go to off */
                pm_goToStandby();
            } else if (pm_timerElapsed()) {
                if (pm_isCallInProgress()) {
                    /* we are in a call, go to the extended time */
                    pm_goToExtendedTimed();
                } else {
                    /* Timer elapsed, go to off */
                    pm_goToStandby();
                }
            }
            break;

        case PM_GOING_EXTENDED_TIMED:
            /* No need to add a buffer time */
            pmCurrentOperativePmState = PM_EXTENDED_TIMED;
            break;

        case PM_EXTENDED_TIMED:
            /* Timed always has hmi on */
            if ( pm_isTransportModeOn() || BM_In_Restricted_Mode() ) {
                pm_goToTransportModeFromSecondStage();                
            }
            else if (pm_ignitionLine() || pm_IgnitionCan()) {
                /* We have ignition or can, go to hmi on */
                pm_goToHmiOn();
            } else if (pm_timerElapsed() || pm_isScreenOff() || (!pm_isCallInProgress()) || (pm_isTimedReasonCan() && pm_isCanKeyStatusRemoved())) {
                /* Timer elapsed or power button pressed or the call ended or key removed and we came from hmi_on, go to off */
                pm_goToStandby();
            }
            break;

        case PM_HMI_GOING_OFF:
            if (pm_timerElapsed()) {
                pmCurrentOperativePmState = PM_HMI_OFF;
                #if (USE_TOUCHSCREEN_AS_PWRBTN == 1)
                    pm_initPowerButtonLocal();
                #endif
            }
            break;

        case PM_HMI_OFF:
            if ( pm_isTransportModeOn() || BM_In_Restricted_Mode() ) {    
                pm_goToStandby();
            }
            else if (pm_ignitionLine() || pm_IgnitionCan()) {
                /* We have to turn it on again, lets check switchOn and move
                 * to that state
                 */
                #if (USE_TOUCHSCREEN_AS_PWRBTN == 1)
                if (pm_isPowerButtonPressed()) {
                #else
                if (pm_isScreenOn()) {
                #endif
                    pm_goToHmiOn();
                } else {
                    if (pm_isPdcRvcViewOn()) {
                        pm_turnOnScreen();
                    } else {
                        pm_turnOffScreen();
                    }
                }
            } else {
                /* go directly to standby, we don't go to timed from here
                 *
                 */
                pm_goToStandby();
            }
            break;

        case PM_GOING_STANDBY:
            if (pm_timerElapsed()) {
                /* Timer elapsed */
                pmCurrentOperativePmState = PM_STANDBY;
            }
            break;

        case PM_STANDBY:
            /*
             * We go back to the first stage machine and we will send
             * the am restart to android.
             * It will be the same as when the HU is booting up
             */
            pm_sendGoToStandby();
            pm_restartFirstStage();
            pmCurrentOperativePmState = PM_DO_NOTHING;
            pm_updateRvcReport(PM_RVC_REPORT_OFF);
            break;

        case PM_DO_NOTHING:
        default:
            LOG_PRINT_ERR(DEBUG_PM, "We should never reach this place");
    }

    /* For debug */
    if (oldState != pmCurrentOperativePmState) {
        LOG_PRINT_VER(DEBUG_PM, "New PM state %d\r\n", pmCurrentOperativePmState);
        pm_sendPowerStateMessage(true);
    }
}

static void famp_pm_Shutdown()
{
    LOG_PRINT_START_FUNC(DEBUG_PM);
}

static void famp_pm_thread(UArg arg0, UArg arg1)
{
    bool running = true;

    LOG_PRINT_START_FUNC(DEBUG_PM);
    LOG_PRINT_START_FUNC(DEBUG_TRANSPORT_MODE);
    LOG_PRINT_INFO(DEBUG_PM, "famp_pm_thread entry\n");
    LOG_PRINT_INFO(DEBUG_PM, "System tick period is %d us\n", Clock_tickPeriod);

    /*
     * Erase this flag before anything to avoid collision
     * with the recovery if we are in a reflash
     *
     */
    pm_eraseReflashingFlag();

#ifdef PM_USE_SECONDS_TIMER
    /* Initialize the seconds module to use as counter. The 0 value sets the today to
     * EPOCH time Jan 1 1970 */
    Seconds_set(0);
#endif
//    FAMP_COM_init();
    PM_QUEUE_Init();

    if (pm_isColdStart()) {
        LOG_PRINT_VER(DEBUG_PM, "Cold Start\n");
        LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Cold Start\n");
        pm_saveWarmStartCondition();
        pm_setSwitchOnValue(PM_SWITCHON_ON);

        // We set our variable to query the transport mode status saved in A15.
        waitingTransportModeStateFromA15 = true;
        recoveringTransportModeFromA15 = true;

        /* If there was a Cold state, we can't trust the tranport mode from MSP430, so
         * we mark this situation.
         */
        pmTransportModeRecoveredByMSP = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;
        pmTransportModeRecoveredByA15 = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;

        /* If we didn't receive any update for transport mode by CAN, our recovered state from
         * the A15 is the best known state up to now.
         */
        if ( pmTransportModeState_By_CAN == TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE ) {
            pmTransportMode = pmTransportModeRecoveredByA15;
        }
        isColdStart = TRUE;

    } else {

        LOG_PRINT_VER(DEBUG_PM, "Warm Start\n");

        pm_getSwitchOnValue();

        pmTransportModeRecoveredByA15 = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;
        pmTransportModeRecoveredByMSP = pm_getTransportMode_MSP();
        pmTransportModeWasInitiallyOn = false;

        if (TRANSPORT_MODE_ON == pmTransportModeRecoveredByMSP) {
            LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Transport Mode by MSP persistence is: enabled\r\n");
            pmTransportModeWasInitiallyOn = true;
        }
        else if (TRANSPORT_MODE_OFF == pmTransportModeRecoveredByMSP) {
            LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Transport Mode by MSP persistence is: disabled\r\n");
        }
        else {
            pmTransportModeRecoveredByMSP = TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;
            LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "Transport Mode by MSP persistence is unknown, so we'll disable transport mode\r\n");
        }

        /* In Warm Start, the state of the transport mode reported by A15 is not useful. So, we
         * don't need to ask about it.
         */
        waitingTransportModeStateFromA15 = false;
        recoveringTransportModeFromA15 = false;

        /* If we didn't receive any update for transport mode by CAN, our recovered state from
         * the MSP is the best known state up to now.
         */
        if ( pmTransportModeState_By_CAN == TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE ) {
            pmTransportMode = pmTransportModeRecoveredByMSP;
            LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, "New Transport Mode asigned acording to the value restored from MSP: %d\r\n", pmTransportMode);
        }
        isColdStart = FALSE;

        /* Inform the HMI manager about the current transport mode */
        HmiManager_update_transport_mode(pm_isTransportModeOn());
    }

    /* It is important that this variable is set from the beging, to avoid false shutdowns, but we  initialize nontheless for completion */
    pm_setIpuRunning();

    pm_getWakeUpReason();
    pm_initPowerButtonLocal();

    /* We start in the first stage */
    pm_setInFirstStage();
    /* Start with the splash off */
    pm_clrSplashState();
    /* No can activity until we ask the MSP */
    pm_clrCanActivity();
    /* No call in progress */
    pm_clrCallInProgress();

    pmCurrentFirstStagePmState = PM_FIRST_STAGE_STARTING; /* TODO: pasar a funcion */
    pmQueueSyncFinished = false;
    pmSendTimeAndDateRequest = true;
    pmSendCanBusActiveMessage = true;

    PMIC_65919_Configure_ADC();
    pm_turnOnAllLights();
    while (running)
    {        
#ifdef REAL_PROGRAM
        if( (false == pmQueueSyncFinished) && (SB_QUEUE_Wait_For_A15()) )
        {
            /* Check if everything is synchronized so we don't enter here again */
            if ( (0 <= PM_QUEUE_Init_Client()) && (0 <= PM_QUEUE_Init_Server()) ) {
                pm_sendIpu1Sync();
                /* All synchronized, we could use this variable before sending
                 * something to the A15.
                 * We should also check for incoming A15 message.
                 * We are assuming that this takes place before any important exchange
                 * takes place, so we are not checking every condition
                 * */
                pmQueueSyncFinished = true;

                // If we need to know the state of the transport mode by A15, we send a query                 
                if ( true == waitingTransportModeStateFromA15 ) {
                    pm_sendTransportModeQueryMessage();
                    LOG_PRINT_VER(DEBUG_PM, "We sent the transport mode query to the A15\r\n");        
                }
            }
        }

        if (true == pmQueueSyncFinished) {
            if ( true == pmSendTimeAndDateRequest ) {
                pm_sendTimeDateInfo();
                pmSendTimeAndDateRequest = false;
            }

            if (true == pmSendCanBusActiveMessage && true == pm_isCanActivity()) {
                pm_sendCanBusStateMessage();
                pmSendCanBusActiveMessage = false;
            }
        }

        BM_State_Machine();

        /* Check If we have to signal the RVC */
        if (pm_isRvcReport(PM_RVC_REPORT_REAL_VALUE)) {
            /* Radio is in FO or IDLE, we have to send the real RVC state */
            CanAppl_ReportCurrentRvcStatus();
            ES_ReportCurrentRvcStatus();
            LOG_PRINT_SVER(DEBUG_PM, "Report camera value\n");
        } else if (pm_isRvcReport(PM_RVC_REPORT_OFF)) {
            /* Radio is not with ignition, force RVC off */
            CanAppl_ReportRvcOff();
            LOG_PRINT_SVER(DEBUG_PM, "Report camera OFF\n");
        } else {
            /* If we have report OFF, then we don't do anything */
            LOG_PRINT_SVER(DEBUG_PM, "Do not Report camera\n");
        }

        /* read inputs */
        if (pm_readQueue() == PM_MESSAGE_RECEIVED) {
            pm_processNewMessage();
            pm_freeMessage();
        }
        pm_readInputs();

        pm_CheckIfReflashing();

        pm_Check_Transport_Mode();

        /* state machine */
        if (pm_isInFirstStage()) {
            pm_firstStagePowerModdingStateMachine();
        } else {
            pm_powerModdingStateMachine();
        }


        // New block to periodically write some error messages that we can't loose.
        #if defined (KEEP_TRACKING_OLD_ERRORS)
        if (oldErrorStored) {
            if (oldErrorTimerCount <= pm_getCurrentTime()) {
                LOG_PRINT_VER(DEBUG_TRANSPORT_MODE, bufferOldError);
                oldErrorTimerCount = pm_getCurrentTime() + OLD_ERROR_TIME_MS;
            }
        }
        #endif


        /* sleep */
        LOG_PRINT_SVER(DEBUG_PM, "Enter Sleep\n");
        if (pm_isInFirstStage()) {
            /* We query the power button in this stage, so we need a shorter sleep time */
            Task_sleep(FAMP_PM_TASK_SLEEP_FIRST_STAGE_US / Clock_tickPeriod);
        }
        else {
            Task_sleep(FAMP_PM_TASK_SLEEP_NORMAL_STAGE_US / Clock_tickPeriod);
        }
        LOG_PRINT_SVER(DEBUG_PM, "Exit Sleep\n");


#endif
    }

    PM_QUEUE_ShutDown();
    famp_pm_Shutdown();
}

void FAMP_PM_Force_Cold_Start (void)
{
    COMM_Protocol_Shut_Down(0);
}

bool_t FAMP_PM_Is_IgnitionOn (void)
{
    bool_t ret = false;
    if (pm_ignitionLine() || pm_IgnitionCan())
    {
        ret = true;
    }
    return ret;
}

bool_t FAMP_PM_Is_IpuRunning(void)
{
    return (true == pm_isIpuRunning());
}

bool FAMP_PM_isSyncFinished (void) {
    return (pmQueueSyncFinished);
}

void FAMP_PM_Task_Init (void)
{
    Error_Block eb;
    Task_Params taskParams;
    Task_Handle task_h;

    LOG_PRINT_START_FUNC(DEBUG_PM);
    LOG_PRINT_INFO(DEBUG_PM, "FAMP_PM initialization\n");

    Error_init(&eb);

    /* create main thread (interrupts not enabled in main on BIOS) */
    Task_Params_init(&taskParams);
    taskParams.instance->name = "famp_pm";
    taskParams.arg0 = NULL;
    taskParams.arg1 = NULL;
    taskParams.stack = stack;
    taskParams.stackSize = 0x1000;
    taskParams.affinity = APP_CORE_NUM;
    task_h = Task_create(famp_pm_thread, &taskParams, &eb);

    if (NULL == task_h)
    {
        LOG_PRINT_ERR(DEBUG_PM, "Couldn't create famp_pm task\n");
    }
    else
    {
        LOG_PRINT_INFO(DEBUG_PM, "famp_pm thread created successfully\n");
    }
}

void FAMP_PM_Inform_RvcPdc_View_On(bool_t state)
{
    pm_updatePdcRvcViewOn(state);
}

void FAMP_PM_Turn_On_Screen(void)
{
    DIMMING_SetChannelOn(DIM_USER_A, DIM_DISP);
}

void FAMP_PM_Turn_Off_Screen(void)
{
    DIMMING_SetChannelOff(DIM_USER_A, DIM_DISP);
}
