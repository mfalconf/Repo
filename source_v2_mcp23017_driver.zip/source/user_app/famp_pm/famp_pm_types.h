/*
 * famp_types.h
 *
 *  Created on: May 8, 2018
 *      Author: ggabriel
 */

#ifndef PM_INCLUDE_FAMP_TYPES_H_
#define PM_INCLUDE_FAMP_TYPES_H_

typedef enum {
   PM_IGNITION_CAN_OFF,
   PM_IGNITION_CAN_ON,
}pmCanState_t;

typedef enum {
   PM_CAN_KEY_REMOVED,
   PM_CAN_KEY_INSERTED,
}pmCanKeyStatus_t;

/* Values in accordance with MSP documentation */
typedef enum {
   PM_IGNITION_LINE_ERROR = -1,
   PM_IGNITION_LINE_OFF = 0,
   PM_IGNITION_LINE_ON = 1,
}pmIgnitionLineState_t;

/* Values in accordance with MSP documentation */
typedef enum {
   PM_CAN_BUS_IDLE = 0,
   PM_CAN_BUS_WITH_ACTIVITY = 1,
}pmCanBusActivity_t;

/* Values in accordance with MSP documentation */
typedef enum {
   PM_POWER_BUTTON_ERROR = -1,
   PM_POWER_BUTTON_RELEASED = 0,
   PM_POWER_BUTTON_PRESSED = 1,
}pmPowerButtonStates_t;

typedef enum {
   PM_TIMED_REASON_CAN_IGNITION,
   PM_TIMED_REASON_POWER_BUTTON,
}pmTimedReason_t;

typedef enum {
   WAKE_UP_ERROR = -1,
   WAKE_UP_POWERDOWN = 0,
   WAKE_UP_POWERUP_CONDITION_POWERBTN = 1,
   WAKE_UP_POWERUP_CONDITION_IGNITION = 2,
   WAKE_UP_POWERUP_CONDITION_CAN = 3,
   WAKE_UP_POWERUP_CONDITION_MFG = 4,
}pmWakeUpCondition_t;

typedef enum {
   PM_NORMAL_INIT,
   PM_GOING_TO_START,
   PM_START,
   PM_HMI_GOING_ON,
   PM_HMI_ON,
   PM_HMI_GOING_OFF,
   PM_HMI_OFF,
   PM_HMI_GOING_TIMED,
   PM_TIMED,
   PM_GOING_EXTENDED_TIMED,
   PM_EXTENDED_TIMED,
   PM_GOING_STANDBY,
   PM_STANDBY,
   PM_DO_NOTHING,
}pmMachineStates_t;

typedef enum {
    PM_FIRST_STAGE_STARTING,
    PM_FIRST_STAGE_RESTARTING,
    PM_FIRST_STAGE_ON,
    PM_FIRST_STAGE_IDLE,
    PM_FIRST_STAGE_TIMED,
    PM_FIRST_STAGE_OFF,
    PM_FIRST_STAGE_SHUT_DOWN,
    PM_FIRST_STAGE_END,
    PM_FIRST_STAGE_REFLASHING,
    PM_FIRST_STAGE_TRANSPORT_MODE
}pmFirstStageMachineStates_t;

/* Replicated in Java program using these properties */
typedef enum {
    PM_POWER_STATE_OFF = 0,
    PM_POWER_STATE_FO = 1,
    PM_POWER_STATE_TIMED = 2,
    PM_POWER_TRANSPORT_MODE = 3
}pmPropertyPowerState_t;

/* Replicated in Java program using these properties. */
#define PM_PROPERTY_SCREEN_KEY "pm.screen.status"

/* Replicated in Java program using these properties. */
typedef enum {
   PM_PROPERTY_SCREEN_ERROR = 0,
   PM_PROPERTY_SCREEN_IS_ON = 1,
   PM_PROPERTY_SCREEN_IS_OFF = 2,
}pmPropertyScreen_t;

typedef enum {
    SPLASH_UNKOWN,
    SPLASH_ON,
    SPLASH_OFF,
}pmSplashState_t;

typedef enum {
    PM_NO_MESSAGE,
    PM_MESSAGE_RECEIVED,
    PM_CRC_INVALID,
}pmQueueStatus_t;

typedef enum {
    PM_SWITCHON_ON,
    PM_SWITCHON_OFF,
}pmSwitchOn_t;


#endif /* PM_INCLUDE_FAMP_TYPES_H_ */
