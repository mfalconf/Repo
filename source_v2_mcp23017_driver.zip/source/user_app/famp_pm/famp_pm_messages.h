/*
 * famp_pm_messages.h
 *
 *  Created on: May 29, 2018
 *      Author: ggabriel
 */
#ifndef SOURCE_INC_FAMP_PM_MESSAGES_H_
#define SOURCE_INC_FAMP_PM_MESSAGES_H_


typedef enum {
    PM_ANDROID_TO_M4_RESERVED = 0,
    PM_ANDROID_TO_M4_SYNC,
    PM_ANDROID_TO_M4_FIRST_STAGE_BOOT_COMPLETED,
    PM_ANDROID_TO_M4_SCREEN_STATUS,
    PM_ANDROID_TO_M4_CALL_IN_PROGRESS,
    PM_ANDROID_TO_M4_REPORT_TRANSPORT_MODE,
    PM_ANDROID_TO_M4_ENG_MODE_STATUS,
    PM_M4_TO_ANDROID_SYNC,
    PM_M4_TO_ANDROID_POWER_BUTTON,
    PM_M4_TO_ANDROID_CURRENT_POWER_STATE,
    PM_M4_TO_ANDROID_GO_TO_STANDBY,
    PM_M4_TO_ANDROID_SHUT_DOWN,
    PM_M4_TO_ANDROID_QUERY_TRANSPORT_MODE,
    PM_M4_TO_ANDROID_SEND_TRANSPORT_MODE_FOR_SAVING,
    PM_M4_TO_ANDROID_TIME_AND_DATE,
    PM_M4_TO_ANDROID_CAN_BUS_STATE,

    PM_NUMBER_OF_MESSAGES
}pmAndroidToM4MessageCodes_t;

/* Message generic type
 * It will be casted after the message code is read
 */
typedef struct SBMsg
{
    MessageQ_MsgHeader header;     // Required
    uint32_t crc32;
    uint32_t len;
    uint32_t data[3];
} SBMsg;

typedef SBMsg* pSBMsg_t;

/* From Android to M4 */
typedef struct {
    uint32_t messageCode;
}pmMessageSync;

typedef struct {
    uint32_t messageCode;
}pmMessageFirstStageCompleted;

typedef struct {
    uint32_t messageCode;
    uint32_t screenStatus;
}pmMessageScreenStatus;

typedef struct {
    uint32_t messageCode;
    uint32_t callInProgress;
}pmMessageCallInProgressStatus;

typedef struct {
    uint32_t messageCode;
    uint32_t engModeStatus;
}pmMessageEngModeStatus;

/* From M4 Android to */

typedef struct {
    uint32_t messageCode;
}pmIpu1Sync;

typedef struct {
    uint32_t messageCode;
    uint32_t powerOn;
}pmMessagePower;

typedef struct {
    uint32_t messageCode;
    uint32_t currentState; /* Sent as a uint32_t to avoid compiler issues, but type is pmPropertyPowerState_t */
}pmCurrentPowerState;

typedef struct {
    uint32_t messageCode;
}pmGoToStandby;

typedef struct {
    uint32_t messageCode;
}pmMessageShutDown;

typedef struct {
    uint32_t messageCode;
}pmMessageQueryTransportMode;

typedef struct {
    uint32_t messageCode;
    uint32_t reportedTransportMode; /* Sent as a uint32_t to avoid compiler issues, but type is pmPropertyPowerState_t */
}pmMessageReportTransportMode;

typedef struct {
    uint32_t messageCode;
    uint32_t newTransportModeState; /* Sent as a uint32_t to avoid compiler issues, but type is pmPropertyPowerState_t */
}pmMessageSendTransportStateForSaving;

typedef struct {
    uint32_t messageCode;
    uint8_t timeAndDate[7];
}pmMessageTimeAndDate;

typedef struct {
    uint32_t messageCode;
}pmCanBusState;

#endif /* SOURCE_INC_FAMP_PM_MESSAGES_H_ */
