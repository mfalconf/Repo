#ifndef ASWC_H_
#define ASWC_H_
/*===========================================================================*/
/**
 * @file ASWC.h
 *
 * Function definitions for the Analog SWC interface module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <stdint.h>

#if (USE_ASWC_TOYOTA == 1)
    #include <aswc_toyota_cfg.h>
#endif
#if (USE_ASWC_NISSAN == 1)
    #include <aswc_nissan_cfg.h>
#endif
#if (USE_ASWC_FT_WI == 1)
    #include <aswc_ft_wi_cfg.h>
#endif
//#if (USE_ASWC_BENCH == 1)
    #include <aswc_bench_cfg.h>
//#endif

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum ASWC_KEY_Tag
{
   ASWC_NOKEY,
   ASWC_Key_Vol_Up,
   ASWC_Key_Vol_Down,
   ASWC_Key_Mute,
   ASWC_Key_Next,
   ASWC_Key_Prev,
   ASWC_Key_Pick_Up,
   ASWC_Key_Hang_Up,
   ASWC_Key_Src,
   ASWC_Key_Voice,
   ASWC_Key_Flash,
   ASWC_Key_Preset
} ASWC_KEY_T;

typedef enum ASWC_CHANNEL_TAG {
    AD_CHANNEL_ASWC_CH2 = 0,
    AD_CHANNEL_ASWC_CH1 = 1,
} ASWC_CHANNEL_T;

typedef enum
{
    NO_PRESSED = 0,
    DEBOUNCE,
    VALIDATE,
    PRESSED
} ASWC_DEBOUNCE_STATE_T;

typedef enum
{
    KEY_NO_PRESSED = 0,
    KEY_PRESSED
}ASWC_Key_State_E;

typedef struct
{
    ASWC_Key_State_E key_state;
    uint32_t voltage;
}ASWC_Key_Cfg_T;

typedef enum
{
    ASWC_UPDATE_CHANNEL = 0,
    ASWC_UPDATE_KEYS,
    ASWC_UPDATE_IDLE,
    ASWC_NUM_STATES
}ASWC_State_E;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
void ASWC_Init (void);
void ASWC_Update (void);
bool_t ASWC_SetState(ASWC_State_E newState);
bool_t ASWC_SetNoKeyCfgState(bool_t value);
void ASWC_SetKeyCfg(int channel,ASWC_KEY_T newKey);
void ASWC_Set_ASWC_Cfg(int channel,uint8_t *data);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file ANTPWR.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 05-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* ASWC_H_ */
