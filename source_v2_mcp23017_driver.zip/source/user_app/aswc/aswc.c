/*===========================================================================*/
/**
 * @file aswc.c
 *
 * Analog SWC interface
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <aswc.h>

#include <drv/board/board.h>
#include <comm_protocol.h>
#include <console.h>
#include <conversions.h>
#include <shadow_storage.h>

#include <ti/csl/soc.h>
#include <ti/csl/csl_gpio.h>
#include <ti/csl/hw_types.h>
#include <xdc/runtime/System.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/BIOS.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define MIN_AD_COUNTS         0x0
#define MAX_AD_COUNTS         0x03FF

#define DELTA                 100

#define SCAN_RATE_ms                50
#define DEBOUNCE_TIME_CONFIG_ms     500
#define DEBOUNCE_TIME_CONFIG        (DEBOUNCE_TIME_CONFIG_ms/SCAN_RATE_ms)
#define DEBOUNCE_TIME_UPDATE_ms     100
#define DEBOUNCE_TIME_UPDATE        (DEBOUNCE_TIME_UPDATE_ms/SCAN_RATE_ms)

#define UPDATE_IDLE_TIME_ms         2000
#define UPDATE_IDLE_TIME            (UPDATE_IDLE_TIME_ms/SCAN_RATE_ms)

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef struct aswc_cfg_Tag
{
   uint16_t v_min;
   uint16_t v_max;
   ASWC_KEY_T key_code;
} aswc_cfg_T;

typedef struct aswc_ch_data_Tag {
    /* Channel data */
    aswc_cfg_T              * config_ch1;
    aswc_cfg_T              * config_ch2;
    uint32_t                number_of_keys;
    /* Key debounce */
    ASWC_KEY_T              key;
    ASWC_KEY_T              last_key;
    ASWC_DEBOUNCE_STATE_T   debounce_state;
    ASWC_DEBOUNCE_STATE_T   next_debounce_state;
    uint32_t                last_time;
} aswc_ch_data_t;

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
aswc_ch_data_t data_key;

ASWC_KEY_T selected_key_cfg_ch1;
ASWC_KEY_T selected_key_cfg_ch2;

ASWC_Key_Cfg_T keycfg_ch1 = {KEY_NO_PRESSED,0};
ASWC_Key_Cfg_T keycfg_ch2 = {KEY_NO_PRESSED,0};

#if (USE_ASWC == 1)
    #undef X
    #define X(a,b,c) {a,b,c},
    static aswc_cfg_T aswc_cfg[] = {ASWC_V_TABLE};
    static uint8_t aswc_cfg_buffer[6] = {0};

    #if (USE_SECOND_ADC_CH == 1)
        static aswc_cfg_T aswc_cfg_ch2[] = {ASWC_V_TABLE_CH2};
        static uint8_t aswc_cfg_ch2_buffer[6] = {0};
    #else
        static aswc_cfg_T aswc_cfg_ch2[];
        static uint8_t aswc_cfg_ch2_buffer[6] = {0};
    #endif
#else
    static aswc_cfg_T aswc_cfg[] = {0};
    static aswc_cfg_T aswc_cfg_ch2[] = {0};
    static uint8_t aswc_cfg_buffer[6] = {0};
    static uint8_t aswc_cfg_ch2_buffer[6] = {0};
#endif

ASWC_State_E aswc_state;
bool_t aswc_nokey_cfg;
static Semaphore_Handle aswc_cfg_sem = NULL;
bool_t measure_idle = false;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
bool_t ASWC_InitState(ASWC_State_E newState);
ASWC_State_E ASWC_GetState(void);

void ASWC_UpdateKeys(void);
void ASWC_KeyPressed(int channel,ASWC_Key_State_E* pKeyState,uint32_t* pVoltage);
void ASWC_KeyPressed_Debounce(int channel, ASWC_DEBOUNCE_STATE_T* pPrevState, uint32_t* pLastTime,ASWC_Key_Cfg_T* pKeyCfg);
void ASWC_SendKeyCfg(ASWC_Key_Cfg_T key_cfg_ch1,ASWC_Key_Cfg_T key_cfg_ch2);
void ASWC_ConfigKey(int channel,uint32_t voltage);

void ASWC_UpdateIdle(void);

void ASWC_UpdateChannel(void);
void ASWC_DebounceKey(aswc_ch_data_t * pData);
ASWC_KEY_T ASWC_ReadKey(aswc_ch_data_t * pData);
void ASWC_ClearUpdateChannelVars(aswc_ch_data_t * pData);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/
#define VAR_AND_SIZE(var) var, Num_Elems(var)

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
*
* @fn         ASWC_Init
*
* @brief      Initialization function
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void ASWC_Init (void)
{
#if (USE_ASWC == 1)
    aswc_cfg_sem = Semaphore_create(1, NULL, NULL);
    ASWC_InitState(ASWC_UPDATE_CHANNEL);

    data_key.config_ch1 = aswc_cfg;
    data_key.config_ch2 = aswc_cfg_ch2;
    data_key.number_of_keys = Num_Elems(aswc_cfg);
    ASWC_ClearUpdateChannelVars(&data_key);
#endif
}

/***************************************************************************//**
*
* @fn         ASWC_InitState
*
* @brief      Check if a SWC button was pressed comparing the read voltage
*             with the ASWC_NOKEY voltage range. If the read voltage is lower
*             than the min voltage of the ASWC_NOKEY the function detect that
*             a key was pressed
*
* @param [in] channel number
*
* @return     true if key pressed, false otherwise
*
******************************************************************************/
bool_t ASWC_InitState(ASWC_State_E newState)
{
    bool_t ret = false;

    if(newState < ASWC_NUM_STATES)
    {
        switch(newState)
        {
            case ASWC_UPDATE_CHANNEL:
                LOG_PRINT(DEBUG_ASWC, "ASWC_InitState: ASWC_UPDATE_CHANNEL\r\n");
                ASWC_ClearUpdateChannelVars(&data_key);
                aswc_state = ASWC_UPDATE_CHANNEL;
                ret = true;
            break;

            case ASWC_UPDATE_KEYS:
                LOG_PRINT(DEBUG_ASWC, "ASWC_InitState: ASWC_UPDATE_KEYS\r\n");
                selected_key_cfg_ch1 = ASWC_NOKEY;
                selected_key_cfg_ch2 = ASWC_NOKEY;
                keycfg_ch1.key_state = KEY_NO_PRESSED;
                keycfg_ch1.voltage = aswc_cfg[0].v_min + (DELTA/2);
                keycfg_ch2.key_state = KEY_NO_PRESSED;
                keycfg_ch2.voltage = aswc_cfg_ch2[0].v_min + (DELTA/2);
                aswc_state = ASWC_UPDATE_KEYS;
                aswc_nokey_cfg = false;
                ret = true;
            break;

            case ASWC_UPDATE_IDLE:
                LOG_PRINT(DEBUG_ASWC, "ASWC_InitState: ASWC_UPDATE_IDLE\r\n");
                keycfg_ch1.key_state = KEY_NO_PRESSED;
                keycfg_ch1.voltage = aswc_cfg[0].v_min + (DELTA/2);
                keycfg_ch2.key_state = KEY_NO_PRESSED;
                keycfg_ch2.voltage = aswc_cfg_ch2[0].v_min + (DELTA/2);
                aswc_state = ASWC_UPDATE_IDLE;
                measure_idle = true;
            break;

            default:

            break;
        }
    }

    return ret;
}

/***************************************************************************//**
*
* @fn         ASWC_GetState
*
* @brief      Check if a SWC button was pressed comparing the read voltage
*             with the ASWC_NOKEY voltage range. If the read voltage is lower
*             than the min voltage of the ASWC_NOKEY the function detect that
*             a key was pressed
*
* @param [in] channel number
*
* @return     true if key pressed, false otherwise
*
******************************************************************************/
ASWC_State_E ASWC_GetState(void)
{
    ASWC_State_E ret;

    /* Get access to resouce */
    Semaphore_pend(aswc_cfg_sem, BIOS_WAIT_FOREVER);

    ret = aswc_state;

    /* Release access to resource */
    Semaphore_post(aswc_cfg_sem);

    return ret;

}


/***************************************************************************//**
*
* @fn         AntPwr_Update
*
* @brief      Update the ASWC state
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void ASWC_Update (void)
{
#if (USE_ASWC == 1)
    switch(ASWC_GetState())
    {
        case ASWC_UPDATE_CHANNEL:
            ASWC_UpdateChannel();
        break;

        case ASWC_UPDATE_KEYS:
            ASWC_UpdateKeys();
        break;

        case ASWC_UPDATE_IDLE:
            ASWC_UpdateIdle();
        break;

        default:

        break;
    }
#endif
}


/***************************************************************************//**
*
* @fn         ASWC_UpdateChannel
*
* @brief      Update an ASWC channel
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void ASWC_UpdateChannel(void){
    /* Get access to resouce */
    Semaphore_pend(aswc_cfg_sem, BIOS_WAIT_FOREVER);

    ASWC_DebounceKey(&data_key);

    /* Release access to resource */
    Semaphore_post(aswc_cfg_sem);
}

/***************************************************************************//**
*
* @fn         ASWC_DebounceKey
*
* @brief      Debounce an ASWC channel. It has a state machine to perform the
*             respective lecture and validates it after @DEBOUNCE_TIME_UPDATE
*             time.
*             A valid key detection is informed to A15 using shadow storage api.
*
* @param [in] aswc_ch_data_t channel pointer data
*
* @return     None
*
******************************************************************************/
void ASWC_DebounceKey(aswc_ch_data_t * pData)
{
    /* We need a 16bit word to be sent to VEPO system */
    uint16_t aux_data16 = 0;
    pData->debounce_state = pData->next_debounce_state;

    switch (pData->next_debounce_state) {
        case NO_PRESSED:
            pData->key = ASWC_ReadKey(pData);

            if(pData->key != pData->last_key) {
                pData->next_debounce_state = VALIDATE;
                pData->last_key = pData->key;
                pData->last_time = 0;
            }
        break;

        case VALIDATE:
            pData->last_time++;
            if (DEBOUNCE_TIME_UPDATE != pData->last_time) {
                // Still debouncing
                break;
            }

            pData->key = ASWC_ReadKey(pData);

            if(pData->key == pData->last_key) {
                // Key validated. Same value read after DEBOUNCE_TIME_UPDATE
                aux_data16 = (ASWC_NOKEY == pData->key) ? 0 : (1 << pData->key);
                LOG_PRINT(DEBUG_ASWC, "Key selected: %d\r\n",pData->key);
                Shadow_Server_Storage_Set(SHADOW_SWCSts, (uint8_t *) &aux_data16);
                pData->next_debounce_state = NO_PRESSED;
            } else {
                // Noise or a transition voltage read
                // Wait another DEBOUNCE_TIME_UPDATE to decide
                pData->last_time = 0;
                pData->next_debounce_state = VALIDATE;
            }

            pData->last_key = pData->key;
        break;
    }
}

/***************************************************************************//**
*
* @fn         ASWC_ReadKey
*
* @brief      Read ADC channel, converts the lecture in voltage and return
*             the @ASWC_KEY_T asociated to this voltage
*
* @param [in] aswc_ch_data_t channel pointer data
*
* @return     ASWC_KEY_T with the key pressed
*
******************************************************************************/
ASWC_KEY_T ASWC_ReadKey(aswc_ch_data_t * pData)
{
    uint32_t i = 0;
    uint32_t value = 0;
    uint32_t voltageCh1 = 0;
    uint32_t voltageCh2 = 0;
    ASWC_KEY_T key = ASWC_NOKEY;

    value = COMM_Protocol_GetADStatus(AD_CHANNEL_ASWC_CH1);
    voltageCh1 = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);
    value = COMM_Protocol_GetADStatus(AD_CHANNEL_ASWC_CH2);
    voltageCh2 = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);

    /* Look for the a possible aswc key */
    for(i = 0; i < pData->number_of_keys; i++) {
        if( ((voltageCh1 >= pData->config_ch1[i].v_min)  &&
            (voltageCh1 <= pData->config_ch1[i].v_max))
            && ((voltageCh2 >= pData->config_ch2[i].v_min)  &&
            (voltageCh2 <= pData->config_ch2[i].v_max)) ) {

            /* key detected */
            key = pData->config_ch1[i].key_code;

            break;
        }
    }

    return key;
}

/***************************************************************************//**
*
* @fn         ASWC_ClearUpdateChannelVars
*
* @brief      Clear update channel variables. It should be called before enter
*             @ASWC_UPDATE_CHANNEL state
*
* @param [in] aswc_ch_data_t channel pointer data
*
* @return     None
*
******************************************************************************/
void ASWC_ClearUpdateChannelVars(aswc_ch_data_t * pData)
{
    pData->key = ASWC_NOKEY;
    pData->last_key = ASWC_NOKEY;
    pData->debounce_state = NO_PRESSED;
    pData->next_debounce_state = NO_PRESSED;
}


/***************************************************************************//**
*
* @fn         ASWC_UpdateCfg
*
* @brief      Update ASWC_Cfg table values
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void ASWC_UpdateKeys(void)
{
    static ASWC_DEBOUNCE_STATE_T prevState_ch1 = NO_PRESSED;
    static ASWC_DEBOUNCE_STATE_T prevState_ch2 = NO_PRESSED;
    static uint32_t lastTime_ch1 = 0;
    static uint32_t lastTime_ch2 = 0;


    /* Get access to resouce */
    Semaphore_pend(aswc_cfg_sem, BIOS_WAIT_FOREVER);

    ASWC_KeyPressed_Debounce(AD_CHANNEL_ASWC_CH1,&prevState_ch1,&lastTime_ch1,&keycfg_ch1);
    ASWC_KeyPressed_Debounce(AD_CHANNEL_ASWC_CH2,&prevState_ch2,&lastTime_ch2,&keycfg_ch2);

    if((keycfg_ch1.key_state == KEY_PRESSED) || (keycfg_ch2.key_state == KEY_PRESSED))
    {
        LOG_PRINT(DEBUG_ASWC, "SWC Key pressed\r\n");
        LOG_PRINT(DEBUG_ASWC, "Channel1 \r\n");
        LOG_PRINT(DEBUG_ASWC, "State: %s\r\n",(keycfg_ch1.key_state == KEY_PRESSED) ? "Pressed" : "No pressed");
        LOG_PRINT(DEBUG_ASWC, "Voltage: %d[mV]\r\n",keycfg_ch1.voltage);
        LOG_PRINT(DEBUG_ASWC, "Channel2 \r\n");
        LOG_PRINT(DEBUG_ASWC, "State: %s\r\n",(keycfg_ch2.key_state == KEY_PRESSED) ? "Pressed" : "No pressed");
        LOG_PRINT(DEBUG_ASWC, "Voltage: %d[mV]\r\n",keycfg_ch2.voltage);

        ASWC_SendKeyCfg(keycfg_ch1,keycfg_ch2);
    }

    /* Release access to resource */
    Semaphore_post(aswc_cfg_sem);
}

/***************************************************************************//**
*
* @fn         ASWC_ConfigKey
*
* @brief      Asociate a voltage in the ch1 with a swc key
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void ASWC_ConfigKey(int channel,uint32_t voltage)
{
    int i = 0;

    switch(channel)
    {
        case AD_CHANNEL_ASWC_CH1:
            if(selected_key_cfg_ch1 != ASWC_NOKEY)
            {
                for(i = 0;i < Num_Elems(aswc_cfg);i++)
                {
                    if((data_key.config_ch1[i].key_code) == selected_key_cfg_ch1)
                    {
                        data_key.config_ch1[i].v_min = voltage - DELTA;
                        data_key.config_ch1[i].v_max = voltage + DELTA;
                    }
                }
            }
        break;

        case AD_CHANNEL_ASWC_CH2:
            if(selected_key_cfg_ch2 != ASWC_NOKEY)
            {
                for(i = 0;i < Num_Elems(aswc_cfg_ch2);i++)
                {
                    if((data_key.config_ch2[i].key_code) == selected_key_cfg_ch2)
                    {
                        data_key.config_ch2[i].v_min = voltage - DELTA;
                        data_key.config_ch2[i].v_max = voltage + DELTA;
                    }
                }
            }
        break;

        default:

        break;
    }
}

/***************************************************************************//**
*
* @fn         ASWC_KeyPressed_Debounce
*
* @brief      Debounce funciton that validates a pressed key
*
* @param [in] channel, previous state,
*
* @return     true if key pressed, false otherwise
*
******************************************************************************/
void ASWC_KeyPressed_Debounce(int channel, ASWC_DEBOUNCE_STATE_T* pPrevState, uint32_t* pLastTime, ASWC_Key_Cfg_T* pKeyCfg)
{
    ASWC_Key_State_E key_state = KEY_NO_PRESSED;
    uint32_t voltage = 0;

    switch(*pPrevState)
    {
        case NO_PRESSED:
            pKeyCfg->key_state = KEY_NO_PRESSED;
            key_state = KEY_NO_PRESSED;
            ASWC_KeyPressed(channel,&key_state,&voltage);
            pKeyCfg->voltage = voltage;
            if(key_state == KEY_PRESSED)
            {
                *pPrevState = DEBOUNCE;
                *pLastTime = 0;
            }
        break;

        case DEBOUNCE:
            (*pLastTime)++;
            if((*pLastTime) == DEBOUNCE_TIME_CONFIG)
            {
                *pPrevState = VALIDATE;
            }
        break;

        case VALIDATE:
            ASWC_KeyPressed(channel,&key_state,&voltage);
            pKeyCfg->voltage = voltage;
            if(key_state == KEY_PRESSED)
            {
                *pPrevState = PRESSED;
                pKeyCfg->key_state = KEY_PRESSED;
            }
            else
            {
                *pPrevState = NO_PRESSED;
            }
        break;

        case PRESSED:
            ASWC_KeyPressed(channel,&key_state,&voltage);
            pKeyCfg->key_state = KEY_NO_PRESSED;
            pKeyCfg->voltage = voltage;
            if(key_state == KEY_NO_PRESSED)
            {
                *pPrevState = NO_PRESSED;
            }
        break;
    }
}

/***************************************************************************//**
*
* @fn         ASWC_KeyPressed
*
* @brief      Check if a SWC button was pressed comparing the read voltage
*             with the ASWC_NOKEY voltage range. If the read voltage is lower
*             than the min voltage of the ASWC_NOKEY the function detect that
*             a key was pressed
*
* @param [in] channel number
*
* @return     true if key pressed, false otherwise
*
******************************************************************************/
void ASWC_KeyPressed(int channel,ASWC_Key_State_E* pKeyState,uint32_t* pVoltage)
{
    ASWC_Key_State_E key_state = KEY_NO_PRESSED;
    uint32_t value = 0;
    uint32_t voltage = 0;
    uint32_t no_key_min_voltage = 0;
    uint32_t i;

    switch(channel)
    {
        case AD_CHANNEL_ASWC_CH2:

            value = COMM_Protocol_GetADStatus(AD_CHANNEL_ASWC_CH2);
            voltage = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);

            for(i = 0;i < Num_Elems(aswc_cfg_ch2);i++)
            {
                if((data_key.config_ch2[i].key_code) == ASWC_NOKEY)
                {
                    no_key_min_voltage = data_key.config_ch2[i].v_min;
                }
            }

        break;

        case AD_CHANNEL_ASWC_CH1:

            value = COMM_Protocol_GetADStatus(AD_CHANNEL_ASWC_CH1);
            voltage = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);

            for(i = 0;i < Num_Elems(aswc_cfg);i++)
            {
                if((data_key.config_ch1[i].key_code) == ASWC_NOKEY)
                {
                    no_key_min_voltage = data_key.config_ch1[i].v_min;
                }
            }

        break;

        default:

        break;
    }

    *pVoltage = voltage;
    if(voltage < no_key_min_voltage)
    {
        key_state = KEY_PRESSED;
    }
    *pKeyState = key_state;
}

/***************************************************************************//**
*
* @fn         ASWC_SetState
*
* @brief      Check if a SWC button was pressed comparing the read voltage
*             with the ASWC_NOKEY voltage range. If the read voltage is lower
*             than the min voltage of the ASWC_NOKEY the function detect that
*             a key was pressed
*
* @param [in] channel number
*
* @return     true if key pressed, false otherwise
*
******************************************************************************/
bool_t ASWC_SetState(ASWC_State_E newState)
{
    bool_t ret = false;

#if (USE_ASWC == 1)
    /* Get access to resouce */
    Semaphore_pend(aswc_cfg_sem, BIOS_WAIT_FOREVER);

    if(newState < ASWC_NUM_STATES)
    {
        if(newState != aswc_state)
        {
            ASWC_InitState(newState);
            ret = true;
        }
    }

    /* Release access to resource */
    Semaphore_post(aswc_cfg_sem);
#endif

    return ret;
}

/***************************************************************************//**
*
* @fn         ASWC_SetKeyCfg
*
* @brief      Check if a SWC button was pressed comparing the read voltage
*             with the ASWC_NOKEY voltage range. If the read voltage is lower
*             than the min voltage of the ASWC_NOKEY the function detect that
*             a key was pressed
*
* @param [in] channel number
*
* @return     true if key pressed, false otherwise
*
******************************************************************************/
void ASWC_SetKeyCfg(int channel,ASWC_KEY_T newKey)
{
#if (USE_ASWC == 1)
    /* Get access to resouce */
    Semaphore_pend(aswc_cfg_sem, BIOS_WAIT_FOREVER);

    if(newKey != ASWC_NOKEY)
    {
        switch(channel)
        {
            case AD_CHANNEL_ASWC_CH2:
                selected_key_cfg_ch2 = newKey;
                LOG_PRINT(DEBUG_ASWC, "ASWC selected_key_cfg_ch2: %d\r\n", selected_key_cfg_ch2);
            break;

            case AD_CHANNEL_ASWC_CH1:
                selected_key_cfg_ch1 = newKey;
                LOG_PRINT(DEBUG_ASWC, "ASWC selected_key_cfg_ch1: %d\r\n", selected_key_cfg_ch1);
            break;

            default:

            break;
        }
    }

    /* Release access to resource */
    Semaphore_post(aswc_cfg_sem);
#endif
}

/***************************************************************************//**
*
* @fn         ASWC_SendKeyCfg
*
* @brief      Check if a SWC button was pressed comparing the read voltage
*             with the ASWC_NOKEY voltage range. If the read voltage is lower
*             than the min voltage of the ASWC_NOKEY the function detect that
*             a key was pressed
*
* @param [in] channel number
*
* @return     true if key pressed, false otherwise
*
******************************************************************************/
void ASWC_SendKeyCfg(ASWC_Key_Cfg_T key_cfg_ch1,ASWC_Key_Cfg_T key_cfg_ch2)
{

    uint32_t vmin_ch1;
    uint32_t vmax_ch1;
    uint32_t vmin_ch2;
    uint32_t vmax_ch2;
    uint32_t low_range_ch1;
    uint32_t up_range_ch1;
    uint32_t low_range_ch2;
    uint32_t up_range_ch2;
    static uint8_t voltage_repeated_ch1 = 0;
    static uint8_t voltage_repeated_ch2 = 0;
    static uint32_t last_voltage_ch1 = 0;
    static uint32_t last_voltage_ch2 = 0;


    voltage_repeated_ch1 = (key_cfg_ch1.voltage == last_voltage_ch1) ? (voltage_repeated_ch1 + 1) : 0;
    voltage_repeated_ch2 = (key_cfg_ch2.voltage == last_voltage_ch2) ? (voltage_repeated_ch2 + 1) : 0;

    last_voltage_ch1 = key_cfg_ch1.voltage;
    last_voltage_ch2 = key_cfg_ch2.voltage;

    low_range_ch1 = (key_cfg_ch1.key_state == KEY_NO_PRESSED) ? (DELTA/2) : DELTA;
    up_range_ch1 = (key_cfg_ch1.key_state == KEY_NO_PRESSED) ? (3*DELTA/2) : DELTA;

    low_range_ch2 = (key_cfg_ch2.key_state == KEY_NO_PRESSED) ? (DELTA/2) : DELTA;
    up_range_ch2 = (key_cfg_ch2.key_state == KEY_NO_PRESSED) ? (3*DELTA/2) : DELTA;

    vmin_ch1 = (key_cfg_ch1.voltage < low_range_ch1) ? 0 : (key_cfg_ch1.voltage - low_range_ch1);
    vmin_ch2 = (key_cfg_ch2.voltage < low_range_ch2) ? 0 : (key_cfg_ch2.voltage - low_range_ch2);

    vmax_ch1 = key_cfg_ch1.voltage + up_range_ch1;
    vmax_ch2 = key_cfg_ch2.voltage + up_range_ch2;

    aswc_cfg_buffer[0] = (uint8_t) 0;
    aswc_cfg_buffer[1] = (uint8_t)(vmin_ch1 & 0xff);
    aswc_cfg_buffer[2] = (uint8_t)((vmin_ch1 >> 8) & 0xff);
    aswc_cfg_buffer[3] = (uint8_t)(vmax_ch1 & 0xff);
    aswc_cfg_buffer[4] = (uint8_t)((vmax_ch1 >> 8) & 0xff);
    aswc_cfg_buffer[5] = (uint8_t)(voltage_repeated_ch1);

    aswc_cfg_ch2_buffer[0] = (uint8_t) 0;
    aswc_cfg_ch2_buffer[1] = (uint8_t)(vmin_ch2 & 0xff);
    aswc_cfg_ch2_buffer[2] = (uint8_t)((vmin_ch2 >> 8) & 0xff);
    aswc_cfg_ch2_buffer[3] = (uint8_t)(vmax_ch2 & 0xff);
    aswc_cfg_ch2_buffer[4] = (uint8_t)((vmax_ch2 >> 8) & 0xff);
    aswc_cfg_ch2_buffer[5] = (uint8_t)(voltage_repeated_ch2);

    LOG_PRINT(DEBUG_ASWC, "CH1 Vmin = %u\r\n",vmin_ch1);
    LOG_PRINT(DEBUG_ASWC, "CH1 Vmax = %u\r\n",vmax_ch1);
    LOG_PRINT(DEBUG_ASWC, "CH2 Vmin = %u\r\n",vmin_ch2);
    LOG_PRINT(DEBUG_ASWC, "CH2 Vmax = %u\r\n",vmax_ch2);
    LOG_PRINT(DEBUG_ASWC, "voltage_repeated_ch1 = %u\r\n",voltage_repeated_ch1);
    LOG_PRINT(DEBUG_ASWC, "voltage_repeated_ch2 = %u\r\n",voltage_repeated_ch2);

    Shadow_Server_Storage_Set(SHADOW_ASWC_Cfg_Req, (uint8_t *)&aswc_cfg_buffer[0]);
    Shadow_Server_Storage_Set(SHADOW_ASWC_Cfg_Req_Ch2, (uint8_t *)&aswc_cfg_ch2_buffer[0]);

}

/***************************************************************************//**
*
* @fn         ASWC_Set_ASWC_Cfg
*
* @brief      Check if a SWC button was pressed comparing the read voltage
*             with the ASWC_NOKEY voltage range. If the read voltage is lower
*             than the min voltage of the ASWC_NOKEY the function detect that
*             a key was pressed
*
* @param [in] channel number
*
* @return     true if key pressed, false otherwise
*
******************************************************************************/
void ASWC_Set_ASWC_Cfg(int channel,uint8_t *data)
{
#if (USE_ASWC == 1)
    int i = 0;
    int j = 0;

    /* Get access to resouce */
    Semaphore_pend(aswc_cfg_sem, BIOS_WAIT_FOREVER);

    switch(channel)
    {
        case AD_CHANNEL_ASWC_CH2:
            LOG_PRINT(DEBUG_ASWC, "ASWC_Set_ASWC_Cfg_Ch2 \r\n");

            for(i = 0; i < Num_Elems(aswc_cfg_ch2);i++)
            {
                data_key.config_ch2[i].key_code = (ASWC_KEY_T)data[j];
                data_key.config_ch2[i].v_min = data[j + 1] + (data[j + 2] << 8);
                data_key.config_ch2[i].v_max = data[j + 3] + (data[j + 4] << 8);
                j += 5;
            }

        break;

        case AD_CHANNEL_ASWC_CH1:
            LOG_PRINT(DEBUG_ASWC, "ASWC_Set_ASWC_Cfg\r\n");

            for(i = 0; i < Num_Elems(aswc_cfg);i++)
            {
                data_key.config_ch1[i].key_code = (ASWC_KEY_T)data[j];
                data_key.config_ch1[i].v_min = data[j + 1] + (data[j + 2] << 8);
                data_key.config_ch1[i].v_max = data[j + 3] + (data[j + 4] << 8);
                j += 5;
            }
        break;

        default:

        break;
    }

    /* Release access to resource */
    Semaphore_post(aswc_cfg_sem);
#endif
}

/***************************************************************************//**
*
* @fn         ASWC_UpdateIdle
*
* @brief      Update ASWC Idle value (NO_KEY voltages)
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void ASWC_UpdateIdle(void)
{
    static uint32_t i = 0;
    static uint32_t nokey_measures_ch1[UPDATE_IDLE_TIME];
    static uint32_t nokey_measures_ch2[UPDATE_IDLE_TIME];
    uint32_t nokey_min_value_ch1 = 0;
    uint32_t nokey_min_value_ch2 = 0;
    uint32_t value = 0;
    uint32_t voltage = 0;

    if(measure_idle)
    {

        /* Get access to resouce */
        Semaphore_pend(aswc_cfg_sem, BIOS_WAIT_FOREVER);

        value = COMM_Protocol_GetADStatus(AD_CHANNEL_ASWC_CH1);
        voltage = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);
        nokey_measures_ch1[i] = voltage;

        value = COMM_Protocol_GetADStatus(AD_CHANNEL_ASWC_CH2);
        voltage = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);
        nokey_measures_ch2[i] = voltage;

        i++;
        if(i == UPDATE_IDLE_TIME)
        {
            LOG_PRINT(DEBUG_ASWC, "ASWC_UpdateIdle: Measure finish\r\n");

            nokey_min_value_ch1 = nokey_measures_ch1[0];
            nokey_min_value_ch2 = nokey_measures_ch2[0];

            for(i = 0; i < UPDATE_IDLE_TIME;i++)
            {
                if(nokey_measures_ch1[i] < nokey_min_value_ch1)
                {
                    nokey_min_value_ch1 = nokey_measures_ch1[i];
                }

                if(nokey_measures_ch2[i] < nokey_min_value_ch2)
                {
                    nokey_min_value_ch2 = nokey_measures_ch2[i];
                }

            }
            LOG_PRINT(DEBUG_ASWC, "No key minimum value measured ch1: %d\r\n",nokey_min_value_ch1);
            LOG_PRINT(DEBUG_ASWC, "No key minimum value measured ch2: %d\r\n",nokey_min_value_ch2);

            keycfg_ch1.voltage = nokey_min_value_ch1;
            keycfg_ch2.voltage = nokey_min_value_ch2;

            ASWC_SendKeyCfg(keycfg_ch1,keycfg_ch2);

            i = 0;
            measure_idle = false;
        }

        /* Release access to resource */
        Semaphore_post(aswc_cfg_sem);

    }
}
