#ifndef aswc_bench_cfg_H
#   define aswc_bench_cfg_H
/*===========================================================================*/
/**
 * @file aswc_bench_cfg.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:micbias_cfg.h~2:incl:kok_basa#1 %
 * @version %version:2 %
 * @author  %derived_by:fzdbm3 %
 * @date    %date_modified:Fri Nov 29 15:26:54 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2013 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * #define Constants
 *===========================================================================*/
#define MAX_VOLTAGE                 3300
#define USE_SECOND_ADC_CH           1

/*===========================================================================*
 * #define MACROS
 *===========================================================================*/
/*---------------------------------------------------------------------*\
 * Set up analog swc voltage table
\*---------------------------------------------------------------------*/
/* define under a) v_min                            */
/* define under b) v_max                            */
/* define under c) ASWC_KEY_T                       */

/*    a      b     c                                */
#define ASWC_V_TABLE\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Vol_Up              )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Vol_Down            )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Mute                )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Next                )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Prev                )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Pick_Up             )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Hang_Up             )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Src                 )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Voice               )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Flash               )\
    X( 3000          ,5000            ,ASWC_NOKEY                   )\

#define ASWC_V_TABLE_CH2\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Vol_Up              )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Vol_Down            )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Mute                )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Next                )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Prev                )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Pick_Up             )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Hang_Up             )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Src                 )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Voice               )\
    X( MAX_VOLTAGE   ,MAX_VOLTAGE     ,ASWC_Key_Flash               )\
    X( 3000          ,5000            ,ASWC_NOKEY                   )\

/*===========================================================================*
 * Custom Type Declarations
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file aswc_bench_cfg.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 18-Oct-2019 Agustin Diaz Antuna
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* aswc_bench_cfg_H */
