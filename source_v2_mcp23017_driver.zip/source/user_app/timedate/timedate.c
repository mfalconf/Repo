/*===========================================================================*/
/**
 * @file timedate.c
 *
 * Antenna Power control interface
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <timedate.h>
#include <shadow_storage.h>
#include <comm_protocol.h>
#include <console.h>
#include <famp_pm.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <xdc/runtime/System.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
/* set default time / date for cold start  */
#define DEFAULT_HR_MODE     hr_mode_24h
#define DEFAULT_HOURS       0
#define DEFAULT_MINUTES     0
#define DEFAULT_SECONDS     0
#define DEFAULT_DAY         1
#define DEFAULT_MONTH       RTC_JAN
#define DEFAULT_YEAR        23

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
TD_TimeDate_T TimeDateIPU;
TD_TimeDate_T TimeDateHU;
TD_TimeDate_T TimeDateCAN;
bool_t ReqUpdateTimeDatebyCAN;
bool_t EnableTimeDatebyCAN;
bool_t FirstTime;
extern bool_t isColdStart;

#ifdef TIMEDATE_HU
   bool_t ReqUpdateTimeDatebyHU = FALSE;
   bool_t EnableTimeDatebyHU = FALSE;
#endif

static Semaphore_Handle td_sem = NULL;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void td_Update_SHADOW_TimeDate(void);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

void TD_Init(void)
{
    TimeDateIPU.rtc_hr_mode  = DEFAULT_HR_MODE;
    TimeDateIPU.rtc_hour     = DEFAULT_HOURS;
    TimeDateIPU.rtc_minute   = DEFAULT_MINUTES;
    TimeDateIPU.rtc_sec      = DEFAULT_SECONDS;

    TimeDateIPU.rtc_day      = DEFAULT_DAY;
    TimeDateIPU.rtc_month    = DEFAULT_MONTH;
    TimeDateIPU.rtc_year     = DEFAULT_YEAR;

    LOG_PRINT_VER(DEBUG_TD, "TD_Init\n");

    FirstTime = TRUE;
    ReqUpdateTimeDatebyCAN  = FALSE;
    EnableTimeDatebyCAN     = TRUE;
    #ifdef TIMEDATE_HU
    ReqUpdateTimeDatebyHU   = FALSE;
    #endif

    td_sem = Semaphore_create(1, NULL, NULL);
}

void TD_Update(void)
{

    LOG_PRINT_VER(DEBUG_TD, "TD_Update\n");

    Semaphore_pend(td_sem, BIOS_WAIT_FOREVER);

    COMM_Protocol_GetTime(&TimeDateIPU.rtc_hr_mode, &TimeDateIPU.rtc_hour,
                         &TimeDateIPU.rtc_minute, &TimeDateIPU.rtc_sec);

    COMM_Protocol_GetDate(&TimeDateIPU.rtc_day,
                         &TimeDateIPU.rtc_month,
                         &TimeDateIPU.rtc_year);

    if(FirstTime){
        LOG_PRINT_VER(DEBUG_TD, "FirstTime in TD Update\n");

        FirstTime = FALSE;

        if(isColdStart) {
            LOG_PRINT_VER(DEBUG_TD, "Cold start\n");

            TimeDateIPU.rtc_hour = DEFAULT_HOURS;
            TimeDateIPU.rtc_minute = DEFAULT_MINUTES;
            TimeDateIPU.rtc_sec = DEFAULT_SECONDS;

            TimeDateIPU.rtc_day = DEFAULT_DAY;
            TimeDateIPU.rtc_month = DEFAULT_MONTH;
            TimeDateIPU.rtc_year = DEFAULT_YEAR;

        } else {
            LOG_PRINT_VER(DEBUG_TD, "Warm start\n");
        }

        COMM_Protocol_SetDate(TimeDateIPU.rtc_day,
                             TimeDateIPU.rtc_month,
                             TimeDateIPU.rtc_year);
    }


    if(TRUE == ReqUpdateTimeDatebyCAN){
      if((TimeDateCAN.rtc_hr_mode != TimeDateIPU.rtc_hr_mode) ||
         (TimeDateCAN.rtc_hour != TimeDateIPU.rtc_hour) ||
         (TimeDateCAN.rtc_minute != TimeDateIPU.rtc_minute) ||
         (TimeDateCAN.rtc_sec != TimeDateIPU.rtc_sec)){
         COMM_Protocol_SetTime(TimeDateCAN.rtc_hr_mode, TimeDateCAN.rtc_hour,
                               TimeDateCAN.rtc_minute, TimeDateCAN.rtc_sec);
      }
      ReqUpdateTimeDatebyCAN = FALSE;
    }
    #ifdef TIMEDATE_HU
    if(TRUE == ReqUpdateTimeDatebyHU){
      if((TimeDateHU.rtc_hr_mode != TimeDateIPU.rtc_hr_mode) ||
         (TimeDateHU.rtc_hour != TimeDateIPU.rtc_hour) ||
         (TimeDateHU.rtc_minute != TimeDateIPU.rtc_minute) ||
         (TimeDateHU.rtc_sec != TimeDateIPU.rtc_sec)){
         COMM_Protocol_SetTime(TimeDateHU.rtc_hr_mode, TimeDateHU.rtc_hour,
                               TimeDateHU.rtc_minute, TimeDateHU.rtc_sec);
      }

      if((TimeDateHU.rtc_day != TimeDateIPU.rtc_day) ||
         (TimeDateHU.rtc_month != TimeDateIPU.rtc_month) ||
         (TimeDateHU.rtc_year != TimeDateIPU.rtc_year)){
      COMM_Protocol_SetDate(TimeDateHU.rtc_day,
                            TimeDateHU.rtc_month,
                            TimeDateHU.rtc_year);
      }
      ReqUpdateTimeDatebyHU = FALSE;
    }
    #endif

    Semaphore_post(td_sem);

    td_Update_SHADOW_TimeDate();
}

void TD_SetTimeDatebyCAN(TD_TimeDate_T* timedate)
{
   Semaphore_pend(td_sem, BIOS_WAIT_FOREVER);
   if (TRUE == EnableTimeDatebyCAN){
      TimeDateCAN.rtc_hr_mode =  timedate->rtc_hr_mode; /* Use the current hr_mode */
      TimeDateCAN.rtc_hour    =  timedate->rtc_hour;
      TimeDateCAN.rtc_minute  =  timedate->rtc_minute;
      TimeDateCAN.rtc_sec     =  timedate->rtc_sec;

      TimeDateCAN.rtc_day     =  timedate->rtc_day;
      TimeDateCAN.rtc_month   =  timedate->rtc_month;
      TimeDateCAN.rtc_year    =  timedate->rtc_year;

      ReqUpdateTimeDatebyCAN = TRUE;
   }
   Semaphore_post(td_sem);
}

void TD_EnableTimeDatebyCAN (bool_t enable)
{
   Semaphore_pend(td_sem, BIOS_WAIT_FOREVER);
   EnableTimeDatebyCAN = enable;
   Semaphore_post(td_sem);
}

/**************************************************************************//**
 * @fn         Update_SHADOW_TimeDate
 *
 * @brief      Update in shadow the variable SHADOW_TimeDate
 *
 * @param [in] TD_TimeDate_T shadowTimeDate
 *
 * @return     void
 *****************************************************************************/
static void td_Update_SHADOW_TimeDate(void)
{
    uint8_t buf[7];

    buf[0] = TimeDateIPU.rtc_year;
    buf[1] = TimeDateIPU.rtc_month;
    buf[2] = TimeDateIPU.rtc_day;
    buf[3] = TimeDateIPU.rtc_hour;
    buf[4] = TimeDateIPU.rtc_minute;
    buf[5] = TimeDateIPU.rtc_sec;
    buf[6] = TimeDateIPU.rtc_hr_mode;

    Shadow_Server_Storage_Set(SHADOW_TimeDate, &buf[0]);

    LOG_PRINT_VER(DEBUG_TD, "---------------------------- \n");
    LOG_PRINT_VER(DEBUG_TD, "%d/%d/%d %d:%d:%d   (%d) \n",buf[0],buf[1],buf[2],buf[3],buf[4],buf[5],buf[6]);

}

#ifdef TIMEDATE_HU
void TD_SetTimeDatebyHU(TD_TimeDate_T* timedate)
{
   Semaphore_pend(td_sem, BIOS_WAIT_FOREVER);
   TimeDateHU.rtc_hr_mode =  timedate->rtc_hr_mode;
   TimeDateHU.rtc_hour    =  timedate->rtc_hour;
   TimeDateHU.rtc_minute  =  timedate->rtc_minute;
   TimeDateHU.rtc_sec     =  timedate->rtc_sec;

   TimeDateHU.rtc_day     =  timedate->rtc_day;
   TimeDateHU.rtc_month   =  timedate->rtc_month;
   TimeDateHU.rtc_year    =  timedate->rtc_year;

   ReqUpdateTimeDatebyHU = TRUE;
   Semaphore_post(td_sem);
}

void TD_EnableTimeDatebyHU(bool_t enable)
{
   Semaphore_pend(td_sem, BIOS_WAIT_FOREVER);
   EnableTimeDatebyHU = enable;
   Semaphore_post(td_sem);
}
#endif

void TD_GetTimeAndDate(TD_TimeDate_T* timedate)
{
    Semaphore_pend(td_sem, BIOS_WAIT_FOREVER);

    timedate->rtc_hr_mode   =   TimeDateIPU.rtc_hr_mode;
    timedate->rtc_hour      =   TimeDateIPU.rtc_hour;
    timedate->rtc_minute    =   TimeDateIPU.rtc_minute;
    timedate->rtc_sec       =   TimeDateIPU.rtc_sec;

    timedate->rtc_day       =   TimeDateIPU.rtc_day;
    timedate->rtc_month     =   TimeDateIPU.rtc_month;
    timedate->rtc_year      =   TimeDateIPU.rtc_year;

    Semaphore_post(td_sem);
}
