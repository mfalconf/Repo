#ifndef TIMEDATE_H_
#define TIMEDATE_H_
/*===========================================================================*/
/**
 * @file timedate.h
 *
 * Function definitions for the Time and Date update module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
/* Months */
#define RTC_JAN     (1)
#define RTC_FEB     (2)
#define RTC_MARCH   (3)
#define RTC_APRIL   (4)
#define RTC_MAY     (5)
#define RTC_JUNE    (6)
#define RTC_JULY    (7)
#define RTC_AUG     (8)
#define RTC_SEPT    (9)
#define RTC_OCT     (10)
#define RTC_NOV     (11)
#define RTC_DEC     (12)

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define TIMEDATE_HU

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum TD_Hr_Mode_Tag
{
   hr_mode_24h,
   hr_mode_pm,
   hr_mode_am
} TD_Hr_Mode_T;

typedef struct TD_TimeDate_Tag
{
    TD_Hr_Mode_T rtc_hr_mode;
    uint8_t rtc_hour;
    uint8_t rtc_minute;
    uint8_t rtc_sec;

    uint8_t rtc_day;
    uint8_t rtc_month;
    uint8_t rtc_year;
}TD_TimeDate_T;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/**************************************************************************//**
* @fn         TD_Init
*
* @brief      Time and date initialization function
*
* @param [in] None
*
* @return     None
******************************************************************************/
void TD_Init(void);

/**************************************************************************//**
* @fn         TD_Update
*
* @brief      Time and date information update from the RTC
*
* @param [in] None
*
* @return     None
******************************************************************************/
void TD_Update(void);

/**************************************************************************//**
 * @fn         TD_SetTimeDatebyCAN
 *
 * @brief      Time and date information update from the CAN.
 *
 * @param [in] timedate
 *
 * @return     void
 *****************************************************************************/
void TD_SetTimeDatebyCAN(TD_TimeDate_T* timedate);

/**************************************************************************//**
 * @fn         TD_EnableTimeDatebyCAN
 *
 * @brief      Time and date set values via CAN enable
 *
 * @param [in] timedate
 *
 * @return     void
 *****************************************************************************/
void TD_EnableTimeDatebyCAN(bool_t enable);

#ifdef TIMEDATE_HU
/**************************************************************************//**
* @fn         TD_SetTimeDatebyHU
*
* @brief      Time and date information update from the HU
*
* @param [in] timedate
*
* @return     None
******************************************************************************/
void TD_SetTimeDatebyHU(TD_TimeDate_T* timedate);

/**************************************************************************//**
 * @fn         TD_EnableTimeDatebyHU
 *
 * @brief      Time and date set values via HU enable
 *
 * @param [in] timedate
 *
 * @return     void
 *****************************************************************************/
void TD_EnableTimeDatebyHU(bool_t enable);

#endif

/**************************************************************************//**
 * @fn          TD_EnableTimeDatebyHU
 *
 * @brief       Get the current date and time.
 *
 * @param [in]  timedate
 *
 * @return      void
 *****************************************************************************/
void TD_GetTimeAndDate(TD_TimeDate_T *);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file timedate.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 07-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* TIMEDATE_H_ */
