#ifndef SHAREDBUS_MSG_IDS_H_
#define SHAREDBUS_MSG_IDS_H_
/*===========================================================================*/
/**
 * @file sharedbus_msg_ids.h
 *
 * Message IDs definitions for the SharedBus module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */

#include "standard.h"

#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>


/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define SB_Server_To_Client_Msgs \
		SB_Server_To_Client_Msg(S2C_UPDATE_SHADOW_SERVER_MEMORY) \

#define SB_Client_To_Server_Msgs \
		SB_Client_To_Server_Msg(C2S_OPEN_CONNECTION) \
		SB_Client_To_Server_Msg(C2S_CLOSE_CONNECTION) \
		SB_Client_To_Server_Msg(C2S_KEEPALIVE) \
		SB_Client_To_Server_Msg(C2S_REQ_SHADOW_SERVER_MEMORY) \
        SB_Client_To_Server_Msg(C2S_UPDATE_SHADOW_CLIENT_MEMORY) \

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
/* The enum for all the messageIDs*/
#undef SB_Server_To_Client_Msg
#undef SB_Client_To_Server_Msg
#define SB_Server_To_Client_Msg(id)      SB_ID_##id,
#define SB_Client_To_Server_Msg(id)      SB_ID_##id,
typedef enum SB_Id_Tag
{
	SB_Server_To_Client_Msgs
	SB_Client_To_Server_Msgs
	SB_NUM_IDs
} SB_MsgId_T;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/* Define the external function prototypes for the Server side */
#undef SB_Server_To_Client_Msg
#undef SB_Client_To_Server_Msg
#define SB_Server_To_Client_Msg(id)      extern void SB_Tx_##id(String dstName, uint8_t *data, uint32_t length);
#define SB_Client_To_Server_Msg(id)      extern void SB_Rx_##id(String srcName, uint8_t *data, uint32_t length);
SB_Server_To_Client_Msgs
SB_Client_To_Server_Msgs

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file sharedbus_msg_ids.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 30-May-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* SHAREDBUS_MSG_IDS_H_ */

