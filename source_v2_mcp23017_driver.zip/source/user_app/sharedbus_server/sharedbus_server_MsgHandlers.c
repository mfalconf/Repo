/*===========================================================================*/
/**
 * @file sharedbus_client_callbacks.c
 *
 * SharedBus Client Callbacks
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <sharedbus_msg_ids.h>
#include <sharedbus.h>
#include <string.h>
#include <console.h>

#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/ipc/remoteproc/Resource.h>
#include <ti/ipc/remoteproc/rsc_types.h>
#include <ti/ipc/ipcmgr/IpcMgr.h>

#include <types.h>

#include <shadow_storage.h>
#include <timedate.h>


/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define DEBUG_EN

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
#if(0)
#undef SB_Server_To_Client_Msg
#undef SB_Client_To_Server_Msg
#define SB_Server_To_Client_Msg(id)      extern void SB_Tx_##id(String dstName, uint8_t *data, uint32_t length);
#define SB_Client_To_Server_Msg(id)      extern void SB_Rx_##id(String srcName, uint8_t *data, uint32_t length);
SB_Server_To_Client_Msgs
SB_Client_To_Server_Msgs

#endif
/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
* @fn         SB_Rx_C2S_OPEN_CONNECTION
* @brief
* @param [in]
* @return
******************************************************************************/
void SB_Rx_C2S_OPEN_CONNECTION (String srcName, uint8_t *data, uint32_t length)
{
   if(NULL != srcName){
      LOG_PRINT_INFO(DEBUG_SB,"[From: %s] [MsgId: SB_Rx_C2S_OPEN_CONNECTION]\n",
                     srcName);
      SB_OpenMsgQ(srcName);
   }
   else{
      LOG_PRINT_ERR(DEBUG_SB,"Invalid name\n");
   }
}

/***************************************************************************//**
* @fn         SB_Rx_C2S_CLOSE_CONNECTION
* @brief
* @param [in]
* @return
******************************************************************************/
void SB_Rx_C2S_CLOSE_CONNECTION (String srcName, uint8_t *data, uint32_t length)
{
   if(NULL != srcName){
      LOG_PRINT_INFO(DEBUG_SB,"[From: %s] [MsgId: SB_Rx_C2S_CLOSE_CONNECTION]\n",
                     srcName);
      SB_CloseMsgQ(srcName);
   }
   else{
      LOG_PRINT_ERR(DEBUG_SB,"Invalid name\n");
   }
}

/***************************************************************************//**
* @fn         SB_Rx_C2S_KEEPALIVE
* @brief
* @param [in]
* @return
******************************************************************************/
void SB_Rx_C2S_KEEPALIVE (String srcName, uint8_t *data, uint32_t length)
{
   if(NULL != srcName){
      LOG_PRINT_INFO(DEBUG_SB,"[From: %s] [MsgId: SB_Rx_C2S_KEEPALIVE]\n",
                     srcName);
      SB_UpdateTimeout(srcName);
   }
   else{
      LOG_PRINT_ERR(DEBUG_SB,"Invalid name\n");
   }
}

/***************************************************************************//**
* @fn         SB_Rx_C2S_REQ_SHADOW_MEMORY
* @brief
* @param [in]
* @return
******************************************************************************/
void SB_Rx_C2S_REQ_SHADOW_SERVER_MEMORY (String srcName, uint8_t *data, uint32_t length)
{
	//LOG_PRINT_INFO(DEBUG_SB, "[From: %s] [MsgId: SB_Rx_C2S_REQ_SHADOW_MEMORY]\n", srcName);
	//SB_Tx_S2C_UPDATE_SHADOW_MEMORY(srcName, "Dale Boca", strlen("Dale Boca"));

    /* Esto esta funcionando. Pero hay que cargar valores validos de shadow
     * ya que si mando cualquier cosa, es incompatible con los vectores de shadow
     * y se va de viaje el binario del A15
     */
    Shadow_Server_Storage_Send_Buffer();
}

void SB_Rx_C2S_UPDATE_SHADOW_CLIENT_MEMORY(String srcName, uint8_t *data, uint32_t length)
{
    if(NULL != srcName){
       LOG_PRINT(DEBUG_AUX,"[From: %s][MsgId: SB_Rx_S2C_UPDATE_SHADOW_MEMORY]\n",
                       srcName);
    }
    else{
       LOG_PRINT(DEBUG_SB,"[From: ?][MsgId: SB_Rx_S2C_UPDATE_SHADOW_MEMORY]\n");
    }

    Shadow_Client_Storage_Receive_Buffer(data);
}

/***************************************************************************//**
* @fn         SB_Tx_S2C_UPDATE_SHADOW_MEMORY
* @brief
* @param [in]
* @return
******************************************************************************/
void SB_Tx_S2C_UPDATE_SHADOW_SERVER_MEMORY (String dstName, uint8_t *data, uint32_t length)
{
   if(NULL != dstName){
      LOG_PRINT_INFO(DEBUG_SB,"[To: %s] [MsgId: SB_Tx_S2C_UPDATE_SHADOW_MEMORY]\n",
                     dstName);
   }
   else{
      LOG_PRINT_INFO(DEBUG_SB,"[To: ALL] [MsgId: SB_Tx_S2C_UPDATE_SHADOW_MEMORY]\n");
   }

   SB_Send(SERVERQ_DEFAULT_NAME, dstName, SB_ID_S2C_UPDATE_SHADOW_SERVER_MEMORY, data, length);
}
