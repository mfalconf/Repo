/*===========================================================================*/
/**
 * @file sharedbus_server.c
 *
 * SharedBus Server
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <sharedbus_msg_ids.h>
#include <sharedbus_server.h>
#include <sharedbus.h>
#include <console.h>

#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

#include <ti/ipc/remoteproc/Resource.h>
#include <ti/ipc/remoteproc/rsc_types.h>
#include <ti/ipc/ipcmgr/IpcMgr.h>

#include "shadow_storage.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define SB_MAX_CLIENTS			SB_MAX_CONNECTION

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef enum SharedBusServer_Task_state_Tag
{
   SB_TASK_STATE_QUEUE_WAIT_FOR_A15 = 0,
   SB_TASK_STATE_INIT,
   SB_TASK_STATE_RECEIVE
}SharedBusServer_Task_state_T;

/*===========================================================================*
 * External Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
SBConnectQId 	 sbClientsQId[SB_MAX_CLIENTS]={0};
MessageQ_Handle  serverQHndl;
uint16_t         serverHeapId;

static Char hostStatus = 0;
static SharedBusServer_Task_state_T sb_task_state = SB_TASK_STATE_QUEUE_WAIT_FOR_A15;


#undef SB_Server_To_Client_Msg
#undef SB_Client_To_Server_Msg
#define SB_Server_To_Client_Msg(id)      SB_Tx_##id,
#define SB_Client_To_Server_Msg(id)      SB_Rx_##id,
SBMsgHandler sbServerMsgHandlers[SB_NUM_IDs] =
{
	SB_Server_To_Client_Msgs
	SB_Client_To_Server_Msgs
};

static uint8_t stack[0x1000];


/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void SharedBusServer_Task_Thread(UArg arg0, UArg arg1);
static void SharedBusServer_Initialize(void);
static void SharedBusServer_Task_Thread_Shutdown(void);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
* @fn         SBCbk_GetConnectInfo
* @brief
* @param [in]
* @return
******************************************************************************/
void SBCbk_GetConnectInfo (SBConnectQId** sbConnectQId, uint32_t* sbConnectQEntries)
{
	*sbConnectQId = sbClientsQId;
	*sbConnectQEntries = SB_MAX_CLIENTS;
}

/***************************************************************************//**
* @fn         SBCbk_GetHeapId
* @brief
* @param [in]
* @return
******************************************************************************/
void SBCbk_GetHeapId (uint16_t* heapId)
{
	*heapId = 0;
}



void SharedBusServer_Task_Init(void)
{
    Error_Block eb;
    Task_Params taskParams;
    Task_Handle task_h;

    LOG_PRINT_INFO(DEBUG_SB, "SharedBusServer task initialization...\n");

    Error_init(&eb);

    /* create main thread (interrupts not enabled in main on BIOS) */
    Task_Params_init(&taskParams);
    taskParams.instance->name = "SharedBusServer_task";
    taskParams.arg0 = NULL;
    taskParams.arg1 = NULL;
    taskParams.stack = stack;
    taskParams.stackSize = 0x1000;
    taskParams.affinity = APP_CORE_NUM;
    task_h = Task_create(SharedBusServer_Task_Thread, &taskParams, &eb);
    if (NULL == task_h)
    {
       LOG_PRINT_INFO(DEBUG_SB, "Couldn't create SharedBusServer task\n");
    }
    else
    {
       LOG_PRINT_INFO(DEBUG_SB, "SharedBusServer thread created successfully\n");
    }
}

static void SharedBusServer_Task_Thread(UArg arg0, UArg arg1)
{
    bool_t running = true;

    LOG_PRINT_INFO(DEBUG_SB, "SharedBusServer_Task_Thread entry\n");

    hostStatus = 0;
    sb_task_state = SB_TASK_STATE_QUEUE_WAIT_FOR_A15;

    Shadow_Client_Storage_Initialize();

    while(running)
    {
        switch(sb_task_state)
        {
            case SB_TASK_STATE_QUEUE_WAIT_FOR_A15:
                if(0 != SharedBusServer_QUEUE_Wait_For_A15())
                {
                    LOG_PRINT_INFO(DEBUG_SB, "SharedBusServer_QUEUE_Wait_For_A15() OK \n");
                    sb_task_state = SB_TASK_STATE_INIT;
                }
                break;
            case SB_TASK_STATE_INIT:
                SharedBusServer_Initialize();

                LOG_PRINT_INFO(DEBUG_SB, "SharedBusServer_Initialize() OK \n");
                sb_task_state = SB_TASK_STATE_RECEIVE;
                break;
            case SB_TASK_STATE_RECEIVE:
                SB_Receive(serverQHndl, 1000000, sbServerMsgHandlers, SB_NUM_IDs);  // 1 seg
                Shadow_Client_Storage_Update_Signals();
                //SB_EvalConnectTimeouts();
                break;
        }

        /* TODO: Check why we can't send all threads to sleep. The ipu1 crashes if we try it
         * We should call 
         * running = MN_Keep_Running();
         */
    }

    SharedBusServer_Task_Thread_Shutdown();
}

static void SharedBusServer_Initialize(void)
{
    /* Variables initialization */
    SB_Init();
    /* Creating a MessageQ Object */
    serverQHndl = SB_CreateMsgQ(SERVERQ_DEFAULT_NAME);

    if( serverQHndl == NULL )
    {
        LOG_PRINT_INFO(DEBUG_SB, "message queue create failed !!!! \n");
    }
    else
    {
        LOG_PRINT_INFO(DEBUG_SB, "message queue create OK \n");
    }
}

static void SharedBusServer_Task_Thread_Shutdown(void)
{
    /* Before exit we need to close all the opened queues */
    SB_CloseAllMsgQ();

    SB_FreeHeap(serverHeapId);
    SB_DeleteMsgQ(&serverQHndl);
}

int SharedBusServer_QUEUE_Wait_For_A15(void)
{
   LOG_PRINT_INFO(DEBUG_SB, "Waiting start of RPMSG: %d\n", hostStatus);

   while(hostStatus == 0){
      hostStatus = Resource_getVdevStatus(VIRTIO_ID_RPMSG);
      Task_sleep(SB_MS_TIME(500));
   }

   IpcMgr_ipcStartup();
   LOG_PRINT_INFO(DEBUG_SB, "IpcMgr_ipcStartup\n");

   return((int)hostStatus);
}

int SB_QUEUE_Wait_For_A15(void)
{
    return((int)hostStatus);
}


#if(0)

Char hostStatus = 0;

int PM_QUEUE_Wait_For_A15()
{
    if (hostStatus == 0) {
        hostStatus = Resource_getVdevStatus(VIRTIO_ID_RPMSG);

        LOG_PRINT_SVER(DEBUG_SB, "Waiting start of RPMSG: %d\n", hostStatus);

        if (hostStatus != 0) {
            IpcMgr_ipcStartup();
            LOG_PRINT_SVER(DEBUG_SB, "IpcMgr_ipcStartup\n");
        }
    }
    return (hostStatus);
}



/* Initialize a queue, NON BLOCKING */
int PM_QUEUE_Init_Server()
{
    if (false == pm_queue_server_initialized) {

        LOG_PRINT_START_FUNC(DEBUG_SB);
        /* Creating a MessageQ Object */
        serverQHndl = PM_QUEUE_createMsgQ(PM_MESSAGE_SERVER_QUEUE_NAME);

        LOG_DEBUG_INFO(DEBUG_SB, "queue id is %d\r\n", MessageQ_getQueueId(serverQHndl));

        LOG_PRINT_VER(DEBUG_SB, "Waiting for incoming connections...\n");

        pm_queue_server_initialized = true;
    }

    return 0;
}

#endif
