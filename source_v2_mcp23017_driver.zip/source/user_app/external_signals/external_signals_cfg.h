#ifndef EXTERNAL_SIGNALS_CFG_H
#   define EXTERNAL_SIGNALS_CFG_H
/*===========================================================================*/
/**
 * @file external_signals_cfg.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:micbias_cfg.h~2:incl:kok_basa#1 %
 * @version %version:2 %
 * @author  %derived_by:fzdbm3 %
 * @date    %date_modified:Fri Nov 29 15:26:54 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2013 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * #define Constants
 *===========================================================================*/
/*
 * Configurable parameters
 */
/* Discrete signals pin logic value */
#define REVERSE_DET_ON          0
#define REVERSE_DET_OFF         !REVERSE_DET_ON
#define PARK_DET_ON             0
#define PARK_DET_OFF            1
#define IGNITION_DET_ON         0
#define IGNITION_DET_OFF        1
#define DIMMING_DET_ON          0                   // VBAT
#define DIMMING_DET_OFF         !DIMMING_DET_ON     // GND

/* Reverse value */
#define ES_REVERSE_ON           SAR_RAM_BIT_REVERSEGEAR_ON
#define ES_REVERSE_OFF          SAR_RAM_BIT_REVERSEGEAR_OFF

/* Park value */
#define ES_PARK_ON              1
#define ES_PARK_OFF             0

/* Ignition value */
#define ES_IGNITION_ON          1
#define ES_IGNITION_OFF         0

/* Dimming value */
#define ES_DISP_DIMMING_DAY     0                       // Same as famp_robertito defines
#define ES_DISP_DIMMING_NIGHT   !ES_DISP_DIMMING_DAY
#define ES_DIMMING_DAY          0
#define ES_DIMMING_NIGHT        !ES_DIMMING_DAY

/* 1000 unit is us */
#define ES_TASK_DELAY           50*1000     // 50ms

/*===========================================================================*
 * #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Custom Type Declarations
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file external_signals_cfg.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 06-Aug-2019 Agustin Diaz Antuna
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* DIMMING_CFG_H */
