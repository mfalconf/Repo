#ifndef EXTERNAL_SIGNALS_H_
#define EXTERNAL_SIGNALS_H_
/*===========================================================================*/
/**
 * @file external_signals.h
 *
 * Function definitions for the DIMMING interface module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
/* SAR RAM registers */
#define DRA7XX_SAR_RAM_BASE                     0x4AE26000
#define SAR_RAM_OFFSET_REG1                     0x00000004

#define SAR_RAM_ALL_BIT_OFF                     0x00000000

#define SAR_RAM_BIT_REVERSEGEAR_OFF             0x00000000
#define SAR_RAM_BIT_REVERSEGEAR_ON              0x00000001

#define ES_UNDEFINED                            0xFF

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum ES_Signals_Tag
{
   ES_REVERSE,
   ES_PARK,
   ES_IGNITION,
   ES_DIMMING,

   ES_NUM_SIGNALS
} ES_Signals_T;

typedef enum dimming_mode_tag {
    DIMMING_MODE_UNDEFINED,
    DIMMING_MODE_DISCRETE,
    DIMMING_MODE_PWM
} dimming_mode_t;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
void ES_Init (void);
void ES_Update (void);
void ES_ReportCurrentRvcStatus (void);

void ES_DimmingSetDetectionMode (dimming_mode_t detection_mode);
void ES_DimmingSetNewDuty (uint32_t new_duty);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file external_signals.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 06-Aug-2019 Agustin Diaz Antuna
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* EXTERNAL_SIGNALS_H_ */
