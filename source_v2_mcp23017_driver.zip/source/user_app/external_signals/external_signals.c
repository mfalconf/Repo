/*===========================================================================*/
/**
 * @file external_signals.c
 *
 * External signals controller
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2019 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <console.h>
#include <conversions.h>
#include <external_signals.h>
#include <external_signals_cfg.h>
#include <drv/board/board.h>
#include <dimming.h>
#include <shadow_storage.h>

#include <ti/csl/soc.h>
#include <ti/csl/csl_gpio.h>
#include <ti/csl/hw_types.h>

#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Semaphore.h>

/*===========================================================================*
 * Local X-MACROS Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef struct dimming_tag {
    dimming_mode_t  detection_mode;
    uint32_t        discrete_status;    /* Value read from GPIO input */
    uint32_t        mode;               /* Day or nights */
    uint32_t        pwm_duty;           /* PWM Duty */
    uint32_t        pwm_duty_new;       /* New PWM Duty informed */
} dimming_t;

typedef struct discrete_tag {
    uint32_t        status;
    uint32_t        discrete_status;
} discrete_t;

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static Semaphore_Handle es_rvc_sem = NULL;
static discrete_t reverse_data;
static discrete_t park_data;
static discrete_t ignition_data;
static dimming_t dimming_data;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
void ES_InitSignal (ES_Signals_T signal);
uint32_t ES_GetSignalStatus (ES_Signals_T signal);
bool_t ES_SetSignalStatus (ES_Signals_T signal);
void ES_ReportRvcOff (void);
void ES_ReportRvcStatus (void);
void ES_ReportParkStatus (void);
void ES_ReportIgnStatus (void);
void ES_ReportDisplayDimmingStatus (void);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/***************************************************************************//**
 *
 * @fn         ES_Init
 *
 * @brief      Function to initialize the GPIO related registers.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void ES_Init (void)
{
#if (USE_EXTERNAL_SIGNALS == 1)
    LOG_PRINT_INFO(DEBUG_ES, "ES_Init -4- \r\n");

    es_rvc_sem = Semaphore_create(1, NULL, NULL);

    ES_InitSignal(ES_REVERSE);
    ES_InitSignal(ES_PARK);
    ES_InitSignal(ES_IGNITION);
    ES_InitSignal(ES_DIMMING);

    reverse_data.status = ES_UNDEFINED;
    reverse_data.discrete_status = ES_UNDEFINED;

    park_data.status = ES_UNDEFINED;

    ignition_data.status = ES_UNDEFINED;
    ignition_data.discrete_status = ES_UNDEFINED;

    dimming_data.detection_mode = DIMMING_MODE_UNDEFINED;
    dimming_data.discrete_status = ES_UNDEFINED;
    dimming_data.mode = ES_DIMMING_DAY;
    dimming_data.pwm_duty = 100;
    dimming_data.pwm_duty_new = 100;
#endif
}

/***************************************************************************//**
 *
 * @fn         ES_DimmingSetDetectionMode
 *
 * @brief      Set dimming detection mode
 *
 * @param [in] detection_mode
 *
 * @return     None
 *
 ******************************************************************************/
void ES_DimmingSetDetectionMode (dimming_mode_t detection_mode)
{
    dimming_data.detection_mode = detection_mode;
}

/***************************************************************************//**
 *
 * @fn         ES_DimmingSetNewDuty
 *
 * @brief      Set dimming new duty
 *
 * @param [in] new_duty
 *
 * @return     None
 *
 ******************************************************************************/
void ES_DimmingSetNewDuty (uint32_t new_duty)
{
    dimming_data.pwm_duty_new = new_duty;
}

/***************************************************************************//**
 *
 * @fn         ES_InitSignal
 *
 * @brief      Initialize every external GPIO signal
 *
 * @param [in] signal
 *
 * @return     None
 *
 ******************************************************************************/
void ES_InitSignal (ES_Signals_T signal)
{
    LOG_PRINT_INFO(DEBUG_ES, "ES_InitSignal\r\n");

    switch(signal)
    {
        case ES_REVERSE:
            GPIOModuleEnable(ES_REVERSE_DET_GPIO_ADDR);
            GPIODirModeSet(ES_REVERSE_DET_GPIO_ADDR, ES_REVERSE_DET_GPIO_PIN, GPIO_DIR_INPUT);
            break;

        case ES_PARK:
            GPIOModuleEnable(ES_PARK_DET_GPIO_ADDR);
            GPIODirModeSet(ES_PARK_DET_GPIO_ADDR, ES_PARK_DET_GPIO_PIN, GPIO_DIR_INPUT);
            break;

        case ES_IGNITION:
            GPIOModuleEnable(ES_IGNITION_DET_GPIO_ADDR);
            GPIODirModeSet(ES_IGNITION_DET_GPIO_ADDR, ES_IGNITION_DET_GPIO_PIN, GPIO_DIR_INPUT);
            break;

        case ES_DIMMING:
        default:
            break;
    }
}

/***************************************************************************//**
 *
 * @fn         ES_SetSignalStatus
 *
 * @brief      Gets the GPIO input value and stores it on a static variable
 *
 * @param [in] signal
 *
 * @return     True if the signal changed from its last value
 *
 ******************************************************************************/
bool_t ES_SetSignalStatus (ES_Signals_T signal)
{
    bool_t signal_changed = FALSE;

    uint32_t new_status = ES_UNDEFINED;

    switch(signal)
    {
        case ES_REVERSE:
            new_status = GPIOPinRead2(ES_REVERSE_DET_GPIO_ADDR, ES_REVERSE_DET_GPIO_PIN);

            if (new_status != reverse_data.discrete_status) {
                reverse_data.discrete_status = new_status;
                signal_changed = TRUE;
                reverse_data.status = (REVERSE_DET_ON == new_status) ? ES_REVERSE_ON : ES_REVERSE_OFF;
                LOG_PRINT_INFO(DEBUG_ES, "ES_SetSignalStatus: signal ES_REVERSE new_status \t %d\r\n", new_status);
            }

            break;

        case ES_PARK:
            new_status = GPIOPinRead2(ES_PARK_DET_GPIO_ADDR, ES_PARK_DET_GPIO_PIN);

            if (new_status != park_data.status) {
                signal_changed = TRUE;
                park_data.status = new_status;
                LOG_PRINT_INFO(DEBUG_ES, "ES_SetSignalStatus: signal ES_PARK new_status \t\t\t %d\r\n", new_status);
            }
            break;

        case ES_IGNITION:
            new_status = GPIOPinRead2(ES_IGNITION_DET_GPIO_ADDR, ES_IGNITION_DET_GPIO_PIN);

            if (new_status != ignition_data.discrete_status) {
                ignition_data.discrete_status = new_status;
                signal_changed = TRUE;
                ignition_data.status = (IGNITION_DET_ON == new_status) ? ES_IGNITION_ON : ES_IGNITION_OFF;
                LOG_PRINT_INFO(DEBUG_ES, "ES_SetSignalStatus: signal ES_IGNITION new_status \t %d\r\n", new_status);
            }
            break;

        case ES_DIMMING:
            new_status = dimming_data.pwm_duty_new;

            if (new_status != dimming_data.pwm_duty) {
                signal_changed = TRUE;
                dimming_data.pwm_duty = new_status;
                LOG_PRINT_INFO(DEBUG_ES, "ES_SetSignalStatus: signal ES_DIMMING new_status \t\t\t %d\r\n", new_status);
            }
            break;

        default:
            break;
    }
    return signal_changed;
}

/***************************************************************************//**
 *
 * @fn         ES_GetSignalStatus
 *
 * @brief      Function to get the last signal value
 *
 * @param [in] Signal
 *
 * @return     Last signal value
 *
 ******************************************************************************/
uint32_t ES_GetSignalStatus (ES_Signals_T signal)
{
    uint32_t retvalue = ES_UNDEFINED;
    switch(signal)
    {
        case ES_REVERSE:
            retvalue = reverse_data.status;
            break;

        case ES_PARK:
            retvalue = park_data.status;
            break;

        case ES_IGNITION:
            retvalue = ignition_data.status;
            break;

        case ES_DIMMING:
            retvalue = dimming_data.pwm_duty;
            break;

        default:
            break;
    }
    return retvalue;
}

/***************************************************************************//**
 *
 * @fn         ES_Task_Thread
 *
 * @brief      This is the external signal task. This thread reads the GPIO input
 *             every 50ms
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void ES_Update (void)
{
#if (USE_EXTERNAL_SIGNALS == 1)
    uint32_t level = 0;
    uint8_t min, max;

    if ( ES_SetSignalStatus (ES_REVERSE) ) {
       ES_ReportRvcStatus();
    }
    if ( ES_SetSignalStatus (ES_PARK) ) {
        ES_ReportParkStatus();
    }
    if ( ES_SetSignalStatus (ES_IGNITION) ) {
       ES_ReportIgnStatus();
    }
    if ( ES_SetSignalStatus (ES_DIMMING) ) {
        level = ES_GetSignalStatus(ES_DIMMING);
        DIMMING_GetLimits_ES(&min, &max);
        DIMMING_SetLevel_ES(Scale(level, 0, 100, min, max), level);
        ES_ReportDisplayDimmingStatus();
    }
#endif
}

/***************************************************************************//**
 *
 * @fn         ES_ReportRvcStatus
 *
 * @brief      Report through Shadow Storage the RVC+HATCH status
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void ES_ReportRvcStatus (void)
{
    uint32_t rvc_status = 0;

    rvc_status = ES_GetSignalStatus(ES_REVERSE);

    Semaphore_pend(es_rvc_sem, BIOS_WAIT_FOREVER);
    HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_REG1, rvc_status);
    Semaphore_post(es_rvc_sem);

    Shadow_Server_Storage_Set(SHADOW_ReverseGearSts, (uint8_t *) &rvc_status);

    if (rvc_status) {
        DIMMING_SetChannelOn(DIM_USER_B, DIM_DISP);
    } else {
        DIMMING_SetChannelOff(DIM_USER_B, DIM_DISP);
    }
}

/***************************************************************************//**
 *
 * @fn         ES_ReportCurrentRvcStatus
 *
 * @brief      Report to the shared memory the RVC+HATCH status
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void ES_ReportCurrentRvcStatus (void)
{
#if (USE_EXTERNAL_SIGNALS == 1)
    uint32_t rvc_status = ES_UNDEFINED;

    rvc_status = ES_GetSignalStatus(ES_REVERSE);

    Semaphore_pend(es_rvc_sem, BIOS_WAIT_FOREVER);
    HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_REG1, rvc_status);
    Semaphore_post(es_rvc_sem);
#endif
}

/***************************************************************************//**
 *
 * @fn         ES_ReportRvcOff
 *
 * @brief      Report to the shared memory that the RVC+HATCH status are off
 *             this depends on the Ignition signals and the power state
 *             machine and is independent of the real state of this signals.
 *             We do not modify the internal signals of the class.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void ES_ReportRvcOff (void)
{
    uint32_t rvc_status = 0;

    rvc_status = SAR_RAM_ALL_BIT_OFF;

    Shadow_Server_Storage_Set(SHADOW_ReverseGearSts, (uint8_t *) &rvc_status);

    Semaphore_pend(es_rvc_sem, BIOS_WAIT_FOREVER);
    /* do not change the global variable */
    HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_REG1, rvc_status);
    Semaphore_post(es_rvc_sem);
}

/***************************************************************************//**
 *
 * @fn         ES_ReportParkStatus
 *
 * @brief      Report to the Shadow Storage the value of the park
 *             external signal
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void ES_ReportParkStatus (void)
{
    uint8_t park_status = ES_UNDEFINED;

    park_status = ES_GetSignalStatus(ES_PARK);
    Shadow_Server_Storage_Set(SHADOW_ParkBrakeSts, &park_status);
}

/***************************************************************************//**
 *
 * @fn         ES_ReportIgnStatus
 *
 * @brief      Report to the Shadow Storage the value of the ignition
 *             external signal
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void ES_ReportIgnStatus (void)
{
    uint16_t aux_data16 = 0;
    uint8_t ign_status = ES_UNDEFINED;

    ign_status = ES_GetSignalStatus(ES_IGNITION);
    aux_data16 = ign_status << 8;
    Shadow_Server_Storage_Set(SHADOW_CmdIgn, (uint8_t *)&aux_data16);
}

/***************************************************************************//**
 *
 * @fn         ES_ReportDisplayDimmingStatus
 *
 * @brief      Report to the Shadow Storage the value of the dimming
 *             external signal
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void ES_ReportDisplayDimmingStatus (void)
{
    uint16_t dimming_status = 0, aux16 = 0;

    dimming_status = (ES_GetSignalStatus(ES_DIMMING) == 0) ? ES_DISP_DIMMING_DAY : ES_DISP_DIMMING_NIGHT;
    aux16 = ( Scale(dimming_data.pwm_duty, 0, 100, 0, 7) << 8 ) | dimming_status;
    
    Shadow_Server_Storage_Set(SHADOW_InternalLight, (uint8_t *) &aux16);
}
