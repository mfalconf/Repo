/*===========================================================================*/
/**
 * @file can_appl.c
 *
 * Wrapper for all the CAN related functions
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"

#include <can_appl.h>
#if (USE_CAN_VOLKSWAGEN == 1)
    #include <can_appl_volkswagen.h>
#endif
#if (USE_CAN_MOPAR == 1)
    #include <can_appl_mopar.h>
#endif

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         CanAppl_Init
 *
 * @brief      Initialization variables CAN
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Init(void)
{
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    CanAppl_Volkswagen_Init();
    #endif
    #if (USE_CAN_MOPAR == 1)
    CanAppl_Mopar_Init();
    #endif
    #endif
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg
 *
 * @brief      Handler thats controls the CAN messages.
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_ProcessMsg(dcanRxParams_t CanRxPrms)
{
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    CanAppl_Volkswagen_ProcessMsg(CanRxPrms);
    #endif
    #if (USE_CAN_MOPAR == 1)
    CanAppl_Mopar_ProcessMsg(CanRxPrms);
    #endif
    #endif
}

/***************************************************************************//**
 *
 * @fn         CanAppl_PrepareMsgToSend
 *
 * @brief      Prepare the message data before sending
 *
 * @param [in] id
 * @param [in] data
 *
 * @return     true - If the message sending should go on. False if not.
 *
 ******************************************************************************/
bool_t CanAppl_PrepareMsgToSend (uint32_t id, uint8_t *data)
{
    bool_t ret = true;
    #if (USE_CAN == 1)
    #if (ENABLE_CAN_TX)
    #if (USE_CAN_VOLKSWAGEN == 1)
    ret = CanAppl_Volkswagen_PrepareMsgToSend(id, data);
    #endif
    #endif
    #endif
    return (ret);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_GetOperationalMode_Status
 *
 * @brief      Get signal OperationalMode_Status
 *
 * @param [in] void
 *
 * @return     uint8_t
 *
 ******************************************************************************/
uint8_t CanAppl_GetOperationalMode_Status()
{
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    return (CanAppl_Volkswagen_GetOperationalMode_Status());
    #endif
    #if (USE_CAN_MOPAR == 1)
    return (CanAppl_Mopar_GetOperationalMode_Status());
    #endif
    #else
    return 0;
    #endif
}

/***************************************************************************//**
 *
 * @fn         CanAppl_GetKey_Status
 *
 * @brief      Get signal if the key is inserted or removed.
 *             Check the particular implementation for details
 *
 * @param [in] void
 *
 * @return     uint8_t
 *
 ******************************************************************************/
uint8_t CanAppl_GetKey_Status()
{
    
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    return CanAppl_Volkswagen_GetKey_Status();
    #endif
    #if (USE_CAN_MOPAR == 1)
    #warning "Not implemented"
    #endif
    #else
    return 0;
    #endif
}

/***************************************************************************//**
 *
 * @fn         CanAppl_GetTransportMode_Status
 *
 * @brief      Get signal TransportMode_Status
 */
uint8_t CanAppl_GetTransportMode_Status()
{
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    return (CanAppl_Volkswagen_GetTransportMode_Status());
    #else
    return TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;
    #endif
    #else
    return TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE;
    #endif
}

/*******************************************************************************
 * @fn         CanAppl_GetNetworkActive_Status
 *
 * @brief      Get the CAN Network active status
 *
 * @param [in] void
 *
 * @return     uint8_t
 *
 ******************************************************************************/

uint8_t CanAppl_GetNetworkActive_Status(void)
{
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    return (CanAppl_Volkswagen_GetNetworkActive_Status());
    #else
    return 0;
    #endif
    #else
    return 0;
    #endif
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ReportCurrentRvcStatus
 *
 * @brief      Report to the shared memory the RVC+HATCH status
 *
 * @param [in]
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_ReportCurrentRvcStatus()
{
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    CanAppl_Volkswagen_ReportCurrentRvcStatus();
    CanAppl_Volkswagen_ReportCurrentPdcStatus();
    #endif
    #if (USE_CAN_MOPAR == 1)
    CanAppl_Mopar_ReportCurrentRvcStatus();
    #endif
    #endif
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ReportRvcOff
 *
 * @brief      Report to the shared memory that the RVC+HATCH status are off
 *             this depends on the Ignition signals and the power state
 *             machine and is independent of the real state of this signals.
 *             We do not modify the internal signals of the class.
 *
 * @param [in]
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_ReportRvcOff()
{
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    CanAppl_Volkswagen_ReportRvcOff();
    CanAppl_Volkswagen_ReportPdcOff();
    #endif
    #if (USE_CAN_MOPAR == 1)
    CanAppl_Mopar_ReportRvcOff();
    #endif
    #endif
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Timeout_Init
 *
 * @brief      Initialization of variables for controller the timeout CAN msg.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Timeout_Init(void)
{
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    CanAppl_Volkswagen_Timeout_Init();
    #endif
    #if (USE_CAN_MOPAR == 1)
    CanAppl_Mopar_Timeout_Init();
    #endif
    #endif
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Timeout
 *
 * @brief      Handler thats controls the timeouts of the periodic CAN messages.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Timeout(void)
{
    #if (USE_CAN == 1)
    #if (USE_CAN_VOLKSWAGEN == 1)
    CanAppl_Volkswagen_Timeout();
    #endif
    #if (USE_CAN_MOPAR == 1)
    CanAppl_Mopar_Timeout();
    #endif
    #endif
}

/***************************************************************************//**
 *
 * @fn         CAN_Disable_Appl_TX_Messages
 *
 * @brief      Determine whether to enable or disable Appl transmit
 *             messages, based on diagnostic commands.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CAN_Disable_Appl_TX_Messages (bool_t disable_transmit)
{
    #if (USE_CAN_VOLKSWAGEN == 1)
    CANAppl_Volkswagen_Disable_Appl_TX_Messages(disable_transmit);
    #endif
}

/***************************************************************************//**
 *
 * @fn         CAN_Disable_Appl_BAP_TX_Messages
 *
 * @brief      Determine whether to enable or disable BAP messages,
 *             based on diagnostic commands.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CAN_Disable_BAP_TX_Messages (bool_t disable_transmit)
{
    #if (USE_CAN_VOLKSWAGEN == 1)
    CANAppl_Volkswagen_Disable_BAP_TX_Messages(disable_transmit);
    #endif
}

/***************************************************************************//**
 *
 * @fn         CAN_Disable_NM_TX_Messages
 *
 * @brief      Determine whether to enable or disable NM messages,
 *             based on diagnostic commands.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CAN_Disable_NM_TX_Messages (bool_t disable_transmit)
{
    #if (USE_CAN_VOLKSWAGEN == 1)
    CANAppl_Volkswagen_Disable_NM_TX_Messages(disable_transmit);
    #endif
}
