#ifndef CAN_APPL_MOPAR_H_
#define CAN_APPL_MOPAR_H_ 0

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

#define CAN_MESSAGE_TIMEOUT_MS                  2500     // 2500000 milli-seconds = 2,5 seconds

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define CAN_RX_MESSAGE_TABLE \
        /* Name                 ID              ID_Format           DLC         PERIODICITY [x10ms]*/   \
        X( STATUS_BH_BCM1,      0x356,          CAN_STANDARD,       8,          CAN_MESSAGE_TIMEOUT_MS) \
        X( STATUS_BH_BCM2,      0x46C,          CAN_STANDARD,       8,          CAN_MESSAGE_TIMEOUT_MS) \
        X( STATUS_CCAN3,        0x3E2,          CAN_STANDARD,       8,          CAN_MESSAGE_TIMEOUT_MS) \
        X( STATUS_CCAN4,        0x3E4,          CAN_STANDARD,       8,          CAN_MESSAGE_TIMEOUT_MS) \
        X( SWS_IGWLIN,          0x2EE,          CAN_STANDARD,       4,          0                     ) \
        X( TIME_DATE,           0x764,          CAN_STANDARD,       6,          CAN_MESSAGE_TIMEOUT_MS) \
        X( IPC_VEHICLE_SETUP,   0x5BC,          CAN_STANDARD,       8,          CAN_MESSAGE_TIMEOUT_MS) \
        X( STATUS_CCAN5,        0x3E6,          CAN_STANDARD,       8,          CAN_MESSAGE_TIMEOUT_MS) \
        X( TRIP_A_B,            0x760,          CAN_STANDARD,       6,          CAN_MESSAGE_TIMEOUT_MS) \
        X( VIN,                 0x3E0,          CAN_STANDARD,       8,          CAN_MESSAGE_TIMEOUT_MS) \
        X( STATUS_CCAN1,        0x3DC,          CAN_STANDARD,       7,          CAN_MESSAGE_TIMEOUT_MS) \
        X( TEST,                0xB0CA,         CAN_EXTENDED,       8,          0                     ) \
        X( TEST_2,              0xB012,         CAN_EXTENDED,       8,          0                     ) \

#define CAN_TX_MESSAGE_TABLE \
        /* Name                 ID              ID_Format           DLC         PERIODICITY [x10ms]*/  \

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern void CanAppl_Mopar_Init(void);
extern void CanAppl_Mopar_ProcessMsg(dcanRxParams_t CanRxPrms);
extern uint8_t CanAppl_Mopar_GetOperationalMode_Status();
extern void CanAppl_Mopar_ReportCurrentRvcStatus();
extern void CanAppl_Mopar_ReportRvcOff();
extern void CanAppl_Mopar_Timeout_Init(void);
extern void CanAppl_Mopar_Timeout(void);

#endif /* CAN_APPL_MOPAR_H_ */
