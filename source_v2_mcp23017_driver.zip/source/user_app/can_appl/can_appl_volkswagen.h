#ifndef CAN_APPL_VOLKSWAGEN_H_
#define CAN_APPL_VOLKSWAGEN_H_ 0

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "can_tp_callouts.h"
#include "famp_pm.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

#define CAN_MESSAGE_TIMEOUT_MS          2500    // 2500 milli-seconds = 2,5 seconds
#define FAST_CAN_MESSAGE_TIMEOUT_MS     500    // 500 milli-seconds = 0,5 seconds

/* Custom messages to handle the validation tone and sync. Please note that if you 
 * decided to change any of those values to a new one that is lesser than 0x800, you 
 * also need to modify the appropiate CAN message type in the table below to CAN_STANDARD 
 */  
#define CAN_MESSAGE_SYNC_STATUS_ID      0x886
#define CAN_SYNC_STATUS_RESPONSE_ID     0x887
#define CAN_MESSAGE_TONE_VALIDATION_ID  0x888   

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*
 * mBSG_3:
 *  - BS3_Klemme_15             -> Ignition
 *  - BS3_PDC_Taster            -> 1 = button pressed, evaluation on/off takes place in the parking aid, not working in sample amarok.
 * mRegen_Licht_Sensor:
 *  - RL1_Licht_ein             -> Lights
 * mLicht_1_alt:
 *  - LIA_Standlicht            -> Parkings lights
 *  - LIA_AFL_Schalter          -> ReverseGearSts
 * mMFL_Tasten:
 *  - MLT_Symbol                -> SWC
 * mKombi_K1:
 *  - KO1_Handbremse            -> Hand Brake
 * mKombi_1:
 *  - KB1_Handbremse            -> Park brake
 * mDiagnose_1                  -> Time & Date
 * mEinheiten:
 *  - EH1_Uhr_Anzeige           -> Time & Date (HrMode)
 * mGW_Bremse_Getriebe:
 *  - GWB_FzgGeschw             -> VehicleSpeed
 * Parkhilfe_01:
 *  - PH_Anf_Audioabsenkung     -> Request to the audio system to lower the volume, can be active if reverse is engaged or PDC/PLA button is pressed
 * BAP_OPS                      -> POC requests (Parking sensor repetition)
 * BAP_ASG_07                   -> Kombi request (Audio and Telephone repetition)
 * mBSG_Kombi
 *  - BSK_Rueckfahrlicht        -> Reverse
 * mGateway_3:
 *  - GW3_Sprachevariante       -> Language selection
 * mMFA_1:
 * - MA1_Verbrauch              -> instant consumption
 * - MA1_Reichweite             -> range / autonomy
 * - MA1_Kilometerstand         -> Kilometerstand
 * - MA1_Reichweite_Reservetank -> reserve range
 * mMFA_2:                      -> Since start
 * - MA2_Verbrauch              -> consumption
 * - MA2_Strecke                -> distance
 * - MA2_Zeit                   -> time
 * - MA2_Geschw                 -> average speed
 * mMFA_3:                      Long term
 * - MA3_Verbrauch              -> consumption
 * - MA3_Strecke                -> distance
 * - MA3_Zeit                   -> time
 * - MA3_Geschw                 -> average speed
 * mFzg_Ident:                  -> Chassis number
 * mLenkwinkel_1:
 * - LW1_Lenkradwinkel          -> wheel angle
 * - LW1_Vorzeichen             -> wheel direction right or left
 * mGW_Motor:
 * - GWM_Motordrehzahl          -> RPM
 * - GWM_KuehlmittelTemp        -> Coolant temperature
 * mGW_ANT_2:
 * - GE2_Senderkennung          -> 1 = MSG (manual), 0 = GSG (auto)
 * - GE2_Variante               -> gear for MSG
 * mGW_ANT_1:
 * - BR2_Querbeschl             -> lateral acceleration (unit: forces of g)
 * - BR8_Laengsbeschl           -> longitudinal acceleration (unit: m/s2)
 * mBremse_10:
 * - B10_Wegimp_VL              -> Counter for front wheel left
 * - B10_Wegimp_VR              -> Counter for front wheel right
 * - B10_Wegimp_HL              -> Counter for rear wheel left
 * - B10_Wegimp_HR              -> Counter for rear wheel right
 * - B10_Fahrtr_VL              -> Direction of front wheel left
 * - B10_Fahrtr_VR              -> Direction of front wheel right
 * - B10_Fahrtr_HL              -> Direction of rear wheel left
 * - B10_Fahrtr_HR              -> Direction of rear wheel right
 * mGW_Kombi:
 * - GWK_Umfang_Reifen          -> Average tire circumference
 * mMotor7:
 * - MO7_Oeltemperatur          -> Oil temperature
 */

#define CAN_RX_MESSAGE_TABLE                                                                      \
    /* Name                 ID              ID_Format           DLC         PERIODICITY [x10ms]*/ \
    X(mBSG_3, 0x575, CAN_STANDARD, 4, CAN_MESSAGE_TIMEOUT_MS)                                     \
    X(mDimmung, 0x635, CAN_STANDARD, 3, CAN_MESSAGE_TIMEOUT_MS)                                   \
    X(mRegen_Licht_Sensor, 0x457, CAN_STANDARD, 3, 0)                                             \
    X(mLicht_1_alt, 0x531, CAN_STANDARD, 4, CAN_MESSAGE_TIMEOUT_MS)                               \
    X(mMFL_Tasten, 0x5C1, CAN_STANDARD, 4, 0)                                                     \
    X(mKombi_1, 0x320, CAN_STANDARD, 8, CAN_MESSAGE_TIMEOUT_MS)                                   \
    X(mKombi_K1, 0x621, CAN_STANDARD, 8, 1000)                                                    \
    X(mDiagnose_1, 0x65D, CAN_STANDARD, 8, CAN_MESSAGE_TIMEOUT_MS)                                \
    X(mEinheiten, 0x60E, CAN_STANDARD, 2, CAN_MESSAGE_TIMEOUT_MS)                                 \
    X(mGW_Bremse_Getriebe, 0x359, CAN_STANDARD, 8, FAST_CAN_MESSAGE_TIMEOUT_MS)                   \
    X(NWM_BCM1, 0x400, CAN_STANDARD, 8, CAN_MESSAGE_TIMEOUT_MS)                                   \
    X(Parkhilfe_01, 0x497, CAN_STANDARD, 8, CAN_MESSAGE_TIMEOUT_MS)                               \
    X(BAP_OPS, 0x6DA, CAN_STANDARD, 8, 0)                                                         \
    X(BAP_ASG_07, 0x67C, CAN_STANDARD, 8, 0)                                                      \
    X(mBSG_Kombi, 0x470, CAN_STANDARD, 8, 0)                                                      \
    X(mGateway_3, 0x653, CAN_STANDARD, 4, 0)                                                      \
    X(mSysteminfo_1, 0x651, CAN_STANDARD, 8, CAN_MESSAGE_TIMEOUT_MS)                              \
    X(cSyncStatus_t, CAN_MESSAGE_SYNC_STATUS_ID, CAN_EXTENDED, 0, 0)                              \
    X(cValidationTone_t, CAN_MESSAGE_TONE_VALIDATION_ID, CAN_EXTENDED, 8, 0)                      \
    X(DiagPhysicalReq, ADDR_PHY_REQ, CAN_STANDARD, 8, 0)                                          \
    X(DiagFunctionalReq, ADDR_FUN_REQ, CAN_STANDARD, 8, 0)                                        \
    X(mMFA_1, 0x629, CAN_STANDARD, 8, CAN_MESSAGE_TIMEOUT_MS)                                     \
    X(mMFA_2, 0x62B, CAN_STANDARD, 8, CAN_MESSAGE_TIMEOUT_MS)                                     \
    X(mMFA_3, 0x62D, CAN_STANDARD, 8, CAN_MESSAGE_TIMEOUT_MS)                                     \
    X(mFzg_Ident, 0x65F, CAN_STANDARD, 8, CAN_MESSAGE_TIMEOUT_MS)                                 \
    X(mLenkwinkel_1, 0x3C3, CAN_STANDARD, 8, FAST_CAN_MESSAGE_TIMEOUT_MS)                         \
    X(mGW_Motor, 0x35B, CAN_STANDARD, 8, FAST_CAN_MESSAGE_TIMEOUT_MS)                             \
    X(mGW_ANT_2, 0x369, CAN_STANDARD, 8, FAST_CAN_MESSAGE_TIMEOUT_MS)                             \
    X(mGW_ANT_1, 0x367, CAN_STANDARD, 8, FAST_CAN_MESSAGE_TIMEOUT_MS)                             \
    X(mBremse_10, 0x5B5, CAN_STANDARD, 8, FAST_CAN_MESSAGE_TIMEOUT_MS)                            \
    X(mGW_Kombi, 0x527, CAN_STANDARD, 8, FAST_CAN_MESSAGE_TIMEOUT_MS)                            \
    X(mMotor7, 0x555, CAN_STANDARD, 8, FAST_CAN_MESSAGE_TIMEOUT_MS)                               \

/*                                                                                                \
 * BAP_Telefon_04               -> Phone repetition messages                                      \
 * BAP_AUDIO                    -> Audio repetition messages                                      \
 * BAP_Anzeige_02               -> Parking sensor repetition messages                             \
 */
#define CAN_TX_MESSAGE_TABLE                                                                      \
    /* Name                 ID              ID_Format           DLC         PERIODICITY [x10ms]*/ \
    X(NWM_RNS, 0x436, CAN_STANDARD, 8, 0)                                                         \
    X(TestMsgPeriodicApp, 0x123, CAN_STANDARD, 6, 0)                                              \
    X(TestMsgPeriodicNm, 0x456, CAN_STANDARD, 8, 0)                                               \
    X(TestMsgOnEvent, 0x789, CAN_STANDARD, 8, 0)                                                  \
    X(MainUnit_01, 0x481, CAN_STANDARD, 2, 100)                                                   \
    X(mNAV_1, 0x604, CAN_STANDARD, 8, 100)                                                        \
    X(mRadio_4, 0x661, CAN_STANDARD, 8, 100)                                                      \
    X(mTelefon_3, 0x665, CAN_STANDARD, 7, 100)                                                    \
    X(BAP_Telefon_04, 0x66F, CAN_STANDARD, 8, 0)                                                  \
    X(BAP_AUDIO, 0x66C, CAN_STANDARD, 8, 0)                                                       \
    X(DiagPhysicalResp, ADDR_PHY_RESP, CAN_EXTENDED, 8, 0)                                        \
    X(cSyncStatusResponse_t, CAN_SYNC_STATUS_RESPONSE_ID, CAN_EXTENDED, 2, 0)                     
    
#define MFL_TASTEN_TABLE    \
    X(NoKey,        0x00)   \
    X(Next,         0x02)   \
    X(Prev,         0x03)   \
    X(VolUp,        0x06)   \
    X(VolDown,      0x07)   \
    X(Flash,        0x1A)   \
    X(FolderUp,     0x22)   \
    X(FolderDown,   0x23)   \
    X(Ok,           0x28)   \
    X(Voice,        0x2A)   \
    X(Mute,         0x2B)   \

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

#undef X
#define X(a, b, c, d, e) a##_ID = b,
typedef enum Id_Can_Rx_Msg_tag
{
    CAN_RX_MESSAGE_TABLE
} Id_Can_Rx_Msg_T;

#undef X
#define X(a, b, c, d, e) a##_ID = b,
typedef enum Id_Can_Tx_Msg_tag
{
    CAN_TX_MESSAGE_TABLE
} Id_Can_Tx_Msg_T;

#undef X
#define X(a,b) MFL_Tasten_##a##_Id = b,
typedef enum MFL_Tasten_Id_Tag
{
    MFL_TASTEN_TABLE    
}MFL_Tasten_Id_T;

//  Express CAN signals indexs in a friendly way.
#define SY1_TRANSPORT_MODE_START_BYTE_INDEX 3 //  Byte 4 from the message, position [3] in the vector
#define SY1_TRANSPORT_MODE_START_BIT 6        //  Bit 6


typedef void (*can_appl_timeout_msg_fptr)(void);

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern void     CanAppl_Volkswagen_Init(void);
extern void     CanAppl_Volkswagen_ProcessMsg(dcanRxParams_t CanRxPrms);
extern bool_t   CanAppl_Volkswagen_PrepareMsgToSend(uint32_t id, uint8_t *data);
extern uint8_t  CanAppl_Volkswagen_GetOperationalMode_Status();
extern uint8_t  CanAppl_Volkswagen_GetKey_Status();
extern uint8_t  CanAppl_Volkswagen_GetTransportMode_Status();
extern uint8_t  CanAppl_Volkswagen_GetNetworkActive_Status();
extern void     CanAppl_Volkswagen_ReportCurrentRvcStatus();
extern void     CanAppl_Volkswagen_ReportCurrentPdcStatus();
extern void     CanAppl_Volkswagen_ReportRvcOff();
extern void     CanAppl_Volkswagen_ReportPdcOff();
extern void     CanAppl_Volkswagen_Timeout_Init(void);
extern void     CanAppl_Volkswagen_Timeout(void);
extern void     CANAppl_Volkswagen_Disable_Appl_TX_Messages(bool_t disable_transmit);
extern void     CANAppl_Volkswagen_Disable_BAP_TX_Messages(bool_t disable_transmit);
extern void     CANAppl_Volkswagen_Disable_NM_TX_Messages(bool_t disable_transmit);
void CANAppl_SendTestMsgOnEvent(uint8_t *data, uint8_t length);
void CANAppl_SendSyncResponse(void);
#endif /* CAN_APPL_VOLKSWAGEN_H_ */
