#ifndef CAN_APPL_H_
#define CAN_APPL_H_ 0

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <ti/csl/src/ip/dcan/V0/dcan.h>

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#define IGN_OFF                     0
#define IGN_ACCESSORY               1
#define IGN_ON                      4
#define IGN_PRESTART                5
#define IGN_START                   6
#define IGN_CRANKING                7
#define IGN_ON_ENGINE_ON            8
#define IGN_SNA                    15

#define CAN_KEY_REMOVED  0
#define CAN_KEY_INSERTED 1

typedef enum {
   TRANSPORT_MODE_ERROR = -1,
   TRANSPORT_MODE_SIGNAL_NOT_AVAILABLE = 0,
   TRANSPORT_MODE_OFF,
   TRANSPORT_MODE_ON
}pmTransportMode_t;

typedef struct __attribute__((__packed__))_tone_generator {
    uint8_t playingStatus;
    uint8_t volume;
    uint32_t duration;
    uint16_t frequency;
} tone_generator_t;

//  Validation Tone defines
#define VT_PLAYING_STATUS       0
#define VT_VOLUME               1
#define VT_TONE_DURATION_7_0    2
#define VT_TONE_DURATION_15_8   3
#define VT_TONE_DURATION_23_16  4
#define VT_TONE_DURATION_31_24  5
#define VT_FREQUENCY_LSB        6
#define VT_FREQUENCY_MSB        7


/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern void CanAppl_Init(void);
extern void CanAppl_ProcessMsg(dcanRxParams_t CanRxPrms);
extern bool_t CanAppl_PrepareMsgToSend (uint32_t id, uint8_t *data);
extern uint8_t CanAppl_GetOperationalMode_Status();
extern uint8_t CanAppl_GetKey_Status();
extern uint8_t CanAppl_GetNetworkActive_Status();
extern uint8_t CanAppl_GetTransportMode_Status();
extern void CanAppl_ReportCurrentRvcStatus();
extern void CanAppl_ReportRvcOff();
extern void CanAppl_Timeout_Init(void);
extern void CanAppl_Timeout(void);
extern void CAN_Disable_Appl_TX_Messages (bool_t disable_transmit);
extern void CAN_Disable_BAP_TX_Messages (bool_t disable_transmit);
extern void CAN_Disable_NM_TX_Messages (bool_t disable_transmit);

#endif /* CAN_APPL_H_ */
