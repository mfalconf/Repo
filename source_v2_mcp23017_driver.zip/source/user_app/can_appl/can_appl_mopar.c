
#include "standard.h"
#include "sar_ram_definitions.h"

#include <console.h>
#include <shadow_storage.h>
#include "source/shared_data/shadow_signals/common_definitions.h"
#include <timedate.h>
#include <dimming.h>
#include <can_appl.h>
#include <can_appl_mopar.h>

#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/csl/src/ip/dcan/V0/dcan.h>
#include <ti/csl/hw_types.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

#include "clock_utils.h"


/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

#define OperationalModeSts_SNA                  0xF
#define CmdIgn_FailSts_SNA                      0x3
#define CmdIgnSts_SNA                           0x7
#define EngineSts_SNA                           0x3
#define ReverseGearSts_SNA                      0x3
#define ShiftLeverPosition_SNA                  0xF
#define AutonomyDistance_SNA                    0x7FF
#define ExternalTemperatureC_SNA                0x1FF
#define VIN_Msg_SNA                             0x3
#define ShiftModeSts_SNA                        0
#define LongAcceleration_BSM_SNA                0xFFF
#define LatAcceleration_BSM_SNA                 0xFFF
#define YawRate_BSM_SNA                         0xFFF

#define IPC_VEHICLE_SETUP_HourMode_24h          0
#define IPC_VEHICLE_SETUP_HourMode_12h          1

#define SAR_RAM_ALL_BIT_OFF                     0x00000000

#define SAR_RAM_BIT_REVERSEGEAR_OFF             0xFFFFFFFE
#define SAR_RAM_BIT_REVERSEGEAR_ON              0x00000001

#define SAR_RAM_BIT_RHATCHSTS_OFF               0xFFFFFFFD
#define SAR_RAM_BIT_RHATCHSTS_ON                0x00000002


/* IPC Vehicle Setup */

#define IPC_VEHICLE_SETUP_NO_LANGUAGE     0x00
#define IPC_VEHICLE_SETUP_ENGLISH         0x01
#define IPC_VEHICLE_SETUP_SPANISH         0x03
#define IPC_VEHICLE_SETUP_PORTUGUES       0x05
#define IPC_VEHICLE_SETUP_US_ENGLISH      0x02
#define IPC_VEHICLE_SETUP_US_SPANISH      0x0A
#define IPC_VEHICLE_SETUP_BR_PORTUGUES    0x08

/* STATUS_CCAN3 */

//Vehicle Speed
#define VEHICLE_SPEED_RES   0.0625  // 0.0625 km/h per bit

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
//typedef bool bool_t;

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef struct Can_Rx_Signals_Tag
{
    uint8_t     OperationalModeSts;
    uint8_t     CmdIgnSts;
    uint8_t     CmdIgn_FailSts;
    float       VehicleSpeedVSOSig;
    uint8_t     EngineSts;
    uint8_t     Command_01Sts;
    uint8_t     Command_02Sts;
    uint8_t     Command_03Sts;
    uint8_t     Command_04Sts;
    uint8_t     Command_05Sts;
    uint8_t     Command_06Sts;
    uint8_t     Command_07Sts;
    uint8_t     Command_08Sts;
    uint8_t     Command_09Sts;
    uint8_t     Command_10Sts;
    uint8_t     Command_11Sts;
    uint8_t     Command_12Sts;
    uint8_t     Command_13Sts;
    uint8_t     Command_14Sts;
    uint8_t     Command_15Sts;
    uint8_t     Day1;
    uint8_t     Day2;
    uint8_t     Hour1;
    uint8_t     Hour2;
    uint8_t     Minute1;
    uint8_t     Minute2;
    uint8_t     Month1;
    uint8_t     Month2;
    uint8_t     Year1;
    uint8_t     Year2;
    uint8_t     Year3;
    uint8_t     Year4;
    uint8_t     hr_mode;
    uint8_t     ReverseGearSts;
    uint8_t     ParkBrakeSts;
    uint8_t     InternalLightSts;
    uint8_t     InternalLightLevel;
    uint8_t     LowFuelWarningSts;
    uint8_t     ShiftLeverPosition;
    uint16_t    AutonomyDistance;
    uint16_t    ExternalTemperatureC;
    uint8_t     VIN_Msg;
    uint8_t     VIN_Data[7];
    uint8_t     RHatchSts;
    uint8_t     ShiftModeSts;
    uint16_t    LongAcceleration_BSM;
    uint16_t    LatAcceleration_BSM;
    uint16_t    YawRate_BSM;
    uint8_t     LanguageSelection;
    uint8_t     transportMode_CAN;
}Can_Rx_Signals_T;



#undef X
#define X(a,b,c,d,e)     a##_ID = b,
typedef enum Id_Can_Rx_Msg_tag
{
    CAN_RX_MESSAGE_TABLE
}Id_Can_Rx_Msg_T;

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static Can_Rx_Signals_T CanRxSignals;

static Semaphore_Handle ignition_sem = NULL;
static Semaphore_Handle rvc_sem = NULL;

static TD_TimeDate_T timedate;

/* Timeout CAN messages */
uint32_t T_Msg_STATUS_BH_BCM1;
uint32_t T_Msg_STATUS_BH_BCM2;
uint32_t T_Msg_STATUS_CCAN3;
uint32_t T_Msg_STATUS_CCAN4;
uint32_t T_Msg_TIME_DATE;
uint32_t T_Msg_IPC_VEHICLE_SETUP;
uint32_t T_Msg_STATUS_CCAN5;
uint32_t T_Msg_TRIP_A_B;
uint32_t T_Msg_VIN;
uint32_t T_Msg_STATUS_CCAN1;

/* SAR RAM registers */
static uint32_t sar_ram_reg1 = SAR_RAM_ALL_BIT_OFF;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void CanAppl_ProcessMsg_STATUS_BH_BCM1(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_STATUS_BH_BCM2(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_STATUS_CCAN3(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_STATUS_CCAN4(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_SWS_IGWLIN(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_TIME_DATE(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_IPC_VEHICLE_SETUP(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_STATUS_CCAN5(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_TRIP_A_B(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_VIN(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_STATUS_CCAN1(dcanRxParams_t CanRxPrms);

static void CanAppl_SetTimeDate(void);

static void CanAppl_TimeoutMsg_STATUS_BH_BCM1(void);
static void CanAppl_TimeoutMsg_STATUS_BH_BCM2(void);
static void CanAppl_TimeoutMsg_STATUS_CCAN3(void);
static void CanAppl_TimeoutMsg_STATUS_CCAN4(void);
static void CanAppl_TimeoutMsg_TIME_DATE(void);
static void CanAppl_TimeoutMsg_IPC_VEHICLE_SETUP(void);
static void CanAppl_TimeoutMsg_STATUS_CCAN5(void);
static void CanAppl_TimeoutMsg_TRIP_A_B(void);
static void CanAppl_TimeoutMsg_VIN(void);
static void CanAppl_TimeoutMsg_STATUS_CCAN1(void);

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         CanAppl_Mopar_Init
 *
 * @brief      Initialization variables CAN
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Mopar_Init(void)
{
    /* Clear CanRxSignals structure */
    memset( &CanRxSignals, 0, sizeof(Can_Rx_Signals_T) );

    ignition_sem = Semaphore_create(1, NULL, NULL);
    rvc_sem = Semaphore_create(1, NULL, NULL);

    // Write (DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC) register for used in rear camera.(Initialization)
    sar_ram_reg1 = SAR_RAM_ALL_BIT_OFF;
    HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC, sar_ram_reg1);

}

/***************************************************************************//**
 *
 * @fn         CanAppl_Mopar_ProcessMsg
 *
 * @brief      Handler thats controls the CAN messages.
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Mopar_ProcessMsg(dcanRxParams_t CanRxPrms)
{
    uint32_t id;

    if( CanRxPrms.rxIdType == DCAN_XID_29_BIT )
    {
        id = CanRxPrms.rxMsgIdentifier;
    }
    else
    {
        id = ( CanRxPrms.rxMsgIdentifier >> 18 ) & 0x00001FFF;
    }

    LOG_PRINT(DEBUG_CAN, "CAN RX !!! \n");
    LOG_PRINT(DEBUG_CAN, "[%x] (%d) %x %x %x %x %x %x %x %x \n"    ,id,CanRxPrms.dataLength
                                                            ,CanRxPrms.msgData[0],CanRxPrms.msgData[1],CanRxPrms.msgData[2],CanRxPrms.msgData[3]
                                                            ,CanRxPrms.msgData[4],CanRxPrms.msgData[5],CanRxPrms.msgData[6],CanRxPrms.msgData[7]
                    );

    switch(id)
    {
        case STATUS_BH_BCM1_ID:
            CanAppl_ProcessMsg_STATUS_BH_BCM1(CanRxPrms);
            break;
        case STATUS_BH_BCM2_ID:
            CanAppl_ProcessMsg_STATUS_BH_BCM2(CanRxPrms);
            break;
        case STATUS_CCAN3_ID:
            CanAppl_ProcessMsg_STATUS_CCAN3(CanRxPrms);
            break;
        case STATUS_CCAN4_ID:
            CanAppl_ProcessMsg_STATUS_CCAN4(CanRxPrms);
            break;
        case SWS_IGWLIN_ID:
            CanAppl_ProcessMsg_SWS_IGWLIN(CanRxPrms);
            break;
        case TIME_DATE_ID:
            CanAppl_ProcessMsg_TIME_DATE(CanRxPrms);
            break;
        case IPC_VEHICLE_SETUP_ID:
            CanAppl_ProcessMsg_IPC_VEHICLE_SETUP(CanRxPrms);
            break;
        case STATUS_CCAN5_ID:
            CanAppl_ProcessMsg_STATUS_CCAN5(CanRxPrms);
            break;
        case TRIP_A_B_ID:
            CanAppl_ProcessMsg_TRIP_A_B(CanRxPrms);
            break;
        case VIN_ID:
            CanAppl_ProcessMsg_VIN(CanRxPrms);
            break;
        case STATUS_CCAN1_ID:
            CanAppl_ProcessMsg_STATUS_CCAN1(CanRxPrms);
            break;
        default:
            break;
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_STATUS_BH_BCM1
 *
 * @brief      Process CAN message Msg_STATUS_BH_BCM1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_STATUS_BH_BCM1(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;

    aux_data8 = ( CanRxPrms.msgData[2] >> 4 ) & 0x0F;
    if( CanRxSignals.OperationalModeSts != aux_data8 )
    {
        CanRxSignals.OperationalModeSts = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_OperationalModeSts, &CanRxSignals.OperationalModeSts);
    }

    aux_data8 = ( CanRxPrms.msgData[3] ) & 0x01;
    if( CanRxSignals.ParkBrakeSts != aux_data8 )
    {
        CanRxSignals.ParkBrakeSts = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_ParkBrakeSts, &CanRxSignals.ParkBrakeSts);
    }

    aux_data8 = ( CanRxPrms.msgData[4] >> 7 ) & 0x01;
    if( CanRxSignals.LowFuelWarningSts != aux_data8 )
    {
        CanRxSignals.LowFuelWarningSts = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_LowFuelWarningSts, &CanRxSignals.LowFuelWarningSts);
    }

    aux_data8 = ( CanRxPrms.msgData[4] >> 3 ) & 0x01;
    if( CanRxSignals.RHatchSts != aux_data8 )
    {
        CanRxSignals.RHatchSts = aux_data8;


        Semaphore_pend(rvc_sem, BIOS_WAIT_FOREVER);
        if (0x01 == CanRxSignals.RHatchSts)
        {
            sar_ram_reg1 |= SAR_RAM_BIT_RHATCHSTS_ON;
            HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC, sar_ram_reg1);
        }
        else
        {
            sar_ram_reg1 &= SAR_RAM_BIT_RHATCHSTS_OFF;
            HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC, sar_ram_reg1);
        }
        Semaphore_post(rvc_sem);
    }

    LOG_PRINT(DEBUG_CAN, "STATUS_BH_BCM1_ID -> OperationalModeSts = %x  \n", CanRxSignals.OperationalModeSts);

    T_Msg_STATUS_BH_BCM1    = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_STATUS_BH_BCM2
 *
 * @brief      Process CAN message Msg_STATUS_BH_BCM2
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_STATUS_BH_BCM2(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;
    uint16_t    aux_data16;
    bool_t      flag_change_data;

    /* CmdIgn */
    flag_change_data = false;

    aux_data8 = ( CanRxPrms.msgData[0] >> 6 ) & 0x03;
    if( CanRxSignals.CmdIgn_FailSts != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.CmdIgn_FailSts = aux_data8;
    }

    aux_data8 = ( CanRxPrms.msgData[1] >> 5 ) & 0x07;
    if( CanRxSignals.CmdIgnSts != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.CmdIgnSts = aux_data8;
    }

    if(flag_change_data)
    {
        aux_data16 = 0;
        aux_data16 = ( CanRxSignals.CmdIgnSts << 8 ) | CanRxSignals.CmdIgn_FailSts;

        Semaphore_pend(ignition_sem, BIOS_WAIT_FOREVER);
        Shadow_Server_Storage_Set(SHADOW_CmdIgn, (uint8_t *)&aux_data16);
        Semaphore_post(ignition_sem);
    }

    /* InternalLight */
    flag_change_data = false;

    aux_data8 = ( CanRxPrms.msgData[5] >> 1 ) & 0x01;
    if( CanRxSignals.InternalLightSts != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.InternalLightSts = aux_data8;
    }

    aux_data8 = ( CanRxPrms.msgData[5] >> 2 ) & 0x0F;
    if( CanRxSignals.InternalLightLevel != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.InternalLightLevel = aux_data8;
    }

    if(flag_change_data)
    {
        aux_data16 = 0;
        aux_data16 = ( CanRxSignals.InternalLightLevel << 8 ) | CanRxSignals.InternalLightSts;

        Shadow_Server_Storage_Set(SHADOW_InternalLight, (uint8_t *)&aux_data16);

        DIMMING_SetLevel_CAN( CanRxSignals.InternalLightLevel, CanRxSignals.InternalLightSts );
    }

    /* ExternalTemperatureC */
    aux_data16 = 0;
    aux_data16 = (((uint16_t)CanRxPrms.msgData[2] << 1) & 0x01FE) | (((uint16_t)CanRxPrms.msgData[3] >> 7) & 0x0001);
    if( CanRxSignals.ExternalTemperatureC != aux_data16 )
    {
        CanRxSignals.ExternalTemperatureC = aux_data16;
        Shadow_Server_Storage_Set(SHADOW_ExternalTemperatureC, (uint8_t*)&CanRxSignals.ExternalTemperatureC);
    }

    LOG_PRINT(DEBUG_CAN, "STATUS_BH_BCM2_ID -> CmdIgnSts      = %x  \n", CanRxSignals.CmdIgnSts);
    LOG_PRINT(DEBUG_CAN, "STATUS_BH_BCM2_ID -> CmdIgn_FailSts = %x  \n", CanRxSignals.CmdIgn_FailSts);

    T_Msg_STATUS_BH_BCM2    = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_STATUS_CCAN3
 *
 * @brief      Process CAN message STATUS_CCAN3
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_STATUS_CCAN3(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;
    uint16_t    aux_data16;
    float       VehicleSpeedVSOSig;

    aux_data16 = 0;
    aux_data16 = (((uint16_t)CanRxPrms.msgData[5] << 5) & 0x1FE0) | (((uint16_t)CanRxPrms.msgData[6] >> 3) & 0x001F);
    VehicleSpeedVSOSig = aux_data16*(VEHICLE_SPEED_RES);
    if( CanRxSignals.VehicleSpeedVSOSig != VehicleSpeedVSOSig )
    {
        CanRxSignals.VehicleSpeedVSOSig = VehicleSpeedVSOSig;
        Shadow_Server_Storage_Set(SHADOW_VehicleSpeedVSOSig, (uint8_t*)&CanRxSignals.VehicleSpeedVSOSig);
    }

    aux_data8 = CanRxPrms.msgData[6] & 0x03;
    if( CanRxSignals.EngineSts != aux_data8 )
    {
        CanRxSignals.EngineSts = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_EngineSts, &CanRxSignals.EngineSts);
    }

    aux_data8 = ( CanRxPrms.msgData[7] >> 3 ) & 0x01;
    if( CanRxSignals.ShiftModeSts != aux_data8 )
    {
        CanRxSignals.ShiftModeSts = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_ShiftModeSts, &CanRxSignals.ShiftModeSts);
    }


    LOG_PRINT(DEBUG_CAN, "STATUS_CCAN3_ID -> VehicleSpeedVSOSig = %x  \n", CanRxSignals.VehicleSpeedVSOSig);
    LOG_PRINT(DEBUG_CAN, "STATUS_CCAN3_ID -> EngineSts          = %x  \n", CanRxSignals.EngineSts);

    T_Msg_STATUS_CCAN3      = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_STATUS_CCAN4
 *
 * @brief      Process CAN message STATUS_CCAN4
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_STATUS_CCAN4(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;

    aux_data8 = ( CanRxPrms.msgData[7] >> 5 ) & 0x03;
    if( CanRxSignals.ReverseGearSts != aux_data8 )
    {
        CanRxSignals.ReverseGearSts = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_ReverseGearSts, &CanRxSignals.ReverseGearSts);


        Semaphore_pend(rvc_sem, BIOS_WAIT_FOREVER);
        if (0x01 == CanRxSignals.ReverseGearSts)
        {
            DIMMING_SetChannelOn(DIM_USER_B, DIM_DISP);

            sar_ram_reg1 |= SAR_RAM_BIT_REVERSEGEAR_ON;
			HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC, sar_ram_reg1);
        }
        else
        {
            DIMMING_SetChannelOff(DIM_USER_B, DIM_DISP);
            sar_ram_reg1 &= SAR_RAM_BIT_REVERSEGEAR_OFF;
			HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC, sar_ram_reg1);
        }
        Semaphore_post(rvc_sem);
    }

    LOG_PRINT(DEBUG_CAN, "STATUS_CCAN4_ID > ReverseGearSts = %d  \n", CanRxSignals.ReverseGearSts);

    T_Msg_STATUS_CCAN4      = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_SWS_IGWLIN
 *
 * @brief      Process CAN message SWS_IGWLIN
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_SWS_IGWLIN(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;
    uint16_t    aux_data16;
    bool_t      flag_change_data;

    uint8_t currentCanStatus = CanAppl_Mopar_GetOperationalMode_Status();
    if ( (IGN_ON == currentCanStatus) || (IGN_PRESTART == currentCanStatus) ||
         (IGN_START == currentCanStatus) || (IGN_CRANKING == currentCanStatus) ||
         (IGN_ON_ENGINE_ON == currentCanStatus) )
    { /* Analyze the SWC CAN message only if the Ign=ON */

        flag_change_data = false;

        aux_data8 = (CanRxPrms.msgData[3] ) & 0x03;
        if( CanRxSignals.Command_01Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_01Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[3] >> 2) & 0x03;
        if( CanRxSignals.Command_02Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_02Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[3] >> 4) & 0x03;
        if( CanRxSignals.Command_03Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_03Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[3] >> 6) & 0x03;
        if( CanRxSignals.Command_04Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_04Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[2] ) & 0x03;
        if( CanRxSignals.Command_05Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_05Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[2] >> 2) & 0x03;
        if( CanRxSignals.Command_06Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_06Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[2] >> 4) & 0x03;
        if( CanRxSignals.Command_07Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_07Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[2] >> 6) & 0x03;
        if( CanRxSignals.Command_08Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_08Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[1] ) & 0x03;
        if( CanRxSignals.Command_09Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_09Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[1] >> 2 ) & 0x03;
        if( CanRxSignals.Command_10Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_10Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[1] >> 4 ) & 0x03;
        if( CanRxSignals.Command_11Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_11Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[1] >> 6 ) & 0x03;
        if( CanRxSignals.Command_12Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_12Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[0] ) & 0x03;
        if( CanRxSignals.Command_13Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_13Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[0] >> 2 ) & 0x03;
        if( CanRxSignals.Command_14Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_14Sts = aux_data8;
        }

        aux_data8 = (CanRxPrms.msgData[0] >> 4 ) & 0x03;
        if( CanRxSignals.Command_15Sts != aux_data8 )
        {
            flag_change_data = true;
            CanRxSignals.Command_15Sts = aux_data8;
        }


        if(flag_change_data)
        {
            /* Bit 0 is reserved for no key */
            aux_data16 = 0;
            aux_data16 |= ((uint16_t)CanRxSignals.Command_01Sts << 1 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_02Sts << 2 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_03Sts << 3 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_04Sts << 4 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_05Sts << 5 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_06Sts << 6 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_07Sts << 7 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_08Sts << 8 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_09Sts << 9 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_10Sts << 10 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_11Sts << 11 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_12Sts << 12 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_13Sts << 13 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_14Sts << 14 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_15Sts << 15 );

            Shadow_Server_Storage_Set(SHADOW_SWCSts, (uint8_t *)&aux_data16);
        }

        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID \n");
        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID -> Command_01Sts = %x  \n", CanRxSignals.Command_01Sts);
        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID -> Command_02Sts = %x  \n", CanRxSignals.Command_02Sts);
        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID -> Command_03Sts = %x  \n", CanRxSignals.Command_03Sts);
        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID -> Command_04Sts = %x  \n", CanRxSignals.Command_04Sts);
        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID -> Command_05Sts = %x  \n", CanRxSignals.Command_05Sts);
        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID -> Command_06Sts = %x  \n", CanRxSignals.Command_06Sts);
        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID -> Command_07Sts = %x  \n", CanRxSignals.Command_07Sts);
        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID -> Command_08Sts = %x  \n", CanRxSignals.Command_08Sts);
        LOG_PRINT(DEBUG_CAN,  "SWS_IGWLIN_ID -> Command_09Sts = %x  \n", CanRxSignals.Command_09Sts);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_TIME_DATE
 *
 * @brief      Process CAN message TIME_DATE
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_TIME_DATE(dcanRxParams_t CanRxPrms)
{
   uint8_t aux_data8;
   bool_t flag_change_data = false;

   aux_data8 = (CanRxPrms.msgData[0] ) & 0x0F;
   if( CanRxSignals.Hour2 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Hour2 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[0] >> 4) & 0x0F;
   if( CanRxSignals.Hour1 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Hour1 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[1] ) & 0x0F;
   if( CanRxSignals.Minute2 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Minute2 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[1] >> 4) & 0x0F;
   if( CanRxSignals.Minute1 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Minute1 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[2] ) & 0x0F;
   if( CanRxSignals.Day2 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Day2 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[2] >> 4) & 0x0F;
   if( CanRxSignals.Day1 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Day1 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[3] ) & 0x0F;
   if( CanRxSignals.Month2 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Month2 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[3] >> 4) & 0x0F;
   if( CanRxSignals.Month1 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Month1 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[4] ) & 0x0F;
   if( CanRxSignals.Year2 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Year2 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[4] >> 4) & 0x0F;
   if( CanRxSignals.Year1 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Year1 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[5] ) & 0x0F;
   if( CanRxSignals.Year4 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Year4 = aux_data8;
   }

   aux_data8 = (CanRxPrms.msgData[5] >> 4) & 0x0F;
   if( CanRxSignals.Year3 != aux_data8 ){
      flag_change_data = true;
      CanRxSignals.Year3 = aux_data8;
   }

   if(true == flag_change_data){
      CanAppl_SetTimeDate();
   }

   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID \n");
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Hour1   = %x  \n", CanRxSignals.Hour1);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Hour2   = %x  \n", CanRxSignals.Hour2);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Minute1 = %x  \n", CanRxSignals.Minute1);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Minute2 = %x  \n", CanRxSignals.Minute2);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Day1    = %x  \n", CanRxSignals.Day1);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Day2    = %x  \n", CanRxSignals.Day2);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Month1  = %x  \n", CanRxSignals.Month1);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Month2  = %x  \n", CanRxSignals.Month2);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Year1   = %x  \n", CanRxSignals.Year1);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Year2   = %x  \n", CanRxSignals.Year2);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Year3   = %x  \n", CanRxSignals.Year3);
   LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Year4   = %x  \n", CanRxSignals.Year4);

   T_Msg_TIME_DATE         = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_IPC_VEHICLE_SETUP
 *
 * @brief      Process CAN message IPC_VEHICLE_SETUP
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_IPC_VEHICLE_SETUP(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;

    aux_data8 = (CanRxPrms.msgData[2] >> 7) & 0x01;
    if( CanRxSignals.hr_mode != aux_data8 )
    {
        CanRxSignals.hr_mode = aux_data8;

        CanAppl_SetTimeDate();
    }

    aux_data8 = CanRxPrms.msgData[0];

    switch(CanRxPrms.msgData[0])
    {
        case IPC_VEHICLE_SETUP_NO_LANGUAGE:
            LOG_PRINT(DEBUG_CAN, "mGateway_3 > No language  \n");
            aux_data8 = CanRxSignals.LanguageSelection;
        break;

        case IPC_VEHICLE_SETUP_SPANISH: // Spanish
        case IPC_VEHICLE_SETUP_US_SPANISH:
            LOG_PRINT(DEBUG_CAN, "mGateway_3 > Spanish  \n");
            aux_data8 = HU_SPANISH;
        break;

        case IPC_VEHICLE_SETUP_PORTUGUES: // Portugues
        case IPC_VEHICLE_SETUP_BR_PORTUGUES:
            LOG_PRINT(DEBUG_CAN, "mGateway_3 > Portugues  \n");
            aux_data8 = HU_PORTUGUES;
        break;

        default: // English
            LOG_PRINT(DEBUG_CAN, "mGateway_3 > English  \n");
            aux_data8 = HU_ENGLISH;
        break;
    }

    if( CanRxSignals.LanguageSelection != aux_data8 )
    {
        CanRxSignals.LanguageSelection = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_LanguageSelection, &CanRxSignals.LanguageSelection);

    }


    LOG_PRINT(DEBUG_CAN, "IPC_VEHICLE_SETUP > hr_mode = %d  \n", CanRxSignals.hr_mode);
    LOG_PRINT(DEBUG_CAN, "IPC_VEHICLE_SETUP > LanguageSelection = %d  \n", CanRxSignals.LanguageSelection);

    T_Msg_IPC_VEHICLE_SETUP      = ClockUtils_Get_Time();

}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_STATUS_CCAN5
 *
 * @brief      Process CAN message STATUS_CCAN5
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_STATUS_CCAN5(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;

    aux_data8 = ( CanRxPrms.msgData[0] >> 4 ) & 0x0F;
    if( CanRxSignals.ShiftLeverPosition != aux_data8 )
    {
        CanRxSignals.ShiftLeverPosition = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_ShiftLeverPosition, &CanRxSignals.ShiftLeverPosition);
    }

    LOG_PRINT(DEBUG_CAN, "STATUS_CCAN5_ID > ShiftLeverPosition = %d  \n", CanRxSignals.ShiftLeverPosition);

    T_Msg_STATUS_CCAN5      = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_TRIP_A_B
 *
 * @brief      Process CAN message TRIP_A_B
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_TRIP_A_B(dcanRxParams_t CanRxPrms)
{
    uint16_t    aux_data16;

    aux_data16 = 0;
    aux_data16 = (((uint16_t)CanRxPrms.msgData[4] << 3) & 0x07F8) | (((uint16_t)CanRxPrms.msgData[5] >> 5) & 0x0007);
    if( CanRxSignals.AutonomyDistance != aux_data16 )
    {
        CanRxSignals.AutonomyDistance = aux_data16;
        Shadow_Server_Storage_Set(SHADOW_AutonomyDistance, (uint8_t*)&CanRxSignals.AutonomyDistance);
    }


    LOG_PRINT(DEBUG_CAN, "TRIP_A_B > AutonomyDistance = %d  \n", CanRxSignals.AutonomyDistance);

    T_Msg_TRIP_A_B      = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_VIN
 *
 * @brief      Process CAN message VIN
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_VIN(dcanRxParams_t CanRxPrms)
{
    uint8_t aux_data8;
    bool_t  flag_change_data;

    aux_data8 = (CanRxPrms.msgData[0] ) & 0x03;
    if( CanRxSignals.VIN_Msg != aux_data8 )
    {
        CanRxSignals.VIN_Msg = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_VIN_Msg, &CanRxSignals.VIN_Msg);
    }

    flag_change_data = false;

    aux_data8 = CanRxPrms.msgData[1];
    if( CanRxSignals.VIN_Data[0] != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.VIN_Data[0] = aux_data8;
    }

    aux_data8 = CanRxPrms.msgData[2];
    if( CanRxSignals.VIN_Data[1] != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.VIN_Data[1] = aux_data8;
    }

    aux_data8 = CanRxPrms.msgData[3];
    if( CanRxSignals.VIN_Data[2] != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.VIN_Data[2] = aux_data8;
    }

    aux_data8 = CanRxPrms.msgData[4];
    if( CanRxSignals.VIN_Data[3] != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.VIN_Data[3] = aux_data8;
    }

    aux_data8 = CanRxPrms.msgData[5];
    if( CanRxSignals.VIN_Data[4] != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.VIN_Data[4] = aux_data8;
    }

    aux_data8 = CanRxPrms.msgData[6];
    if( CanRxSignals.VIN_Data[5] != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.VIN_Data[5] = aux_data8;
    }

    aux_data8 = CanRxPrms.msgData[7];
    if( CanRxSignals.VIN_Data[6] != aux_data8 )
    {
        flag_change_data = true;
        CanRxSignals.VIN_Data[6] = aux_data8;
    }

    if(flag_change_data)
    {
        Shadow_Server_Storage_Set(SHADOW_VIN_Data, &CanRxSignals.VIN_Data[0]);
    }

    T_Msg_VIN = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_STATUS_CCAN1
 *
 * @brief      Process CAN message STATUS_CCAN1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_STATUS_CCAN1(dcanRxParams_t CanRxPrms)
{
    uint16_t    aux_data16;

    aux_data16 = 0;
    aux_data16 = (((uint16_t)CanRxPrms.msgData[0] << 4) & 0x0FF0) | (((uint16_t)CanRxPrms.msgData[1] >> 4) & 0x000F);
    if( CanRxSignals.LongAcceleration_BSM != aux_data16 )
    {
        CanRxSignals.LongAcceleration_BSM = aux_data16;
        Shadow_Server_Storage_Set(SHADOW_LongAcceleration, (uint8_t*)&CanRxSignals.LongAcceleration_BSM);
    }

    aux_data16 = 0;
    aux_data16 = (((uint16_t)CanRxPrms.msgData[1] << 8) & 0x0F00) | (((uint16_t)CanRxPrms.msgData[2] ) & 0x00FF);
    if( CanRxSignals.LatAcceleration_BSM != aux_data16 )
    {
        CanRxSignals.LatAcceleration_BSM = aux_data16;
        Shadow_Server_Storage_Set(SHADOW_LatAcceleration, (uint8_t*)&CanRxSignals.LatAcceleration_BSM);
    }


    aux_data16 = 0;
    aux_data16 = (((uint16_t)CanRxPrms.msgData[3] << 4) & 0x0FF0) | (((uint16_t)CanRxPrms.msgData[4] >> 4) & 0x000F);
    if( CanRxSignals.YawRate_BSM != aux_data16 )
    {
        CanRxSignals.YawRate_BSM = aux_data16;
        Shadow_Server_Storage_Set(SHADOW_YawRate_BSM, (uint8_t*)&CanRxSignals.YawRate_BSM);
    }

    T_Msg_STATUS_CCAN1      = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Mopar_GetOperationalMode_Status
 *
 * @brief      Get signal OperationalMode_Status
 *
 * @param [in] void
 *
 * @return     uint8_t
 *
 ******************************************************************************/
uint8_t CanAppl_Mopar_GetOperationalMode_Status()
{
    uint8_t ignition_status;
    Semaphore_pend(ignition_sem, BIOS_WAIT_FOREVER);
    ignition_status = CanRxSignals.OperationalModeSts;
    Semaphore_post(ignition_sem);
    return ignition_status;
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Mopar_ReportCurrentRvcStatus
 *
 * @brief      Report to the shared memory the RVC+HATCH status
 *
 * @param [in]
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Mopar_ReportCurrentRvcStatus()
{
    Semaphore_pend(rvc_sem, BIOS_WAIT_FOREVER);
    HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC, sar_ram_reg1);
    Semaphore_post(rvc_sem);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Mopar_ReportRvcOff
 *
 * @brief      Report to the shared memory that the RVC+HATCH status are off
 *             this depends on the Ignition signals and the power state
 *             machine and is independent of the real state of this signals.
 *             We do not modify the internal signals of the class.
 *
 * @param [in]
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Mopar_ReportRvcOff()
{
    uint32_t aux_reg1;
    Semaphore_pend(rvc_sem, BIOS_WAIT_FOREVER);
    /* do not change the global variable */
    aux_reg1 = sar_ram_reg1 & SAR_RAM_BIT_REVERSEGEAR_OFF & SAR_RAM_BIT_RHATCHSTS_OFF;
    HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC, aux_reg1);
    Semaphore_post(rvc_sem);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_SetTimeDate
 *
 * @brief      Set Time Date with values received via CAN.
 *
 * @param [in] TD_TimeDate_T* timedate
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_SetTimeDate(void)
{
    /* Date update */
    timedate.rtc_year   = (CanRxSignals.Year1) * 1000;
    timedate.rtc_year   += (CanRxSignals.Year2) * 100;
    timedate.rtc_year   += (CanRxSignals.Year3) * 10;
    timedate.rtc_year   += (CanRxSignals.Year4);
    timedate.rtc_year   = (timedate.rtc_year - 2000);
    timedate.rtc_month  = (CanRxSignals.Month1) * 10;
    timedate.rtc_month  += (CanRxSignals.Month2);
    timedate.rtc_day    = (CanRxSignals.Day1) * 10;
    timedate.rtc_day    += (CanRxSignals.Day2);

    /* Time update */
    timedate.rtc_hour   = (CanRxSignals.Hour1) * 10;
    timedate.rtc_hour   += (CanRxSignals.Hour2);
    timedate.rtc_minute = (CanRxSignals.Minute1) * 10;
    timedate.rtc_minute += (CanRxSignals.Minute2);
    timedate.rtc_sec    = 0;

    if( CanRxSignals.hr_mode == IPC_VEHICLE_SETUP_HourMode_24h )
    {
        timedate.rtc_hr_mode =  hr_mode_24h;
    }
    else
    {
        // The time received via CAN is always in 24 hs mode but msp work in am/pm
        if(timedate.rtc_hour > 12)
        {
            timedate.rtc_hour = timedate.rtc_hour - 12;
            timedate.rtc_hr_mode =  hr_mode_pm;
        }
        else
        {
            timedate.rtc_hr_mode =  hr_mode_am;
        }
    }

    TD_SetTimeDatebyCAN( &timedate );

    LOG_PRINT(DEBUG_CAN,"%d/%d/%d %d:%d:%d   (%d) \n",  timedate.rtc_year,timedate.rtc_month,timedate.rtc_day,
                                                        timedate.rtc_hour,timedate.rtc_minute,timedate.rtc_sec,
                                                        timedate.rtc_hr_mode);

    // Shadow_Server_Storage_Set(SHADOW_Year3, &CanRxSignals.Year3);   Shadow is update in TD_Update()
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Mopar_Timeout_Init
 *
 * @brief      Initialization of variables for controller the timeout CAN msg.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Mopar_Timeout_Init(void)
{
    T_Msg_STATUS_BH_BCM1    = 1; // ClockUtils_Get_Time()
    T_Msg_STATUS_BH_BCM2    = 1; // ClockUtils_Get_Time()
    T_Msg_STATUS_CCAN3      = 1; // ClockUtils_Get_Time()
    T_Msg_STATUS_CCAN4      = 1; // ClockUtils_Get_Time()
    T_Msg_TIME_DATE         = 1; // ClockUtils_Get_Time()
    T_Msg_IPC_VEHICLE_SETUP = 1; // ClockUtils_Get_Time()
    T_Msg_STATUS_CCAN5      = 1; // ClockUtils_Get_Time()
    T_Msg_TRIP_A_B          = 1; // ClockUtils_Get_Time()
    T_Msg_VIN               = 1; // ClockUtils_Get_Time()
    T_Msg_STATUS_CCAN1      = 1; // ClockUtils_Get_Time()

    /*
     *  Note: the theoretical value should be ClockUtils_Get_Time() but use 1
     *  because at the beginning ClockUtils_Get_Time() = 0
     *  why??
     *  Clock_tickPeriod = 1000 = constant
     *  Clock_getTicks() < 1000
     *  Then Clock_getTicks()/Clock_tickPeriod = 0
     */
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Timeout
 *
 * @brief      Handler thats controls the timeouts of the periodic CAN messages.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Mopar_Timeout(void)
{
    if( (T_Msg_STATUS_BH_BCM1 != 0) && (ClockUtils_Elapsed_Time(T_Msg_STATUS_BH_BCM1) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_STATUS_BH_BCM1 = 0;
        CanAppl_TimeoutMsg_STATUS_BH_BCM1();
    }

    if( (T_Msg_STATUS_BH_BCM2 != 0) && (ClockUtils_Elapsed_Time(T_Msg_STATUS_BH_BCM2) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_STATUS_BH_BCM2 = 0;
        CanAppl_TimeoutMsg_STATUS_BH_BCM2();
    }

    if( (T_Msg_STATUS_CCAN3 != 0) && (ClockUtils_Elapsed_Time(T_Msg_STATUS_CCAN3) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_STATUS_CCAN3 = 0;
        CanAppl_TimeoutMsg_STATUS_CCAN3();
    }

    if( (T_Msg_STATUS_CCAN4 != 0) && (ClockUtils_Elapsed_Time(T_Msg_STATUS_CCAN4) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_STATUS_CCAN4 = 0;
        CanAppl_TimeoutMsg_STATUS_CCAN4();
    }

    if( (T_Msg_TIME_DATE != 0) && (ClockUtils_Elapsed_Time(T_Msg_TIME_DATE) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_TIME_DATE = 0;
        CanAppl_TimeoutMsg_TIME_DATE();
    }

    if( (T_Msg_IPC_VEHICLE_SETUP != 0) && (ClockUtils_Elapsed_Time(T_Msg_IPC_VEHICLE_SETUP) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_TIME_DATE = 0;
        CanAppl_TimeoutMsg_IPC_VEHICLE_SETUP();
    }

    if( (T_Msg_STATUS_CCAN5 != 0) && (ClockUtils_Elapsed_Time(T_Msg_STATUS_CCAN5) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_STATUS_CCAN5 = 0;
        CanAppl_TimeoutMsg_STATUS_CCAN5();
    }

    if( (T_Msg_TRIP_A_B != 0) && (ClockUtils_Elapsed_Time(T_Msg_TRIP_A_B) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_TRIP_A_B = 0;
        CanAppl_TimeoutMsg_TRIP_A_B();
    }

    if( (T_Msg_VIN != 0) && (ClockUtils_Elapsed_Time(T_Msg_VIN) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_VIN = 0;
        CanAppl_TimeoutMsg_VIN();
    }

    if( (T_Msg_STATUS_CCAN1 != 0) && (ClockUtils_Elapsed_Time(T_Msg_STATUS_CCAN1) >= CAN_MESSAGE_TIMEOUT_MS) )
    {
        T_Msg_STATUS_CCAN1 = 0;
        CanAppl_TimeoutMsg_STATUS_CCAN1();
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_STATUS_BH_BCM1
 *
 * @brief      Handler thats controls the timeouts of the STATUS_BH_BCM1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_STATUS_BH_BCM1(void)
{
    CanRxSignals.OperationalModeSts = OperationalModeSts_SNA;
    Shadow_Server_Storage_Set(SHADOW_OperationalModeSts, &CanRxSignals.OperationalModeSts);

    /* ParkBrakeSts */
    /* Not change the ParkBrakeSts if STATUS_BH_BCM1 message is missing
     *
    CanRxSignals.ParkBrakeSts = 0;
    Shadow_Server_Storage_Set(SHADOW_ParkBrakeSts, &CanRxSignals.ParkBrakeSts);
    */
    Semaphore_pend(rvc_sem, BIOS_WAIT_FOREVER);
    sar_ram_reg1 &= SAR_RAM_BIT_RHATCHSTS_OFF;
    HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC, sar_ram_reg1);
    Semaphore_post(rvc_sem);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_STATUS_BH_BCM2
 *
 * @brief      Handler thats controls the timeouts of the STATUS_BH_BCM2
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_STATUS_BH_BCM2(void)
{
    uint16_t aux_data16;

    /* CmdIgn */
    CanRxSignals.CmdIgn_FailSts = CmdIgn_FailSts_SNA;
    CanRxSignals.CmdIgnSts      = CmdIgnSts_SNA;
    aux_data16 = 0;
    aux_data16 = ( CanRxSignals.CmdIgnSts << 8 ) | CanRxSignals.CmdIgn_FailSts;
    Shadow_Server_Storage_Set(SHADOW_CmdIgn, (uint8_t *)&aux_data16);

    /* InternalLight */
    /* Not change the internalLight if STATUS_BH_BCM2 message is missing
     *
    CanRxSignals.InternalLightSts   = 0;
    CanRxSignals.InternalLightLevel = 0;
    aux_data16 = 0;
    aux_data16 = ( CanRxSignals.InternalLightLevel << 8 ) | CanRxSignals.InternalLightSts;
    Shadow_Server_Storage_Set(SHADOW_InternalLight, (uint8_t *)&aux_data16);
    */

    /* ExternalTemperatureC */
    CanRxSignals.ExternalTemperatureC = ExternalTemperatureC_SNA;
    Shadow_Server_Storage_Set(SHADOW_ExternalTemperatureC, (uint8_t*)&CanRxSignals.ExternalTemperatureC);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_STATUS_CCAN3
 *
 * @brief      Handler thats controls the timeouts of the STATUS_CCAN3
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_STATUS_CCAN3(void)
{
    /* VehicleSpeedVSOSig */
    /* Not change the VehicleSpeedVSOSig if STATUS_CCAN3 message is missing
     *
    CanRxSignals.VehicleSpeedVSOSig = 0;
    Shadow_Server_Storage_Set(SHADOW_VehicleSpeedVSOSig, (uint8_t*)&CanRxSignals.VehicleSpeedVSOSig);
    */

    /* EngineSts */
    CanRxSignals.EngineSts = EngineSts_SNA;
    Shadow_Server_Storage_Set(SHADOW_EngineSts, &CanRxSignals.EngineSts);

    /* ShiftModeSts */
    CanRxSignals.ShiftModeSts = ShiftModeSts_SNA;
    Shadow_Server_Storage_Set(SHADOW_ShiftModeSts, &CanRxSignals.ShiftModeSts);
}

/***************************************************************************//**
 *
 * @fn         STATUS_CCAN4
 *
 * @brief      Handler thats controls the timeouts of the STATUS_CCAN4
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_STATUS_CCAN4(void)
{
    DIMMING_SetChannelOff(DIM_USER_B, DIM_DISP);

    Semaphore_pend(rvc_sem, BIOS_WAIT_FOREVER);
    sar_ram_reg1 &= SAR_RAM_BIT_REVERSEGEAR_OFF;
    HW_WR_REG32(0x20000000 + DRA7XX_SAR_RAM_BASE + SAR_RAM_OFFSET_RVC, sar_ram_reg1);
    Semaphore_post(rvc_sem);

    CanRxSignals.ReverseGearSts = ReverseGearSts_SNA;
    Shadow_Server_Storage_Set(SHADOW_ReverseGearSts, &CanRxSignals.ReverseGearSts);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_TIME_DATE
 *
 * @brief      Handler thats controls the timeouts of the TIME_DATE
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_TIME_DATE(void)
{
    /* Not change the signals of TIME_DATE if TIME_DATE message is missing */
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_IPC_VEHICLE_SETUP
 *
 * @brief      Handler thats controls the timeouts of the IPC_VEHICLE_SETUP
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_IPC_VEHICLE_SETUP(void)
{
    /* Not change the signals of IPC_VEHICLE_SETUP if IPC_VEHICLE_SETUP message is missing */
}

/***************************************************************************//**
 *
 * @fn         STATUS_CCAN5
 *
 * @brief      Handler thats controls the timeouts of the STATUS_CCAN5
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_STATUS_CCAN5(void)
{
    CanRxSignals.ShiftLeverPosition = ShiftLeverPosition_SNA;
    Shadow_Server_Storage_Set(SHADOW_ShiftLeverPosition, &CanRxSignals.ShiftLeverPosition);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_TRIP_A_B
 *
 * @brief      Handler thats controls the timeouts of the TRIP_A_B
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_TRIP_A_B(void)
{
    CanRxSignals.AutonomyDistance = AutonomyDistance_SNA;
    Shadow_Server_Storage_Set(SHADOW_AutonomyDistance, (uint8_t*)&CanRxSignals.AutonomyDistance);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_VIN
 *
 * @brief      Handler thats controls the timeouts of the VIN
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_VIN(void)
{
    CanRxSignals.VIN_Msg = VIN_Msg_SNA;
    Shadow_Server_Storage_Set(SHADOW_VIN_Msg, &CanRxSignals.VIN_Msg);

    /* Not change the signals of VIN_Data if VIN message is missing */
}

/***************************************************************************//**
 *
 * @fn         STATUS_CCAN1
 *
 * @brief      Handler thats controls the timeouts of the STATUS_CCAN1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_STATUS_CCAN1(void)
{
    CanRxSignals.LongAcceleration_BSM = LongAcceleration_BSM_SNA;
    Shadow_Server_Storage_Set(SHADOW_LongAcceleration, (uint8_t*)&CanRxSignals.LongAcceleration_BSM);

    CanRxSignals.LatAcceleration_BSM = LatAcceleration_BSM_SNA;
    Shadow_Server_Storage_Set(SHADOW_LatAcceleration, (uint8_t*)&CanRxSignals.LatAcceleration_BSM);

    CanRxSignals.YawRate_BSM = YawRate_BSM_SNA;
    Shadow_Server_Storage_Set(SHADOW_YawRate_BSM, (uint8_t*)&CanRxSignals.YawRate_BSM);
}
