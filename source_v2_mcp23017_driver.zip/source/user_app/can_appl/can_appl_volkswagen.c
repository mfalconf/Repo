
#include <standard.h>

#include <console.h>
#include <shadow_storage.h>
#include <common_definitions.h>
#include <timedate.h>
#include <can_appl.h>
#include <can_appl_volkswagen.h>
#include <can_tp.h>

#include <conversions.h>

#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/csl/src/ip/dcan/V0/dcan.h>
#include <ti/csl/hw_types.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <clock_utils.h>
#include <can.h>
#include <bap_canubs.h>
#include <math.h>

#include <hmi_manager.h>

#include <bap_appl.h>
#include <sar_ram.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

#define OperationalModeSts_SNA                  IGN_SNA /* WARNING: this value must match IGN_SNA in can_appl.h, we should have only one place with this definitions */
#define CmdIgn_FailSts_SNA                      0x3
#define CmdIgnSts_SNA                           0x7
#define EngineSts_SNA                           0x3
#define ReverseGearSts_SNA                      0x3
#define ShiftLeverPosition_SNA                  0xF
#define AutonomyDistance_SNA                    0x7FF
#define ExternalTemperatureC_SNA                0x1FF
#define VIN_Msg_SNA                             0x3
#define ShiftModeSts_SNA                        0
#define LongAcceleration_SNA                    0x3FF
#define LatAcceleration_SNA                     0xFF
#define YawRate_BSM_SNA                         0xFFF

#define IPC_VEHICLE_SETUP_HourMode_24h          0
#define IPC_VEHICLE_SETUP_HourMode_12h          1

/* mGateway_3 */

// GW3_Sprachevariante
#define GW3_NO_LANGUAGE     0x00
#define GW3_ENGLISH         0x02
#define GW3_SPANISH         0x05
#define GW3_PORTUGUES       0x06
#define GW3_US_ENGLISH      0x0A
#define GW3_US_SPANISH      0x13
#define GW3_BR_PORTUGUES    0x15

/* mGW_Bremse_Getriebe */

// GWB_FzgGeschw (Vehicle speed) 0.01 km/h per bit
#define GWB_MIN_SPEED       0x0000 // 0.00   km/h
#define GWB_MAX_SPEED       0x7F7F // 326.39 km/h
#define GWB_SPEED_RES       0.01   // 0.01   km/h per bit

/* mMFA_1 mMFA_2 mMFA_3 */
#define MAX_UINT8       0xFF
#define MAX_UINT16      0xFFFF
#define MAX_UINT32      0xFFFFFFFF
#define MAX_INT16       0x7FFF
//from VW PQ25 DBC
#define MAX_RANGE           16381
#define MAX_CONSUMPTION     4093
#define MAX_DISTANCE        16382
#define MAX_TIME            16382
#define MAX_SPEED           16381
#define MAX_KILOMETERSTAND  4194302
#define CONSUMPTION_SCALE   0.1

/* LW1_Lenkradwinkel */
#define WHEEL_ANGLE_SCALE 0.04375
#define MAX_WHEEL_ANGLE    1434

/* GWM_Motordrehzahl */
#define RPM_SCALE   0.25
#define MAX_RPM     16256

/* MO7_Oeltemperatur */
#define OIL_TEMP_OFFSET 60
#define MAX_OIL_TEMP    194   //°C
#define MIN_OIL_TEMP    -58   //°C

/* GWB_Info_Waehlhebel */
static const char GWB_Info_Waehlhebel[16][5] =
{
    "-",
    "1",
    "2",
    "3",
    "4",
    "D",
    "N",
    "R",
    "P",
    "RSP",
    "Z1",
    "Z2",
    "S",
    "L",
    "TGas",
    "-"
};

#define GWB_Info_Waehlhebel_ManualSelespeed 0x0E

/* GE2_Variante */
#define MAX_GE2_VARIANTE 7
static const char GE2_Variante[MAX_GE2_VARIANTE][2] =
{
    "N",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6"
};

#define GE2_Variante_Sollgang 0x0A

/* GE2_Sollgang */
#define MAX_GE2_SOLLGANG 11
static const char GE2_Sollgang[MAX_GE2_SOLLGANG][2] =
{
    "-",
    "-",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
};

/* BR2_Querbeschl */
#define LAT_ACC_SCALE   0.01    // unit: force of g
#define LAT_ACC_OFFSET  1.27
#define STD_VALUE_OF_g  9.80665 // unit: m/s2

/* BR8_Laengsbeschl */
#define LONG_ACC_SCALE  0.03125 //unit: m/s2
#define LONG_ACC_OFFSET 16

/* CAN Interface channel*/
#define BAP_CAN_INTERFACE_CHANNEL   1   

/* NWM_RNS */

#define NWM_RNS_CMD_RING_BYTE       1
#define NWM_RNS_CMD_RING_OFFSET     0

#define NWM_RNS_SLEEP_IND_BYTE      1  
#define NWM_RNS_SLEEP_IND_OFFSET    4

#define NWM_RNS_SLEEP_ACK_BYTE      1
#define NWM_RNS_SLEEP_ACK_OFFSET    5   

#define NWM_RNS_KLEMME_15_BYTE      3
#define NWM_RNS_KLEMME_15_OFFSET    0

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
//typedef bool bool_t;

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef struct Can_Rx_Signals_Tag
{
    uint8_t     NetworkActive;
    uint8_t     NWM_BCM1_CmdAlive;
    uint8_t     NWM_BCM1_SleepInd;
    uint8_t     OperationalModeSts;
    uint8_t     CmdIgnSts;
    uint8_t     CmdIgn_FailSts;
    float       VehicleSpeedVSOSig;
    uint8_t     EngineSts;
    uint8_t     Command_01Sts;
    uint8_t     Command_02Sts;
    uint8_t     Command_03Sts;
    uint8_t     Command_04Sts;
    uint8_t     Command_05Sts;
    uint8_t     Command_06Sts;
    uint8_t     Command_07Sts;
    uint8_t     Command_08Sts;
    uint8_t     Command_09Sts;
    uint8_t     Command_10Sts;
    uint8_t     Command_11Sts;
    uint8_t     Command_12Sts;
    uint8_t     Command_13Sts;
    uint8_t     Command_14Sts;
    uint8_t     Command_15Sts;
    uint8_t     Day1;
    uint8_t     Day2;
    uint8_t     Hour1;
    uint8_t     Hour2;
    uint8_t     Minute1;
    uint8_t     Minute2;
    uint8_t     Second1;
    uint8_t     Second2;
    uint8_t     Month1;
    uint8_t     Month2;
    uint8_t     Year1;
    uint8_t     Year2;
    uint8_t     Year3;
    uint8_t     hr_mode;
    uint8_t     ReverseGearSts;
    uint8_t     ParkBrakeSts;
    uint8_t     InternalLightSts;
    uint8_t     InternalLightLevel;
    uint8_t     LowFuelWarningSts;
    uint8_t     TankContents;
    uint8_t     ShiftLeverPosition;
    uint16_t    AutonomyDistance;
    uint16_t    ExternalTemperatureC;
    uint8_t     VIN_Msg;
    uint8_t     VIN_Data[7];
    uint8_t     RHatchSts;
    uint8_t     ShiftModeSts;
    float_t     LongAcceleration;
    float_t     LatAcceleration;
    uint16_t    YawRate_BSM;
    uint8_t     LanguageSelection;
    uint8_t     ParkingActive;
    uint8_t     ParkingAssistButton;
    uint8_t     ParkingFrontSensors[4];
    uint8_t     ParkingRearSensors[4];
    uint8_t     TransportModeStatus_CAN;
    float_t     InstConsumption;
    char        InstConsumptionUnit[8];
    uint16_t    Range;
    char        RangeUnit[8];
    uint32_t    Kilometerstand;
    char        KilometerstandUnit[8];
    uint8_t     ReserveRange;
    float_t     ShortTermConsumption;
    char        ShortTermConsumptionUnit[8];
    uint16_t    ShortTermDistance;
    char        ShortTermDistanceUnit[8];
    uint16_t    ShortTermTime;
    uint16_t    ShortTermAvSpeed;
    char        ShortTermAvSpeedUnit[8];
    float_t     LongTermConsumption;
    char        LongTermConsumptionUnit[8];
    uint16_t    LongTermDistance;
    char        LongTermDistanceUnit[8];
    uint16_t    LongTermTime;
    uint16_t    LongTermAvSpeed;
    char        LongTermAvSpeedUnit[8];
    char        ChassisNumber[18];
    float_t     SteeringWheelAngle;
    float_t     SteeringWheelAngleChangeRate;
    uint8_t     SteeringWheelAngleCalibration;
    uint16_t    RPM;
    float_t     OilTemperature;
    char        Gear[8];
    bool        ManualGearbox;
    bool        ManualSelespeed;
    uint8_t     PdcButton;
    bool_t      DirectionWheelFL;
    bool_t      DirectionWheelFR;
    bool_t      DirectionWheelRL;
    bool_t      DirectionWheelRR;
    uint16_t    CounterWheelFL;
    uint16_t    CounterWheelFR;
    uint16_t    CounterWheelRL;
    uint16_t    CounterWheelRR;
    uint16_t    WheelCircumference;
    uint8_t     KeyStatus;
    uint8_t     CarModel;
    uint8_t     OffroadEnable;
}Can_Rx_Signals_T;

typedef struct Can_Tx_Signals_Tag
{
    uint8_t NWM_RNS_CmdRing;
    uint8_t NWM_RNS_SleepInd;
    uint8_t NWM_RNS_SleepAck;
    uint8_t NWM_RNS_Klemme_15;
}Can_Tx_Signals_T;


typedef struct Can_Rx_Msg_Timeout_tag
{
    uint32_t cnt;
    uint32_t timeout;
}Can_Rx_Msg_Timeout_T;

#undef X
#define X(a,b,c,d,e)    a,
typedef enum Can_Rx_Msg_tag
{
    CAN_RX_MESSAGE_TABLE
    NUM_CAN_RX_MESSAGES
}Can_Rx_Msg_T;


typedef enum Consumption_unit
{
    Consumption_in_l_100km = 1,
    Consumption_in_km_l = 2,
    Consumption_in_mpg = 4,
    Consumption_in_kg_100km = 5,
    Consumption_in_kg_h = 6,
    Consumption_in_mpkg = 7,
    Consumption_in_lph = 8,
}Consumption_unit_T;

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static Can_Rx_Signals_T CanRxSignals;
static Can_Tx_Signals_T CanTxSignals;

static Semaphore_Handle ignition_sem = NULL;
static Semaphore_Handle network_sem = NULL;
static Semaphore_Handle rvc_sem = NULL;

static TD_TimeDate_T timedate;

#undef X
#define X(a,b,c,d,e)     {0,e},
static Can_Rx_Msg_Timeout_T T_Can_Rx_Msg[NUM_CAN_RX_MESSAGES] = {CAN_RX_MESSAGE_TABLE};

static bool_t Disable_Appl_TX_Messages;
static bool_t Disable_BAP_TX_Messages;
static bool_t Disable_NM_TX_Messages;
static bool_t Disable_NWM_RNS_TX_Messages;

static bool_t __internal_rvc_state = false;
static bool_t __internal_pdc_key_state = false;
static Shadow_CarModel_T __internal_detected_car = CAR_MODEL_INVALID;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void CanAppl_ProcessMsg_mBSG3(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mSysteminfo_1(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mDimmung(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mRegen_Licht_Sensor(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mLicht_1_Alt(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mMFL_Tasten(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mKombi_1(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mKombi_K1(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mDiagnose_1(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mEinheten(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_NWM_BCM1(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mGW_Bremse_Getriebe(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_Parkhilfe_01(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_BAP_OPS(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_BAP_ASG_07(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mGateway_3(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_cSyncStatus_t(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_cValidationTone_t(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mMFA_1(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mMFA_2(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mMFA_3(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mFzg_Ident(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mLenkwinkel_1(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mGW_Motor(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mGW_ANT_2(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mGW_ANT_1(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mBremse_10(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mGW_Kombi(dcanRxParams_t CanRxPrms);
static void CanAppl_ProcessMsg_mMotor7(dcanRxParams_t CanRxPrms);

static void CanAppl_SetTimeDate(void);
void CANAppl_updateRVC (void);

void ConsumptionUnitToString(Consumption_unit_T unit, char *string);
void SetCanRxSignalGear(const char * s);

static Shadow_CarModel_T CanAppl_GetModelFromVinNumber(const char *chassis);
static void CanAppl_SetCarModel(Shadow_CarModel_T car_model);

/* Prototype CanAppl_TimeoutMsg_XXXX */
#undef X
#define X(a,b,c,d,e) static void CanAppl_TimeoutMsg_##a(void);
CAN_RX_MESSAGE_TABLE

/* Pointer to function CanAppl_TimeOut_XXXX */
#undef X
#define X(a,b,c,d,e)     &CanAppl_TimeoutMsg_##a,
static can_appl_timeout_msg_fptr CanAppl_TimeoutMsg_Callback[NUM_CAN_RX_MESSAGES] = {CAN_RX_MESSAGE_TABLE};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         CanAppl_Volkswagen_Init
 *
 * @brief      Initialization variables CAN
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Volkswagen_Init(void)
{
    Disable_Appl_TX_Messages = false;
    Disable_BAP_TX_Messages = false;
    Disable_NM_TX_Messages = false;

    /* Clear CanRxSignals structure */
    memset( &CanRxSignals, 0, sizeof(Can_Rx_Signals_T) );

    /* Set the front and rear parking sensors initial state to 0xFF (invalid state) */
    CanRxSignals.ParkingFrontSensors[0] = 0xFF;
    CanRxSignals.ParkingFrontSensors[1] = 0xFF;
    CanRxSignals.ParkingFrontSensors[2] = 0xFF;
    CanRxSignals.ParkingFrontSensors[3] = 0xFF;
    CanRxSignals.ParkingRearSensors[0] = 0xFF;
    CanRxSignals.ParkingRearSensors[1] = 0xFF;
    CanRxSignals.ParkingRearSensors[2] = 0xFF;
    CanRxSignals.ParkingRearSensors[3] = 0xFF;

    ignition_sem = Semaphore_create(1, NULL, NULL);
    network_sem = Semaphore_create(1, NULL, NULL);
    rvc_sem = Semaphore_create(1, NULL, NULL);

    CanAppl_SetCarModel(CAR_MODEL_INVALID);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Volkswagen_ProcessMsg
 *
 * @brief      Handler thats controls the CAN messages.
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Volkswagen_ProcessMsg(dcanRxParams_t CanRxPrms)
{
    uint32_t id;

    if( CanRxPrms.rxIdType == DCAN_XID_29_BIT )
    {
        id = CanRxPrms.rxMsgIdentifier;
    }
    else
    {
        id = ( CanRxPrms.rxMsgIdentifier >> 18 ) & 0x00001FFF;
    }

    LOG_PRINT(DEBUG_CAN, "CAN RX !!! \n");
    LOG_PRINT(DEBUG_CAN, "[%x] (%d) %x %x %x %x %x %x %x %x \n"    ,id,CanRxPrms.dataLength
                                                            ,CanRxPrms.msgData[0],CanRxPrms.msgData[1],CanRxPrms.msgData[2],CanRxPrms.msgData[3]
                                                            ,CanRxPrms.msgData[4],CanRxPrms.msgData[5],CanRxPrms.msgData[6],CanRxPrms.msgData[7]
                    );

    switch(id)
    {
        case mBSG_3_ID:
            CanAppl_ProcessMsg_mBSG3(CanRxPrms);
            break;
        case mDimmung_ID:
            CanAppl_ProcessMsg_mDimmung(CanRxPrms);
            break;
        case mRegen_Licht_Sensor_ID:
            CanAppl_ProcessMsg_mRegen_Licht_Sensor(CanRxPrms);
            break;
        case mLicht_1_alt_ID:
            CanAppl_ProcessMsg_mLicht_1_Alt(CanRxPrms);
            break;
        case mMFL_Tasten_ID:
            CanAppl_ProcessMsg_mMFL_Tasten(CanRxPrms);
            break;
        case mKombi_1_ID:
            CanAppl_ProcessMsg_mKombi_1(CanRxPrms);
            break;
        case mKombi_K1_ID:
            CanAppl_ProcessMsg_mKombi_K1(CanRxPrms);
            break;
        case mDiagnose_1_ID:
            CanAppl_ProcessMsg_mDiagnose_1(CanRxPrms);
            break;
        case mEinheiten_ID:
            CanAppl_ProcessMsg_mEinheten(CanRxPrms);
            break;
        case mGW_Bremse_Getriebe_ID:
            CanAppl_ProcessMsg_mGW_Bremse_Getriebe(CanRxPrms);
            break;
        case NWM_BCM1_ID:
            CanAppl_ProcessMsg_NWM_BCM1(CanRxPrms);
            break;
        case Parkhilfe_01_ID:
            CanAppl_ProcessMsg_Parkhilfe_01(CanRxPrms);
            break;
        case BAP_OPS_ID:
            CanAppl_ProcessMsg_BAP_OPS(CanRxPrms);
            break;
        case mGateway_3_ID:
            CanAppl_ProcessMsg_mGateway_3(CanRxPrms);
            break;
        case BAP_ASG_07_ID:
            CanAppl_ProcessMsg_BAP_ASG_07(CanRxPrms);
            break;
        case DiagPhysicalReq_ID:
            TP_D_UUData_Indication_Physical(CanRxPrms.dataLength, CanRxPrms.msgData);
            break;
        case DiagFunctionalReq_ID:
            TP_D_UUData_Indication_Functional(CanRxPrms.dataLength, CanRxPrms.msgData);
            break;
        case mSysteminfo_1_ID:
            CanAppl_ProcessMsg_mSysteminfo_1(CanRxPrms);
            break;
        case cSyncStatus_t_ID:
            CanAppl_ProcessMsg_cSyncStatus_t(CanRxPrms);
            break;
        case cValidationTone_t_ID:
            CanAppl_ProcessMsg_cValidationTone_t(CanRxPrms);
            break;
        case mMFA_1_ID:
            CanAppl_ProcessMsg_mMFA_1(CanRxPrms);
            break;
        case mMFA_2_ID:
            CanAppl_ProcessMsg_mMFA_2(CanRxPrms);
            break;
        case mMFA_3_ID:
            CanAppl_ProcessMsg_mMFA_3(CanRxPrms);
            break;
        case mFzg_Ident_ID:
            CanAppl_ProcessMsg_mFzg_Ident(CanRxPrms);
            break;
        case mLenkwinkel_1_ID:
            CanAppl_ProcessMsg_mLenkwinkel_1(CanRxPrms);
            break;
        case mGW_Motor_ID:
            CanAppl_ProcessMsg_mGW_Motor(CanRxPrms);
            break;
        case mGW_ANT_2_ID:
            CanAppl_ProcessMsg_mGW_ANT_2(CanRxPrms);
            break;
        case mGW_ANT_1_ID:
            CanAppl_ProcessMsg_mGW_ANT_1(CanRxPrms);
            break;
        case mBremse_10_ID:
            CanAppl_ProcessMsg_mBremse_10(CanRxPrms);
            break;
        case mGW_Kombi_ID:
            CanAppl_ProcessMsg_mGW_Kombi(CanRxPrms);
            break;
        case mMotor7_ID:
            CanAppl_ProcessMsg_mMotor7(CanRxPrms);
            break;
        default:
            break;
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Volkswagen_PrepareMsgToSend
 *
 * @brief      Prepare the message data before sending
 *
 * @param [in] id
 * @param [in] data
 *
 * @return     true - If the message sending should go on. False if not.
 *
 ******************************************************************************/
bool_t CanAppl_Volkswagen_PrepareMsgToSend (uint32_t id, uint8_t *data)
{
    bool_t ret = true;
    uint8_t tempRobertitoStatus;

    uint8_t currentCanStatus = CanAppl_Volkswagen_GetOperationalMode_Status();

    static uint8_t numSegmented = 0;

    /* Prepare message data only if the Ign=ON */
    switch(id)
    {
        case TestMsgPeriodicApp_ID:
            if((Disable_Appl_TX_Messages == false) && (currentCanStatus == IGN_ON))
            {
                data[0] = 0x11;
                data[1] = 0x22;
                data[2] = 0x33;
                data[3] = 0x44;
                data[4] = 0x55;
                data[5] = 0x66;
                data[6] = 0x77;
                data[7] = 0x88;
            }
            else
            {
                ret = false;
            }
            break;

        case TestMsgPeriodicNm_ID:
            if((Disable_NM_TX_Messages == false) && (currentCanStatus == IGN_ON))
            {
                data[0] = 0x99;
                data[1] = 0xAA;
                data[2] = 0xBB;
                data[3] = 0xCC;
                data[4] = 0xDD;
                data[5] = 0xEE;
                data[6] = 0xFF;
                data[7] = 0x00;
            }
            else
            {
                ret = false;
            }
            break;

        case TestMsgOnEvent_ID:
            break;

        case MainUnit_01_ID:
                data[0] = 0x01;
                data[1] = 0x00;
            break;

        case mNAV_1_ID:
                data[0] = 0x01;
                data[1] = 0x00;
                data[2] = 0x00;
                data[3] = 0x00;
                data[4] = 0x00;
                data[5] = 0x00;
                data[6] = 0x00;
                data[7] = 0x00;
            break;

        case mRadio_4_ID:
                data[0] = 0x03;
                data[1] = 0x00;
                data[2] = 0x00;
                data[3] = 0x00;
                data[4] = 0x00;
                data[5] = 0x00;
                data[6] = 0x00;
                data[7] = 0x00;
            break;

        case mTelefon_3_ID:
                data[0] = 0x01;
                data[1] = 0x00;
                data[2] = 0x00;
                data[3] = 0x00;
                data[4] = 0x00;
                data[5] = 0x00;
                data[6] = 0x00;
            break;

        case BAP_Telefon_04_ID:
            if((Disable_BAP_TX_Messages == false) && (currentCanStatus == IGN_ON))
            {
                /* The message is dispatched by the BAP Stack with
                 * the TELEPHONY data already prepared. Print the data
                 * only for debug purposes
                 */
                LOG_PRINT(DEBUG_BAP, "BAP_Telefon_04_ID -> data[0] = %x  \n", data[0]);
                LOG_PRINT(DEBUG_BAP, "BAP_Telefon_04_ID -> data[1] = %x  \n", data[1]);
                LOG_PRINT(DEBUG_BAP, "BAP_Telefon_04_ID -> data[2] = %x  \n", data[2]);
                LOG_PRINT(DEBUG_BAP, "BAP_Telefon_04_ID -> data[3] = %x  \n", data[3]);
                LOG_PRINT(DEBUG_BAP, "BAP_Telefon_04_ID -> data[4] = %x  \n", data[4]);
                LOG_PRINT(DEBUG_BAP, "BAP_Telefon_04_ID -> data[5] = %x  \n", data[5]);
                LOG_PRINT(DEBUG_BAP, "BAP_Telefon_04_ID -> data[6] = %x  \n", data[6]);
                LOG_PRINT(DEBUG_BAP, "BAP_Telefon_04_ID -> data[7] = %x  \n", data[7]);
            }
            else
            {
                ret = false;
            }
            break;

        case BAP_AUDIO_ID:
            if((Disable_BAP_TX_Messages == false) && (currentCanStatus == IGN_ON))
            {
                /* The message is dispatched by the BAP Stack with
                 * the AUDIO data already prepared. Print the data
                 * only for debug purposes
                 */
                LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_ID -> data[0] = %x  \n", data[0]);
                LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_ID -> data[1] = %x  \n", data[1]);
                LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_ID -> data[2] = %x  \n", data[2]);
                LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_ID -> data[3] = %x  \n", data[3]);
                LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_ID -> data[4] = %x  \n", data[4]);
                LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_ID -> data[5] = %x  \n", data[5]);
                LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_ID -> data[6] = %x  \n", data[6]);
                LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_ID -> data[7] = %x  \n", data[7]);
            }
            else
            {
                ret = false;
            }

            break;

        case NWM_RNS_ID:
            ret = true;
            break;

        case DiagPhysicalResp_ID:
            TP_D_UUData_Confirm();
            break;

        case cSyncStatusResponse_t_ID:
            data[0] = FAMP_PM_isSyncFinished();

            if (Shadow_Client_Storage_Get(SHADOW_RobertitoSyncStatus, &tempRobertitoStatus) ) {
                data[1] = tempRobertitoStatus;
            }
            else {
                data[1] = 0;
            }
            break;
            
        default:
            break;
    }

    return ret;
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mBSG3
 *
 * @brief      Process CAN message mBSG3
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mBSG3(dcanRxParams_t CanRxPrms)
{
    uint8_t     ign_status;
    uint8_t     key_status;
    uint8_t     OperationalModeSts = 0;
    uint8_t     KeyStatus = 0;
    uint8_t     pdc_button;

    ign_status = ((CanRxPrms.msgData[0] >> 1) & 0x01);
    key_status = (CanRxPrms.msgData[0] & 0x01);

    /*
                PREV        |  IGN  | KEY | NEW KEY VALUE   |  IGN VALUE
            KEY_REMOVED     |   0   |  0  |   KEY_REMOVED   |   IGN_OFF <- Here we leave timed
            KEY_REMOVED     |   0   |  1  |   KEY_INSERTED  |   IGN_OFF
            KEY_REMOVED     |   1   |  0  |   IMPOSSIBLE    |   xxxxxxx we default to IGN_ON
            KEY_REMOVED     |   1   |  1  |   KEY_INSERTED  |   IGN_ON
            KEY_INSERTED    |   0   |  0  |   KEY_REMOVED   |   IGN_OFF <- Here we leave timed
            KEY_INSERTED    |   0   |  1  |   KEY_INSERTED  |   IGN_OFF <- Here we go to timed
            KEY_INSERTED    |   1   |  0  |   IMPOSSIBLE    |   xxxxxxx we default to IGN_ON
            KEY_INSERTED    |   1   |  1  |   KEY_INSERTED  |   IGN_ON
            KEY_REMOVED     |  SNA  | SNA |   KEY_REMOVED   |   IGN_OFF
            KEY_INSERTED    |  SNA  | SNA |   KEY_INSERTED  |   IGN_OFF
    */

    if (ign_status) {
        OperationalModeSts = IGN_ON;
    } else {
        OperationalModeSts = IGN_OFF;
    }

    KeyStatus = CanRxSignals.KeyStatus;
    if (CAN_KEY_REMOVED == KeyStatus) {
        if (key_status) {
            KeyStatus = CAN_KEY_INSERTED;
            LOG_PRINT_VER(DEBUG_CAN, "KEY_INSERTED\r\n");
        }
    } else {
        if (!key_status) {
            KeyStatus = CAN_KEY_REMOVED;
            LOG_PRINT_VER(DEBUG_CAN, "KEY_REMOVED\r\n");
        }
    }

    if (CanRxSignals.OperationalModeSts != OperationalModeSts) {
        LOG_PRINT_VER(DEBUG_CAN, "ign_status %d, key_status %d, CanRxSignals.OperationalModeSts %d, OperationalModeSts %d\r\n", ign_status, key_status, CanRxSignals.OperationalModeSts, OperationalModeSts);
        CanRxSignals.OperationalModeSts = OperationalModeSts;
        Shadow_Server_Storage_Set(SHADOW_OperationalModeSts, &CanRxSignals.OperationalModeSts);

        CanTxSignals.NWM_RNS_Klemme_15 = ign_status;
    }

    if (CanRxSignals.KeyStatus != KeyStatus) {
        LOG_PRINT_VER(DEBUG_CAN, "ign_status %d, key_status %d, CanRxSignals.KeyStatus %d, KeyStatus %d\r\n", ign_status, key_status, CanRxSignals.KeyStatus, KeyStatus);
        CanRxSignals.KeyStatus = KeyStatus;
    }

    LOG_PRINT_SVER(DEBUG_CAN, "mBSG3 -> OperationalModeSts = %x  \n", CanRxSignals.OperationalModeSts);

    //BS3_PDC_Taster
    pdc_button = ((CanRxPrms.msgData[2] >> 6) & 0x01);
    if (CanRxSignals.PdcButton != pdc_button)
    {
        CanRxSignals.PdcButton = pdc_button;
        //signal not working in sample amarok CANAppl_updateRVC();
    }

    T_Can_Rx_Msg[mBSG_3].cnt    = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mSysteminfo_1
 *
 * @brief      Process CAN message mSysteminfo_1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mSysteminfo_1(dcanRxParams_t CanRxPrms)
{
    static uint8_t last_transport_mode_status;

    uint8_t transport_mode_status;

    transport_mode_status = ((CanRxPrms.msgData[SY1_TRANSPORT_MODE_START_BYTE_INDEX] >> SY1_TRANSPORT_MODE_START_BIT) & 0x01);

    if (!transport_mode_status) {
        CanRxSignals.TransportModeStatus_CAN = 1;   // Transport Mode OFF
    }
    else {
        CanRxSignals.TransportModeStatus_CAN = 2;   // Transport Mode ON
    }

    if (last_transport_mode_status != transport_mode_status) {
        
        if (!transport_mode_status) {
           LOG_PRINT(DEBUG_CAN, "mSysteminfo_1 -> TransportModeStatus_CAN = OFF\r\n");
        }
        else {
           LOG_PRINT(DEBUG_CAN, "mSysteminfo_1 -> TransportModeStatus_CAN = ON\r\n");
        }

        last_transport_mode_status = transport_mode_status;
    }

    T_Can_Rx_Msg[mSysteminfo_1].cnt    = ClockUtils_Get_Time();
}

static void CanAppl_ProcessMsg_cSyncStatus_t(dcanRxParams_t CanRxPrms) {

    T_Can_Rx_Msg[cSyncStatus_t].cnt = ClockUtils_Get_Time();
    CANAppl_SendSyncResponse();
}

static void CanAppl_ProcessMsg_cValidationTone_t(dcanRxParams_t CanRxPrms) {

    tone_generator_t aux;

    aux.playingStatus   = CanRxPrms.msgData[VT_PLAYING_STATUS];
    aux.volume          = CanRxPrms.msgData[VT_VOLUME];
    aux.frequency       = (uint16_t) ( CanRxPrms.msgData[VT_FREQUENCY_MSB] * 256 + CanRxPrms.msgData[VT_FREQUENCY_LSB]);
    aux.duration        = (uint32_t) ( (CanRxPrms.msgData[VT_TONE_DURATION_31_24] << 24 ) +
                                       (CanRxPrms.msgData[VT_TONE_DURATION_23_16] << 16 ) +
                                       (CanRxPrms.msgData[VT_TONE_DURATION_15_8]  <<  8 ) +
                                       (CanRxPrms.msgData[VT_TONE_DURATION_7_0]) );

    Shadow_Server_Storage_Set(SHADOW_ValidationTone, (uint8_t *) &aux);

    LOG_PRINT(DEBUG_VALIDATION_TONE, "New validation tone message received by CAN\r\n");
    LOG_PRINT(DEBUG_VALIDATION_TONE, "Playing:%d Volume:%d\r\n", aux.playingStatus, aux.volume);

    T_Can_Rx_Msg[cValidationTone_t].cnt    = ClockUtils_Get_Time();
}
/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mDimmung
 *
 * @brief      Process CAN message mDimmung
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mDimmung(dcanRxParams_t CanRxPrms)
{
    uint16_t    InternalLightLevel;
    uint16_t    aux_data16;


    //DI1_Sensor
    InternalLightLevel = CanRxPrms.msgData[2] & 0xFF;

    LOG_PRINT(DEBUG_CAN, "InternalLightLevel = %d  \n", InternalLightLevel);

    if(CanRxSignals.InternalLightLevel != InternalLightLevel)
    {
        CanRxSignals.InternalLightLevel = InternalLightLevel;
        aux_data16 = 0;
        aux_data16 = ( CanRxSignals.InternalLightLevel << 8 ) | CanRxSignals.InternalLightSts;

        Shadow_Server_Storage_Set(SHADOW_InternalLight, (uint8_t *)&aux_data16);

        DIMMING_SetLevel_CAN( CanRxSignals.InternalLightLevel, CanRxSignals.InternalLightSts );

        LOG_PRINT(DEBUG_CAN, "InternalLightLevel changed. InternalLightLevel = 0x%02x, InternalLightSts = 0x%02x  \n", CanRxSignals.InternalLightLevel, CanRxSignals.InternalLightSts);
    }

    T_Can_Rx_Msg[mDimmung].cnt  = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mRegen_Licht_Sensor
 *
 * @brief      Process CAN message mRegen_Licht_Sensor
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mRegen_Licht_Sensor(dcanRxParams_t CanRxPrms)
{
    T_Can_Rx_Msg[mRegen_Licht_Sensor].cnt    = ClockUtils_Get_Time();
}


/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mLicht_1_Alt
 *
 * @brief      Process CAN message mLicht_1_Alt
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mLicht_1_Alt(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;
    uint16_t    aux_data16;

    //LIA_Rueckfahrlicht
    aux_data8 = ( CanRxPrms.msgData[0] >> 5 ) & 0x01;
    if( CanRxSignals.ReverseGearSts != aux_data8 )
    {
        CanRxSignals.ReverseGearSts = aux_data8;
        CANAppl_updateRVC();
        Shadow_Server_Storage_Set(SHADOW_ReverseGearSts, &CanRxSignals.ReverseGearSts);
        //for manual gearbox set gear in "R" in GE2_Variante comes N,1,2,3,4,5,6 but no R
        if (CanRxSignals.ManualGearbox)
        {
            SetCanRxSignalGear("R");
        }
    }

    LOG_PRINT(DEBUG_CAN, "mLicht_1_Alt > ReverseGearSts = %d  \n", CanRxSignals.ReverseGearSts);

    //LIA_Standlicht
    aux_data8 = ( CanRxPrms.msgData[0] >> 0 ) & 0x01;
    if( CanRxSignals.InternalLightSts != aux_data8 )
    {
        CanRxSignals.InternalLightSts = aux_data8;
        aux_data16 = 0;
        aux_data16 = ( CanRxSignals.InternalLightLevel << 8 ) | CanRxSignals.InternalLightSts;
        Shadow_Server_Storage_Set(SHADOW_InternalLight, (uint8_t *)&aux_data16);
        DIMMING_SetLevel_CAN( CanRxSignals.InternalLightLevel, CanRxSignals.InternalLightSts );
        LOG_PRINT(DEBUG_CAN, "InternalLightLevel changed. InternalLightLevel = 0x%02x, InternalLightSts = 0x%02x  \n", CanRxSignals.InternalLightLevel, CanRxSignals.InternalLightSts);
    }

    T_Can_Rx_Msg[mLicht_1_alt].cnt    = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_BAP_ASG_07
 *
 * @brief      Process CAN message BAP_ASG_07
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_BAP_ASG_07(dcanRxParams_t CanRxPrms)
{
    LOG_PRINT(DEBUG_BAP, "BAP_ASG_07 > Id = %x  \n",( CanRxPrms.rxMsgIdentifier >> 18 ) & 0x00001FFF);
    LOG_PRINT(DEBUG_BAP, "BAP_ASG_07 > Data length = %d  \n", CanRxPrms.dataLength);

    BAP_CANUBS_RxData(BAP_CAN_INTERFACE_CHANNEL, BAP_ASG_07_ID, &(CanRxPrms.msgData[0]), CanRxPrms.dataLength);
}


/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mMFL_Tasten
 *
 * @brief      Process CAN message mMFL_Tasten
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mMFL_Tasten(dcanRxParams_t CanRxPrms)
{
    MFL_Tasten_Id_T     aux_data8;
    uint16_t            aux_data16;
    bool_t              flag_change_data;
    static bool_t       key_ok_pressed = false;
    static bool_t       key_up_pressed = false;
    static bool_t       key_down_pressed = false;

    uint8_t currentCanStatus = CanAppl_Volkswagen_GetOperationalMode_Status();
    if ( (IGN_ON == currentCanStatus) || (IGN_PRESTART == currentCanStatus) ||
         (IGN_START == currentCanStatus) || (IGN_CRANKING == currentCanStatus) ||
         (IGN_ON_ENGINE_ON == currentCanStatus) )
    { /* Analyze the SWC CAN message only if the Ign=ON */

        flag_change_data = false;

        aux_data8 = (CanRxPrms.msgData[0]);

        LOG_PRINT(DEBUG_CAN, "CanAppl_ProcessMsg_mMFL_Tasten, received = 0x%02x \n", aux_data8);

        switch(aux_data8)
        {
        case MFL_Tasten_Next_Id:     //Next
            if (CanRxSignals.Command_04Sts != 1)
            {
                flag_change_data = true;
                CanRxSignals.Command_04Sts = 1;
            }
            break;
        case MFL_Tasten_Prev_Id:     //Prev
            if (CanRxSignals.Command_05Sts != 1)
            {
                flag_change_data = true;
                CanRxSignals.Command_05Sts = 1;
            }
            break;
        case MFL_Tasten_VolUp_Id:     //VolUp
            if (CanRxSignals.Command_01Sts != 1)
            {
                flag_change_data = true;
                CanRxSignals.Command_01Sts = 1;
            }
            break;
        case MFL_Tasten_VolDown_Id:     //VolDown
            if (CanRxSignals.Command_02Sts != 1)
            {
                flag_change_data = true;
                CanRxSignals.Command_02Sts = 1;
            }
            break;
        case MFL_Tasten_Mute_Id:    //Mute
            if (CanRxSignals.Command_03Sts != 1)
            {
                flag_change_data = true;
                CanRxSignals.Command_03Sts = 1;
            }
            break;
        case MFL_Tasten_Flash_Id:    //Flash
            if (CanRxSignals.Command_10Sts != 1)
            {
                flag_change_data = true;
                CanRxSignals.Command_10Sts = 1;

                BAP_TELEPHONY_ProcessKeyEvent(aux_data8);
            }
            break;
        case MFL_Tasten_Voice_Id:    //Voice
            if (CanRxSignals.Command_09Sts != 1)
            {
                flag_change_data = true;
                CanRxSignals.Command_09Sts = 1;
            }
            break;
        case MFL_Tasten_FolderDown_Id:
            if (key_down_pressed == false)
            {
                key_down_pressed = true;
                BAP_TELEPHONY_ProcessKeyEvent(aux_data8);
            }
            break;            

        case MFL_Tasten_FolderUp_Id:
            if (key_up_pressed == false)
            {
                key_up_pressed = true;
                BAP_TELEPHONY_ProcessKeyEvent(aux_data8);
            }
            break;
        case MFL_Tasten_Ok_Id:
            if (key_ok_pressed == false)
            {
                key_ok_pressed = true;
                BAP_TELEPHONY_ProcessKeyEvent(aux_data8);
            }            
            break;
        default:
            if (CanRxSignals.Command_01Sts != 0)
            {
                flag_change_data = true;
                CanRxSignals.Command_01Sts = 0;
            }
            if (CanRxSignals.Command_02Sts != 0)
            {
                flag_change_data = true;
                CanRxSignals.Command_02Sts = 0;
            }
            if (CanRxSignals.Command_03Sts != 0)
            {
                flag_change_data = true;
                CanRxSignals.Command_03Sts = 0;
            }
            if (CanRxSignals.Command_04Sts != 0)
            {
                flag_change_data = true;
                CanRxSignals.Command_04Sts = 0;
            }
            if (CanRxSignals.Command_05Sts != 0)
            {
                flag_change_data = true;
                CanRxSignals.Command_05Sts = 0;
            }
            if (CanRxSignals.Command_07Sts != 0)
            {
                flag_change_data = true;
                CanRxSignals.Command_07Sts = 0;
            }
            if (CanRxSignals.Command_09Sts != 0)
            {
                flag_change_data = true;
                CanRxSignals.Command_09Sts = 0;
            }
            if (CanRxSignals.Command_10Sts != 0)
            {
                flag_change_data = true;
                CanRxSignals.Command_10Sts = 0;
            }

            if(key_up_pressed == true)
            {
                key_up_pressed = false;
            }
            if(key_down_pressed == true)
            {
                key_down_pressed = false;
            }
            if(key_ok_pressed == true)
            {
                key_ok_pressed = false;
            }

            break;
        }

        if(flag_change_data)
        {
            /* Bit 0 is reserved for no key */
            aux_data16 = 0;
            aux_data16 |= ((uint16_t)CanRxSignals.Command_01Sts << 1 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_02Sts << 2 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_03Sts << 3 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_04Sts << 4 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_05Sts << 5 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_06Sts << 6 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_07Sts << 7 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_08Sts << 8 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_09Sts << 9 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_10Sts << 10 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_11Sts << 11 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_12Sts << 12 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_13Sts << 13 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_14Sts << 14 );
            aux_data16 |= ((uint16_t)CanRxSignals.Command_15Sts << 15 );

            Shadow_Server_Storage_Set(SHADOW_SWCSts, (uint8_t *)&aux_data16);
            LOG_PRINT(DEBUG_CAN, "new swc key received = 0x%04x \n", aux_data16);
        }

        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten \n");
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_01Sts = %x  \n", CanRxSignals.Command_01Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_02Sts = %x  \n", CanRxSignals.Command_02Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_03Sts = %x  \n", CanRxSignals.Command_03Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_04Sts = %x  \n", CanRxSignals.Command_04Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_05Sts = %x  \n", CanRxSignals.Command_05Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_06Sts = %x  \n", CanRxSignals.Command_06Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_07Sts = %x  \n", CanRxSignals.Command_07Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_08Sts = %x  \n", CanRxSignals.Command_08Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_09Sts = %x  \n", CanRxSignals.Command_09Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_09Sts = %x  \n", CanRxSignals.Command_09Sts);
        LOG_PRINT(DEBUG_CAN,  "mMFL_Tasten -> Command_10Sts = %x  \n", CanRxSignals.Command_10Sts);
    }

    T_Can_Rx_Msg[mMFL_Tasten].cnt    = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mKombi_1
 *
 * @brief      Process CAN message mKombi_1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mKombi_1(dcanRxParams_t CanRxPrms)
{
    // signal KB1_Warn_Tank
    uint8_t aux = (CanRxPrms.msgData[0] >> 6) & 0x01;

    if (CanRxSignals.LowFuelWarningSts != aux)
    {
        CanRxSignals.LowFuelWarningSts = aux;
        Shadow_Server_Storage_Set(SHADOW_LowFuelWarningSts, &CanRxSignals.LowFuelWarningSts);
    }

    // signal KB1_Tankinhalt
    aux = (CanRxPrms.msgData[2] & 0x7F);

    if (CanRxSignals.TankContents != aux)
    {
        CanRxSignals.TankContents = aux;
        Shadow_Server_Storage_Set(SHADOW_TankContents, &CanRxSignals.TankContents);
    }

    LOG_PRINT(DEBUG_CAN, "mKombi_1 -> LowFuelWarningSts = %x  \n", CanRxSignals.LowFuelWarningSts);
    LOG_PRINT(DEBUG_CAN, "mKombi_1 -> TankContents = %x  \n", CanRxSignals.TankContents);

    T_Can_Rx_Msg[mKombi_1].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mKombi_K1
 *
 * @brief      Process CAN message mKombi_K1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mKombi_K1(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;

    aux_data8 = ((CanRxPrms.msgData[0] >> 5) & 0x01);

    if( CanRxSignals.ParkBrakeSts != aux_data8 )
    {
        CanRxSignals.ParkBrakeSts = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_ParkBrakeSts, &CanRxSignals.ParkBrakeSts);
    }

    LOG_PRINT(DEBUG_CAN, "mKOMBI_K1 -> ParkBrakeSts = %x  \n", CanRxSignals.ParkBrakeSts);

    T_Can_Rx_Msg[mKombi_K1].cnt    = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mKombi_1
 *
 * @brief      Process CAN message mDiagnose_1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mDiagnose_1(dcanRxParams_t CanRxPrms)
{
    uint8_t aux_data8;
    uint8_t yr_aux, mn_aux, dm_aux, hr_aux, mm_aux;
    bool_t flag_change_data = false;

    /* Year */

    aux_data8 = ((CanRxPrms.msgData[3] & 0xF0) >> 4) | ((CanRxPrms.msgData[4] & 0x07) << 4);

    yr_aux = aux_data8 / 100;
    if ( CanRxSignals.Year1 != yr_aux ){
        flag_change_data = true;
        CanRxSignals.Year1 = yr_aux;
    }

    yr_aux = (aux_data8 % 100) / 10;
    if ( CanRxSignals.Year2 != yr_aux ){
        flag_change_data = true;
        CanRxSignals.Year2 = yr_aux;
    }

    yr_aux = ((aux_data8 % 100) % 10);
    if ( CanRxSignals.Year3 != yr_aux ){
        flag_change_data = true;
        CanRxSignals.Year3 = yr_aux;
    }

    /* Month */

    aux_data8 = ((CanRxPrms.msgData[4] & 0x78) >> 3);

    mn_aux = aux_data8 / 10;
    if( CanRxSignals.Month1 != mn_aux){
        flag_change_data = true;
        CanRxSignals.Month1 = mn_aux;
    }

    mn_aux = aux_data8 % 10;
    if(CanRxSignals.Month2 != mn_aux){
        flag_change_data = true;
        CanRxSignals.Month2 = mn_aux;
    }

    /* Day of month */

    aux_data8 = ((CanRxPrms.msgData[4] & 0x80) >> 7) | ((CanRxPrms.msgData[5] & 0x0F) << 1);

    dm_aux = aux_data8 / 10;
    if( CanRxSignals.Day1 != dm_aux){
        flag_change_data = true;
        CanRxSignals.Day1 = dm_aux;
    }

    dm_aux = aux_data8 % 10;
    if(CanRxSignals.Day2 != dm_aux){
        flag_change_data = true;
        CanRxSignals.Day2 = dm_aux;
    }

    /* Hour */

    aux_data8 = ((CanRxPrms.msgData[6] & 0x01) << 4) | ((CanRxPrms.msgData[5] & 0xF0) >> 4);

    hr_aux = aux_data8 % 10;
    if( CanRxSignals.Hour2 != hr_aux ){
        flag_change_data = true;
        CanRxSignals.Hour2 = hr_aux;
    }

    hr_aux = aux_data8 / 10;
    if( CanRxSignals.Hour1 != hr_aux ){
        flag_change_data = true;
        CanRxSignals.Hour1 = hr_aux;
    }

    /* Minute */
    aux_data8 = ( (CanRxPrms.msgData[6] & 0x7E) >> 1);

    mm_aux = aux_data8 % 10;
    if( CanRxSignals.Minute2 != mm_aux ){
        flag_change_data = true;
        CanRxSignals.Minute2 = mm_aux;
    }

    mm_aux = aux_data8 / 10;
    if( CanRxSignals.Minute1 != mm_aux ){
        flag_change_data = true;
        CanRxSignals.Minute1 = mm_aux;
    }

    /* Seconds */     
    aux_data8 = ( (CanRxPrms.msgData[6] & 0x80) >> 7) | ((CanRxPrms.msgData[7] & 0x1F) << 1);
    mm_aux = aux_data8 % 10;
    CanRxSignals.Second2 = mm_aux;
    mm_aux = aux_data8 / 10;
    CanRxSignals.Second1 = mm_aux;


    /* Set new Time & Date if neccesary */
    if(true == flag_change_data){
        CanAppl_SetTimeDate();
    }

    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID \n");
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Year1   = %x  \n", CanRxSignals.Year1);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Year2   = %x  \n", CanRxSignals.Year2);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Year3   = %x  \n", CanRxSignals.Year3);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Month1   = %x  \n", CanRxSignals.Month1);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Month2   = %x  \n", CanRxSignals.Month2);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Day1   = %x  \n", CanRxSignals.Day1);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Day2   = %x  \n", CanRxSignals.Day2);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Hour1   = %x  \n", CanRxSignals.Hour1);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Hour2   = %x  \n", CanRxSignals.Hour2);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Minute1 = %x  \n", CanRxSignals.Minute1);
    LOG_PRINT(DEBUG_CAN,  "TIME_DATE_ID -> Minute2 = %x  \n", CanRxSignals.Minute2);

    T_Can_Rx_Msg[mDiagnose_1].cnt    = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mKombi_1
 *
 * @brief      Process CAN message mKombi_1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mEinheten(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;

    aux_data8 = (CanRxPrms.msgData[0] & 0x80) >> 7;
    if( CanRxSignals.hr_mode != aux_data8 )
    {
        CanRxSignals.hr_mode = aux_data8;

        CanAppl_SetTimeDate();
    }

    LOG_PRINT(DEBUG_CAN, "IPC_VEHICLE_SETUP > hr_mode = %d  \n", CanRxSignals.hr_mode);


    T_Can_Rx_Msg[mEinheiten].cnt    = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mGW_Bremse_Getriebe
 *
 * @brief      Process CAN message mGW_Bremse_Getriebe
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mGW_Bremse_Getriebe(dcanRxParams_t CanRxPrms)
{
    uint16_t     aux_data16;
    float        VehicleSpeedVSOSig;
    uint8_t      aux_data8;

    //GWB_FzgGeschw
    aux_data16 = ((CanRxPrms.msgData[1] & 0xFE) >> 1) | ((CanRxPrms.msgData[2]) << 7);
    aux_data16 = (aux_data16 < GWB_MAX_SPEED) ? aux_data16 : GWB_MAX_SPEED;
    VehicleSpeedVSOSig = aux_data16*(GWB_SPEED_RES);

    if( CanRxSignals.VehicleSpeedVSOSig != VehicleSpeedVSOSig )
    {
        CanRxSignals.VehicleSpeedVSOSig = VehicleSpeedVSOSig;
        Shadow_Server_Storage_Set(SHADOW_VehicleSpeedVSOSig, (uint8_t *)&CanRxSignals.VehicleSpeedVSOSig);
    }

    LOG_PRINT(DEBUG_CAN, "VehicleSpeedVSOSSig > = %f \n", CanRxSignals.VehicleSpeedVSOSig);

    //GWB_Info_Waehlhebel
    if (!CanRxSignals.ManualGearbox)
    {
        aux_data8 = (CanRxPrms.msgData[7] & 0xF0) >> 4;
        if (aux_data8 != GWB_Info_Waehlhebel_ManualSelespeed)
        {
            CanRxSignals.ManualSelespeed = false;
            SetCanRxSignalGear(GWB_Info_Waehlhebel[aux_data8]);
        }
        else
        {
            CanRxSignals.ManualSelespeed = true;
        }
    }
    T_Can_Rx_Msg[mGW_Bremse_Getriebe].cnt    = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_NWM_BCM1
 *
 * @brief      Process CAN message NWM_BCM1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_NWM_BCM1(dcanRxParams_t CanRxPrms)
{
    uint8_t     network_active;
    uint8_t     cmd_alive_status;
    uint8_t     sleep_ind_status;

    cmd_alive_status = ((CanRxPrms.msgData[1] >> 1) & 0x01);
    sleep_ind_status = ((CanRxPrms.msgData[1] >> 4) & 0x01);

    if(cmd_alive_status)
    {
        network_active = true;
    }
    else
    {
        if(sleep_ind_status)
        {
           network_active = false;
        }
        else
        {
            network_active = true;
        }
    }

    if(network_active != CanRxSignals.NetworkActive)
    {
        CanRxSignals.NetworkActive = network_active;
    }

    if(sleep_ind_status != CanRxSignals.NWM_BCM1_SleepInd)
    {
        CanRxSignals.NWM_BCM1_SleepInd = sleep_ind_status;
        CanTxSignals.NWM_RNS_SleepAck = sleep_ind_status;
    }

    CANAppl_Volkswagen_NWM_RNS_Tx_Message();

    T_Can_Rx_Msg[NWM_BCM1].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_Parkhilfe_01
 *
 * @brief      Process CAN message Parkhilfe_01
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_Parkhilfe_01(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;

    aux_data8 = (CanRxPrms.msgData[1] & 0xE0) >> 5;
    if((aux_data8==0x03) || (aux_data8==0x00))
    {
        if(CanRxSignals.ParkingActive==ENABLE)
        {
            if(aux_data8==0x03)
            {
                CanRxSignals.ParkingActive = DISABLE;
//                Shadow_Storage_Set(SHADOW_ParkingActive, &CanRxSignals.ParkingActive);
            }
        }
        else
        {
            if(aux_data8==0x00)
            {
                CanRxSignals.ParkingActive = ENABLE;
//                Shadow_Storage_Set(SHADOW_ParkingActive, &CanRxSignals.ParkingActive);
            }
        }
        LOG_PRINT(DEBUG_CAN, "Parkhilfe_01 > ParkingActive = %d  \n", CanRxSignals.ParkingActive);
    }

    aux_data8 = (CanRxPrms.msgData[2] & 0x80) >> 7;
    if(CanRxSignals.ParkingAssistButton != aux_data8)
    {
        CanRxSignals.ParkingAssistButton = aux_data8;
        CANAppl_updateRVC();
        Shadow_Server_Storage_Set(SHADOW_ParkingAssistButton, &CanRxSignals.ParkingAssistButton);
    }

    T_Can_Rx_Msg[Parkhilfe_01].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_BAP_OPS
 *
 * @brief      Process CAN message BAP_OPS
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_BAP_OPS(dcanRxParams_t CanRxPrms)
{
    if (0x42 == CanRxPrms.msgData[0])
    {
        if (0x92 == CanRxPrms.msgData[1])
        {
            CanRxSignals.ParkingFrontSensors[0] = CanRxPrms.msgData[2];
            CanRxSignals.ParkingFrontSensors[1] = CanRxPrms.msgData[3];
            CanRxSignals.ParkingFrontSensors[2] = CanRxPrms.msgData[4];
            CanRxSignals.ParkingFrontSensors[3] = CanRxPrms.msgData[5];
//            Shadow_Storage_Set(SHADOW_ParkingFrontSensors, &CanRxSignals.ParkingFrontSensors[0]);

            LOG_PRINT(DEBUG_CAN, "BAP_OPS > FrontSensors [%d][%d][%d][%d]  \n", CanRxSignals.ParkingFrontSensors[0], CanRxSignals.ParkingFrontSensors[1], CanRxSignals.ParkingFrontSensors[2], CanRxSignals.ParkingFrontSensors[3]);
            HmiManager_update_front_parking_sensors(CanRxSignals.ParkingFrontSensors);
        }
        else if (0x93 == CanRxPrms.msgData[1])
        {
            CanRxSignals.ParkingRearSensors[0] = CanRxPrms.msgData[2];
            CanRxSignals.ParkingRearSensors[1] = CanRxPrms.msgData[3];
            CanRxSignals.ParkingRearSensors[2] = CanRxPrms.msgData[4];
            CanRxSignals.ParkingRearSensors[3] = CanRxPrms.msgData[5];
//            Shadow_Storage_Set(SHADOW_ParkingRearSensors, &CanRxSignals.ParkingRearSensors[0]);

            LOG_PRINT(DEBUG_CAN, "BAP_OPS > RearSensors [%d][%d][%d][%d]  \n", CanRxSignals.ParkingRearSensors[0], CanRxSignals.ParkingRearSensors[1], CanRxSignals.ParkingRearSensors[2], CanRxSignals.ParkingRearSensors[3]);
            HmiManager_update_rear_parking_sensors(CanRxSignals.ParkingRearSensors);
        }
    }

    T_Can_Rx_Msg[BAP_OPS].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mGateway_3
 *
 * @brief      Process CAN message mGateway_3
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mGateway_3(dcanRxParams_t CanRxPrms)
{
    uint8_t aux_data8;

    switch(CanRxPrms.msgData[1])
    {
        case GW3_NO_LANGUAGE:
            LOG_PRINT(DEBUG_CAN, "mGateway_3 > No language  \n");
            aux_data8 = CanRxSignals.LanguageSelection;
            HmiManager_set_language(RENDERER_LANGUAGE_INVALID);
        break;

        case GW3_ENGLISH: // English
        case GW3_US_ENGLISH:
            LOG_PRINT(DEBUG_CAN, "mGateway_3 > English  \n");
            aux_data8 = HU_ENGLISH;
            HmiManager_set_language(RENDERER_LANGUAGE_ENGLISH);
        break;

        case GW3_SPANISH: // Spanish
        case GW3_US_SPANISH:
            LOG_PRINT(DEBUG_CAN, "mGateway_3 > Spanish  \n");
            aux_data8 = HU_SPANISH;
            HmiManager_set_language(RENDERER_LANGUAGE_SPANISH);
        break;

        case GW3_PORTUGUES: // Portugues
        case GW3_BR_PORTUGUES:
            LOG_PRINT(DEBUG_CAN, "mGateway_3 > Portugues  \n");
            aux_data8 = HU_PORTUGUES;
            HmiManager_set_language(RENDERER_LANGUAGE_PORTUGUESE);
        break;

        default: // English
            LOG_PRINT(DEBUG_CAN, "mGateway_3 > English  \n");
            aux_data8 = HU_ENGLISH;
            HmiManager_set_language(RENDERER_LANGUAGE_ENGLISH);
        break;
    }

    if( CanRxSignals.LanguageSelection != aux_data8 )
    {
        CanRxSignals.LanguageSelection = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_LanguageSelection, &CanRxSignals.LanguageSelection);
    }

    LOG_PRINT(DEBUG_CAN, "mGateway_3 > LanguageSelection = %d  \n", CanRxSignals.LanguageSelection);

    T_Can_Rx_Msg[mGateway_3].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mMFA_1
 *
 * @brief      Process CAN message mMFA_1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mMFA_1(dcanRxParams_t CanRxPrms)
{
    char buff[8];

    //consumption
    float_t consumption = CONSUMPTION_SCALE * (CanRxPrms.msgData[0] + (((uint16_t) CanRxPrms.msgData[1] & 0x0F) << 8));
    uint8_t consumption_unit = (CanRxPrms.msgData[1] & 0xF0) >> 4;
    if (consumption > (MAX_CONSUMPTION * CONSUMPTION_SCALE))
    {
        consumption = MAX_UINT16;
    }
    if (CanRxSignals.InstConsumption != consumption)
    {
        CanRxSignals.InstConsumption = consumption;
        Shadow_Server_Storage_Set(SHADOW_InstConsumption, (uint8_t *) &consumption);
    }
    ConsumptionUnitToString(
        (Consumption_unit_T) consumption_unit,
        buff
    );
    if (memcmp(CanRxSignals.InstConsumptionUnit, buff, 8))
    {
        memcpy(CanRxSignals.InstConsumptionUnit, buff, 8);
        Shadow_Server_Storage_Set(SHADOW_InstConsumptionUnit, (uint8_t *) buff);
    }

    //range
    uint16_t range = CanRxPrms.msgData[2] + (((uint16_t) CanRxPrms.msgData[3] & 0x3F) << 8);
    bool range_km = (bool) ((CanRxPrms.msgData[3] & 0x40) >> 6);
    bool range_mls = (bool) ((CanRxPrms.msgData[3] & 0x80) >> 7);
    if (range > MAX_RANGE)
    {
        range = MAX_UINT16;
    }
    if (CanRxSignals.Range != range)
    {
        CanRxSignals.Range = range;
        Shadow_Server_Storage_Set(SHADOW_Range, (uint8_t *) &range);
    }
    memcpy(buff, range_km ? "km" : range_mls ? "ml" : " ", 8);
    if (memcmp(CanRxSignals.RangeUnit, buff, 8))
    {
        memcpy(CanRxSignals.RangeUnit, buff, 8);
        Shadow_Server_Storage_Set(SHADOW_RangeUnit, (uint8_t *) buff);
    }

    //kilometerstand
    uint32_t kilometerstand = CanRxPrms.msgData[4] + ((uint32_t) CanRxPrms.msgData[5] << 8)
            + (((uint32_t) CanRxPrms.msgData[6] & 0x3F) << 16);
    bool kilometerstand_km = (bool) ((CanRxPrms.msgData[6] & 0x40) >> 6);
    bool kilometerstand_mls = (bool) ((CanRxPrms.msgData[6] & 0x80) >> 7);
    if (kilometerstand > MAX_KILOMETERSTAND)
    {
        kilometerstand = MAX_UINT32;
    }
    if (CanRxSignals.Kilometerstand != kilometerstand)
    {
        CanRxSignals.Kilometerstand = kilometerstand;
        Shadow_Server_Storage_Set(SHADOW_Kilometerstand, (uint8_t *) &kilometerstand);
    }
    memcpy(buff, kilometerstand_km ? "km" : kilometerstand_mls ? "ml" : " ", 8);
    if (memcmp(CanRxSignals.KilometerstandUnit, buff, 8))
    {
        memcpy(CanRxSignals.KilometerstandUnit, buff, 8);
        Shadow_Server_Storage_Set(SHADOW_KilometerstandUnit, (uint8_t *) buff);
    }

    //reserverange
    if (CanRxSignals.ReserveRange != CanRxPrms.msgData[7])
    {
        CanRxSignals.ReserveRange = CanRxPrms.msgData[7];
        Shadow_Server_Storage_Set(SHADOW_ReserveRange, (uint8_t *) &CanRxPrms.msgData[7]);
    }
    T_Can_Rx_Msg[mMFA_1].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mMFA_2
 *
 * @brief      Process CAN message mMFA_2
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mMFA_2(dcanRxParams_t CanRxPrms)
{
    uint16_t aux_data16;
    char buff[8];

    //consumption
    float_t consumption = CONSUMPTION_SCALE *
            (CanRxPrms.msgData[0] + (((uint16_t) CanRxPrms.msgData[1] & 0x0F) << 8));
    uint8_t consumption_unit = (CanRxPrms.msgData[1] & 0x70) >> 4;
    if (consumption > (MAX_CONSUMPTION * CONSUMPTION_SCALE))
    {
        consumption = MAX_UINT16;
    }
    if (CanRxSignals.ShortTermConsumption != consumption)
    {
        CanRxSignals.ShortTermConsumption = consumption;
        Shadow_Server_Storage_Set(SHADOW_ShortTermConsumption, (uint8_t *) &consumption);
    }
    ConsumptionUnitToString(
        (Consumption_unit_T) consumption_unit,
        buff
    );
    if (memcmp(CanRxSignals.ShortTermConsumptionUnit, buff, 8))
    {
        memcpy(CanRxSignals.ShortTermConsumptionUnit, buff, 8);
        Shadow_Server_Storage_Set(SHADOW_ShortTermConsumptionUnit, (uint8_t *) buff);
    }

    //distance
    uint16_t distance = CanRxPrms.msgData[2] + (((uint16_t) CanRxPrms.msgData[3] & 0x3F) << 8);
    bool distance_km = (bool) ((CanRxPrms.msgData[3] & 0x40) >> 6);
    bool distance_mls = (bool) ((CanRxPrms.msgData[3] & 0x80) >> 7);
    if (distance > MAX_DISTANCE)
    {
        distance = MAX_UINT16;
    }
    if (CanRxSignals.ShortTermDistance != distance)
    {
        CanRxSignals.ShortTermDistance = distance;
        Shadow_Server_Storage_Set(SHADOW_ShortTermDistance, (uint8_t *) &distance);
    }
    memcpy(buff, distance_km ? "km" : distance_mls ? "ml" : " ", 8);
    if (memcmp(CanRxSignals.ShortTermDistanceUnit, buff, 8))
    {
        memcpy(CanRxSignals.ShortTermDistanceUnit, buff, 8);
        Shadow_Server_Storage_Set(SHADOW_ShortTermDistanceUnit, (uint8_t *) buff);
    }

    //time
    aux_data16 = CanRxPrms.msgData[4] + (((uint16_t) CanRxPrms.msgData[5] & 0x3F) << 8);
    if (aux_data16 > MAX_TIME)
    {
        aux_data16 = MAX_UINT16;
    }
    if (CanRxSignals.ShortTermTime != aux_data16)
    {
        CanRxSignals.ShortTermTime = aux_data16;
        Shadow_Server_Storage_Set(SHADOW_ShortTermTime, (uint8_t *) &aux_data16);
    }

    //avspeed
    uint16_t avSpeed = CanRxPrms.msgData[6] + (((uint16_t) CanRxPrms.msgData[7] & 0x3F) << 8);
    bool avSpeed_kmh = (bool) ((CanRxPrms.msgData[7] & 0x40) >> 6);
    bool avSpeed_mph = (bool) ((CanRxPrms.msgData[7] & 0x80) >> 7);
    if (avSpeed > MAX_SPEED)
    {
        avSpeed = MAX_UINT16;
    }
    if (CanRxSignals.ShortTermAvSpeed != avSpeed)
    {
        CanRxSignals.ShortTermAvSpeed = avSpeed;
        Shadow_Server_Storage_Set(SHADOW_ShortTermAvSpeed, (uint8_t *) &avSpeed);
    }
    memcpy(buff, avSpeed_kmh ? "km/h" : avSpeed_mph ? "mph" : " ", 8);
    if (memcmp(CanRxSignals.ShortTermAvSpeedUnit, buff, 8))
    {
        memcpy(CanRxSignals.ShortTermAvSpeedUnit, buff, 8);
        Shadow_Server_Storage_Set(SHADOW_ShortTermAvSpeedUnit, (uint8_t *) buff);
    }
    T_Can_Rx_Msg[mMFA_2].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mMFA_3
 *
 * @brief      Process CAN message mMFA_3
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mMFA_3(dcanRxParams_t CanRxPrms)
{
    uint16_t aux_data16;
    char buff[8];

    //consumption
    float_t consumption = CONSUMPTION_SCALE *
            (CanRxPrms.msgData[0] + (((uint16_t) CanRxPrms.msgData[1] & 0x0F) << 8));
    uint8_t consumption_unit = (CanRxPrms.msgData[1] & 0x70) >> 4;
    if (consumption > (MAX_CONSUMPTION * CONSUMPTION_SCALE))
    {
        consumption = MAX_UINT16;
    }
    if (CanRxSignals.LongTermConsumption != consumption)
    {
        CanRxSignals.LongTermConsumption = consumption;
        Shadow_Server_Storage_Set(SHADOW_LongTermConsumption, (uint8_t *) &consumption);
    }
    ConsumptionUnitToString(
        (Consumption_unit_T) consumption_unit,
        buff
    );
    if (memcmp(CanRxSignals.LongTermConsumptionUnit, buff, 8))
    {
        memcpy(CanRxSignals.LongTermConsumptionUnit, buff, 8);
        Shadow_Server_Storage_Set(SHADOW_LongTermConsumptionUnit, (uint8_t *) buff);
    }

    //distance
    uint16_t distance = CanRxPrms.msgData[2] + (((uint16_t) CanRxPrms.msgData[3] & 0x3F) << 8);
    bool distance_km = (bool) ((CanRxPrms.msgData[3] & 0x40) >> 6);
    bool distance_mls = (bool) ((CanRxPrms.msgData[3] & 0x80) >> 7);
    if (distance > MAX_DISTANCE)
    {
        distance = MAX_UINT16;
    }
    if (CanRxSignals.LongTermDistance != distance)
    {
        CanRxSignals.LongTermDistance = distance;
        Shadow_Server_Storage_Set(SHADOW_LongTermDistance, (uint8_t *) &distance);
    }
    memcpy(buff, distance_km ? "km" : distance_mls ? "ml" : " ", 8);
    if (memcmp(CanRxSignals.LongTermDistanceUnit, buff, 8))
    {
        memcpy(CanRxSignals.LongTermDistanceUnit, buff, 8);
        Shadow_Server_Storage_Set(SHADOW_LongTermDistanceUnit, (uint8_t *) buff);
    }

    //time
    aux_data16 = CanRxPrms.msgData[4] + (((uint16_t) CanRxPrms.msgData[5] & 0x3F) << 8);
    if (aux_data16 > MAX_TIME)
    {
        aux_data16 = MAX_UINT16;
    }
    if (CanRxSignals.LongTermTime != aux_data16)
    {
        CanRxSignals.LongTermTime = aux_data16;
        Shadow_Server_Storage_Set(SHADOW_LongTermTime, (uint8_t *) &aux_data16);
    }

    //avspeed
    uint16_t avSpeed = CanRxPrms.msgData[6] + (((uint16_t) CanRxPrms.msgData[7] & 0x3F) << 8);
    bool avSpeed_kmh = (bool) ((CanRxPrms.msgData[7] & 0x40) >> 6);
    bool avSpeed_mph = (bool) ((CanRxPrms.msgData[7] & 0x80) >> 7);
    if (avSpeed > MAX_SPEED)
    {
        avSpeed = MAX_UINT16;
    }
    if (CanRxSignals.LongTermAvSpeed != avSpeed)
    {
        CanRxSignals.LongTermAvSpeed = avSpeed;
        Shadow_Server_Storage_Set(SHADOW_LongTermAvSpeed, (uint8_t *) &avSpeed);
    }
    memcpy(buff, avSpeed_kmh ? "km/h" : avSpeed_mph ? "mph" : " ", 8);
    if (memcmp(CanRxSignals.LongTermAvSpeedUnit, buff, 8))
    {
        memcpy(CanRxSignals.LongTermAvSpeedUnit, buff, 8);
        Shadow_Server_Storage_Set(SHADOW_LongTermAvSpeedUnit, (uint8_t *) buff);
    }

    T_Can_Rx_Msg[mMFA_3].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mFzg_Ident
 *
 * @brief      Process CAN message mFzg_Ident
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mFzg_Ident(dcanRxParams_t CanRxPrms)
{
    uint8_t mux;
    static uint8_t aux_data8[18];
    static uint8_t state = 0;
    mux = CanRxPrms.msgData[0] & 0x03;

    if (mux != state)
    {
        /* As VIN number can arrive in a not ordered way, we simply continue 
         * along with the FSM the next time a message arrives
         */
        return;
    }

    switch (mux)
    {
        case 0:
            aux_data8[0] = CanRxPrms.msgData[5];
            aux_data8[1] = CanRxPrms.msgData[6];
            aux_data8[2] = CanRxPrms.msgData[7];
            state = 1;
            break;
        case 1:
            aux_data8[3] = CanRxPrms.msgData[1];
            aux_data8[4] = CanRxPrms.msgData[2];
            aux_data8[5] = CanRxPrms.msgData[3];
            aux_data8[6] = CanRxPrms.msgData[4];
            aux_data8[7] = CanRxPrms.msgData[5];
            aux_data8[8] = CanRxPrms.msgData[6];
            aux_data8[9] = CanRxPrms.msgData[7];
            state = 2;
            break;
        case 2:
            aux_data8[10] = CanRxPrms.msgData[1];
            aux_data8[11] = CanRxPrms.msgData[2];
            aux_data8[12] = CanRxPrms.msgData[3];
            aux_data8[13] = CanRxPrms.msgData[4];
            aux_data8[14] = CanRxPrms.msgData[5];
            aux_data8[15] = CanRxPrms.msgData[6];
            aux_data8[16] = CanRxPrms.msgData[7];
            aux_data8[17] = 0;
            if (memcmp(CanRxSignals.ChassisNumber, aux_data8, 18))
            {
                Shadow_CarModel_T detected_car;

                memcpy(CanRxSignals.ChassisNumber, aux_data8, 18);
                Shadow_Server_Storage_Set(SHADOW_ChassisNumber, (uint8_t *) aux_data8);

                detected_car = CanAppl_GetModelFromVinNumber(CanRxSignals.ChassisNumber);

                if (CAR_MODEL_INVALID != detected_car)
                {
                    __internal_detected_car = detected_car;
                    HmiManager_set_car(detected_car);
                    sar_ram_set_car_model(detected_car);
                }

                CanAppl_SetCarModel(detected_car);
            }
            state = 0;
            break;
    }
    T_Can_Rx_Msg[mFzg_Ident].cnt = ClockUtils_Get_Time();
}


/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mLenkwinkel_1
 *
 * @brief      Process CAN message mLenkwinkel_1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mLenkwinkel_1(dcanRxParams_t CanRxPrms)
{
    float_t aux_data;
    uint8_t aux_data8;

    //LW1_Lenkradwinkel
    aux_data = CanRxPrms.msgData[0] + (((uint16_t) CanRxPrms.msgData[1] & 0x7F) << 8);
    aux_data = aux_data * WHEEL_ANGLE_SCALE;
    if (aux_data < MAX_WHEEL_ANGLE)
    {
        //LW1_Vorzeichen
        aux_data = aux_data * (((CanRxPrms.msgData[1] & 0x80) != 0) ? -1:1);
    }
    else
    {
        aux_data = MAX_INT16;
    }
    if (CanRxSignals.SteeringWheelAngle != aux_data)
    {
        CanRxSignals.SteeringWheelAngle = aux_data;
        Shadow_Server_Storage_Set(SHADOW_SteeringWheelAngle,
                (uint8_t *) &CanRxSignals.SteeringWheelAngle);
    }

    T_Can_Rx_Msg[mLenkwinkel_1].cnt = ClockUtils_Get_Time();

    //LW1_Geschwindigkeit
    aux_data = CanRxPrms.msgData[2] + (((uint16_t) CanRxPrms.msgData[3] & 0x7F) << 8);
    aux_data = aux_data * WHEEL_ANGLE_SCALE;

    //LW1_Geschw_Vorzeichen
    aux_data = aux_data * (((CanRxPrms.msgData[3] & 0x80) != 0) ? -1:1);

    if (CanRxSignals.SteeringWheelAngleChangeRate != aux_data)
    {
        CanRxSignals.SteeringWheelAngleChangeRate = aux_data;
        Shadow_Server_Storage_Set(SHADOW_SteeringWheelAngleChangeRate, (uint8_t *) &CanRxSignals.SteeringWheelAngleChangeRate);
    }

    //LW1_ID
    aux_data8 = CanRxPrms.msgData[4];

    if (CanRxSignals.SteeringWheelAngleCalibration != aux_data8)
    {
        CanRxSignals.SteeringWheelAngleCalibration = aux_data8;
        Shadow_Server_Storage_Set(SHADOW_SteeringWheelAngleCalibration, (uint8_t *) &CanRxSignals.SteeringWheelAngleCalibration);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mGW_Motor
 *
 * @brief      Process CAN message mGW_Motor
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mGW_Motor(dcanRxParams_t CanRxPrms)
{
    uint16_t aux_data16;

    //GWM_Motordrehzahl
    aux_data16 = CanRxPrms.msgData[1] + ((uint16_t) CanRxPrms.msgData[2] << 8);
    aux_data16 = (uint16_t) round(RPM_SCALE * aux_data16);
    if (aux_data16 > MAX_RPM)
    {
        aux_data16 = MAX_UINT16;
    }
    if (CanRxSignals.RPM != aux_data16)
    {
        CanRxSignals.RPM = aux_data16;
        Shadow_Server_Storage_Set(SHADOW_RPM,
                (uint8_t *) &CanRxSignals.RPM);
    }

    T_Can_Rx_Msg[mGW_Motor].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mGW_ANT_2
 *
 * @brief      Process CAN message mGW_ANT_2
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mGW_ANT_2(dcanRxParams_t CanRxPrms)
{
    uint8_t      aux_data8;
    bool         manualGearbox = (CanRxPrms.msgData[1] & 0x01) != 0;

    //GE2_Senderkennung => 1 = MSG (manual), 0 = GSG (auto)
    if (CanRxSignals.ManualGearbox != manualGearbox)
    {
        CanRxSignals.ManualGearbox = manualGearbox;
        SetCanRxSignalGear("-");
    }

    //GE2_Variante
    aux_data8 = (CanRxPrms.msgData[2] & 0x0F);
    if (CanRxSignals.ManualGearbox)
    {
        //dont overwrite "R" only set signal if ReverseGearSts is 0
        if (CanRxSignals.ReverseGearSts == 0)
        {
            SetCanRxSignalGear(aux_data8 < MAX_GE2_VARIANTE ?
                    GE2_Variante[aux_data8] : "-");
        }
    }
    else
    {
        if (CanRxSignals.ManualSelespeed && (aux_data8 == GE2_Variante_Sollgang))
        {
            //GE2_Sollgang
            aux_data8 = (CanRxPrms.msgData[2] & 0xF0) >> 4;
            SetCanRxSignalGear(aux_data8 < MAX_GE2_SOLLGANG ?
                    GE2_Sollgang[aux_data8] : "-");
        }
    }

    T_Can_Rx_Msg[mGW_ANT_2].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mGW_ANT_1
 *
 * @brief      Process CAN message mGW_ANT_1
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mGW_ANT_1(dcanRxParams_t CanRxPrms)
{
    uint8_t     aux_data8;
    uint16_t    aux_data16;
    float_t       lateralAcceleration;
    float_t       longitudinalAcceleration;

    //BR2_Querbeschl
    aux_data8 = CanRxPrms.msgData[4];
    lateralAcceleration = aux_data8 * LAT_ACC_SCALE - LAT_ACC_OFFSET;
    lateralAcceleration = lateralAcceleration * STD_VALUE_OF_g;

    if (CanRxSignals.LatAcceleration != lateralAcceleration)
    {
        CanRxSignals.LatAcceleration = lateralAcceleration;
        Shadow_Server_Storage_Set(SHADOW_LatAcceleration, (uint8_t *)&CanRxSignals.LatAcceleration);
    }

    //BR8_Laengsbeschl
    aux_data16 = ((CanRxPrms.msgData[6] & 0x03) << 8) | CanRxPrms.msgData[5];
    longitudinalAcceleration = aux_data16 * LONG_ACC_SCALE - LONG_ACC_OFFSET;

    if (CanRxSignals.LongAcceleration != longitudinalAcceleration)
    {
        CanRxSignals.LongAcceleration = longitudinalAcceleration;
        Shadow_Server_Storage_Set(SHADOW_LongAcceleration, (uint8_t *)&CanRxSignals.LongAcceleration);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mBremse_10
 *
 * @brief      Process CAN message mBremse_10
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mBremse_10(dcanRxParams_t CanRxPrms)
{
    bool_t direction_wheel_FL;
    bool_t direction_wheel_FR;
    bool_t direction_wheel_RL;
    bool_t direction_wheel_RR;
    uint16_t counter_wheel_FL;
    uint16_t counter_wheel_FR;
    uint16_t counter_wheel_RL;
    uint16_t counter_wheel_RR;

    //B10_Fahrtr_VL
    direction_wheel_FL = ((CanRxPrms.msgData[7] & 0x10) >> 4);

    if (CanRxSignals.DirectionWheelFL != direction_wheel_FL)
    {
        CanRxSignals.DirectionWheelFL = direction_wheel_FL;
        Shadow_Server_Storage_Set(SHADOW_DirectionWheelFL, (uint8_t *)&CanRxSignals.DirectionWheelFL);
    }

    //B10_Fahrtr_VR
    direction_wheel_FR = ((CanRxPrms.msgData[7] & 0x20) >> 5);

    if (CanRxSignals.DirectionWheelFR != direction_wheel_FR)
    {
        CanRxSignals.DirectionWheelFR = direction_wheel_FR;
        Shadow_Server_Storage_Set(SHADOW_DirectionWheelFR, (uint8_t *)&CanRxSignals.DirectionWheelFR);
    }

    //B10_Fahrtr_HL
    direction_wheel_RL = ((CanRxPrms.msgData[7] & 0x40) >> 6);

    if (CanRxSignals.DirectionWheelRL != direction_wheel_RL)
    {
        CanRxSignals.DirectionWheelRL = direction_wheel_RL;
        Shadow_Server_Storage_Set(SHADOW_DirectionWheelRL, (uint8_t *)&CanRxSignals.DirectionWheelRL);
    }

    //B10_Fahrtr_HR
    direction_wheel_RR = ((CanRxPrms.msgData[7] & 0x80) >> 7);

    if (CanRxSignals.DirectionWheelRR != direction_wheel_RR)
    {
        CanRxSignals.DirectionWheelRR = direction_wheel_RR;
        Shadow_Server_Storage_Set(SHADOW_DirectionWheelRR, (uint8_t *)&CanRxSignals.DirectionWheelRR);
    }

    //B10_Wegimp_VL
    counter_wheel_FL = ((CanRxPrms.msgData[3] & 0x03) << 8) | CanRxPrms.msgData[2];

    if (CanRxSignals.CounterWheelFL != counter_wheel_FL)
    {
        CanRxSignals.CounterWheelFL = counter_wheel_FL;
        Shadow_Server_Storage_Set(SHADOW_CounterWheelFL, (uint8_t *)&CanRxSignals.CounterWheelFL);
    }

    //B10_Wegimp_VR
    counter_wheel_FR = ((CanRxPrms.msgData[4] & 0x0F) << 6) | (CanRxPrms.msgData[3] >> 2);

    if (CanRxSignals.CounterWheelFR != counter_wheel_FR)
    {
        CanRxSignals.CounterWheelFR = counter_wheel_FR;
        Shadow_Server_Storage_Set(SHADOW_CounterWheelFR, (uint8_t *)&CanRxSignals.CounterWheelFR);
    }

    //B10_Wegimp_HL
    counter_wheel_RL = ((CanRxPrms.msgData[5] & 0x3F) << 4) | (CanRxPrms.msgData[4] >> 4);

    if (CanRxSignals.CounterWheelRL != counter_wheel_RL)
    {
        CanRxSignals.CounterWheelRL = counter_wheel_RL;
        Shadow_Server_Storage_Set(SHADOW_CounterWheelRL, (uint8_t *)&CanRxSignals.CounterWheelRL);
    }

    //B10_Wegimp_HR
    counter_wheel_RR = (CanRxPrms.msgData[6] << 2) | (CanRxPrms.msgData[5] >> 6);

    if (CanRxSignals.CounterWheelRR != counter_wheel_RR)
    {
        CanRxSignals.CounterWheelRR = counter_wheel_RR;
        Shadow_Server_Storage_Set(SHADOW_CounterWheelRR, (uint8_t *)&CanRxSignals.CounterWheelRR);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mGW_Kombi
 *
 * @brief      Process CAN message mGW_Kombi
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mGW_Kombi(dcanRxParams_t CanRxPrms)
{
    uint16_t wheel_circumference;

    //GWK_Umfang_Reifen
    wheel_circumference = (CanRxPrms.msgData[4] << 4) | (CanRxPrms.msgData[3] >> 4);

    if (CanRxSignals.WheelCircumference != wheel_circumference)
    {
        CanRxSignals.WheelCircumference = wheel_circumference;
        Shadow_Server_Storage_Set(SHADOW_WheelCircumference, (uint8_t *)&CanRxSignals.WheelCircumference);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_mMotor7
 *
 * @brief      Process CAN message mMotor7
 *
 * @param [in] dcanRxParams_t CanRxPrms
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_ProcessMsg_mMotor7(dcanRxParams_t CanRxPrms)
{
    //MO7_Oeltemperatur
    float_t aux_data = (CanRxPrms.msgData[7] - OIL_TEMP_OFFSET);
    if ((aux_data > MAX_OIL_TEMP) || (aux_data < MIN_OIL_TEMP))
    {
        aux_data = MAX_INT16;
    }
    if (CanRxSignals.OilTemperature != aux_data)
    {
        CanRxSignals.OilTemperature = aux_data;
        Shadow_Server_Storage_Set(SHADOW_OilTemperature,
                (uint8_t *) &CanRxSignals.OilTemperature);
    }

    T_Can_Rx_Msg[mMotor7].cnt = ClockUtils_Get_Time();
}

/***************************************************************************//**
 *
 * @fn         SetCanRxSignalGear
 *
 * @brief      set a new string value in CanRxSignals.Gear and propagates to A15
 *
 * @param [in] s String
 *
 * @return     void
 *
 ******************************************************************************/
void SetCanRxSignalGear(const char * s)
{
    if (strcmp(s, CanRxSignals.Gear) != 0 )
    {
        strcpy(CanRxSignals.Gear, s);
        Shadow_Server_Storage_Set(SHADOW_Gear, (uint8_t *) CanRxSignals.Gear);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_GetModelFromVinNumber
 *
 * @brief      get the car model from the VIN number
 *
 * @param [in] vin VIN number
 *
 * @return     Shadow_CarModel_T detected car model or CAR_MODEL_INVALID if not recognized
 *
 ******************************************************************************/
static Shadow_CarModel_T CanAppl_GetModelFromVinNumber(const char *vin)
{
    Shadow_CarModel_T car_model = CAR_MODEL_INVALID;

    if (((vin[6] == '2') && (vin[7] == 'H')) || ((vin[6] == 'S') && (vin[7] == 'D')))
    {
        car_model = CAR_MODEL_VW_AMAROK;
    }
    else if ((vin[6] == '5') && (vin[7] == 'U'))
    {
        if (vin[3] == 'K')
        {
            car_model = CAR_MODEL_VW_SAVEIRO;
        }
        else
        {
            /* This way if we eventually receive a weird VIN number, we assume double cabin */
            car_model = CAR_MODEL_VW_SAVEIRO_DOUBLE_CABIN;
        }
    }
    else if (((vin[6] == '6') && (vin[7] == 'R')) || ((vin[6] == 'A') && (vin[7] == '5')))
    {
        car_model = CAR_MODEL_VW_POLO;
    }

    return car_model;
}

/***************************************************************************//**
 *
 * @fn         ConsumptionUnitToString
 *
 * @brief      Convert unit Comsumption enum to String
 *
 * @param [in] Consumption_unit_T unit
 * @param [in] char * string to save the output
 *
 *
 ******************************************************************************/
void ConsumptionUnitToString(Consumption_unit_T unit, char *string)
{
    switch (unit)
    {
        case Consumption_in_l_100km:
            memcpy(string, "l/100km", 8);
            break;
        case Consumption_in_km_l:
            memcpy(string, "km/l", 8);
            break;
        case Consumption_in_mpg:
            memcpy(string, "mpg", 8);
            break;
        case Consumption_in_kg_100km:
            memcpy(string, "kg/100km", 8);
            break;
        case Consumption_in_kg_h:
            memcpy(string, "kg/h", 8);
            break;
        case Consumption_in_mpkg:
            memcpy(string, "mpkg", 8);
            break;
        case Consumption_in_lph:
            memcpy(string, "lph", 8);
            break;
        default:
            memcpy(string, " ", 8);
            break;
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Volkswagen_GetOperationalMode_Status
 *
 * @brief      Get signal OperationalMode_Status
 *
 * @param [in] void
 *
 * @return     uint8_t
 *
 ******************************************************************************/
uint8_t CanAppl_Volkswagen_GetOperationalMode_Status()
{
    uint8_t ignition_status;
    Semaphore_pend(ignition_sem, BIOS_WAIT_FOREVER);
    ignition_status = CanRxSignals.OperationalModeSts;
    Semaphore_post(ignition_sem);
    return ignition_status;
}

uint8_t CanAppl_Volkswagen_GetKey_Status() {
    return CanRxSignals.KeyStatus;
}

bool_t CanAppl_Volkswagen_GetNetworkActive_Status(void)
{
    uint8_t can_network_status;
    Semaphore_pend(network_sem, BIOS_WAIT_FOREVER);
    can_network_status = CanRxSignals.NetworkActive;
    Semaphore_post(network_sem);
    return can_network_status;
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Volkswagen_GetTransportMode_Status
 *
 * @brief      Get signal TransportMode_Status
 *
 * @param [in] void
 *
 * @return     uint8_t
 *
 ******************************************************************************/
uint8_t CanAppl_Volkswagen_GetTransportMode_Status() {   
    return (CanRxSignals.TransportModeStatus_CAN);
}


/***************************************************************************//**
 *
 * @fn         CanAppl_Volkswagen_ReportCurrentRvcStatus
 *
 * @brief      Report to the shared memory the RVC+HATCH status
 *
 * @param [in]
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Volkswagen_ReportCurrentRvcStatus()
{
    Semaphore_pend(rvc_sem, BIOS_WAIT_FOREVER);
    HmiManager_set_rvc_state(__internal_rvc_state);
    Semaphore_post(rvc_sem);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Volkswagen_ReportCurrentPdcStatus
 *
 * @brief      Report to the shared memory the PDC status
 *
 * @param [in]
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Volkswagen_ReportCurrentPdcStatus()
{
    Semaphore_pend(rvc_sem, BIOS_WAIT_FOREVER);
    HmiManager_set_pdc_key_state(__internal_pdc_key_state);
    Semaphore_post(rvc_sem);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Volkswagen_ReportRvcOff
 *
 * @brief      Report to the shared memory that the RVC+HATCH status are off
 *             this depends on the Ignition signals and the power state
 *             machine and is independent of the real state of this signals.
 *             We do not modify the internal signals of the class.
 *
 * @param [in]
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Volkswagen_ReportRvcOff()
{
    HmiManager_set_rvc_state(false);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Volkswagen_ReportPdcOff
 *
 * @brief      Report to the shared memory that the PDC status is off.
 *             This depends on the Ignition signals and the power state
 *             machine and is independent of the real state of this signals.
 *             We do not modify the internal signals of the class.
 *
 * @param [in]
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Volkswagen_ReportPdcOff()
{
    HmiManager_set_pdc_key_state(false);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Timeout_Init
 *
 * @brief      Initialization of variables for controller the timeout CAN msg.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Volkswagen_Timeout_Init(void)
{
    uint8_t i = 0;

    for(i= 0; i < NUM_CAN_RX_MESSAGES;i++)
    {
        T_Can_Rx_Msg[i].cnt = 1;
    }

    ClockUtil_Init();

    /*
     *  Note: the theoretical value should be ClockUtils_Get_Time() but use 1
     *  because at the beginning ClockUtils_Get_Time() = 0
     *  why??
     *  Clock_tickPeriod = 1000 = constant
     *  Clock_getTicks() < 1000
     *  Then Clock_getTicks()/Clock_tickPeriod = 0
     */
}

/***************************************************************************//**
 *
 * @fn         CanAppl_Timeout
 *
 * @brief      Handler thats controls the timeouts of the periodic CAN messages.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CanAppl_Volkswagen_Timeout(void)
{
    uint8_t i = 0;

    for(i = 0; i < NUM_CAN_RX_MESSAGES;i++)
    {
        if((T_Can_Rx_Msg[i].cnt != 0) && (ClockUtils_Elapsed_Time(T_Can_Rx_Msg[i].cnt) >= T_Can_Rx_Msg[i].timeout))
        {
            T_Can_Rx_Msg[i].cnt = 0;
            CanAppl_TimeoutMsg_Callback[i]();
        }
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_STATUS_BH_BCM1
 *
 * @brief      Handler thats controls the timeouts of the STATUS_BH_BCM1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mBSG_3(void)
{
    CanRxSignals.OperationalModeSts = OperationalModeSts_SNA;
    LOG_PRINT(DEBUG_CAN, "TimeOut > OperationalModeSts > %d  \n",CanRxSignals.OperationalModeSts);
    Shadow_Server_Storage_Set(SHADOW_OperationalModeSts, &CanRxSignals.OperationalModeSts);

    //BS3_PDC_Taster
    if (CanRxSignals.PdcButton != 0x00)
    {
        CanRxSignals.PdcButton = 0x00;
        //signal not working in sample amarok CANAppl_updateRVC();
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mSysteminfo_1
 *
 * @brief      Handler thats controls the timeouts of the mSysteminfo_1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mSysteminfo_1(void) {   
    LOG_PRINT(DEBUG_CAN, "TimeOut TransportMode Signal by CAN\r\n");
    CanRxSignals.TransportModeStatus_CAN = 0;   // Transport Mode SNA.
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeOutMsg_cSyncStatus_t
 *
 * @brief      Handler thats controls the timeouts of the cSyncStatus Messages
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_cSyncStatus_t(void) {
    
    // No action here, because cSyncStatus_t is not a periodical message. 
}

/***************************************************************************//**
 *
 * @fn         CanAppl_ProcessMsg_cValidationTone_t
 *
 * @brief      Handler thats controls the timeouts of the cValidationTone
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_cValidationTone_t(void) {

    // No action here, because cValidationTone is not a periodical message. 
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_STATUS_BH_BCM2
 *
 * @brief      Handler thats controls the timeouts of the STATUS_BH_BCM2
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mDimmung(void)
{

}


/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mRegen_Licht_Sensor
 *
 * @brief      Handler thats controls the timeouts of the mRegen_Licht_Sensor
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mRegen_Licht_Sensor(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_STATUS_CCAN3
 *
 * @brief      Handler thats controls the timeouts of the STATUS_CCAN3
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mLicht_1_alt(void)
{
    if (CanRxSignals.ReverseGearSts != ReverseGearSts_SNA)
    {
        CanRxSignals.ReverseGearSts = ReverseGearSts_SNA;
        LOG_PRINT(DEBUG_CAN, "TimeOut > ReverseGearSts > %d  \n",CanRxSignals.ReverseGearSts);
        Shadow_Server_Storage_Set(SHADOW_ReverseGearSts, &CanRxSignals.ReverseGearSts);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mMFL_Tasten
 *
 * @brief      Handler thats controls the timeouts of the mMFL_Tasten
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mMFL_Tasten(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mKombi_1
 *
 * @brief      Handler thats controls the timeouts of the mKombi_1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mKombi_1(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mKombi_K1
 *
 * @brief      Handler thats controls the timeouts of the mKombi_K1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mKombi_K1(void)
{
    CanRxSignals.ParkBrakeSts = 1;
    LOG_PRINT(DEBUG_CAN, "TimeOut > ParkBrakeSts > %d  \n",CanRxSignals.ParkBrakeSts);
    Shadow_Server_Storage_Set(SHADOW_ParkBrakeSts, &CanRxSignals.ParkBrakeSts);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_STATUS_BH_BCM2
 *
 * @brief      Handler thats controls the timeouts of the STATUS_BH_BCM2
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mDiagnose_1(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_STATUS_BH_BCM2
 *
 * @brief      Handler thats controls the timeouts of the STATUS_BH_BCM2
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mEinheiten(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_NWM_BCM1
 *
 * @brief      Handler thats controls the timeouts of the NWM_BCM1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_NWM_BCM1(void)
{
    CanRxSignals.NetworkActive = false;
    LOG_PRINT(DEBUG_CAN, "TimeOut > NetworkActive > %d  \n",CanRxSignals.NetworkActive);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mGW_Bremse_Getriebe
 *
 * @brief      Handler thats controls the timeouts of the mGW_Bremse_Getriebe
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mGW_Bremse_Getriebe(void)
{

    CanRxSignals.VehicleSpeedVSOSig = 0;
    Shadow_Server_Storage_Set(SHADOW_VehicleSpeedVSOSig, (uint8_t *)&CanRxSignals.VehicleSpeedVSOSig);

    //GWB_Info_Waehlhebel
    if (!CanRxSignals.ManualGearbox)
    {
        SetCanRxSignalGear("-");
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_STATUS_BH_BCM2
 *
 * @brief      Handler thats controls the timeouts of the STATUS_BH_BCM2
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_Parkhilfe_01(void)
{
    CanRxSignals.ParkingActive = DISABLE;
//    Shadow_Storage_Set(SHADOW_ParkingActive, &CanRxSignals.ParkingActive);

    if (CanRxSignals.ParkingAssistButton != 0x00)
    {
        CanRxSignals.ParkingAssistButton = 0x00;
        CANAppl_updateRVC();
        Shadow_Server_Storage_Set(SHADOW_ParkingAssistButton, &CanRxSignals.ParkingAssistButton);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_BAP_OPS
 *
 * @brief      Handler thats controls the timeouts of the BAP_OPS
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_BAP_OPS(void)
{

}


/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_BAP_ASG_07
 *
 * @brief      Handler thats controls the timeouts of the BAP_ASG_07
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_BAP_ASG_07(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mBSG_Kombi
 *
 * @brief      Handler thats controls the timeouts of the mBSG_Kombi
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/

static void CanAppl_TimeoutMsg_mBSG_Kombi(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mGateway_3
 *
 * @brief      Handler thats controls the timeouts of the mGateway_3
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mGateway_3(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_DiagPhysicalReq
 *
 * @brief      Handler thats controls the timeouts of the DiagPhysicalReq
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_DiagPhysicalReq(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_DiagFunctionalReq
 *
 * @brief      Handler thats controls the timeouts of the DiagFunctionalReq
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_DiagFunctionalReq(void)
{

}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mMFA_1
 *
 * @brief      Handler thats controls the timeouts of the mMFA_1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mMFA_1(void)
{
    //consumption
    if (CanRxSignals.InstConsumption != MAX_UINT16)
    {
        CanRxSignals.InstConsumption = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_InstConsumption,
                (uint8_t *) &CanRxSignals.InstConsumption);
    }

    //range
    if (CanRxSignals.Range != MAX_UINT16)
    {
        CanRxSignals.Range = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_Range,
                (uint8_t *) &CanRxSignals.Range);
    }

    //kilometerstand
    if (CanRxSignals.Kilometerstand != MAX_UINT32)
    {
        CanRxSignals.Kilometerstand = MAX_UINT32;
        Shadow_Server_Storage_Set(SHADOW_Kilometerstand,
                (uint8_t *) &CanRxSignals.Kilometerstand);
    }

    //reserverange
    if (CanRxSignals.ReserveRange != MAX_UINT8)
    {
        CanRxSignals.ReserveRange = MAX_UINT8;
        Shadow_Server_Storage_Set(SHADOW_ReserveRange,
                (uint8_t *) &CanRxSignals.ReserveRange);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mMFA_2
 *
 * @brief      Handler thats controls the timeouts of the mMFA_2
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mMFA_2(void)
{
    //consumption
    if (CanRxSignals.ShortTermConsumption != MAX_UINT16)
    {
        CanRxSignals.ShortTermConsumption = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_ShortTermConsumption,
                (uint8_t *) &CanRxSignals.ShortTermConsumption);
    }

    //distance
    if (CanRxSignals.ShortTermDistance != MAX_UINT16)
    {
        CanRxSignals.ShortTermDistance = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_ShortTermDistance,
                (uint8_t *) &CanRxSignals.ShortTermDistance);
    }

    //time
    if (CanRxSignals.ShortTermTime != MAX_UINT16)
    {
        CanRxSignals.ShortTermTime = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_ShortTermTime,
                (uint8_t *) &CanRxSignals.ShortTermTime);
    }

    //avspeed
    if (CanRxSignals.ShortTermAvSpeed != MAX_UINT16)
    {
        CanRxSignals.ShortTermAvSpeed = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_ShortTermAvSpeed,
                (uint8_t *) &CanRxSignals.ShortTermAvSpeed);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mMFA_3
 *
 * @brief      Handler thats controls the timeouts of the mMFA_3
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mMFA_3(void)
{
    //consumption
    if (CanRxSignals.LongTermConsumption != MAX_UINT16)
    {
        CanRxSignals.LongTermConsumption = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_LongTermConsumption,
                (uint8_t *) &CanRxSignals.LongTermConsumption);
    }

    //distance
    if (CanRxSignals.LongTermDistance != MAX_UINT16)
    {
        CanRxSignals.LongTermDistance = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_LongTermDistance,
                (uint8_t *) &CanRxSignals.LongTermDistance);
    }

    //time
    if (CanRxSignals.LongTermTime != MAX_UINT16)
    {
        CanRxSignals.LongTermTime = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_LongTermTime,
                (uint8_t *) &CanRxSignals.LongTermTime);
    }

    //avspeed
    if (CanRxSignals.LongTermAvSpeed != MAX_UINT16)
    {
        CanRxSignals.LongTermAvSpeed = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_LongTermAvSpeed,
                (uint8_t *) &CanRxSignals.LongTermAvSpeed);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mFzg_Ident
 *
 * @brief      Handler thats controls the timeouts of the mFzg_Ident
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mFzg_Ident(void)
{
    memset(CanRxSignals.ChassisNumber, '/0', 18);
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mLenkwinkel_1
 *
 * @brief      Handler thats controls the timeouts of the mLenkwinkel_1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mLenkwinkel_1(void)
{
    //LW1_Lenkradwinkel
    //LW1_Vorzeichen
    if (CanRxSignals.SteeringWheelAngle != MAX_INT16)
    {
        CanRxSignals.SteeringWheelAngle = MAX_INT16;
        Shadow_Server_Storage_Set(SHADOW_SteeringWheelAngle,
                (uint8_t *) &CanRxSignals.SteeringWheelAngle);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mGW_Motor
 *
 * @brief      Handler thats controls the timeouts of the mGW_Motor
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mGW_Motor(void)
{
    //GWM_Motordrehzahl
    if (CanRxSignals.RPM != MAX_UINT16)
    {
        CanRxSignals.RPM = MAX_UINT16;
        Shadow_Server_Storage_Set(SHADOW_RPM,
                (uint8_t *) &CanRxSignals.RPM);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mFzg_mGW_ANT_2
 *
 * @brief      Handler thats controls the timeouts of the mGW_ANT_2
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mGW_ANT_2(void)
{
    //GE2_Variante
    if (CanRxSignals.ManualGearbox)
    {
        SetCanRxSignalGear("-");
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mGW_ANT_1
 *
 * @brief      Handler thats controls the timeouts of the mGW_ANT_1
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mGW_ANT_1(void)
{
    // do nothing
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mBremse_10
 *
 * @brief      Handler thats controls the timeouts of the mBremse_10
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mBremse_10(void)
{
    // do nothing
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mGW_Kombi
 *
 * @brief      Handler thats controls the timeouts of the mGW_Kombi
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mGW_Kombi(void)
{
    // do nothing
}

/***************************************************************************//**
 *
 * @fn         CanAppl_TimeoutMsg_mMotor7
 *
 * @brief      Handler thats controls the timeouts of the mMotor7
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_TimeoutMsg_mMotor7(void)
{
    //MO7_Oeltemperatur
    if (CanRxSignals.OilTemperature != MAX_INT16)
    {
        CanRxSignals.OilTemperature = MAX_INT16;
        Shadow_Server_Storage_Set(SHADOW_OilTemperature,
                (uint8_t *) &CanRxSignals.OilTemperature);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_SetTimeDate
 *
 * @brief      Set Time Date with values received via CAN.
 *
 * @param [in] TD_TimeDate_T* timedate
 *
 * @return     void
 *
 ******************************************************************************/
static void CanAppl_SetTimeDate(void)
{
    /* Date update */
    timedate.rtc_year   = (CanRxSignals.Year1) * 100;
    timedate.rtc_year   += (CanRxSignals.Year2) * 10;
    timedate.rtc_year   += (CanRxSignals.Year3);
    timedate.rtc_month  = (CanRxSignals.Month1) * 10;
    timedate.rtc_month  += (CanRxSignals.Month2);
    timedate.rtc_day    = (CanRxSignals.Day1) * 10;
    timedate.rtc_day    += (CanRxSignals.Day2);

    /* Time update */
    timedate.rtc_hour   = (CanRxSignals.Hour1) * 10;
    timedate.rtc_hour   += (CanRxSignals.Hour2);
    timedate.rtc_minute = (CanRxSignals.Minute1) * 10;
    timedate.rtc_minute += (CanRxSignals.Minute2);
    timedate.rtc_sec    = (CanRxSignals.Second1) * 10;
    timedate.rtc_sec    += (CanRxSignals.Second2);


    if( CanRxSignals.hr_mode == 0 )
    {
        timedate.rtc_hr_mode =  hr_mode_24h;
    }
    else
    {
        // The time received via CAN is always in 24 hs mode but msp work in am/pm
        if(timedate.rtc_hour > 12)
        {
            timedate.rtc_hour = timedate.rtc_hour - 12;
            timedate.rtc_hr_mode =  hr_mode_pm;
        }
        else
        {
            timedate.rtc_hr_mode =  hr_mode_am;
        }
    }


    TD_SetTimeDatebyCAN( &timedate );

    LOG_PRINT(DEBUG_CAN,"%d/%d/%d %d:%d:%d   (%d) \n",  timedate.rtc_year,timedate.rtc_month,timedate.rtc_day,
                                                        timedate.rtc_hour,timedate.rtc_minute,timedate.rtc_sec,
                                                        timedate.rtc_hr_mode);

    // Shadow_Server_Storage_Set(SHADOW_Year3, &CanRxSignals.Year3);   Shadow is update in TD_Update()
}

/***************************************************************************//**
 *
 * @fn         CANAppl_Volkswagen_Disable_Appl_TX_Messages
 *
 * @brief      Determine whether to enable or disable Appl transmit
 *             messages, based on diagnostic commands.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CANAppl_Volkswagen_Disable_Appl_TX_Messages (bool_t disable_transmit)
{
    Disable_Appl_TX_Messages = disable_transmit;
}

/***************************************************************************//**
 *
 * @fn         CANAppl_Volkswagen_Disable_BAP_TX_Messages
 *
 * @brief      Determine whether to enable or disable BAP
 *             messages, based on diagnostic commands.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CANAppl_Volkswagen_Disable_BAP_TX_Messages (bool_t disable_transmit)
{
    Disable_BAP_TX_Messages = disable_transmit;
}

/***************************************************************************//**
 *
 * @fn         CAN_Volkswagen_Disable_NM_TX_Messages
 *
 * @brief      Determine whether to enable or disable NM messages,
 *             based on diagnostic commands.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CANAppl_Volkswagen_Disable_NM_TX_Messages (bool_t disable_transmit)
{
    Disable_NM_TX_Messages = disable_transmit;
}


void CANAppl_Volkswagen_NWM_RNS_Tx_Message(void)
{
    uint8_t data[8];
    uint8_t sleep_ack;
    uint8_t klemme_15;

    // Initialize NWM_RNS message data
    memset(data,0x00,8);

    // NWM_RNS_CmdRing always set to 1
    data[NWM_RNS_CMD_RING_BYTE] |= (1 << NWM_RNS_CMD_RING_OFFSET);

    // NWM_RNS_SleepInd always set to 1
    data[NWM_RNS_SLEEP_IND_BYTE] |= (1 << NWM_RNS_SLEEP_IND_OFFSET);

    // NWM_RNS_SleepAck set
    sleep_ack = (CanTxSignals.NWM_RNS_SleepAck) ? 1 : 0;
    data[NWM_RNS_SLEEP_ACK_BYTE] |= (sleep_ack << NWM_RNS_SLEEP_IND_OFFSET);

    // Kl15 set following mBSG_3 message
    klemme_15 = (CanTxSignals.NWM_RNS_Klemme_15) ? 1 : 0;
    data[NWM_RNS_KLEMME_15_BYTE] |= (klemme_15 << NWM_RNS_KLEMME_15_OFFSET);

    Can_Tx_Message (NWM_RNS_ID, data, 8);
}

/*******************************************************************************
 * FUNCTION:      CANAppl_SendTestMsgOnEvent                                   *
 * DESCRIPTION:   Debug function to send data through CAN                      *
 * PARAMETERS:    data buffer and data length                                  *
 * RETURN VALUE:  Nothing                                                      *
 *******************************************************************************/
void CANAppl_SendTestMsgOnEvent(uint8_t* data, uint8_t length)
{
    uint8_t buffer[8];
    if(length<8)
    {
        memcpy(buffer, data, length);
    }

    Can_Tx_Message (TestMsgOnEvent_ID, buffer, 8);
}

/*******************************************************************************
 * FUNCTION:      CANAppl_SendSyncResponse                                     *
 * DESCRIPTION:   Send CAN response to the message that is asking about sync.  *
 *                The function must provide a buffer to store data that we     *
 *                want to send in our response. Be careful because this buffer *
 *                must be at least 8 bytes long, no matter if our response     *
 *                is shorter than that.                                        *
 * PARAMETERS:    void                                                         *
 * RETURN VALUE:  void                                                         *
 *******************************************************************************/
void CANAppl_SendSyncResponse(void) {

    uint8_t buffer[8];

    memset(buffer, 0xFF, 8);
    Can_Tx_Message (cSyncStatusResponse_t_ID, buffer,2);
}

/***************************************************************************//**
 *
 * @fn         CANAppl_updateRVC
 *
 * @brief      Update RVC shared RAM variable
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void CANAppl_updateRVC (void)
{
    static uint32_t last_pdc_key = 0;
    static uint32_t last_rvc = 0;
    uint32_t pdc = CanRxSignals.ParkingAssistButton;
    uint32_t rvc = CanRxSignals.ReverseGearSts;
    //ParkingAssistButton is really PH_Anf_Audioabsenkung (Request to the audio system
    // to lower the volume) this signal is activated for both reverse or PDC button.
    //and can be turn off/on pushing the PDC button.
    //RVC app must show ṔDC or RVC view pedending of CanRxSignals.ReverseGearSts signal
    if ((pdc != last_pdc_key) || (rvc != last_rvc))
    {
        last_pdc_key = pdc;
        last_rvc = rvc;
        FAMP_PM_Inform_RvcPdc_View_On(HmiManager_get_adas_view_on(__internal_detected_car, pdc, rvc));
        Semaphore_pend(rvc_sem, BIOS_WAIT_FOREVER);
        __internal_pdc_key_state = pdc ? true : false;
        __internal_rvc_state = rvc ? true : false;
        HmiManager_set_pdc_key_state(__internal_pdc_key_state);
        HmiManager_set_rvc_state(__internal_rvc_state);
        Semaphore_post(rvc_sem);
    }
}

/***************************************************************************//**
 *
 * @fn         CanAppl_SetCarModel
 *
 * @brief      set CarModel OffroadEnable signal and write shadow
 *
 * @param [in] Shadow_CarModel_T car_model
 *
 ******************************************************************************/
static void CanAppl_SetCarModel(Shadow_CarModel_T car_model)
{
    if (CanRxSignals.CarModel != car_model)
    {
        CanRxSignals.CarModel = car_model;
        Shadow_Server_Storage_Set(
                SHADOW_CarModel, (uint8_t *) &CanRxSignals.CarModel);
    }
    uint8_t offroadEnable = (CanRxSignals.CarModel == CAR_MODEL_VW_POLO) ? 0 : 1;
    if (CanRxSignals.OffroadEnable != offroadEnable)
    {
        CanRxSignals.OffroadEnable = offroadEnable;
        Shadow_Server_Storage_Set(
                SHADOW_OffroadEnable, (uint8_t *) &CanRxSignals.OffroadEnable);
    }
}