#ifndef ANTPWR_H_
#define ANTPWR_H_
/*===========================================================================*/
/**
 * @file ANTPWR.h
 *
 * Function definitions for the Antenna Power interface module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <stdint.h>

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum AntPwr_Ctrl_Tag
{
    ANTPWR_ENABLE,
    ANTPWR_DISABLE
}AntPwr_Ctrl_T;

typedef enum AntPwr_Status_Tag
{
   ANTPWR_OK,
   ANTPWR_OPEN_CIRCUIT,
   ANTPWR_SC_TO_GND,
   ANTPWR_THERMAL_SHUTDOWN,
   ANTPWR_SC_TO_VBAT,
   ANTPWR_NOT_INIT
}AntPwr_Status_T;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
void AntPwr_Init (void);
void AntPwr_Update (void);
AntPwr_Status_T AntPwr_FMAM_Get_Status (void);
void AntPwr_Run_Test (void);
void check_AntMicTest_Finished(void);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file ANTPWR.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 05-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* ANTPWR_H_ */
