/*===========================================================================*/
/**
 * @file antpwr.c
 *
 * Antenna Power control interface
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <antpwr.h>
#include <antpwr_cfg.h>

#include <drv/board/board.h>
#include <comm_protocol.h>
#include <console.h>
#include <conversions.h>
#include <shadow_storage.h>

#include <ti/csl/soc.h>
#include <ti/csl/csl_gpio.h>
#include <ti/csl/hw_types.h>
#include <xdc/runtime/System.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/BIOS.h>
#include <micbias.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define MIN_AD_COUNTS         0x0
#define MAX_AD_COUNTS         0x03FF

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef enum cs_antpwr_tag
{
    CS_ANTPWR_INIT,
    CS_ANTPWR_CHECK_DIAG,
    CS_ANTPWR_WAITING_TO_CHECK_DIAG_AGAIN,
    CS_ANTPWR_ERROR
}cs_antpwr_t;

typedef struct AntPwr_Diag_Tag
{
   uint16_t v_min;
   uint16_t v_max;
   AntPwr_Status_T antpwr_status;
}AntPwr_Diag_T;

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
uint8_t antpwr_fmam_err_cnt;
uint8_t antpwr_gps_err_cnt;

cs_antpwr_t cs_antpwr_fmam;
cs_antpwr_t cs_antpwr_gps;

AntPwr_Status_T antpwr_fmam_status = ANTPWR_NOT_INIT;
AntPwr_Status_T antpwr_gps_status = ANTPWR_NOT_INIT;

static Semaphore_Handle antpwr_sem = NULL;

static uint8_t ant_mic_test_finished = 0;
static bool ant_mic_test_in_progress = false;

#undef X
#define X(a,b,c) {a,b,c},
static AntPwr_Diag_T antpwr_fmam_diag[] = {ANTPWR_FMAM_V_TABLE};
static AntPwr_Diag_T antpwr_gps_diag[] = {ANTPWR_GPS_V_TABLE};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
void AntPwr_FMAM_Ctrl (AntPwr_Ctrl_T enable);
void AntPwr_GPS_Ctrl (AntPwr_Ctrl_T enable);
void AntPwr_SENSE_EN (AntPwr_Ctrl_T enable);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
*
* @fn         AntPwr_Init
*
* @brief      Initialization function
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void AntPwr_Init (void)
{
    GPIOModuleEnable(ANT_FMAM_PWR_GPIO_ADDR);
    GPIOModuleEnable(ANT_GPS_PWR_GPIO_ADDR);
    GPIOModuleEnable(ANT_SENSE_EN_GPIO_ADDR);

    /* Set pins as output */
    GPIODirModeSet(ANT_FMAM_PWR_GPIO_ADDR, ANT_FMAM_PWR_GPIO_PIN, GPIO_DIR_OUTPUT);
    GPIODirModeSet(ANT_GPS_PWR_GPIO_ADDR, ANT_GPS_PWR_GPIO_PIN, GPIO_DIR_OUTPUT);
    GPIODirModeSet(ANT_SENSE_EN_GPIO_ADDR, ANT_SENSE_EN_GPIO_PIN, GPIO_DIR_OUTPUT);

    /* Put to low so they all start off */
    GPIOPinWrite(ANT_FMAM_PWR_GPIO_ADDR, ANT_FMAM_PWR_GPIO_PIN, GPIO_PIN_LOW);
    GPIOPinWrite(ANT_GPS_PWR_GPIO_ADDR, ANT_GPS_PWR_GPIO_PIN, GPIO_PIN_LOW);
    GPIOPinWrite(ANT_SENSE_EN_GPIO_ADDR, ANT_SENSE_EN_GPIO_PIN, GPIO_PIN_LOW);

    AntPwr_SENSE_EN(ANTPWR_ENABLE);

    cs_antpwr_fmam = CS_ANTPWR_INIT;
    cs_antpwr_gps = CS_ANTPWR_INIT;

    antpwr_sem = Semaphore_create(1, NULL, NULL);
}

/***************************************************************************//**
*
* @fn         AntPwr_SENSE_EN
*
* @brief      Enable the Current sense
*
* @param [in] enable
*
* @return     None
*
******************************************************************************/
void AntPwr_SENSE_EN (AntPwr_Ctrl_T enable)
{
    if(ANTPWR_ENABLE == enable)
    {
        GPIOPinWrite(ANT_SENSE_EN_GPIO_ADDR, ANT_SENSE_EN_GPIO_PIN, GPIO_PIN_LOW);
    }
    else
    {
        GPIOPinWrite(ANT_SENSE_EN_GPIO_ADDR, ANT_SENSE_EN_GPIO_PIN, GPIO_PIN_HIGH);
    }
}

/***************************************************************************//**
*
* @fn         AntPwr_FMAM_Ctrl
*
* @brief      Power up the FMAM antenna
*
* @param [in] enable
*
* @return     None
*
******************************************************************************/
void AntPwr_FMAM_Ctrl (AntPwr_Ctrl_T enable)
{
    if(ANTPWR_ENABLE == enable)
    {
        GPIOPinWrite(ANT_FMAM_PWR_GPIO_ADDR, ANT_FMAM_PWR_GPIO_PIN, GPIO_PIN_HIGH);
    }
    else
    {
        GPIOPinWrite(ANT_FMAM_PWR_GPIO_ADDR, ANT_FMAM_PWR_GPIO_PIN, GPIO_PIN_LOW);
    }
}

/***************************************************************************//**
*
* @fn         AntPwr_GPS_Ctrl
*
* @brief      Power up the FMAM antenna
*
* @param [in] enable
*
* @return     None
*
******************************************************************************/
void AntPwr_GPS_Ctrl (AntPwr_Ctrl_T enable)
{
    if(ANTPWR_ENABLE == enable)
    {
        GPIOPinWrite(ANT_GPS_PWR_GPIO_ADDR, ANT_GPS_PWR_GPIO_PIN, GPIO_PIN_HIGH);
    }
    else
    {
        GPIOPinWrite(ANT_GPS_PWR_GPIO_ADDR, ANT_GPS_PWR_GPIO_PIN, GPIO_PIN_LOW);
    }
}

/***************************************************************************//**
*
* @fn         AntPwr_Update
*
* @brief      Update the antenna diag state
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void AntPwr_Update (void)
{
    int i;
    uint32_t value;
    uint32_t voltage;
    AntPwr_Status_T antpwr_fmam_status_temp;
    AntPwr_Status_T antpwr_gps_status_temp;

    Semaphore_pend(antpwr_sem, BIOS_WAIT_FOREVER);
    switch(cs_antpwr_fmam)
    {
        case CS_ANTPWR_INIT:
            antpwr_fmam_err_cnt = 0;
            AntPwr_FMAM_Ctrl(ANTPWR_ENABLE);
            cs_antpwr_fmam = CS_ANTPWR_CHECK_DIAG;
            break;

        case CS_ANTPWR_CHECK_DIAG:
            value = COMM_Protocol_GetADStatus(AD_CHANNEL_ANT_FMAM_DIAG);
            voltage = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);
            LOG_PRINT_INFO(DEBUG_ANTPWR, "Antenna FMAM value = %d\r\n", value);
            LOG_PRINT_INFO(DEBUG_ANTPWR, "Antenna FMAM voltage = %d\r\n", voltage);

            /* Look for the current antpwr_fmam status */
            for(i=0; i<Num_Elems(antpwr_fmam_diag); i++)
            {
                if( (voltage  >= antpwr_fmam_diag[i].v_min)  &&
                    (voltage  <= antpwr_fmam_diag[i].v_max) )
                {
                    /* voltage error condition founded */
                    antpwr_fmam_status_temp = antpwr_fmam_diag[i].antpwr_status;
                    break;
                }
            }

            if(ANTPWR_OK != antpwr_fmam_status_temp)
            {
                AntPwr_FMAM_Ctrl(ANTPWR_DISABLE);
                antpwr_fmam_err_cnt++;
                if (antpwr_fmam_err_cnt >= ANTPWR_FMAM_ERR_CNT_MAX)
                {
                    cs_antpwr_fmam = CS_ANTPWR_ERROR;
                    LOG_PRINT_INFO(DEBUG_ANTPWR, "Antenna Error = %d\r\n", antpwr_fmam_status_temp);
                }
                else
                {
                    cs_antpwr_fmam = CS_ANTPWR_WAITING_TO_CHECK_DIAG_AGAIN;
                    antpwr_fmam_status_temp = antpwr_fmam_status;
                }
            }
            else
            {
                antpwr_fmam_err_cnt = 0;
            }

            //if there is a change set the update shadow storage
            if (antpwr_fmam_status != antpwr_fmam_status_temp)
            {
                Shadow_Server_Storage_Set(SHADOW_AntPwr_FMAM_Sts, (uint8_t *)&antpwr_fmam_status_temp);
                antpwr_fmam_status = antpwr_fmam_status_temp;
            }
            break;

        case CS_ANTPWR_WAITING_TO_CHECK_DIAG_AGAIN:
            AntPwr_FMAM_Ctrl(ANTPWR_ENABLE);
            cs_antpwr_fmam = CS_ANTPWR_CHECK_DIAG;
            break;

        case CS_ANTPWR_ERROR:
            break;

        default:
            break;
    }

    switch(cs_antpwr_gps)
    {
        case CS_ANTPWR_INIT:
            antpwr_gps_err_cnt = 0;
            AntPwr_GPS_Ctrl(ANTPWR_ENABLE);
            cs_antpwr_gps = CS_ANTPWR_CHECK_DIAG;
            break;

        case CS_ANTPWR_CHECK_DIAG:
#ifdef IGNORE_ANTPWR_GPS_DIAGNOSTIC
            antpwr_gps_status_temp = ANTPWR_OK;
#else
            value = COMM_Protocol_GetADStatus(AD_CHANNEL_ANT_GPS_DIAG);
            voltage = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);
            LOG_PRINT_INFO(DEBUG_ANTPWR, "Antenna GPS value = %d\r\n", value);
            LOG_PRINT_INFO(DEBUG_ANTPWR, "Antenna GPS voltage = %d\r\n", voltage);

            /* Look for the current antpwr_fmam status */
            for(i=0; i<Num_Elems(antpwr_gps_diag); i++)
            {
                if( (voltage  >= antpwr_gps_diag[i].v_min)  &&
                    (voltage  <= antpwr_gps_diag[i].v_max) )
                {
                    /* voltage error condition founded */
                    antpwr_gps_status_temp = antpwr_gps_diag[i].antpwr_status;
                    break;
                }
            }

            if(antpwr_gps_status_temp != ANTPWR_OK)
            {
                AntPwr_GPS_Ctrl(ANTPWR_DISABLE);
                antpwr_gps_err_cnt++;
                if (antpwr_gps_err_cnt >= ANTPWR_GPS_ERR_CNT_MAX)
                {
                    cs_antpwr_gps = CS_ANTPWR_ERROR;
                    LOG_PRINT_INFO(DEBUG_ANTPWR, "Antenna Error = %d\r\n", antpwr_gps_status_temp);
                }
                else
                {
                    antpwr_gps_status_temp = antpwr_gps_status;
                    cs_antpwr_gps = CS_ANTPWR_WAITING_TO_CHECK_DIAG_AGAIN;
                }
            }
            else
            {
                antpwr_gps_err_cnt = 0;
            }
#endif

            //if there is a change set the update shadow storage
            if (antpwr_gps_status != antpwr_gps_status_temp)
            {
                Shadow_Server_Storage_Set(SHADOW_AntPwr_GPS_Sts, (uint8_t *)&antpwr_gps_status_temp);
                antpwr_gps_status = antpwr_gps_status_temp;
            }
            break;

        case CS_ANTPWR_WAITING_TO_CHECK_DIAG_AGAIN:
            AntPwr_GPS_Ctrl(ANTPWR_ENABLE);
            cs_antpwr_gps = CS_ANTPWR_CHECK_DIAG;
            break;

        case CS_ANTPWR_ERROR:
            break;

        default:
            break;
    }
    Semaphore_post(antpwr_sem);
    check_AntMicTest_Finished();
}

/***************************************************************************//**
*
* @fn         AntPwr_FMAM_Get_Status
*
* @brief      Return the FMAM antenna status
*
* @param [in] None
*
* @return     AntPwr_Status_T
*
******************************************************************************/
AntPwr_Status_T AntPwr_FMAM_Get_Status (void)
{
    return (antpwr_fmam_status);
}

/***************************************************************************//**
*
* @fn         AntPwr_Run_Test
*
* @brief      The eng app is requesting a new test
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void AntPwr_Run_Test (void)
{
    //reset test ready signal
    ant_mic_test_in_progress = true;

    Semaphore_pend(antpwr_sem, BIOS_WAIT_FOREVER);
    //ant fmam
    antpwr_fmam_status = ANTPWR_NOT_INIT;
    cs_antpwr_fmam = CS_ANTPWR_INIT;

    //ant gps
    antpwr_gps_status = ANTPWR_NOT_INIT;
    cs_antpwr_gps = CS_ANTPWR_INIT;

    Semaphore_post(antpwr_sem);
}

/***************************************************************************//**
*
* @fn         check_AntMicTest_Finished
*
* @brief      Tell the eng app the test is complete
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void check_AntMicTest_Finished(void)
{
    //test if finished and write the signal
    if (ant_mic_test_in_progress &&
        (antpwr_fmam_status != ANTPWR_NOT_INIT) &&
        (antpwr_gps_status != ANTPWR_NOT_INIT)  &&
        (MicBias_Get_Status() != MIC_NOT_INIT))
    {
        ant_mic_test_in_progress = false;
        //toogle the signal when the test is finish
        ant_mic_test_finished = (ant_mic_test_finished == 0) ? 1 : 0;
        Shadow_Server_Storage_Set(SHADOW_AntMicTestFinished, (uint8_t *)&ant_mic_test_finished);
    }
}
