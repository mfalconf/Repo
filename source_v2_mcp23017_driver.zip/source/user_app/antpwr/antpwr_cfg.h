#ifndef ANTPWR_CFG_H
#   define ANTPWR_CFG_H
/*===========================================================================*/
/**
 * @file antpwr_cfg.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:micbias_cfg.h~2:incl:kok_basa#1 %
 * @version %version:2 %
 * @author  %derived_by:fzdbm3 %
 * @date    %date_modified:Fri Nov 29 15:26:54 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2013 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * #define Constants
 *===========================================================================*/
#define MAX_VOLTAGE                 3300

#define AD_CHANNEL_ANT_FMAM_DIAG    5
#define AD_CHANNEL_ANT_GPS_DIAG     4

#define ANTPWR_FMAM_ERR_CNT_MAX     3
#define ANTPWR_GPS_ERR_CNT_MAX      3

/*===========================================================================*
 * #define MACROS
 *===========================================================================*/
/*---------------------------------------------------------------------*\
 * Set up mic_diag voltage table
\*---------------------------------------------------------------------*/
/* define under a) v_min                            */
/* define under b) v_max                            */
/* define under c) antenna_status                   */

/*    a      b     c                                */
#define ANTPWR_FMAM_V_TABLE\
   X( 0     ,49   ,ANTPWR_OPEN_CIRCUIT          )\
   X( 50    ,2449 ,ANTPWR_OK                    )\
   X( 2450  ,2649 ,ANTPWR_SC_TO_GND             )\
   X( 2650  ,2949 ,ANTPWR_THERMAL_SHUTDOWN      )\
   X( 2950  ,3300 ,ANTPWR_SC_TO_VBAT            )\

/*    a      b     c                                */
#define ANTPWR_GPS_V_TABLE\
   X( 0     ,39   ,ANTPWR_OPEN_CIRCUIT          )\
   X( 40    ,2499 ,ANTPWR_OK                    )\
   X( 2500  ,2600 ,ANTPWR_SC_TO_GND             )\
   X( 2650  ,2949 ,ANTPWR_THERMAL_SHUTDOWN      )\
   X( 3100  ,3200 ,ANTPWR_SC_TO_VBAT            )\

/*===========================================================================*
 * Custom Type Declarations
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file antpwr_cfg.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 07-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* ANTPWR_CFG_H */
