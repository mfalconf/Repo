#ifndef CAN_DIAG_RDI_CFG_H
#define CAN_DIAG_RDI_CFG_H
/*===========================================================================*/
/**
 * @file can_diag_rdi_cfg.h
 *
 * Table definition for the available ReadDataByidentifier and WriteDataByIdentifier
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
/* RDI_TABLE is used to control which RDIs are supported for reads (mode $22)
 * and writes (mode $2E).
 *
 * RDI: recordDataIdentifier
 *      Enter the RDI, with the format 0xYYZZ ( 2 bytes ).
 *
 * Length: Data length of the response for Reading, and data length of the request for Writing.
 *    If 0 there's no length verification for Writing.
 *
 * RDI Read Routine:
 *    For reads, this function name can be used instead of the variable shadow storage.
 * Physical Msg Required For Read:
 *    Enter true if functional messages are not allowed to read the RDI.
 *    (Functional messages are never allowed to write an RDI, and is prevented
 *    in diag_hdlr.c instead of here).
 * Write Allowed:
 *    Indicates whether a write (mode $2E) is also allowed.  All writes require
 *    an address hard-coded in the table or a write routine.
 *    Enter NO if writes not allowed, YES if allows allowed, or SECURE if allowed
 *    when radio is unlocked.
 * RDI Write Routine:
 *    If a write routine is entered, the write routine handles it.
*/

#define RDI_TABLE \
/*                                                                           Phys Msg                                              */ \
/*             (R)RespLength                                                 Required    Write                                     */ \
/*   RDI       (W)ReqLength     RDI Read Routine                             For Read    Allowed  RDI Write Routine                */ \
/*   -------   --------         ---------------------------------            --------    -------  ---------------------------      */ \
   X(0xF186,   1,               diag_rdi_read_active_diag_session,           false,      NO,      NULL)                               \
   X(0xF100,   7,               diag_rdi_read_diag_identification,           true,       NO,      NULL)                               \
   X(0xF132,   10,              diag_rdi_read_ecu_part_number,               true,       NO,      NULL)                               \
   X(0xF10D,   4,               diag_rdi_read_diag_specifcation_info,        true,       NO,      NULL)                               \
   X(0xF154,   2,               diag_rdi_read_hard_supplier_identification,  true,       NO,      NULL)                               \
   X(0xF155,   2,               diag_rdi_read_soft_supplier_identification,  true,       NO,      NULL)                               \
   X(0x2023,   0,               NULL,                                        true,       YES,     diag_rdi_write_test_data )          \

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/* Read functions   */
uint8_t diag_rdi_read_active_diag_session (uint8_t *data, uint8_t num_bytes);
uint8_t diag_rdi_read_diag_identification(uint8_t *data, uint8_t num_bytes);
uint8_t diag_rdi_read_ecu_part_number(uint8_t *data, uint8_t num_bytes);
uint8_t diag_rdi_read_diag_specifcation_info(uint8_t *data, uint8_t num_bytes);
uint8_t diag_rdi_read_hard_supplier_identification(uint8_t *data, uint8_t num_bytes);
uint8_t diag_rdi_read_soft_supplier_identification(uint8_t *data, uint8_t num_bytes);

/* Write functions   */
uint8_t diag_rdi_write_test_data (uint8_t *data, uint8_t num_bytes);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file CAN_DIAG_RDI_CFG.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 01-May-2020 Pablo Luis Joaquim
 *   - Created initial file based in B7 - can_diag module
 *
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* CAN_DIAG_RDI_CFG_H */
