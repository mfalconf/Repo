/*===========================================================================*/
/**
 * @file can_diag_dtc_callouts.c
 *
 * UDS Services callouts
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"
#include "can_diag.h"
#include "can_diag_dtc_cfg.h"

/* Include other necessary files */
#include "antpwr.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         diag_dtc_periodic_failure_tests_10ms
 *
 * @brief      Handler for dtc tests called only one time, once the ignition is detected
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void diag_dtc_first_failure_tests (void)
{

}

/***************************************************************************//**
 *
 * @fn         diag_dtc_periodic_failure_tests_10ms
 *
 * @brief      Handler for dtc periodic tests - called every 10ms
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void diag_dtc_periodic_failure_tests_10ms (void)
{

}

/***************************************************************************//**
 *
 * @fn         diag_dtc_periodic_failure_tests_1000ms
 *
 * @brief      Handler for dtc periodic tests - called every 1 second
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void diag_dtc_periodic_failure_tests_1000ms (void)
{
    bool_t open_status = false;
    bool_t short_status = false;

    switch(AntPwr_FMAM_Get_Status())
    {
        case ANTPWR_OK:
            break;
        case ANTPWR_OPEN_CIRCUIT:
            open_status = true;
            break;
        case ANTPWR_SC_TO_GND:
        case ANTPWR_THERMAL_SHUTDOWN:
        case ANTPWR_SC_TO_VBAT:
            short_status = true;
            break;
        default:
            break;
    }

    Diag_DTC_Set(DTC_ANTENNA_OPEN,    open_status);         /* (0x800000 + 0x157813)   */
    Diag_DTC_Set(DTC_ANTENNA_SHORT,   short_status);        /* (0x800000 + 0x15781A)   */
}
