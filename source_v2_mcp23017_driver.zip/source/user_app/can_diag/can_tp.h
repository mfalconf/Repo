#ifndef CAN_TP_H
#define CAN_TP_H
/*===========================================================================*/
/**
 * @file CAN_TP.h
 *
 * This file contains macros and types required for can_tp.c
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#define FRAME_TYPE_MASK                                                     0xF0
#define FLOW_STATUS_MASK                                                    0x0F
#define SEQUENCE_NUMBER_MASK                                                0x0F
#define SINGLE_FRAME_DATA_LENGTH_MASK                                       0x0F
#define FIRST_FRAME_DATA_LENGTH_MSB_NIBBLE_MASK                             0x0F
#define SEQUENCE_NUMBER_MAX                                                 0x10
#define CAN_FRAME_BYTES_UPPER_RANGE                                            7
#define ZERO_LOOP_COUNT                                                        0
#define ONE_LOOP_COUNT                                                         1
#define TWO_LOOP_COUNT                                                         2
#define MINIMUM_FIRST_FRAME_DATA_LENGTH                                        8

#ifdef RX_MULTI_BUFFER_SUPPORT
  #define RECEIVE_MULTI_BUFFER_SUPPORT                                     TRUE
#else
  #define RECEIVE_MULTI_BUFFER_SUPPORT                                    FALSE
#endif

#define NW_DLC_MAX_BYTES                                                      8
/* number of bytes to represent N_PCI in a sinlge frame */
#define SINGLE_FRAME_N_PCI_BYTE                                               1
/* maximum number of data bytes in a single frame */
#define MAXIMUM_SINGLE_FRAME_DATA_BYTE                                        7
/* Two N_PCI + six data bytes in a first frame */
#define FIRST_FRAME_N_PCI_PLUS_DATA_BYTE                                      8
/* maximum number of data  bytes in a consecutive frame */
#define CONSECUTIVE_FRAME_N_PCI_BYTE                                          1
#define CONSECUTIVE_FRAME_DATA_BYTE                                           7
/* One N_PCI + seven data  bytes in a consecutive frame */
#define CONSECUTIVE_FRAME_N_PCI_PLUS_DATA_BYTE                                8
/* Three N_PCI  bytes in a   flow control frame */
#define FLOW_CONTROL_N_PCI_PLUS_DATA_BYTE                                     3
/* Three N_PCI  bytes in a   flow control frame */
/* Frame buffer size  */
#define FRAME_DATA_SIZE                                                       8

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define N_As_TIMER_COUNT   N_As_TIME_OUT/CALL_RATE
#define N_Ar_TIMER_COUNT   N_Ar_TIME_OUT/CALL_RATE
#define N_Bs_TIMER_COUNT   N_Bs_TIME_OUT/CALL_RATE
#define N_Cr_TIMER_COUNT   N_Cr_TIME_OUT/CALL_RATE

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum TPN_PCI_Type_Tag 
{
  /* N_PCI type for single frame */
  SINGLE_FRAME = 0x00,   
  /* N_PCI type for first frame */  
  FIRST_FRAME  = 0x10,     
  /* N_PCI type for consecutive frame */
  CONSECUTIVE_FRAME = 0x20, 
  /* N_PCI type for flow control frame */   
  FLOW_CONTROL_FRAME = 0x30  
}TPN_PCI_Type_T;

typedef enum TPRequestTpye_Tag /* Moved by Prasanna */
{
  PHYSICAL_ADDRESS_TYPE = 0,
  FUNCTIONAL_ADDRESS_TYPE
}TPRequestTpye_T; 

typedef enum TPResult_Tag  /* Moved by Prasanna */
{
  N_OK = 0, 
  N_TIMEOUT_A,
  N_TIMEOUTBs,
  N_TIMEOUTCr, 
  N_WRONG_SN, 
  N_INVALID_FS,
  N_UNEXP_PDU,
  N_WFT_OVRN,
  N_BUFFER_OVFLW,
  N_WRONG_DLC, 
  N_ERROR,
  TP_BUFFER_OVER_FLOW,
  TP_BUFFER_NOT_FILLED,
  TP_RX_LENGTH_INVALID
 } TPResult_T;

/* States */
typedef enum TPState_Tag 
{
  TP_Idle_State = 0, 
  TP_Wait_For_SFORFF_TxConf_State,
  TP_Wait_For_FCFrame_Rx_State, 
  TP_Transmit_CF_State, 
  TP_Wait_For_CF_TxConf_State,
  TP_Wait_For_STmin_State,
  TP_Wait_For_FC_TXconf_State,
  TP_Rx_CF_State,
  TP_Wait_For_DataRead_State 
 }TPState_T;

/* Result */
/* Parameters */
typedef enum TPParameters_Tag 
{
  N_BLOCKSIZE = 0, 
  N_SEPERATIONTIME
}TPParameters_T;

/* Result for change parameter */
typedef enum TPResultChangePara_Tag 
{
  N_OK_R = 0, 
  N_RX_ON,
  N_WRONG_PARAMETER,
  N_WRONG_VALUE 
}TPResultChangePara_T;

/* Transmit sub state */          
typedef enum TPTransmitSubState_Tag         
{
  TP_TX_LOAD_CF_DATA = 0,     
  TP_TX_LOAD_REMAINING_BYTES_OF_CF,     
  TP_TX_LOAD_REMAINING_BYTES_OF_LAST_CF   
}TPTransmitSubState_T;

/* Receive sub state */
typedef enum TPReceiveSubState_Tag 
{
  TP_RX_UNLOAD_CF_DATA = 0, 
  TP_RX_UNLOAD_REMAINING_BYTES_OF_CF,
  TP_RX_UNLOAD_REMAINING_BYTES_OF_LAST_CF
}TPReceiveSubState_T;

/* Transmit Status */
typedef enum TPTransmitStatus_Tag 
{
  TP_TRANSMIT_IDLE = 0,
  TP_TRANSMIT_START, 
  WAITINGFORFLOWCONTROL
}TPTransmitStatus_T;

/* Receive Status */
typedef enum TPReceiveStatus_Tag 
{
  TP_RECEIVE_IDLE = 0,
  TP_RECEIVE_START 
}TPReceiveStatus_T;

/* Timer control */
typedef enum TPTimerControl_Tag 
{
  TIMER_STOP = 0,
  TIMER_RUN
}TPTimerControl_T;

/* Timer control */
typedef enum TPFlowControlStatus_Tag 
{
  CLEAR_TO_SEND = 0,
  WAIT,
  OVERFLOW,
  RESERVED_FCS
}TPFlowControlStatus_T;

typedef enum TPBufferStatus_Tag 
{
  EMPTY = 0,
  FILLED
}TPBufferStatus_T;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/*============================================================================*/
/* Exported Function Declarations moved from can_tp_config.h.h to this file:       */
/*============================================================================*/
/* Exported Interface-1 */
extern void TP_Init( void );            /* to be called in the main initialization function */
extern void TP_Periodic_Task( void );   /* to be called in the peroidic task as per the call rate */

/* Exported Interface-2 */
/* To be called by Diagnostic/Application layer */
extern void TP_Transmit_Buffer_Filled(void);
extern void TP_Receive_Buffer_Read(void);
extern uint16_t TP_Get_Message_Buffer_Size(void);
extern uint8_t * TP_Get_Message_Buffer_Pointer(void);
extern uint8_t TP_Get_Request_Type(void);
extern void TP_N_USData_Request(uint16_t TPTransmitMessageLength);
extern void TP_N_Change_Parameters_Request(uint8_t Parameter, uint16_t ParameterValue);
extern void TP_Reset_Tx(void);
extern void TP_Reset_Rx(void);
extern void TP_Send_Negative_Response(uint8_t SID, uint8_t NRC);

/* Exported Interface-3 */
/* TP call back functions to be called by VBM layer(config table) */
extern void TP_D_UUData_Confirm(void);  
extern void TP_D_UUData_Indication_Physical(uint8_t dlc, uint8_t* data);
#ifdef TP_DIAG_FUNCTIONAL_MSG_SUPPORT
extern void TP_D_UUData_Indication_Functional(uint8_t dlc, uint8_t* data);
#endif

/*============================================================================*/
/* User (Diagnostics/Applications)Call Back Function Declarations */
/*============================================================================*/
extern void TP_N_USData_Confirm(uint8_t N_Result);  
extern void TP_N_USData_FF_Indication(uint16_t TPReceivexMessageLength);
extern void TP_N_USData_Indication(uint16_t TPReceivexMessageLength, uint8_t N_Result);
extern void TP_N_Change_Parameter_Confirm(uint8_t Parameter, uint8_t ParameterChangeResult);
extern void TP_N_USData_FF_Confirmation(void);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file CAN_TP.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 24-Apr-2020 Pablo Luis Joaquim
 *   - Created initial file based in CCA - CAN Transport Protocol
 *
 */
/*===========================================================================*/
#endif /* CAN_TP_H */
