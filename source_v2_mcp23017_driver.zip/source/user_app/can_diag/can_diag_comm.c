/*===========================================================================*/
/**
 * @file can_diag_comm.c
 *
 * UDS Services
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * UDS Services: Diagnostic and Communication Management
 *    - DiagnosticSessionControl (0x10)
 *    - ECUReset (0x11)
 *    - SecurityAccess(0x27)
 *    - CommunicationControl (0x28)
 *    - TesterPresent (0x3E)
 *    - AccessTimingParameter (0x83)
 *    - SecuredDataTransmission (0x84)
 *    - ControlDTCSetting (0x85)
 *    - ResponseOnEvent (0x86)
 *    - LinkControl (0x87)
 *
 * Positive and Negative response:
 *    All positive responses are sent from the testmode_routine.
 *    All negative responses are just returned from the testmode_routine (and sent by the caller).
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"
#include "can_diag.h"
#include "can_diag_comm_cfg.h"

/* Include other necessary files */
#include <comm_protocol.h>
#include <can_appl.h>
#include <famp_pm.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
/* defines for mode 10 */
#define DIAG_EXTENDED_SESSION_TIME        5000 /* 5 seconds */

/* defines for mode 11 */
#define ECU_RESET_REQUEST_TIME            500

/* defines for mode 27 */
#define DG27_LOCKOUT_TIME_MS              (10000)

/* defines for mode 28 */
#define COMM_CTRL_NORMAL_COMM_MSGS         0x01
#define COMM_CTRL_NETWORK_MANAGEMENT_MSGS  0x02

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
/* macros for mode 27 */
/* If the key is invalid we start a lockout timer to avoid brute force hacking */
#define dg27_lockout()           (Diag_GetClock() < dg27_lockout_timer)
#define dg27_put_lockout(lock)   dg27_lockout_timer = ((lock) ?  (Diag_GetClock() + DG27_LOCKOUT_TIME_MS) : 0)

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/* local variables for mode 10 */
static uint32_t diag_extended_session_timer;
static bool_t   diag_extended_session_active;

/* local variables for mode 11 */
static uint32_t ecu_reset_request_timer;

/* local variables for mode 27 */
static uint32_t dg27_lockout_timer;
static uint32_t dg27_seed;
static bool_t   dg27_unlocked;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
/* support functions for mode 10 */
static uint8_t diag_session_queue_response (uint8_t *data);

/* support functions for mode 27 */
static uint32_t diag_generate_seed (void);
static uint32_t diag_generate_key (uint32_t seed);

/* support functions for mode 28 */
static uint8_t diag_communication_control (bool_t disable_transmit, uint8_t comm_type);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         DG_Default_Session
 *
 * @brief      Handle request for a default diagnostic session.
 *             Clear actions from all diagnostic services.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Default_Session (uint8_t *data)
{
   Diag_Clear_Diagnostics_Mode();

   return(diag_session_queue_response(data));
}

/***************************************************************************//**
 *
 * @fn         DG_Programming_Session
 *
 * @brief      Handle request for a programming session.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Programming_Session (uint8_t *data)
{
   return(RC_SFNS_IF);
}

/***************************************************************************//**
 *
 * @fn         DG_Extended_Session
 *
 * @brief      Handle request for an extended diagnostic session.
 *             The extended session timer is restarted.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Extended_Session (uint8_t *data)
{
   Diag_Start_Extended_Session_Timer();
   Diag_Set_Extended_Session(true);
   Diag_Lock();

   return(diag_session_queue_response(data));
}

/***************************************************************************//**
 *
 * @fn         diag_session_queue_response
 *
 * @brief      Queue the response message for the request for a default
 *             or extended diagnostic session.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
static uint8_t diag_session_queue_response (uint8_t *data)
{
    /* Implementation specific */
    data[0] = 0;
    data[1] = 0;
    data[2] = 0;
    data[3] = 0;

    DiagTransmit(RC_OK, 6);

    return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         Diag_Start_Extended_Session_Timer
 *
 * @brief      Start the extended session timer
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Start_Extended_Session_Timer (void)
{
   diag_extended_session_timer = Diag_GetClock() + DIAG_EXTENDED_SESSION_TIME;
}

/***************************************************************************//**
 *
 * @fn         Diag_Stop_Extended_Session_Timer
 *
 * @brief      Stop the extended session timer
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Stop_Extended_Session_Timer (void)
{
   diag_extended_session_timer = 0;
}

/***************************************************************************//**
 *
 * @fn         Diag_Is_Extended_Session_Timer_Expired
 *
 * @brief      Request if the Extended session timer is expired
 *
 * @param [in] void
 *
 * @return     true if the timer is expired
 *
 ******************************************************************************/
bool_t Diag_Is_Extended_Session_Timer_Expired (void)
{
   return( (0 < diag_extended_session_timer) && (diag_extended_session_timer < Diag_GetClock()) );
}

/***************************************************************************//**
 *
 * @fn         Diag_Is_Extended_Session
 *
 * @brief      Accessor to indicate whether extended diagnostic
 *             session is active.
 *
 * @param [in] void
 *
 * @return     true if in extended diagnostic session
 *
 ******************************************************************************/
bool_t Diag_Is_Extended_Session (void)
{
   return(diag_extended_session_active);
}

/***************************************************************************//**
 *
 * @fn         Diag_Set_Extended_Session
 *
 * @brief      Set the indicator for extended diagnostic
 *             session currently active.
 *
 * @param [in] true if in extended diagnostic session
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Set_Extended_Session (bool_t active)
{
   diag_extended_session_active = active;
}

/***************************************************************************//**
 *
 * @fn         DG_Hard_Reset
 *
 * @brief      Handle request to do a hard reset.  If a CAN response is
 *             not needed, then force a reset immediately.  If a CAN
 *             response is needed, then set a timer to allow time for
 *             the response to go out first, then force the reset later.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Hard_Reset (uint8_t *data)
{
   if (Diag_Is_Suppress_Response())
   {
      FAMP_PM_Force_Cold_Start();
   }
   else
   {
      ecu_reset_request_timer = Diag_GetClock() + ECU_RESET_REQUEST_TIME;
      DiagTransmit(RC_OK, 2);
   }

   return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         DG_Key_Off_On_Reset
 *
 * @brief      This reset condition should simulate a key-off-on sequence
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Key_Off_On_Reset (uint8_t *data)
{
   return(RC_SFNS_IF);
}

/***************************************************************************//**
 *
 * @fn         Diag_Check_ECUReset
 *
 * @brief      Check if we're waiting for the ECUReset service response to be sent.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
void Diag_Check_ECUReset (void)
{
   /* The ecu_reset_request_timer is currently running
      (are we waiting for the response to be sent?) */
   if (0 < ecu_reset_request_timer)
   {
      ecu_reset_request_timer = Diag_GetClock();
   }
}

/***************************************************************************//**
 *
 * @fn         Diag_Check_ECUReset_Tmr_Expiration
 *
 * @brief      Check for the ECUReset timer expiration.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
void Diag_Check_ECUReset_Tmr_Expiration (void)
{
   /* If a hard reset was requested (by service $11), it is indicated by
      a timer.  When the timer is expired, do a reset.
      The timer is used to allow a chance for the CAN response to be
      transmitted.                                                    */
   if ( (0 < ecu_reset_request_timer) && (Diag_GetClock() >= ecu_reset_request_timer) )
   {
       FAMP_PM_Force_Cold_Start();
   }
}

/***************************************************************************//**
 *
 * @fn         Diag_Set_ecu_reset_request_timer
 *
 * @brief      Set ecu reset request timer
 *
 * @param [in] uint32_t timer_ms
 *
 * @return     none
 *
 ******************************************************************************/
void Diag_Set_ecu_reset_request_timer(uint32_t timer_ms)
{
   ecu_reset_request_timer = Diag_GetClock() + timer_ms;
}

/***************************************************************************//**
 *
 * @fn         DG_Process_Seed_Request
 *
 * @brief      This function calculates a seed.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Process_Seed_Request (uint8_t *data)
{
   uint8_t return_code = RC_OK;

   /* Check if still lockout (timeout if incorrect key has been entered) */
   if (dg27_lockout())
   {/* lockout still running */
      return_code = RC_RTDNE;
   }
   else
   {/* No lockout - a new seed/key process is allowed */

      /* Reset the lockout timeout */
      dg27_put_lockout(false);

      if (dg27_unlocked)
      {/* If the radio is already unlocked, 0 shall be responded as the seed */
         dg27_seed = 0;
      }
      else
      {/* If the radio is locked, generate the new seed */
         dg27_seed = diag_generate_seed();
      }

      memcpy(&data[0], &dg27_seed, sizeof(dg27_seed));
      DiagTransmit(RC_OK, 2 + sizeof(dg27_seed));
   }

   return (return_code);
}

/***************************************************************************//**
 *
 * @fn         DG_Process_Key
 *
 * @brief      This function determines whether the key is correct.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Process_Key (uint8_t *data)
{
   static bool_t incorrect_key = false;
   uint32_t received_key;

   uint8_t return_code = RC_OK;

   /* Check if still lockout (timeout if incorrect key has been entered) */
   if (dg27_lockout())
   {/* lockout still running */
      return_code = RC_RTDNE;
   }
   else
   {/* No lockout - a new seed/key process is allowed */

      /* Reset the lockout timeout */
      dg27_put_lockout(false);

      received_key =
           ((data[0] & 0xFF) << 24)
         + ((data[1] & 0xFF) << 16)
         + ((data[2] & 0xFF) << 8)
         +  (data[3] & 0xFF);

      if ((diag_generate_key(dg27_seed) == received_key) && (0 != dg27_seed))
      {
         DiagTransmit(RC_OK, 2);
         incorrect_key = false;
         dg27_unlocked = true;
      }
      else
      {
         if (incorrect_key)
         {
            return_code = RC_ENOA;
            dg27_put_lockout(true);
         }
         else
         {
            return_code = RC_IK;
         }

         incorrect_key = true;
         dg27_unlocked = false;
      }
   }

   return (return_code);
}

/***************************************************************************//**
 *
 * @fn         Diag_Unlocked
 *
 * @brief      This function reports whether the radio is unlocked
 *             for programming.
 *
 * @param [in] void
 *
 * @return     true if locked
 *
 ******************************************************************************/
bool_t Diag_Is_Locked (void)
{
   return (!dg27_unlocked);
}

/***************************************************************************//**
 *
 * @fn         Diag_Lock
 *
 * @brief      This function locks the radio for programming.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Lock (void)
{
   dg27_unlocked = false;
}

/***************************************************************************//**
 *
 * @fn         diag_generate_seed
 *
 * @brief      This function calculates a random, non-zero seed.
 *
 * @param [in] void
 *
 * @return     seed
 *
 ******************************************************************************/
static uint32_t diag_generate_seed (void)
{
   uint32_t seed;

   srand ( Diag_GetClock() );    /* random value for seed */
   seed = rand();

   if (0 == seed)
   {
      seed = dg27_seed + 0xAA55AA55;
   }
   if (0 == seed)
   {
      seed = 0xAA55AA55;
   }

   return (seed);
}

/***************************************************************************//**
 *
 * @fn         diag_generate_key
 *
 * @brief      This function calculates the key for a given seed.
 *
 * @param [in] seed
 *
 * @return     key
 *
 ******************************************************************************/
static uint32_t diag_generate_key (uint32_t seed)
{
   uint32_t key;

   /* key calc algorithm for tests (convert big endian to little endian) */
   key = seed >> 24;
   key |= ((seed >> 16)&0x000000FF)<<8;
   key |= ((seed >> 8)&0x000000FF)<<16;
   key |= ((seed)&0x000000FF)<<24;

   return (key);
}

/***************************************************************************//**
 *
 * @fn         DG_Comm_Control_Enable_Tx
 *
 * @brief      Handle request to enable normal IL and NM communications.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Comm_Control_Enable_Tx (uint8_t *data)
{
   return(diag_communication_control(false, (*data)));
}

/***************************************************************************//**
 *
 * @fn         DG_Comm_Control_Disable_Tx
 *
 * @brief      Handle request to disable normal IL and NM communications.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Comm_Control_Disable_Tx (uint8_t *data)
{
   return(diag_communication_control(true, (*data)));
}

/***************************************************************************//**
 *
 * @fn         diag_communication_control
 *
 * @brief      Handle request to enable or disable normal IL and NM
 *             communications.
 *
 * @param [in] comm_type - byte containing flags indicating what should
 *                         be enabled or disabled
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
static uint8_t diag_communication_control (bool_t disable_transmit, uint8_t comm_type)
{
    uint8_t rc = RC_ROOR;

    if ((comm_type & COMM_CTRL_NORMAL_COMM_MSGS) != 0)
    {
        CAN_Disable_Appl_TX_Messages(disable_transmit);
        rc = RC_OK;
    }
    if ((comm_type & COMM_CTRL_NETWORK_MANAGEMENT_MSGS) != 0)
    {
        CAN_Disable_NM_TX_Messages(disable_transmit);
        rc = RC_OK;
    }

    if (RC_OK == rc)
    {
        DiagTransmit(rc, 2);
    }

    return(rc);
}

/***************************************************************************//**
 *
 * @fn         DG_Tester_Present
 *
 * @brief      Handle tester present message.
 *             The extended session timer is restarted.
 *             Send response only for physical message.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Tester_Present (uint8_t *data)
{
   Diag_Start_Extended_Session_Timer();

   DiagTransmit(RC_OK, 2);

   return(RC_OK);
}
