#ifndef CAN_DIAG_ROUTINE_CFG_H
#define CAN_DIAG_ROUTINE_CFG_H
/*===========================================================================*/
/**
 * @file can_diag_routine_cfg.h
 *
 * Table definition for the available diag routines
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
/* ROUTINE_TABLE is used to routine control
 *
 * DID: Data Identifier
 *
 * Length Response: Data length of the response.
 *
 * Routine Control Type:
 *
 * RX data Length:
 *
 * Response data Length:
 *
 * Routine control:
 *
*/

#define ROUTINE_TABLE \
   /*             Routine Control         RX             Response       Routine                                         */    \
   /*  DID        Type                    data Length    data Length    Control                                         */    \
   /*  -------    --------------------    -----------    --------       -----------------------------------------       */    \
      X(0x0301,    DIAG_ROUTINE_START,     0,             0,             diag_reset_parameter_to_default_start          )     \
                                                                                                                              \
      X(0x0317,    DIAG_ROUTINE_START,     0,             0,             diag_routine_ctrl_EOL_audio_test_start         )     \
      X(0x0317,    DIAG_ROUTINE_STOP,      0,             0,             diag_routine_ctrl_EOL_audio_test_stop          )     \
      X(0x0317,    DIAG_ROUTINE_RESULT,    0,             1,             diag_routine_ctrl_EOL_audio_test_result        )     \

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
uint8_t diag_reset_parameter_to_default_start (uint8_t *data);
uint8_t diag_routine_ctrl_EOL_audio_test_start (uint8_t *data);
uint8_t diag_routine_ctrl_EOL_audio_test_stop (uint8_t *data);
uint8_t diag_routine_ctrl_EOL_audio_test_result (uint8_t *data);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file CAN_DIAG_ROUTINE_CFG.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 01-May-2020 Pablo Luis Joaquim
 *   - Created initial file based in B7 - can_diag module
 *
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* CAN_DIAG_ROUTINE_CFG_H */
