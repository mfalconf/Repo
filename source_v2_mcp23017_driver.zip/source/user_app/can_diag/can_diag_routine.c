/*===========================================================================*/
/**
 * @file can_diag_routine.c
 *
 * UDS Services
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * UDS Services: Remote Activation of Routine
 *    - RoutineControl (0x31)
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"
#include "can_diag.h"
#include "can_diag_routine_cfg.h"

/* Include other necessary files */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define DIAG_ROUTINE_START                   0x01
#define DIAG_ROUTINE_STOP                    0x02
#define DIAG_ROUTINE_RESULT                  0x03

#define DIAG_ROUTINE_CTRL_CMD_HEADER_LENGTH        3
#define DIAG_ROUTINE_CTRL_REQUEST_LENGTH_MIN       4
#define DIAG_ROUTINE_CTRL_RESPONSE_LENGTH_MIN      4

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef uint8_t (*routine_control_fptr) (uint8_t *);

typedef struct routine_control_Tag
{
   uint16_t             routine_id;
   uint8_t              routine_control_type;
   uint8_t              rx_data_length;
   uint8_t              response_data_length;
   routine_control_fptr control_routine;
} routine_control_T;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*\
 * Local Object Definitions - CONST
\*===========================================================================*/
/* ROUTINE table for Service $31 */
#undef X
#define X(a, b, c, d, e) {a, b, c, d, e},
static const routine_control_T routine_control_list[]=
{
   ROUTINE_TABLE
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         DG_Routine_Control
 *
 * @brief      Handler for Routine Control.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_Routine_Control( uint8_t *data )
{
   uint8_t rc = RC_SFNS_IF;
   static uint8_t  routine_type;
   static uint16_t received_id;
   uint8_t i;
   uint8_t data_length = Diag_Get_Received_Data_Length();
   uint16_t response_data_length = 0;

   /* Convert the received_id to big endian */
   received_id = data[2];
   received_id |= data[1]<<8;

   /* routine control type */
   routine_type = data[0];

   for (i=0; i < Num_Elems(routine_control_list); i++)
   {
      /* Is the received ID supported? */
      if (  ( received_id  == routine_control_list[i].routine_id                                                     )&&
            ( routine_type & (~DIAG_SUPPRESS_POSITIVE_RESPONSE)  ) == (routine_control_list[i].routine_control_type  )
         )
      {
         /* A service with subfunction has the possibility
            of suppressing a positive response.            */
         if( ( routine_type & DIAG_SUPPRESS_POSITIVE_RESPONSE ) != 0 )
         {
            Diag_Set_Suppress_Response();
         }

         /* Does the received message length meet the requirement? */
         if( data_length != ( DIAG_ROUTINE_CTRL_REQUEST_LENGTH_MIN + routine_control_list[i].rx_data_length ))
         {
            rc = RC_IML_IF;
         }
         else
         {
            /* Received Routine Control ID was found, and is the correct
               length, so call function to process the data.                */
            rc = routine_control_list[i].control_routine(&data[(DIAG_ROUTINE_CTRL_CMD_HEADER_LENGTH)]);
            response_data_length = DIAG_ROUTINE_CTRL_RESPONSE_LENGTH_MIN + routine_control_list[i].response_data_length;
         }
         break;
      }
   }

   if (RC_OK == rc)
   {
      DiagTransmit(RC_OK, response_data_length );
   }

   return(rc);
}
