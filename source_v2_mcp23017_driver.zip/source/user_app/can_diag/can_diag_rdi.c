/*===========================================================================*/
/**
 * @file can_diag_rdi.c
 *
 * UDS Services
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * UDS Services: Data Transmission
 *    - ReadDataByIdentifier (0x22)
 *    - ReadMemoryByAddress (0x23)
 *    - ReadScalingDataByIdentifier (0x24)
 *    - ReadDataByPeriodicIdentifier (0x2A)
 *    - DynamicallyDefineDataIdentifier (0x2C)
 *    - WriteDataByIdentifier (0x2E)
 *    - WriteMemoryByAddress (0x3D)
 *
 * @section ABBR ABBREVIATIONS:
 *   - rdi: record data identifier
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"
#include "can_diag.h"
#include "can_diag_rdi_cfg.h"

/* Include other necessary files */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define MODE_2E_HEADER_LENGTH             (3)

#define DIAG_RDI_AVAILABLE_LANGUAGES_MESSAGE_SIZE  (80)

#define DIAG_OVERRIDE_COUNTRY_CODE        0x01

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef uint8_t (*read_routine_fptr) (uint8_t *dest_data_ptr, uint8_t num_bytes);
typedef uint8_t (*write_routine_fptr)(uint8_t *data, uint8_t num_bytes);

typedef enum write_allowed_Tag
{
   NO,
   SECURE,
   YES
} write_allowed_T;

typedef struct rdi_Tag
{
   uint16_t             rdi;
   uint8_t              data_length;
   read_routine_fptr    read_routine;
   bool_t               phys_msg_required_for_read : 1;
   write_allowed_T      write_allowed;
   write_routine_fptr   write_routine;
} rdi_T;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
/* Generals functions   */
static void       diag_rdi_convert_to_big_endian (void *dest, const void *src, size_t num_bytes);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/* RDI table   */
#undef X
#define X(a, b, c, d, e, f) {a, b, c, d, e, f},
static const rdi_T rdi_table[]=
{
   RDI_TABLE
};

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/***************************************************************************//**
 *
 * @fn         DG_RDI_Read
 *
 * @brief      Look up RDI's in table to determine whether they
 *             are supported, then read the data for each RDI.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_RDI_Read (uint8_t* data)
{
   static uint8_t requested_rdi_list[Num_Elems(rdi_table)];
   uint8_t rc = RC_ROOR;
   uint8_t received_data_length = Diag_Get_Received_Data_Length();
   uint8_t number_of_rdis;
   uint8_t i = 0;
   uint8_t rdi_index;
   uint16_t *rdi_ptr = (uint16_t *)data;
   uint16_t received_rdi;
   bool rdi_is_valid;
   uint16_t response_data_length = 0;

   /* Check received message length.  It includes the service ID, followed
      by 1 or more RDI's, which are 2 bytes each.  So the length must be at
      least 3 bytes, and it must be an odd number.                           */
   number_of_rdis = (received_data_length - 1 )/ 2;
   if ( (3 > received_data_length) ||
        (0 == (received_data_length % 2)) )
   {
      rc = RC_IML_IF;
   }
   /* The number of RDI's is limited by the size of requested_rdi_list.      */
   else if (Num_Elems(requested_rdi_list) >= number_of_rdis)
   {
      /* Create a requested RDI list.  If any are invalid, then the entire
         list is rejected.  Also, check the total response length.           */
      do
      {
         diag_rdi_convert_to_big_endian(&received_rdi, rdi_ptr, sizeof(received_rdi));
         rdi_is_valid = false;
         for (rdi_index=0; rdi_index < Num_Elems(rdi_table); rdi_index++)
         {
            if (received_rdi == rdi_table[rdi_index].rdi)
            {
               /* Use this table entry only if the received message is
                  physical or the service is supported for functional.       */
               if ( Diag_Is_Received_Physical_Message() ||
                    (!rdi_table[rdi_index].phys_msg_required_for_read) )
               {
                  requested_rdi_list[i] = rdi_index;
                  response_data_length = response_data_length +
                                         sizeof(received_rdi) +
                                         rdi_table[rdi_index].data_length;
                  rdi_is_valid = true;
               }
               break;
            }
         }
         i++;
         rdi_ptr++;
      }
      while (rdi_is_valid && (i < number_of_rdis));

      /* If all requested RDI's are supported, and the total response length
         is not too large, then continue.  Response length needs to include
         the 1 byte service ID at the beginning.                             */
      if (rdi_is_valid && (CAN_DIAG_BUFFER_SIZE >= (response_data_length + 1)))
      {
         /* Length and format has been checked, so now assume success.  If
            an EEPROM read fails, then the entire list will be rejected.     */
         rc = RC_OK;

         /* For each requested RDI, first write the RDI to the response
            buffer, then write the related data to the response buffer.      */
         response_data_length = 0;
         for (i=0; i < number_of_rdis; i++)
         {
            /* Get each requested RDI, and write it to the response buffer.  */
            rdi_index = requested_rdi_list[i];
            received_rdi = rdi_table[rdi_index].rdi;
            diag_rdi_convert_to_big_endian(&data[response_data_length],
                                &received_rdi, sizeof(received_rdi));
            response_data_length = response_data_length + sizeof(received_rdi);

            /* For each RDI, the read value is obtained through an specific read routine*/
            if( rdi_table[rdi_index].read_routine != NULL )
            {
               rc = rdi_table[rdi_index].read_routine(&data[response_data_length], rdi_table[rdi_index].data_length);
            }
            else
            {
               /* Read not supported */
               rc = RC_ROOR;
               break;
            }
            response_data_length = response_data_length + rdi_table[rdi_index].data_length;
         }
      }
   }

   if (RC_OK == rc)
   {
      DiagTransmit(RC_OK, (response_data_length + 1));
   }

   return(rc);
}

/***************************************************************************//**
 *
 * @fn         DG_RDI_Write
 *
 * @brief      Look up RDI's in table to determine whether they
 *             are supported, then write the data for each RDI.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_RDI_Write (uint8_t *data)
{
   uint16_t received_rdi;
   uint8_t rc = RC_ROOR;
   uint8_t i;

   diag_rdi_convert_to_big_endian(&received_rdi, data, sizeof(received_rdi));

   for (i=0; i < Num_Elems(rdi_table); i++)
   {
      /* Is the received ID supported? */
      if (received_rdi == rdi_table[i].rdi)
      {
         /* Check whether a write is allowed:
               - All writes require a write routine.
         */
         if(YES == rdi_table[i].write_allowed)
         {
            /* Does the received message length meet the requirement? */
            if (((MODE_2E_HEADER_LENGTH + rdi_table[i].data_length) != Diag_Get_Received_Data_Length())
               && (rdi_table[i].data_length > 0))
            {
               rc = RC_IML_IF;
            }
            else
            {
               /* For this RDI, write routine from the table   */
               if ((Diag_Is_Locked()) && (SECURE == rdi_table[i].write_allowed))
               {
                  rc = RC_SAD;
               }
               else if (NULL != rdi_table[i].write_routine)
               {
                  rc = rdi_table[i].write_routine(&data[sizeof(received_rdi)], Diag_Get_Received_Data_Length() - MODE_2E_HEADER_LENGTH);
               }
               else
               {
                  /* Write not allowed, use default return code */
               }
            }
         }
         break;
      }
   }

   if (RC_OK == rc)
   {
      DiagTransmit(RC_OK, MODE_2E_HEADER_LENGTH);
   }

   return(rc);
}

/***************************************************************************//**
 *
 * @fn         diag_rdi_convert_to_big_endian
 *
 * @brief      Converts a half_word or word from Little Endian to Big Endian.
 *
 * @param [in] *src - pointer to half_word or word to be converted
 *             *dest - pointer to destination of the conversion
 *             num_bytes - # of bytes to convert
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
static void diag_rdi_convert_to_big_endian (void *dest, const void *src, size_t num_bytes)
{
   uint8_t *temp_dest = (uint8_t *)dest;
   const uint8_t *temp_src = ((const uint8_t *)src) + num_bytes;

   for ( ; 0 != num_bytes ; num_bytes--)
   {
      *(temp_dest++) = *(--temp_src);
   }
}
