/*===========================================================================*/
/**
 * @file can_diag_io.c
 *
 * UDS Services
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * UDS Services: Input Output Control
 *    - InputOutputControlByIdentifier (0x2F)
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"
#include "can_diag.h"
#include "can_diag_io_cfg.h"

/* Include other necessary files */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define RETURN_CONTROL_TO_ECU                0
#define SHORT_TERM_ADJUSTMENT                3

#define RESPONSE_RX_DATA_LENGTH              4

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef uint8_t (*io_control_fptr) (uint8_t *);

typedef struct io_control_Tag
{
   uint16_t        data_id;
   uint8_t         control_param;
   uint8_t         rx_length;
   io_control_fptr control_routine;
} io_control_T;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*\
 * Local Object Definitions - CONST
\*===========================================================================*/
/* IO Table for Service $2F */
#undef X
#define X(a, b, c, d) {a, b, c, d},
static const io_control_T io_control_list[]=
{
   IO_TABLE
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         DG_IO_Control
 *
 * @brief      Looks up IO Control ID in table to determine whether the
 *             ID is supported, then executes the corresponding routine.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_IO_Control (uint8_t *data)
{
   uint16_t received_id;
   uint8_t rc = RC_ROOR;
   uint8_t i;
   uint8_t data_length = Diag_Get_Received_Data_Length();
   uint16_t response_data_length = 0;


   /* Convert the received_id to big endian */
   received_id = data[1];
   received_id |= data[0]<<8;

   for (i=0; i < Num_Elems(io_control_list); i++)
   {
      /* Is the received ID and control parameter supported? */
      if ( (io_control_list[i].data_id == received_id) &&
           (io_control_list[i].control_param == data[2]) )
      {
         /* Does the received message length meet the requirement? */
         if (io_control_list[i].rx_length != data_length)
         {
            rc = RC_IML_IF;
         }
         else
         {
            rc = io_control_list[i].control_routine(&data[3]);
            /* All messages response with same length */
            response_data_length = RESPONSE_RX_DATA_LENGTH;       /* = io_control_list[i].rx_length; */
         }
         break;
      }
   }

   if (RC_OK == rc)
   {
      DiagTransmit(RC_OK, response_data_length);
   }

   return(rc);
}
