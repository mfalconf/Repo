/*===========================================================================*/
/**
 * @file can_diag.c
 *
 * This file contains the entry/exit point to the diagnostic services callbacks
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"

#include <can_appl.h>

#include <drv/can/can.h>
#include <can_diag.h>
#include <can_tp.h>
#include <can_tp_callouts.h>
#include <can_appl.h>
#if (USE_CAN_VOLKSWAGEN == 1)
    #include <can_appl_volkswagen.h>
#endif
#if (USE_CAN_MOPAR == 1)
    #include <can_appl_mopar.h>
#endif

/* Include other necessary files */
#include <famp_pm.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef uint8_t (*testmode_routine_fptr) (uint8_t *);

typedef struct testmode_type_tag
{
   uint8_t               service_id;
   uint8_t               subfunction_id;
   uint8_t               rx_length;
   testmode_routine_fptr testmode_routine;
   bool_t                subfunction_support : 1;
   bool_t                phys_msg_required : 1;
   bool_t                ext_session_required : 1;
} testmode_t;


/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/* DiagBuffer is the buffer used for both receiving and transmitting diagnostic data. */
uint8_t* DiagBuffer;

static uint16_t received_data_length;
static bool_t diag_msg_received;
static diag_msg_received_T diag_msg_received_type;
static bool_t suppress_response;

static bool_t diag_power_mode;
static bool_t diag_init_ok = false;
static uint32_t diag_clock = 0;


/*===========================================================================*
 * Local Object Definitions - testmode_list
 *===========================================================================*/
static const testmode_t testmode_list[]=
{
/*          Sub-     Required                                       Sub-     Physical Extended  */
/*  Service function Rx msg                                         function Msg      Session   */
/*  ID      ID       length   Test Mode Routine                     Support  Required Required  */
/*  ------- -------- -------- ------------------------------------- -------- -------- --------  */
   {0x10,   0x01,      2,     DG_Default_Session,                   true,    false,   false    },
   {0x10,   0x02,      2,     DG_Programming_Session,               true,    true,    false    },
   {0x10,   0x03,      2,     DG_Extended_Session,                  true,    false,   false    },
   {0x10,   0x40,      2,     DG_Extended_Session,                  true,    false,   false    },
   {0x11,   0x01,      2,     DG_Hard_Reset,                        true,    false,   false    },
   {0x11,   0x02,      2,     DG_Key_Off_On_Reset,                  true,    false,   false    },
   {0x14,   0x00,      4,     DG_DTC_Clear,                         false,   false,   false    },
   {0x19,   0x01,      3,     DG_DTC_Read_Number_By_Status,         true,    false,   false    },
   {0x19,   0x02,      3,     DG_DTC_Read_By_Status,                true,    false,   false    },
   {0x19,   0x04,      6,     DG_DTC_Read_Snapshot,                 true,    false,   false    },
   {0x19,   0x06,      6,     DG_DTC_Read_Ext_Data_Record,          true,    false,   false    },
   {0x19,   0x07,      4,     DG_DTC_Read_Number_Of_DTC_By_Severity,true,    false,   false    },
   {0x19,   0x08,      4,     DG_DTC_Read_By_Severity,              true,    false,   false    },
   {0x19,   0x09,      5,     DG_DTC_Read_Severity_Info,            true,    false,   false    },
   {0x19,   0x0C,      2,     DG_DTC_Read_First_Confirmed,          true,    false,   false    },
   {0x19,   0x0E,      2,     DG_DTC_Read_Most_Recent_Confirmed,    true,    false,   false    },
   {0x22,   0x00,      0,     DG_RDI_Read,                          false,   false,   false    },
   {0x27,   0x01,      3,     NULL,                                 true,    true,    false    },
   {0x27,   0x02,      3,     NULL,                                 true,    true,    false    },
   {0x27,   0x05,      2,     DG_Process_Seed_Request,              true,    true,    true     },
   {0x27,   0x06,      6,     DG_Process_Key,                       true,    true,    true     },
   {0x28,   0x00,      3,     DG_Comm_Control_Enable_Tx,            true,    false,   true     },
   {0x28,   0x01,      3,     DG_Comm_Control_Disable_Tx,           true,    false,   true     },
   {0x2E,   0x00,      0,     DG_RDI_Write,                         false,   true,    true     },
   {0x2F,   0x00,      0,     DG_IO_Control,                        false,   true,    true     },
   {0x31,   0x00,      0,     DG_Routine_Control,                   false,   true,    true     },
   {0x34,   0x00,      2,     NULL,                                 false,   true,    false    },
   {0x36,   0x00,      2,     NULL,                                 false,   true,    false    },
   {0x37,   0x00,      1,     NULL,                                 false,   true,    false    },
   {0x3E,   0x00,      2,     DG_Tester_Present,                    true,    false,   false    },
   {0x85,   0x01,      2,     DG_DTC_Control_On,                    true,    false,   true     },
   {0x85,   0x02,      2,     DG_DTC_Control_Off,                   true,    false,   true     },
};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void diag_process_received_message (void);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         Diag_Init
 *
 * @brief      Init routine for diagnostics.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Init(void)
{
   DiagBuffer = TP_Get_Message_Buffer_Pointer();
   diag_power_mode = false;
   Diag_DTC_Init();
   diag_init_ok = true;
   diag_clock = 0;
}

/***************************************************************************//**
 *
 * @fn         Diag_Not_Init
 *
 * @brief      The diag is not initialized
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Not_Init(void)
{
   diag_init_ok = false;
}

/***************************************************************************//**
 *
 * @fn         Diag_Init_Is
 *
 * @brief      Return if diagnostic is initialized.
 *
 * @param [in] void
 *
 * @return     bool_t
 *
 ******************************************************************************/
bool_t Diag_Init_Is(void)
{
   return(diag_init_ok);
}

/***************************************************************************//**
 *
 * @fn         Diag_GetClock
 *
 * @brief      Return the diag_clock status
 *
 * @param [in] void
 *
 * @return     the diag_clock status
 *
 ******************************************************************************/
uint32_t Diag_GetClock (void)
{
    return(diag_clock);
}

/***************************************************************************//**
 *
 * @fn         DiagTask
 *
 * @brief      Called from CAN_Task, to handle diagnostics.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void DiagTask (void)
{
    diag_clock+=10;   /* This clock is incremented every 10ms */

   /*****************************************************\
      Check for the ECUReset timer expiration.
      When the timer is expired, do a reset.
   \*****************************************************/
   Diag_Check_ECUReset_Tmr_Expiration();

   /*****************************************************\
      Process the current received message
   \*****************************************************/
   if (diag_msg_received)
   {
      diag_msg_received = false;
      suppress_response = false;
      /* Ignore the message if SF_DL is 0. */
      if (received_data_length != 0)
      {
         diag_process_received_message();
      }
   }

   /*****************************************************\
      Determine whether to cancel an extended diagnostic session.
   \*****************************************************/
   if (Diag_Is_Extended_Session_Timer_Expired())
   {
      Diag_Clear_Diagnostics_Mode();
   }

   /*****************************************************\
      Determine the current power mode
   \*****************************************************/
    if( Diag_Init_Is() )
    {
        if (true == FAMP_PM_Is_IgnitionOn())
        {
            if(false == diag_power_mode)
            {
                Diag_DTC_Key_On();
                diag_power_mode = true;
            }
        }
        else
        {
            if(true == diag_power_mode)
            {
                Diag_DTC_Key_Off();
                diag_power_mode = false;
            }
        }
    }

   /*****************************************************\
      Call periodic checks for DTCs
   \*****************************************************/
   Diag_DTC_Periodic_Checks();
}

/***************************************************************************//**
 *
 * @fn         DiagTransmit
 *
 * @brief      Request transmit of a diagnostic message, for either a
 *             positive or negative response.
 *             In both the positive and negative response cases, the
 *             first byte of DiagBuffer is the Service ID; it should
 *             still be there from the received data.
 *             If rc=0, then the request is for a positive response.
 *             In this case, it is expected that the calling function
 *             has put the appropriate data into DiagBuffer.
 *             If rc>0, then the request is for a negative response.
 *             In this case, the calling function should not write
 *             anything to DiagBuffer.
 *             The calling function is responsible for ensuring that
 *             the requested length of data fits in DiagBuffer.  It
 *             is checked here to be sure.
 *             For positive responses, the response might be suppressed
 *             if requested.
 *             For functional messages, some negative responses are
 *             always suppressed.
 *             The extended session timer is restarted here if there
 *             will be no response message.  Otherwise, it is restarted
 *             at confirmation.
 *
 * @param [in] rc - RC_OK (0) if a positive response is requested
 *                - appropriate return code if a negative response is requested
 *             length - desired length of transmit message
 *
 * @return     void
 *
 ******************************************************************************/
void DiagTransmit (uint8_t rc, uint16_t length)
{
   if ( (FUNCTIONAL_MSG_RECEIVED == diag_msg_received_type) &&
        ( (RC_SNS == rc) || (RC_SFNS_IF == rc) || (RC_ROOR == rc) ) )
   {
      suppress_response = true;
   }
   if( (true == suppress_response) && (rc == RC_OK) )
   {
       Diag_Start_Extended_Session_Timer();
   }
   else if(CAN_DIAG_BUFFER_SIZE >= length)
   {
      if (RC_OK == rc)
      {
         DiagBuffer[0] |= 0x40;
         TP_Transmit_Buffer_Filled();
         TP_N_USData_Request(length);
      }
      else
      {
         TP_Send_Negative_Response(DiagBuffer[0], rc);
      }
   }
}

/***************************************************************************//**
 *
 * @fn         Diag_Tx_Confirmation
 *
 * @brief      Called when an entire message (all frames) has been
 *             transmitted.
 *             If a hard reset was previously requested (by service $11),
 *             then when it gets successfully transmitted, adjust the
 *             timer so that the reset will occur immediately.
 *             SY_Cold_Start should not be called from an interrupt,
 *             so it is delayed until DiagTransmit.
 *             The extended session timer is restarted.
 *
 * @param [in] state - kTpSuccess, kTpCanTxFailed, kTpBusy, etc.
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Tx_Confirmation(uint8_t state)
{
   if( 0 == state )   /* kTpSuccess */
   {
      Diag_Check_ECUReset();
   }
   Diag_Start_Extended_Session_Timer();
}

/***************************************************************************//**
 *
 * @fn         Diag_Rx_Indication
 *
 * @brief      Called when an entire message (all frames) has been
 *             received.
 *             Save the data length, for use in verifying the correct
 *             length for a particular Service ID.
 *             This function is called from an interrupt, so set the
 *             flag diag_msg_received, so that the data can be
 *             processed from DiagTask.
 *             Save diag_frame_received_type to diag_msg_received_type,
 *             to be used in DiagTask to indicate whether the received
 *             message is physical or functional.
 *             Stop extended session timer.  It will be restarted
 *             when a response is sent.
 *
 * @param [in] dataLength - actual data length of received message
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Rx_Indication(uint16_t dataLength, diag_msg_received_T diag_frame_received_type)
{
   received_data_length = dataLength;
   diag_msg_received = true;
   diag_msg_received_type = diag_frame_received_type;
   Diag_Stop_Extended_Session_Timer();
}

/***************************************************************************//**
 *
 * @fn         Diag_Rx_FF_Indication
 *
 * @brief      Indication of the first frame of a TP receive.
 *             The extended session timer is stopped.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Rx_FF_Indication (void)
{
   Diag_Stop_Extended_Session_Timer();
}

/***************************************************************************//**
 *
 * @fn         Diag_Error_Indication
 *
 * @brief      Indication of an error in TP receive or transmit.
 *             The extended session timer is restarted.
 *
 * @param [in] errorCode - unused
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Error_Indication(uint8_t errorCode)
{
    Diag_Start_Extended_Session_Timer();
}

/***************************************************************************//**
 *
 * @fn         Diag_Get_Received_Data_Length
 *
 * @brief      Accessor for received_data_length.
 *
 * @param [in] void
 *
 * @return     number of bytes in received diagnostic message
 *
 ******************************************************************************/
uint8_t Diag_Get_Received_Data_Length (void)
{
   return(received_data_length);
}

/***************************************************************************//**
 *
 * @fn         Diag_Is_Received_Physical_Message
 *
 * @brief      Accessor for type of received message, functional or physical.
 *
 * @param [in] void
 *
 * @return     true if received message is physical
 *             false if received message is functional
 *
 ******************************************************************************/
bool_t Diag_Is_Received_Physical_Message (void)
{
   return(PHYSICAL_MSG_RECEIVED == diag_msg_received_type);
}

/***************************************************************************//**
 *
 * @fn         Diag_Is_Suppress_Response
 *
 * @brief      Indicates if the current service has been requested with
 *             suppressing positive response.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
bool_t Diag_Is_Suppress_Response (void)
{
   return (suppress_response);
}

/***************************************************************************//**
 *
 * @fn         Diag_Set_Suppress_Response
 *
 * @brief      Set suppressing positive response.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Set_Suppress_Response (void)
{
   suppress_response = true;
}

/***************************************************************************//**
 *
 * @fn         Diag_Get_Power_Mode
 *
 * @brief      Retrieve the current power mode for the diag modules requests.
 *
 * @param [in] void
 *
 * @return     true if power mode equals running
 *
 ******************************************************************************/
bool_t Diag_Get_Power_Mode (void)
{
   return (diag_power_mode);
}

/***************************************************************************//**
 *
 * @fn         Diag_Clear_Diagnostics_Mode
 *
 * @brief      Clear Customer Extended Diagnostics Mode.
 *             If manufacturing diagnostics is active, then device
 *             control tests are not cleared, because some of them
 *             are shared between manufacturing test and customer
 *             extended diagnostic tests.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_Clear_Diagnostics_Mode (void)
{
   if (Diag_Is_Extended_Session())
   {
      /* Reset all possible diag interactions */
      Diag_Stop_Extended_Session_Timer();
      Diag_Set_Extended_Session(false);
      Diag_Lock();
      CAN_Disable_Appl_TX_Messages(false);
      CAN_Disable_NM_TX_Messages(false);
      Diag_DTC_Enable();
   }
}

/***************************************************************************//**
 *
 * @fn         diag_process_received_message
 *
 * @brief      Looks up service id or subfunction id in table to determine
 *             whether it is supported, and whether other conditions are
 *             met, then executes the corresponding routine.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void diag_process_received_message (void)
{
   uint8_t i;
   bool_t active_session_ok = false;
   bool_t service_supported_this_session = false;
   uint8_t found_service = Num_Elems(testmode_list);
   uint8_t * diag_buffer_start_data = &DiagBuffer[1];
   uint8_t rc = RC_SNS;      /* Start by assuming that the received service cannot be found, so is not supported. */

   if( Diag_Init_Is() == true )
   {
      /* Search the table for a match with the received message.          */
      for (i=0; i < Num_Elems(testmode_list); i++)
      {
         /* Test this table entry only if the received message is physical
            or the service is supported for functional.                   */
         if ( (PHYSICAL_MSG_RECEIVED == diag_msg_received_type) ||
              (!testmode_list[i].phys_msg_required) )
         {
            /* Is the service supported? */
            if (DiagBuffer[0] == testmode_list[i].service_id)
            {
               /* Is the service supported in the current diagnostic
                  session?                                                */
               if ( (NULL == testmode_list[i].testmode_routine) ||
                    (testmode_list[i].ext_session_required && (!Diag_Is_Extended_Session())) )
               {
                  active_session_ok = false;
               }
               else
               {
                  active_session_ok = true;
                  service_supported_this_session = true;
               }

               /* Does the service have subfunctions? */
               if (testmode_list[i].subfunction_support)
               {
                  if (1 == received_data_length)
                  {
                     /* Service does not have enough bytes to provide
                        a subfunction.  Continue searching for other
                        subfunctions that are supported in this session,
                        because a negative response of RC_SNSAC has
                        precedence over RC_IML_IF.                        */
                     rc = RC_IML_IF;
                  }
                  else if ( testmode_list[i].subfunction_id ==
                            (DiagBuffer[1] & (~DIAG_SUPPRESS_POSITIVE_RESPONSE)) )
                  {
                     /* The received subfunction is supported.            */
                     if (active_session_ok)
                     {
                        /* Service with a subfunction has been found, and
                           it is supported in the current session, so stop
                           searching.                                     */
                        rc = RC_OK;
                        found_service = i;
                        diag_buffer_start_data = &DiagBuffer[2];
                        /* A service with subfunction has the possibility
                           of suppressing a positive response.            */
                        if ((DiagBuffer[1] & DIAG_SUPPRESS_POSITIVE_RESPONSE) != 0)
                        {
                           suppress_response = true;
                        }
                        break;
                     }
                     else
                     {
                        /* Service with a subfunction has been found, but
                           it is not supported in the current session, so
                           continue searching for other subfunctions of
                           this service that are supported in this session,
                           because a negative response of RC_SNSAC has
                           precedence over RC_SFNSAS.                     */
                        rc = RC_SFNSAS;
                     }
                  }
                  else if (RC_SNS == rc)
                  {
                     /* Service with a subfunction has been found, but a
                        supported subfunction has not yet been found.     */
                     rc = RC_SFNS_IF;
                  }
               }
               else
               {
                  /* Service without a subfunction has been found, so
                     stop searching.                                      */
                  rc = RC_OK;
                  found_service = i;
                  diag_buffer_start_data = &DiagBuffer[1];
                  break;
               }
            }
         }
      }

      /* Do additional processing if any match was found. */
      if (RC_SNS != rc)
      {
         /* If no subfunction of a service is supported in the current
            session, then RC_SNSAC has precedence over any other code.    */
         if (!service_supported_this_session)
         {
            rc = RC_SNSAC;
         }
         else if (found_service < Num_Elems(testmode_list))
         {
            /* Does the received message length meet the requirement? */
            if ( (testmode_list[found_service].rx_length != received_data_length) &&
                 (testmode_list[found_service].rx_length > 0) )
            {
               rc = RC_IML_IF;
            }
            else
            {
               /* Received message has met all criteria, so call function that
                  might test for more criteria, and then process the data.      */
               rc = testmode_list[found_service].testmode_routine(diag_buffer_start_data);
            }
         }
      }

      /* All positive responses are sent from the testmode_routine.
         All negative responses are sent from here.                  */
      if (RC_OK != rc)
      {
         DiagTransmit(rc, RC_DLC);
      }
   }
   else
   {
      /* If the diagnostic is not initialized, then response busy  */
      DiagTransmit(RC_BUSY, RC_DLC);
   }
}

/***************************************************************************//**
 *
 * @fn         Diag_Support_Command_Request
 *
 * @brief      Send message via DESIP for command request.
 *
 * @param [in] uint8_t cmd
 * @param [in] uint8_t length_data
 * @param [in] uint8_t *data
 *
 * @return     bool_t
 *
 ******************************************************************************/
void Diag_Support_Command_Request( uint8_t cmd, uint8_t length_data, uint8_t *data)
{
//   SIP_Diag_Support_Cmd_T diag_support_command;
//
//   if( (cmd < NUM_DS_CMD) && (length_data <= SPI_MAX_DIAG_SUPPORT_DATA_SIZE) )
//   {
//      diag_support_command.cmd         = cmd;
//      diag_support_command.length_data = length_data;
//
//      memcpy(&diag_support_command.data[0], data, length_data);
//
//      VIP_Send(VIPP_EV_DIAG_SUPPORT_COMMAND, &diag_support_command, (sizeof(DS_Cmd_Id_T) + 1 + length_data) );
//   }
}
