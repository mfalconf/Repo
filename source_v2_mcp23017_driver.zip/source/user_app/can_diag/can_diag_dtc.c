/*===========================================================================*/
/**
 * @file can_diag_services_dtc.c
 *
 * UDS Services
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * UDS Services: Stored Data Transmission
 *    - ClearDiagnosticInformation (0x14)
 *    - ReadDTCInformation (0x19)
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"
#include "can_diag.h"
#include "can_diag_dtc_cfg.h"

/* Include other necessary files */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
/* Number of DTCSnapshotRecord_number  */
#define DTC_SNAPSHOT_RECORD_NUMBER                    0           /* In this case the server not support multiples DTCSnapshot   */
#define DTC_SNAPSHOT_RECORD_NUMBER_OF_IDENTIFIERS_1   19

/* Default DTC status is test not completed this cycle.*/
#define DEFAULT_DTC_STATUS                            0x40

#define DTC_FAIL_TYPE_NONE                            0        /* no additional info about DTC */
#define DTC_TEST_FAILED_BIT                           (0x00000001)
#define DTC_TEST_FAILED_THIS_CYCLE_BIT                (0x00000002)
#define DTC_PENDING_BIT                               (0x00000004)
#define DTC_CONFIRMED_BIT                             (0x00000008)
#define DTC_TEST_NOT_COMPLETED_THIS_CYCLE_BIT         (0x00000040)

/* DTCStatusAvailabilityMask, mask of dtc bits supported for DTC reports */
#define DTC_BITS_SUPPORTED                            (0xCF)     /*(0x4F)*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/* dtc extended data */
typedef struct dtc_extended_data_tag
{
   uint8_t event_counter;
} dtc_extended_data_t;

/* DTC status bit definitions */
typedef struct diag_dtc_status_bits_tag
{
   bool_t
      dtc_test_failed : 1,
      dtc_test_failed_this_monitoring_cycle : 1,
      dtc_pending_dtc : 1,
      dtc_confirmed_dtc : 1,
      dtc_test_not_completed_since_last_clear : 1,
      dtc_test_failed_since_last_clear : 1,
      dtc_test_not_completed_this_monitoring_cycle : 1,
      dtc_warning_indicator_requested : 1;
} diag_dtc_status_bits_t;

/* dtc status  */
typedef union diag_dtc_status_Tag
{
  uint8_t                  dtc_byte;
  diag_dtc_status_bits_t   dtc_bits;
} diag_dtc_status_T;

typedef enum failure_test_state_Tag
{
    FIRST_FAILURE_TESTS,
    PERIODIC_FAILURE_TESTS
} failure_test_state_T;

/* See 09009, sec. 4.3.1
 */
typedef struct dtc_snapshot_data_tag
{
   uint32_t ecu_time_stamp;
   uint16_t ecu_time_stamp_since_key_on;
   uint16_t key_on_counter;
   uint8_t  failure_type;
} dtc_snapshot_data_t;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
uint32_t diag_periodic_check_prescaler;

/* diag_DTC_ID */
/* This array corresponds 1-to-1 with the Diag_DTC_Name_T enumeration */
#undef X
#define X(a,b,c)      b,
static const uint32_t  diag_DTC_ID[ NUM_FIXED_DTCS ]={DIAG_SUPPORT_DTC_TABLE};

/* diag_DTC_Severity */
/* This array corresponds 1-to-1 with the Diag_DTC_Name_T enumeration */
/* From ISO 14229, sec. D.3:
 *    bits 0-4 : reserved, must be 0
 *    bit 5 : maintenance only
 *    bit 6 : check at next halt
 *    bit 7 : check immediately
 *
 * Actual values defined in "RRM_500US  DTC_Table  (WIP_100311).xls"
 */
#undef X
#define X(a,b,c)      c,
static const uint8_t  diag_DTC_Severity[NUM_FIXED_DTCS]={DIAG_SUPPORT_DTC_TABLE};

/* State of diag_dtc_setting  */
static bool_t dtc_setting_prohibited = false;
static bool_t test_started_this_cycle[NUM_FIXED_DTCS];

/* check_state */
static failure_test_state_T failure_test_cs = FIRST_FAILURE_TESTS;

/*****************************************************************************
 * Status storage variables
 *****************************************************************************/
uint8_t dtc_status_storage[NUM_FIXED_DTCS];
uint8_t dtc_event_counter[NUM_FIXED_DTCS];
Diag_DTC_Code_Id_t dtc_code_id_first;
Diag_DTC_Code_Id_t dtc_code_id_most_recent;
dtc_snapshot_data_t dtc_snapshot_data[NUM_FIXED_DTCS];

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
/* General  */
static void    diag_dtc_set_nm_msg_fail_info (void);
static void    diag_dtc_clear_diagnostic_information (void);
static void    diag_dtc_initialize_and_reset (void);
static void    diag_dtc_convert_to_big_endian (void *dest, const void *src, size_t num_bytes);

/* snapshot */
static void    diag_dtc_take_snapshot(Diag_DTC_Code_Id_t dtc_code_id);
//static void    diag_dtc_clear_snapshot(Diag_DTC_Code_Id_t dtc_code_id);
static void    diag_dtc_clear_ALL_snapshot(void);
static void    diag_dtc_get_snapshot_record(uint8_t *dest, uint8_t dtc_code_id, uint8_t record);
static void    diag_dtc_get_snapshot_data( Diag_DTC_Code_Id_t dtc_code_id, dtc_snapshot_data_t *data );
static void    diag_dtc_set_snapshot_data( Diag_DTC_Code_Id_t dtc_code_id, dtc_snapshot_data_t data );
static uint8_t diag_dtc_get_ext_data_record(uint8_t *data, Diag_DTC_Code_Id_t dtc_code_id, uint8_t requested_record);

/* status DTC  */
static bool_t  diag_dtc_status_enabled_DTC( Diag_DTC_Code_Id_t dtc_code_id );
static uint8_t diag_dtc_get_status_DTC( Diag_DTC_Code_Id_t dtc_code_id );
static void    diag_dtc_set_status_DTC( Diag_DTC_Code_Id_t dtc_code_id, uint8_t dtc_status );
static void    diag_dtc_set_status_ALL_DTCs( uint8_t dtc_status );
static void    diag_dtc_set_status_ALL_DTCs_with_different_status(uint8_t *buffer_dtc_status);

/*event counter   */
static void    diag_dtc_set_event_counter_ALL_DTCs(uint8_t *buffer_event_counter_DTC);
static uint8_t diag_dtc_get_event_counter_DTC( Diag_DTC_Code_Id_t dtc_code_id );
static void    diag_dtc_set_event_counter_DTC( Diag_DTC_Code_Id_t dtc_code_id, uint8_t event_counter );

/* first DTC   */
static Diag_DTC_Code_Id_t diag_dtc_get_first_DTC( void );
static void    diag_dtc_set_first_DTC( Diag_DTC_Code_Id_t dtc_code_id );

/* most recent DTC   */
static Diag_DTC_Code_Id_t diag_dtc_get_most_recent_DTC( void );
static void    diag_dtc_set_most_recent_DTC( Diag_DTC_Code_Id_t dtc_code_id );

/* dtc check   */
static void    diag_dtc_check_initialization(void);

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         Diag_DTC_Init
 *
 * @brief      Initialization for diagnostic DTC service.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_DTC_Init (void)
{
   diag_dtc_set_nm_msg_fail_info();
   diag_dtc_check_initialization();
   diag_periodic_check_prescaler = 0;
}

/***************************************************************************//**
 *
 * @fn         Diag_DTC_Periodic_Checks_Fast
 *
 * @brief      Used to run DTC tests Fast periodically.
 *             This function is called every 10ms in the DiagTask
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_DTC_Periodic_Checks(void)
{
    /* Call the slow periodic dtc check function */
    if( true == Diag_Get_Power_Mode() )
    {
        switch(failure_test_cs)
        {
            case FIRST_FAILURE_TESTS:
                diag_dtc_first_failure_tests();
                failure_test_cs = PERIODIC_FAILURE_TESTS;
                break;
            case PERIODIC_FAILURE_TESTS:
                diag_dtc_periodic_failure_tests_10ms();
                diag_periodic_check_prescaler++;
                if(diag_periodic_check_prescaler > 100) /* Check every 1sec */
                {
                    diag_periodic_check_prescaler = 0;
                    diag_dtc_periodic_failure_tests_1000ms();
                }
                break;
        }
    }
    else
    {
        failure_test_cs = FIRST_FAILURE_TESTS;
    }
}

/***************************************************************************//**
 *
 * @fn         Diag_DTC_Set
 *
 * @brief      changes status of DTC
 *             C2 style DTCs for support of C2 modules
 *
 * @param [in] DTC ID and DTC failure mode and flag if DTC is to be set or cleared
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_DTC_Set (Diag_DTC_Code_Id_t dtc_code_id, bool_t dtc_value)
{
   diag_dtc_status_T temp_dtc;
   bool_t dtc_set_ok;

   dtc_set_ok = false;
   if( !dtc_setting_prohibited  )
   {
      if(   ( diag_dtc_status_enabled_DTC(dtc_code_id) )&&
            ( dtc_code_id < NUM_FIXED_DTCS             )&&
            ( true == Diag_Get_Power_Mode()            )
         )
      {
         dtc_set_ok = true;
      }
   }

   if( true == dtc_set_ok )
   {
      temp_dtc.dtc_byte = diag_dtc_get_status_DTC(dtc_code_id);

      /* Execute only if the first test of the cycle */
      if( !test_started_this_cycle[dtc_code_id] )
      {
         /* If no failure in previous cycle, clear pending bit */
         if (!temp_dtc.dtc_bits.dtc_test_failed_this_monitoring_cycle)
         {
            temp_dtc.dtc_bits.dtc_pending_dtc = false;
         }

         temp_dtc.dtc_bits.dtc_test_failed_this_monitoring_cycle     = false;
      }

      temp_dtc.dtc_bits.dtc_test_not_completed_since_last_clear      = false;
      temp_dtc.dtc_bits.dtc_test_failed_since_last_clear             = false;
      temp_dtc.dtc_bits.dtc_test_not_completed_this_monitoring_cycle = false;
      temp_dtc.dtc_bits.dtc_warning_indicator_requested              = false;

      if( dtc_value ) /* Test failed */
      {
         if( !temp_dtc.dtc_bits.dtc_test_failed_this_monitoring_cycle )
         {
            diag_dtc_set_event_counter_DTC(dtc_code_id, DEFAULT_EVENT_COUNTER);
         }

         temp_dtc.dtc_bits.dtc_test_failed                        = true;
         temp_dtc.dtc_bits.dtc_test_failed_this_monitoring_cycle  = true;
         temp_dtc.dtc_bits.dtc_pending_dtc                        = true;
         temp_dtc.dtc_bits.dtc_confirmed_dtc                      = true;

         if( temp_dtc.dtc_byte != diag_dtc_get_status_DTC(dtc_code_id) )      /* only update DTC data on change  */
         {
            diag_dtc_take_snapshot(dtc_code_id);

            if( diag_dtc_get_first_DTC() >= NUM_FIXED_DTCS )
            {
               diag_dtc_set_first_DTC(dtc_code_id);
            }

            diag_dtc_set_most_recent_DTC(dtc_code_id);
         }
      }
      else           /* Test passed */
      {
         temp_dtc.dtc_bits.dtc_test_failed = false;
      }

      if (temp_dtc.dtc_byte != diag_dtc_get_status_DTC(dtc_code_id))      /* only update DTC data on change  */
      {
         diag_dtc_set_status_DTC(dtc_code_id, temp_dtc.dtc_byte);

         if (temp_dtc.dtc_bits.dtc_test_failed)
         {
            /* If dtc_test_failed is set, then dtc_confirmed_dtc must
               also be set.  Immediately set GenericFailSts and
               CurrentFailSts flags in NM message.                   */
//            NmSetCurrentFailState(kNmFunctionFail);
//            NmSetGenericFailState(kNmFunctionFail);
         }
         else
         {
            /* If dtc_test_failed is not set, then need to check
               the status of all DTCs.                               */
            diag_dtc_set_nm_msg_fail_info();
         }
      }
      test_started_this_cycle[dtc_code_id] = true;
   }
}

/***************************************************************************//**
 *
 * @fn         Diag_DTC_Key_On
 *
 * @brief      Updates DTC status as needed for key on.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_DTC_Key_On (void)
{
   uint8_t dtc_code_id;
   uint8_t temp_event_counter;
   diag_dtc_status_T temp_dtc;
   uint8_t buffer_dtc_status[NUM_FIXED_DTCS];
   uint8_t buffer_event_counter_DTC[NUM_FIXED_DTCS];

   for( dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++ )
   {
      temp_dtc.dtc_byte    = diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id);
      temp_event_counter   = diag_dtc_get_event_counter_DTC((Diag_DTC_Code_Id_t)dtc_code_id);

      if( !temp_dtc.dtc_bits.dtc_test_failed )
      {
         if( 0 != temp_event_counter )
         {
            temp_event_counter--;
         }
      }

      /* criteria of automatic deletion */
      if( 0 == temp_event_counter )
      {
         temp_dtc.dtc_bits.dtc_confirmed_dtc = false;
      }

      temp_dtc.dtc_bits.dtc_test_not_completed_since_last_clear   = false;
      temp_dtc.dtc_bits.dtc_test_failed_since_last_clear          = false;
      temp_dtc.dtc_bits.dtc_warning_indicator_requested           = false;

      /* Load dtc_status each dtc_code_id */
      buffer_dtc_status[dtc_code_id] = temp_dtc.dtc_byte;

      /* Load event counter for each dtc_code_id */
      buffer_event_counter_DTC[dtc_code_id] = temp_event_counter;

      test_started_this_cycle[dtc_code_id] = false;
   }

   diag_dtc_set_status_ALL_DTCs_with_different_status(&buffer_dtc_status[0]);

   diag_dtc_set_event_counter_ALL_DTCs(&buffer_event_counter_DTC[0]);

   diag_dtc_set_nm_msg_fail_info();
}

/***************************************************************************//**
 *
 * @fn         Diag_DTC_Key_Off
 *
 * @brief      Updates DTC status as needed for key off.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_DTC_Key_Off(void)
{

}

/***************************************************************************//**
 *
 * @fn         Diag_Enable_DTCs
 *
 * @brief      Enables setting of DTCS.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Diag_DTC_Enable (void)
{
   dtc_setting_prohibited = false;
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_set_nm_msg_fail_info
 *
 * @brief      Check all DTCs for failures, and set GenericFailSts and
 *             CurrentFailSts flags in NM message, according to
 *             requirements in 09009 section 4.2.7.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void diag_dtc_set_nm_msg_fail_info (void)
{
   uint8_t dtc_code_id;
   bool any_test_failed = false;
   bool any_test_confirmed = false;

   for ( dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++ )
   {
      if (0 != (diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id) & DTC_TEST_FAILED_BIT))
      {
         any_test_failed = true;
         break;
      }
      if (0 != (diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id) & DTC_CONFIRMED_BIT))
      {
         any_test_confirmed = true;
      }
   }

   if (any_test_failed)
   {
//      NmSetCurrentFailState(kNmFunctionFail);
//      NmSetGenericFailState(kNmFunctionFail);
   }
   else
   {
//      NmSetCurrentFailState(kNmNoFunctionFail);
      if (any_test_confirmed)
      {
//         NmSetGenericFailState(kNmFunctionFail);
      }
      else
      {
//         NmSetGenericFailState(kNmNoFunctionFail);
      }
   }
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_clear_diagnostic_information
 *
 * @brief      Clears DTC info.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void diag_dtc_clear_diagnostic_information (void)
{
   diag_dtc_initialize_and_reset();
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_initialize_and_reset
 *
 * @brief      Initialize diagnostic variables and trouble code status.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void diag_dtc_initialize_and_reset (void)
{
   uint16_t dtc_code_id;
   uint8_t buffer_event_counter_DTC[NUM_FIXED_DTCS];

   diag_dtc_check_initialization();

   diag_dtc_set_first_DTC(INVALID_VALUE_OF_DTC);
   diag_dtc_set_most_recent_DTC(INVALID_VALUE_OF_DTC);

   diag_dtc_set_status_ALL_DTCs(DEFAULT_DTC_STATUS);
   diag_dtc_clear_ALL_snapshot();

   for( dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++ )
   {
      buffer_event_counter_DTC[dtc_code_id]  = 0;
      test_started_this_cycle[dtc_code_id]   = false;
   }

   diag_dtc_set_event_counter_ALL_DTCs(&buffer_event_counter_DTC[0]);

//   NmSetCurrentFailState(kNmNoFunctionFail);
//   NmSetGenericFailState(kNmNoFunctionFail);
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_take_snapshot
 *
 * @brief      Stores relevant data for the snapshot.
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 *
 * @return     void
 *
 ******************************************************************************/
static void diag_dtc_take_snapshot(Diag_DTC_Code_Id_t dtc_code_id)
{
   dtc_snapshot_data_t temp_snapshot;

   /* Obtains data for store in snapshot  */
   temp_snapshot.ecu_time_stamp              = 0;
   temp_snapshot.ecu_time_stamp_since_key_on = 0;
   temp_snapshot.key_on_counter              = 0;
   temp_snapshot.failure_type                = diag_DTC_ID[dtc_code_id] & 0x0000FF;

   /* Set dtc snapshot data   */
   diag_dtc_set_snapshot_data(dtc_code_id, temp_snapshot);
}

///***************************************************************************//**
// *
// * @fn         diag_dtc_clear_snapshot
// *
// * @brief      Clears snapshots for DTC.
// *
// * @param [in] Diag_DTC_Code_Id_t dtc_code_id
// *
// * @return     void
// *
// ******************************************************************************/
//static void diag_dtc_clear_snapshot(Diag_DTC_Code_Id_t dtc_code_id)
//{
//   dtc_snapshot_data_t temp_snapshot;
//
//   /* Clear snapshot data  */
//   temp_snapshot.ecu_time_stamp              = 0;
//   temp_snapshot.ecu_time_stamp_since_key_on = 0;
//   temp_snapshot.key_on_counter              = 0;
//   temp_snapshot.failure_type                = 0;
//
//   /* Set dtc snapshot data   */
//   diag_dtc_set_snapshot_data(dtc_code_id, temp_snapshot);
//}

/***************************************************************************//**
 *
 * @fn         diag_dtc_clear_ALL_snapshot
 *
 * @brief      Clears ALL snapshots for DTC.
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void diag_dtc_clear_ALL_snapshot(void)
{
    uint8_t dtc_code_id;

    dtc_snapshot_data_t dtc_snapshot_data_aux;
    dtc_snapshot_data_aux.ecu_time_stamp = 0;
    dtc_snapshot_data_aux.ecu_time_stamp_since_key_on = 0;
    dtc_snapshot_data_aux.failure_type = 0;
    dtc_snapshot_data_aux.key_on_counter = 0;

   for (dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++)
   {
       dtc_snapshot_data[dtc_code_id].ecu_time_stamp = dtc_snapshot_data_aux.ecu_time_stamp;
       dtc_snapshot_data[dtc_code_id].ecu_time_stamp_since_key_on = dtc_snapshot_data_aux.ecu_time_stamp_since_key_on;
       dtc_snapshot_data[dtc_code_id].failure_type = dtc_snapshot_data_aux.failure_type;
       dtc_snapshot_data[dtc_code_id].key_on_counter = dtc_snapshot_data_aux.key_on_counter;
   }
}


/***************************************************************************//**
 *
 * @fn         diag_get_snapshot_record
 *
 * @brief      This function reports the requested snapshot record.
 *             NOTE: Record IDs from 09009, sec. 4.3.1
 *
 * @param [in] dest - location to write data
 * @param [in] dtc_code_id - offset of requested DTC
 * @param [in] record - record number requested
 *
 * @return     void
 *
 ******************************************************************************/
static void diag_dtc_get_snapshot_record (uint8_t *dest, uint8_t dtc_code_id, uint8_t record)
{
   dtc_snapshot_data_t snapshot_data;

   dest[0] = record;
   dest[1] = 0x04;   /* Number of IDs in record */

   diag_dtc_get_snapshot_data((Diag_DTC_Code_Id_t)dtc_code_id, &snapshot_data);

   dest[2] = 0x10;   /* Time stamp */
   dest[3] = 0x08;
   diag_dtc_convert_to_big_endian(&dest[4], &(snapshot_data.ecu_time_stamp), 4);

   dest[8] = 0x10;   /* Time stamp since key on*/
   dest[9] = 0x09;
   diag_dtc_convert_to_big_endian(&dest[10], &(snapshot_data.ecu_time_stamp_since_key_on), 2);

   dest[12] = 0x20;   /* Key on counter */
   dest[13] = 0x0A;
   diag_dtc_convert_to_big_endian(&dest[14], &(snapshot_data.key_on_counter), 2);

   dest[16] = 0x60;   /* Failure type */
   dest[17] = 0x82;
   dest[18] = snapshot_data.failure_type;
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_convert_to_big_endian
 *
 * @brief      Converts a half_word or word from Little Endian to Big Endian.
 *
 * @param [in] *src - pointer to half_word or word to be converted
 *             *dest - pointer to destination of the conversion
 *             num_bytes - # of bytes to convert
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
static void diag_dtc_convert_to_big_endian (void *dest, const void *src, size_t num_bytes)
{
   uint8_t *temp_dest = (uint8_t *)dest;
   const uint8_t *temp_src = ((const uint8_t *)src) + num_bytes;

   for ( ; 0 != num_bytes ; num_bytes--)
   {
      *(temp_dest++) = *(--temp_src);
   }
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Clear
 *
 * @brief      This function clears all DTC information.  This only
 *             works when commanded to clear "all groups" (0xFFFFFF)
 *             per 07209, Table 66 � Request message data parameter
 *             definition.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Clear (uint8_t *data)
{
   uint8_t return_code = RC_ROOR;

   if ((0xFF == data[0]) && (0xFF == data[1]) && (0xFF == data[2]))
   {
      diag_dtc_clear_diagnostic_information();
      DiagTransmit(RC_OK, 1);
      return_code = RC_OK;
   }

   return return_code;
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Control_On
 *
 * @brief      Enables setting of DTCs.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Control_On (uint8_t *data)
{
   dtc_setting_prohibited = false;
   DiagTransmit(RC_OK, 2);
   return RC_OK;
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Control_Off
 *
 * @brief      Disables setting of DTCS.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Control_Off (uint8_t *data)
{
   dtc_setting_prohibited = true;
   DiagTransmit(RC_OK, 2);
   return RC_OK;
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Read_Number_By_Status
 *
 * @brief      This function reports the numbers DTCs that match the requested
 *             status.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Read_Number_By_Status (uint8_t *data)
{
   uint8_t dtc_code_id;
   uint8_t matching_codes = 0;
   uint8_t status_mask = data[0];
   uint8_t status;

   for( dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++ )
   {
      status = diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id);
      if ((diag_dtc_status_enabled_DTC((Diag_DTC_Code_Id_t)dtc_code_id)) &&
          (0 != (status_mask & status)) )
      {
         matching_codes++;
      }
   }

   data[1] = 0x00;   /* DTCFormatIdentifier: 0x00 (ISO15031-6DTCFormat) */
   data[2] = matching_codes;

   DiagTransmit(RC_OK, 2 + 1 + 2);

   return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Read_By_Status
 *
 * @brief      This function reports the DTCs that match the requested
 *             status.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Read_By_Status (uint8_t *data)
{
   uint8_t dtc_code_id;
   uint8_t matching_codes = 0;
   uint8_t status_mask = data[0];
   uint8_t status;

   data[0] = DTC_BITS_SUPPORTED;

   for (dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++)
   {
      status = diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id);
      if ((diag_dtc_status_enabled_DTC((Diag_DTC_Code_Id_t)dtc_code_id)) &&
          (0 != (status_mask & status)))
      {
         data[(matching_codes * 4) + 1] = (diag_DTC_ID[dtc_code_id] >> 16) & 0xFF;
         data[(matching_codes * 4) + 2] = (diag_DTC_ID[dtc_code_id] >> 8) & 0xFF;
         data[(matching_codes * 4) + 3] = diag_DTC_ID[dtc_code_id] & 0xFF;
         data[(matching_codes * 4) + 4] = status;

         matching_codes++;
      }
   }
   DiagTransmit(RC_OK, 2 + 1 + (4 * matching_codes));

   return RC_OK;
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Read_Snapshot
 *
 * @brief      This function reports the requested snapshot record.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Read_Snapshot (uint8_t *data)
{
   uint8_t  return_code = RC_ROOR;
   uint32_t requested_dtc;
   uint8_t  requested_record;
   uint8_t  dtc_code_id;
   bool     dtc_found = false;

   /* obtain the dtc number   */
   requested_dtc = (data[0] << 16) + (data[1] << 8) + data[2];

   /* obtain the DTCSnapshotRecordNumber  */
   requested_record = data[3];

   /* Search for requested DTC */
   for( dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++ )
   {
      if ((diag_dtc_status_enabled_DTC((Diag_DTC_Code_Id_t)dtc_code_id)) &&
          (diag_DTC_ID[dtc_code_id] == requested_dtc))
      {
         dtc_found = true;
         break;
      }
   }

   if( dtc_found == true )
   {
      /* data[0] = DTCHighByte   */
      /* data[1] = DTCMiddleByte */
      /* data[2] = DTCLowByte    */

      data[3] = diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id); /* status of DTC  */

      /* If requested DTC is found and requested record is valid, report the data */
      if( requested_record <=  DTC_SNAPSHOT_RECORD_NUMBER )
      {
         diag_dtc_get_snapshot_record(&data[4], dtc_code_id, requested_record);

         DiagTransmit(RC_OK, 2 + 4 + DTC_SNAPSHOT_RECORD_NUMBER_OF_IDENTIFIERS_1);
         return_code = RC_OK;
      }
      else if ( 0xFF == requested_record )   /* report all DTCSnapshot  */
      {
         diag_dtc_get_snapshot_record(&data[4], dtc_code_id, 0);

         DiagTransmit(RC_OK, 2 + 4 + DTC_SNAPSHOT_RECORD_NUMBER_OF_IDENTIFIERS_1);
         return_code = RC_OK;

         /* only made for one snapshot!!!!
          * In the case of more snapshot, to make!!!!
          *
          * diag_dtc_get_snapshot_record(&data[4 + (DTC_SNAPSHOT_RECORD_NUMBER_OF_IDENTIFIERS_1 * 1)], dtc_code_id, 1);
          * diag_dtc_get_snapshot_record(&data[4 + (DTC_SNAPSHOT_RECORD_NUMBER_OF_IDENTIFIERS_1 * 2)], dtc_code_id, 2);
          * diag_dtc_get_snapshot_record(&data[4 + (DTC_SNAPSHOT_RECORD_NUMBER_OF_IDENTIFIERS_1 * 3)], dtc_code_id, n);
          *
          * DiagTransmit(RC_OK, 2 + 4 + (DTC_SNAPSHOT_RECORD_NUMBER_OF_IDENTIFIERS_1 * n));
          * return_code = RC_OK;
         */
      }
   }
   else
   {
      /* Invalid request, do nothing (allow negative response) */
   }

   return(return_code);
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Read_Ext_Data_Record
 *
 * @brief      This function reports the requested extended data
 *             record.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Read_Ext_Data_Record (uint8_t *data)
{
   uint8_t return_code = RC_ROOR;
   uint32_t requested_dtc = (data[0] << 16) + (data[1] << 8) + data[2];
   uint8_t requested_record = data[3];
   uint8_t dtc_code_id;
   bool dtc_found = false;
   uint8_t ext_data_length;


   /* Search for requested DTC */
   for (dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++)
   {
      if ((diag_dtc_status_enabled_DTC((Diag_DTC_Code_Id_t)dtc_code_id)) &&
          (diag_DTC_ID[dtc_code_id] == requested_dtc))
      {
         dtc_found = true;
         break;
      }
   }

   if (dtc_code_id >= NUM_FIXED_DTCS)
   {
      dtc_code_id = NUM_FIXED_DTCS - 1;
   }

   data[3] = diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id);

   /* If requested DTC is found and requested record is valid, report the data */
   if( dtc_found && ((1 == requested_record) || (0xFF == requested_record)) )
   {
      ext_data_length = diag_dtc_get_ext_data_record(&data[4], (Diag_DTC_Code_Id_t)dtc_code_id, requested_record);

      DiagTransmit(RC_OK, (2 + 4 + ext_data_length));
      return_code = RC_OK;
   }

   return(return_code);
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Read_Number_Of_DTC_By_Severity
 *
 * @brief      This function counts the number of DTCs matching the
 *             requested severity and status.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Read_Number_Of_DTC_By_Severity (uint8_t *data)
{
   uint8_t severity_mask = data[0];
   uint8_t status_mask = data[1];
   uint16_t matching_codes = 0;
   uint8_t dtc_code_id;
   uint8_t status;

   data[0] = DTC_BITS_SUPPORTED;
   data[1] = 0;   /* Format ID, 0 per 07209, table 80 */

   for (dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++)
   {
      status = diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id);
      if ((diag_dtc_status_enabled_DTC((Diag_DTC_Code_Id_t)dtc_code_id)) &&
          (0 != (status_mask & status)) &&
          (0 != (severity_mask & diag_DTC_Severity[dtc_code_id])))
      {
         matching_codes++;
      }
   }

   diag_dtc_convert_to_big_endian(&data[2], &matching_codes, sizeof(matching_codes));
   DiagTransmit(RC_OK, 2 + 4);

   return RC_OK;
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Read_By_Severity
 *
 * @brief      This function reports the DTCs matching the requested
 *             severity and status.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Read_By_Severity (uint8_t *data)
{
   uint8_t return_code = RC_IML_IF;
   uint8_t severity_mask = data[0];
   uint8_t status_mask = data[1];
   uint8_t matching_codes = 0;
   uint8_t dtc_code_id;
   uint8_t status;

   data[0] = DTC_BITS_SUPPORTED;

   for (dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++)
   {
      status = diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id);
      if ((diag_dtc_status_enabled_DTC((Diag_DTC_Code_Id_t)dtc_code_id)) &&
          (0 != (status_mask & status)) &&
          (0 != (severity_mask & diag_DTC_Severity[dtc_code_id])))
      {
         data[(matching_codes * 6) + 1] = matching_codes & 0xFF;
         data[(matching_codes * 6) + 2] = severity_mask; /* Functional unit, undefined */
         data[(matching_codes * 6) + 3] = (diag_DTC_ID[dtc_code_id] >> 16) & 0xFF;
         data[(matching_codes * 6) + 4] = (diag_DTC_ID[dtc_code_id] >> 8) & 0xFF;
         data[(matching_codes * 6) + 5] = diag_DTC_ID[dtc_code_id] & 0xFF;
         data[(matching_codes * 6) + 6] = status;

         matching_codes++;
      }
   }

   /* The max length of DiagBuffer is 255. This length is modify via canGen.
    * In documentation of vector, says what the max value for this buffer is 255.
    * I don't sure if can be use a greater value. For safety take the max value to 255.
    * In the case what response is greater of 255, then send negative response with
    * code RC_IML_IF (0x13)
    */
   if( ( 2 + 1 + (6 * matching_codes) ) < 254 )
   {
      DiagTransmit(RC_OK, 2 + 1 + (6 * matching_codes));
      return_code = RC_OK;
   }

   return( return_code );
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Read_Severity_Info
 *
 * @brief      This function reports the severity info of a requested
 *             DTC.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Read_Severity_Info (uint8_t *data)
{
   uint8_t return_code = RC_ROOR;
   uint32_t requested_dtc = (data[0] << 16) + (data[1] << 8) + data[2];
   uint8_t dtc_code_id;

   data[0] = DTC_BITS_SUPPORTED;

   for (dtc_code_id = 0; dtc_code_id < NUM_FIXED_DTCS; dtc_code_id++)
   {
      if ( (diag_dtc_status_enabled_DTC((Diag_DTC_Code_Id_t)dtc_code_id)) &&
           (diag_DTC_ID[dtc_code_id] == requested_dtc))
      {
         data[1] = diag_DTC_Severity[dtc_code_id]; /* Severity */
         data[2] = 0x00; /* Functional unit, undefined */
         data[3] = (diag_DTC_ID[dtc_code_id] >> 16) & 0xFF;
         data[4] = (diag_DTC_ID[dtc_code_id] >> 8) & 0xFF;
         data[5] = diag_DTC_ID[dtc_code_id] & 0xFF;
         data[6] = diag_dtc_get_status_DTC((Diag_DTC_Code_Id_t)dtc_code_id);

         DiagTransmit(RC_OK, 2 + 7);
         return_code = RC_OK;
         break;
      }
   }

   return return_code;
}

/***************************************************************************//**
 *
 * @fn         DG_Read_First_Confirmed_DTC
 *
 * @brief      This function reports information on the first DTC.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Read_First_Confirmed (uint8_t *data)
{
   Diag_DTC_Code_Id_t dtc_code_id = diag_dtc_get_first_DTC();

   if( dtc_code_id < INVALID_VALUE_OF_DTC)
   {
      data[1] = (diag_DTC_ID[dtc_code_id] >> 16) & 0xFF;
      data[2] = (diag_DTC_ID[dtc_code_id] >> 8) & 0xFF;
      data[3] = diag_DTC_ID[dtc_code_id] & 0xFF;
   }
   else
   {
      data[1] = 0xFF;
      data[2] = 0xFF;
      data[3] = 0xFF;
   }
   data[0] = DTC_BITS_SUPPORTED;
   data[4] = diag_dtc_get_status_DTC(dtc_code_id);

   DiagTransmit(RC_OK, 2 + 5);

   return RC_OK;
}

/***************************************************************************//**
 *
 * @fn         DG_Read_Most_Recent_Confirmed_DTC
 *
 * @brief      This function reports information on the most recent
 *             DTC.
 *
 * @param [in] data - data received in request
 *
 * @return     return code indicating success or failure
 *
 ******************************************************************************/
uint8_t DG_DTC_Read_Most_Recent_Confirmed (uint8_t *data)
{
   Diag_DTC_Code_Id_t dtc_code_id = diag_dtc_get_most_recent_DTC();

   if( dtc_code_id < (uint8_t)INVALID_VALUE_OF_DTC)
   {
      data[1] = (diag_DTC_ID[dtc_code_id] >> 16) & 0xFF;
      data[2] = (diag_DTC_ID[dtc_code_id] >> 8) & 0xFF;
      data[3] = diag_DTC_ID[dtc_code_id] & 0xFF;
   }
   else
   {
      data[1] = 0xFF;
      data[2] = 0xFF;
      data[3] = 0xFF;
   }
   data[0] = DTC_BITS_SUPPORTED;
   data[4] = diag_dtc_get_status_DTC(dtc_code_id);

   DiagTransmit(RC_OK, 2 + 5);

   return RC_OK;
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_status_enabled_DTC
 *
 * @brief      Return if the dtc is enable
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 *
 * @return     bool_t
 *
 ******************************************************************************/
static bool_t diag_dtc_status_enabled_DTC( Diag_DTC_Code_Id_t dtc_code_id )
{
   bool_t dtc_enabled = false;

   if( dtc_code_id < NUM_FIXED_DTCS )
   {
       /* At this point we could check if there's any impediment to check any specific dtc */
       dtc_enabled = true;
   }

   return(dtc_enabled);
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_get_status_DTC
 *
 * @brief      Return the status of dtc
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 *
 * @return     uint8_t
 *
 ******************************************************************************/
static uint8_t diag_dtc_get_status_DTC( Diag_DTC_Code_Id_t dtc_code_id )
{
   uint8_t dtc_status = 0xFF;

   if( dtc_code_id < (uint8_t)NUM_FIXED_DTCS )
   {
      dtc_status = dtc_status_storage[dtc_code_id];
   }

   return(dtc_status);
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_set_status_DTC
 *
 * @brief      Set status of DTC
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 * @param [in] uint8_t dtc_status
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_set_status_DTC( Diag_DTC_Code_Id_t dtc_code_id, uint8_t dtc_status )
{
   if( dtc_code_id < NUM_FIXED_DTCS )
   {
       dtc_status_storage[dtc_code_id] = dtc_status;
   }
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_set_status_ALL_DTCs
 *
 * @brief      Set status of ALL DTCs
 *
 * @param [in] uint8_t dtc_status
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_set_status_ALL_DTCs( uint8_t dtc_status )
{
   memset(dtc_status_storage, dtc_status, NUM_FIXED_DTCS);
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_set_status_ALL_DTCs_with_different_status
 *
 * @brief      Set status of ALL DTCs with different status
 *
 * @param [in] uint8_t *buffer_dtc_status
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_set_status_ALL_DTCs_with_different_status(uint8_t *buffer_dtc_status)
{
   memcpy(dtc_status_storage, buffer_dtc_status, NUM_FIXED_DTCS);
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_set_event_counter_ALL_DTCs
 *
 * @brief      Set event counter of ALL DTCs with different event counter
 *
 * @param [in] uint8_t *buffer_event_counter_DTC
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_set_event_counter_ALL_DTCs(uint8_t *buffer_event_counter_DTC)
{
   memcpy(dtc_event_counter, buffer_event_counter_DTC, NUM_FIXED_DTCS);
}


/***************************************************************************//**
 *
 * @fn         diag_dtc_get_event_counter_DTC
 *
 * @brief      Return the event counter of DTC
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 *
 * @return     uint8_t
 *
 ******************************************************************************/
static uint8_t diag_dtc_get_event_counter_DTC( Diag_DTC_Code_Id_t dtc_code_id )
{
   uint8_t event_counter;

   if( dtc_code_id < NUM_FIXED_DTCS )
   {
      event_counter = dtc_event_counter[dtc_code_id];
   }

   return(event_counter);
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_set_event_counter_DTC
 *
 * @brief      Set event counter.
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 * @param [in] uint8_t event_counter
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_set_event_counter_DTC( Diag_DTC_Code_Id_t dtc_code_id, uint8_t event_counter )
{
   if( dtc_code_id < NUM_FIXED_DTCS )
   {
      dtc_event_counter[dtc_code_id] = event_counter;
   }
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_get_first_DTC
 *
 * @brief      Return the first DTC
 *
 * @param [in] none
 *
 * @return     uint8_t
 *
 ******************************************************************************/
static Diag_DTC_Code_Id_t diag_dtc_get_first_DTC( void )
{
   return(dtc_code_id_first);
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_set_first_DTC
 *
 * @brief      Set first dtc
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_set_first_DTC( Diag_DTC_Code_Id_t dtc_code_id )
{
    dtc_code_id_first = dtc_code_id;
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_get_most_recent_DTC
 *
 * @brief      Return the most recent dtc
 *
 * @param [in] none
 *
 * @return     uint8_t
 *
 ******************************************************************************/
static Diag_DTC_Code_Id_t diag_dtc_get_most_recent_DTC( void )
{
   return(dtc_code_id_most_recent);
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_set_most_recent_DTC
 *
 * @brief      Set most recent dtc
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_set_most_recent_DTC( Diag_DTC_Code_Id_t dtc_code_id )
{
    dtc_code_id_most_recent = dtc_code_id;
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_get_snapshot_data
 *
 * @brief      Get snapshot data
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 * @param [in] dtc_snapshot_data_t *data
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_get_snapshot_data( Diag_DTC_Code_Id_t dtc_code_id, dtc_snapshot_data_t *data )
{
   if( dtc_code_id < NUM_FIXED_DTCS )
   {
       memcpy(data, &dtc_snapshot_data[dtc_code_id], sizeof(dtc_snapshot_data_t));
   }
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_set_snapshot_data
 *
 * @brief      Set snapshot data
 *
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 * @param [in] dtc_snapshot_data_t data
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_set_snapshot_data (Diag_DTC_Code_Id_t dtc_code_id, dtc_snapshot_data_t data)
{
   if( dtc_code_id < NUM_FIXED_DTCS )
   {
      dtc_snapshot_data[dtc_code_id].ecu_time_stamp = data.ecu_time_stamp;
      dtc_snapshot_data[dtc_code_id].ecu_time_stamp_since_key_on = data.ecu_time_stamp_since_key_on;
      dtc_snapshot_data[dtc_code_id].failure_type = data.failure_type;
      dtc_snapshot_data[dtc_code_id].key_on_counter = data.key_on_counter;
   }
}

/***************************************************************************//**
 *
 * @fn         DG_DTC_Get_Ext_Data_Record
 *
 * @brief      Get get extended data of DTC
 *
 * @param [in] uint8_t *data
 * @param [in] Diag_DTC_Code_Id_t dtc_code_id
 * @param [in] uint8_t requested_record
 *
 * @return     uint8_t
 *
 ******************************************************************************/
static uint8_t diag_dtc_get_ext_data_record(uint8_t *data, Diag_DTC_Code_Id_t dtc_code_id, uint8_t requested_record)
{
    uint8_t length;

    /* There are only 1 record, therefore requested_record not used */
    data[0] = 0x01;      /* DTC Extended Data Record Number */
    length = 1;

    /* Extended Data #1 - Aging Counter */
    data[1] = 0x60;
    data[2] = 0x80;
    data[3] = dtc_event_counter[dtc_code_id];

    length += 3;

    return(length);
}

/***************************************************************************//**
 *
 * @fn         diag_dtc_check_initialization
 *
 * @brief      Initialization for check DTCs
 *
 * @param [in] none
 *
 * @return     none
 *
 ******************************************************************************/
static void diag_dtc_check_initialization(void)
{
    /* Is necessary to check if the non volatile memory has been initialized
     * This is done with a signature field (i.e. signature==0x55AA)
     * If the non volatile memory is not initialized then we shall init the dtc status data,
     * and store them in the non volatile memory, and finally sign it with the signature.
     * If the non volatile memory is already initialized we just need to retrieve the dtc status data
     * */
//    if (0x55AA == DG_Get_BackupMemory_Signature())
//    {
//
//    }
//    else
//    {
        dtc_code_id_first = INVALID_VALUE_OF_DTC;

        dtc_code_id_most_recent = INVALID_VALUE_OF_DTC;

        memset(dtc_status_storage, DEFAULT_DTC_STATUS, NUM_FIXED_DTCS);
        memset(dtc_event_counter, 0, NUM_FIXED_DTCS);

        diag_dtc_clear_ALL_snapshot();

//        DG_Set_BackupMemory_Signature(0x55AA);
//    }
}

