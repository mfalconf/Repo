#ifndef CAN_TP_CBK_H
#define CAN_TP_CBK_H
/*===========================================================================*/
/**
 * @file CAN_TP_CBK.h
 *
 * This header file contains macros for configuration of the can_tp module
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#define ADDR_PHY_RESP                           0x7DD
#define ADDR_PHY_REQ                            0x773
#define ADDR_FUN_REQ                            0x700

/* Call rate of the periodic task */
#define CALL_RATE                               10

/* default value : max as per standard = 1000msec */
#define N_As_TIME_OUT                           20

/* default value : max as per standard = 1000msec */
#define N_Ar_TIME_OUT                           50

/* default value : max as per standard = 1000msec */
#define N_Bs_TIME_OUT                           70

/* default value : max as per standard = 1000msec */
#define N_Cr_TIME_OUT                           150

/* default block size for receive. */
#define TP_RX_BLOCK_SIZE_MAX                    0

/* default STmin for receive.      */
#define TP_RX_SEPARATION_TIME_MIN               1

/* Configure the channel number(0, 1, 0r 2) on which TP is implemented */
#define TP_CHANNEL_NUMBER                       0

/* Wait frame Transmit support: if 0 no wait frame tx supported  */
/* otherwise configure max wait frame tx count */
#define N_WAIT_FRAME_TX_MAX                     0

/* If the Padding is required select as 'TRUE'. Otherwise 'FALSE'*/
#define PADDING_OPERATION                       TRUE

/* Default selected as -xaa; change it to required value */
#define PADDING_BYTE                            00

#define TP_FIXED_FRAME_DLC

#define RX_MULTI_BUFFER_SUPPORT

#define STmin_ZERO                             CALL_RATE
#define STmin_MAX_VALUE                        0x7Fu /*125ms*/

#define TP_DIAG_PHYSICAL_MSG_SUPPORT
#define TP_DIAG_FUNCTIONAL_MSG_SUPPORT

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern void TP_Transmit_Buffer_Empty(void);
extern void TP_Receive_Buffer_Filled(void);
extern void TP_USData_FF_Indication(uint16_t RxLength);
extern void DG_TP_Request_Received(uint16_t RxLength, uint8_t Result);
extern void DG_TP_USData_Confirm(uint8_t Result);
extern bool_t DG_Response_Pending(void);
extern void TP_Can_Tx_Message(uint8_t *data);
extern bool_t TP_Is_Response_Pending(void);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file CAN_TP_CBK.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 24-Apr-2020 Pablo Luis Joaquim
 *   - Created initial file based in CCA - CAN Transport Protocol
 *
 */
/*===========================================================================*/
#endif /* CAN_TP_CBK_H */
