#ifndef CAN_DIAG_H
#   define CAN_DIAG_H
/*===========================================================================*/
/**
 * @file can_diag.h
 *
 * can_diag Provide API description and define/delete next line
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "can_diag_dtc_cfg.h"

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
/*--- Diag service definition ------------------------------------------------*/
#define DS_NEGATIVE_RESPONSE   0x7F

/*--- Diag Return Code Definition --------------------------------------------*/
#define RC_OK          0x00    /* Positive Response                           */
#define RC_SNS         0x11    /* Service not supported                       */
#define RC_SFNS_IF     0x12    /* Subfunction not sup.                        */
#define RC_IML_IF      0x13    /* Incorrect msg length/Invalid format         */
#define RC_BUSY        0x21    /* Busy-repeatRequest                          */
#define RC_CNCRSE      0x22    /* Conditions not correct                      */
#define RC_SE          0x24    /* Sequence error                              */
#define RC_ROOR        0x31    /* Request Out Of Range                        */
#define RC_SAD         0x33    /* Security access denied                      */
#define RC_IK          0x35    /* Invalid Key                                 */
#define RC_ENOA        0x36    /* Exceed number of attempts                   */
#define RC_RTDNE       0x37    /* Required time delay not expired             */
#define RC_ULNA        0x70    /* Upload/Download not accepted                */
#define RC_TDS         0x71    /* Transfer data suspended                     */
#define RC_GPF         0x72    /* General programming failure                 */
#define RC_WBSC        0x73    /* Wrong block sequence counter                */
#define RC_RCRRP       0x78    /* Request correctly received response pending */
#define RC_SFNSAS      0x7E    /* Subfunction not supported in active session */
#define RC_SNSAC       0x7F    /* Service not supported in active session     */

#define RC_DLC         3       /* Length of RC-Code                           */

#define DIAG_SUPPRESS_POSITIVE_RESPONSE   (0x80)

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define CAN_DIAG_BUFFER_SIZE              210

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum diag_msg_received_Tag
{
   PHYSICAL_MSG_RECEIVED,
   FUNCTIONAL_MSG_RECEIVED,
} diag_msg_received_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/
/*===========================================================================*
 * Function definitions for can_diag
 *===========================================================================*/
extern void    Diag_Init(void);
extern void    Diag_Not_Init(void);
extern bool_t  Diag_Init_Is(void);
extern uint32_t Diag_GetClock (void);
extern void    DiagTask (void);
extern void    DiagTransmit (uint8_t rc, uint16_t length);
extern uint8_t Diag_Get_Received_Data_Length (void);
extern bool_t  Diag_Is_Received_Physical_Message (void);
extern bool_t  Diag_Is_Suppress_Response (void);
extern void    Diag_Set_Suppress_Response(void);
extern bool_t  Diag_Get_Power_Mode (void);
extern void    Diag_Clear_Diagnostics_Mode (void);
extern void    Diag_Support_Command_Request( uint8_t cmd, uint8_t length_data, uint8_t *data);

/* Function definitions for the can_tp_callouts callbacks */
extern void Diag_Tx_Confirmation(uint8_t state);
extern void Diag_Rx_Indication(uint16_t dataLength, diag_msg_received_T diag_frame_received_type);
extern void Diag_Rx_FF_Indication (void);
extern void Diag_Error_Indication(uint8_t errorCode);

/*===========================================================================*
 * Function definitions for can_diag_comm
 *===========================================================================*/
    /* UDS Service: DiagnosticSessionControl (0x10) */
    /* testmode_routines */
    uint8_t DG_Default_Session (uint8_t *data);
    uint8_t DG_Programming_Session (uint8_t *data);
    uint8_t DG_Extended_Session (uint8_t *data);
    /* support functions */
    void Diag_Start_Extended_Session_Timer (void);
    void Diag_Stop_Extended_Session_Timer (void);
    bool_t Diag_Is_Extended_Session_Timer_Expired (void);
    bool_t Diag_Is_Extended_Session (void);
    void Diag_Set_Extended_Session (bool_t active);

    /* UDS Service: ECUReset (0x11) */
    /* testmode_routines */
    uint8_t DG_Hard_Reset (uint8_t *data);
    uint8_t DG_Key_Off_On_Reset (uint8_t *data);
    /* support functions */
    void Diag_Check_ECUReset (void);
    void Diag_Check_ECUReset_Tmr_Expiration (void);
    void Diag_Set_ecu_reset_request_timer(uint32_t timer_ms);

    /* UDS Service: SecurityAccess (0x27) */
    /* testmode_routines */
    uint8_t DG_Process_Seed_Request (uint8_t *data);
    uint8_t DG_Process_Key (uint8_t *data);
    /* support functions */
    bool_t Diag_Is_Locked (void);
    void Diag_Lock (void);

    /* UDS Service: CommunicationControl (0x28) */
    /* testmode_routines */
    uint8_t DG_Comm_Control_Enable_Tx (uint8_t *data);
    uint8_t DG_Comm_Control_Disable_Tx (uint8_t *data);
    /* support functions */

    /* UDS Service: TesterPresent (0x3E) */
    /* testmode_routines */
    uint8_t DG_Tester_Present (uint8_t *data);
    /* support functions */

/*===========================================================================*
 * Function definitions for can_diag_dtc
 *===========================================================================*/
    /* UDS Service: DTCs related */
    void Diag_DTC_Init (void);
    void Diag_DTC_Periodic_Checks (void);
    void Diag_DTC_Set (Diag_DTC_Code_Id_t dtc_code, bool_t dtc_value);
    void Diag_DTC_Key_On (void);
    void Diag_DTC_Key_Off(void);
    void Diag_DTC_Enable (void);
    uint8_t DG_DTC_Clear (uint8_t *data);
    uint8_t DG_DTC_Control_On (uint8_t *data);
    uint8_t DG_DTC_Control_Off (uint8_t *data);
    uint8_t DG_DTC_Read_Number_By_Status (uint8_t *data);
    uint8_t DG_DTC_Read_By_Status(uint8_t *data);
    uint8_t DG_DTC_Read_Snapshot(uint8_t *data);
    uint8_t DG_DTC_Read_Ext_Data_Record(uint8_t *data);
    uint8_t DG_DTC_Read_Number_Of_DTC_By_Severity(uint8_t *data);
    uint8_t DG_DTC_Read_By_Severity(uint8_t *data);
    uint8_t DG_DTC_Read_Severity_Info(uint8_t *data);
    uint8_t DG_DTC_Read_First_Confirmed(uint8_t *data);
    uint8_t DG_DTC_Read_Most_Recent_Confirmed(uint8_t *data);

/*===========================================================================*
 * Function definitions for can_diag_io
 *===========================================================================*/
    /* UDS Service: IO Control related */
    uint8_t DG_IO_Control (uint8_t *data);

/*===========================================================================*
 * Function definitions for can_diag_routine
 *===========================================================================*/
    /* UDS Service: RoutineControl related */
    uint8_t DG_Routine_Control (uint8_t *data);

/*===========================================================================*
 * Function definitions for can_diag_rdi
 *===========================================================================*/
    /* UDS Service: ReadDataByIdentifier and WriteDataByIdentifier related */
    uint8_t DG_RDI_Read (uint8_t* data);
    uint8_t DG_RDI_Write (uint8_t *data);

/*===========================================================================*
 * External variables
 *===========================================================================*/


#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file CAN_DIAG.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 01-May-2020 Pablo Luis Joaquim
 *   - Created initial file based in B7 - can_diag module
 *
 */
/*===========================================================================*/
#endif                          /* CAN_DIAG_H */
