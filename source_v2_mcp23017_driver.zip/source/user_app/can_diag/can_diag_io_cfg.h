#ifndef CAN_DIAG_IO_CFG_H
#define CAN_DIAG_IO_CFG_H
/*===========================================================================*/
/**
 * @file can_diag_io_cfg.h
 *
 * Table definition for the available diag io control functions
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
/* ROUTINE_TABLE is used to routine control
 *
 * DID: Data Identifier
 *
 * Control Parameter: Data length of the response.
 *
 * Required RX msg Length:
 *
 * IO Control Adjust Routine:
 *
 *
*/

#define IO_TABLE \
/*                                 Required                                            */    \
/*                                 Rx msg                                              */    \
/*  DID     Control Parameter      length   IO Control Adjust Routine                  */    \
/*  ------- ---------------------- -------- -------------------------------            */    \
   X(0x5000, SHORT_TERM_ADJUSTMENT, 5,       dg_test_control                           )     \
   X(0x5000, RETURN_CONTROL_TO_ECU, 4,       dg_cancel_test_control                    )     \

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
uint8_t dg_test_control(uint8_t *data);
uint8_t dg_cancel_test_control(uint8_t *data);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file CAN_DIAG_IO_CFG.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 01-May-2020 Pablo Luis Joaquim
 *   - Created initial file based in B7 - can_diag module
 *
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* CAN_DIAG_IO_CFG_H */
