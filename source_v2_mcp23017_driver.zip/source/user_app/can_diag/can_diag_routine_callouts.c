/*===========================================================================*/
/**
 * @file can_diag_callouts.c
 *
 * UDS Services callouts
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"
#include "can_diag.h"
#include "can_diag_routine_cfg.h"

/* Include other necessary files */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         diag_reset_parameter_to_default_start
 *
 * @brief      Handler for Diag service: $31 $01 $0301 - Reset Parameters to Default Start
 *
 * @param [in] uint8_t *data
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_reset_parameter_to_default_start (uint8_t *data)
{
   Diag_Set_ecu_reset_request_timer(500);

   return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         diag_routine_ctrl_EOL_audio_test_start
 *
 * @brief      Handler for Diag service: $31 $01 $0317 - EOL_audio_test Start
 *
 * @param [in] uint8_t *data
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_routine_ctrl_EOL_audio_test_start (uint8_t *data)
{
   return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         diag_routine_ctrl_EOL_audio_test_stop
 *
 * @brief      Handler for Diag service: $31 $02 $0317 - EOL_audio_test Stop
 *
 * @param [in] uint8_t *data
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_routine_ctrl_EOL_audio_test_stop (uint8_t *data)
{
   return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         diag_routine_ctrl_EOL_audio_test_result
 *
 * @brief      Handler for Diag service: $31 $03 $0317 - EOL_audio_test Result
 *
 * @param [in] uint8_t *data
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_routine_ctrl_EOL_audio_test_result (uint8_t *data)
{
   uint8_t result = 0x01;
   data[0] = result;
   return(RC_OK);
}
