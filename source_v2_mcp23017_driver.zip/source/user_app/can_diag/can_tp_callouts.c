/*===========================================================================*/
/**
 * @file can_tp_callouts.c
 *
 * This file contains user call back functions
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"

#include "drv/can/can.h"
#include "can_tp.h"
#include "can_tp_callouts.h"
#include "can_diag.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*****************************************************************************
* FUNCTION:      UCB_TP_N_USData_Confirm                                     *
* DESCRIPTION:   Transmit operation is completed successfully / unsuccessfully *
* PARAMETERS:    None                                                        *
* RETURN VALUE:  Nothing                                                     *
******************************************************************************/
void TP_N_USData_Confirm(uint8_t N_Result)
{
    if (N_OK == N_Result)
    {
        Diag_Tx_Confirmation(N_Result);
    }
    else
    {
        Diag_Error_Indication(N_Result);
    }
   //DG_TP_USData_Confirm(N_Result);
}

/*****************************************************************************
* FUNCTION:      UCB_TP_N_USData_FF_Indication                               *
* DESCRIPTION:   Reception of the first frame of multiframe message arrival  *
* PARAMETERS:    TPReceivexMessageLength                                     *
* RETURN VALUE:  Nothing                                                     *
******************************************************************************/
void TP_N_USData_FF_Indication(uint16_t TPReceivexMessageLength)
{
    Diag_Rx_FF_Indication();
    //DG_TP_USData_FF_Indication(TPReceivexMessageLength);
}

/*****************************************************************************
* FUNCTION:      UCB_TP_N_USData_Indication                                  *
* DESCRIPTION:   Receive operation is completed successfully / unsuccessfully  *
* PARAMETERS:    TPReceivexMessageLength, N_Result                           *
* RETURN VALUE:  Nothing                                                     *
******************************************************************************/
void TP_N_USData_Indication(uint16_t TPReceivexMessageLength, uint8_t N_Result)
{
   //DG_TP_Request_Received(TPReceivexMessageLength, N_Result);
    if (N_OK == N_Result)
    {
        Diag_Rx_Indication(TPReceivexMessageLength,
                           ((PHYSICAL_ADDRESS_TYPE == TP_Get_Request_Type())?PHYSICAL_MSG_RECEIVED : FUNCTIONAL_MSG_RECEIVED));
    }
    else
    {
        Diag_Error_Indication(N_Result);
    }
}

/*****************************************************************************
* FUNCTION:      UCB_TP_N_Change_Parameter_Confirm                           *
* DESCRIPTION:   The parameters BlockSize and the Minimum SeparationTime has *
*                been changed.                                               *
* PARAMETERS:    Parameter, ParameterChangeResult                            *
* RETURN VALUE:  Nothing                                                     *
******************************************************************************/
void TP_N_Change_Parameter_Confirm(uint8_t Parameter, uint8_t ParameterChangeResult)
{
   
}

/*****************************************************************************
* FUNCTION:      UCB_TP_N_USData_FF_Confirmation                             *
* DESCRIPTION:   Tranmission of the FF has been completed                    *
* PARAMETERS:    None                                                        *
* RETURN VALUE:  Nothing                                                     *
******************************************************************************/
void TP_N_USData_FF_Confirmation(void)
{
   
}

/*****************************************************************************
* FUNCTION:      TP_Transmit_Buffer_Empty                                *
* DESCRIPTION:   *
* PARAMETERS:    None                                                        *
* RETURN VALUE:  Nothing                                                     *
******************************************************************************/
void TP_Transmit_Buffer_Empty(void)
{
   TP_Transmit_Buffer_Filled();
}

/*****************************************************************************
* FUNCTION:      TP_Receive_Buffer_Filled                                *
* DESCRIPTION:   *
* PARAMETERS:    None                                                        *
* RETURN VALUE:  Nothing                                                     *
******************************************************************************/
void TP_Receive_Buffer_Filled(void)
{

}

/*****************************************************************************
* FUNCTION:      TP_Can_Tx_Message                                           *
* DESCRIPTION:   Tranmission callout                                         *
* PARAMETERS:    data                                                        *
* RETURN VALUE:  Nothing                                                     *
******************************************************************************/
void TP_Can_Tx_Message(uint8_t *data)
{
    Can_Tx_Message(ADDR_PHY_RESP, data, 8);
}

/*****************************************************************************
* FUNCTION:      TP_Is_Response_Pending                                      *
* DESCRIPTION:   If the response is not pending, then only tp shall receive  *
*                the new request as the same buffer is used for              *
*                request n response                                          *
* PARAMETERS:    data                                                        *
* RETURN VALUE:  response pending status                                     *
******************************************************************************/
bool_t TP_Is_Response_Pending(void)
{
    return FALSE;
}
