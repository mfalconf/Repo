#ifndef CAN_DIAG_DTC_CFG_H
#define CAN_DIAG_DTC_CFG_H
/*===========================================================================*/
/**
 * @file can_diag_dtc_cfg.h
 *
 * Table definition for the available diag dtc definitions
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
/* If the dtc is not happening for DEFAULT_EVENT_COUNTER key_off-key_on cycles
 * then the dtc could be cleared*/
#define DEFAULT_EVENT_COUNTER   40

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

#define DIAG_SUPPORT_DTC_TABLE \
/*  DIAG_CODES              DTC_ID                  DTC_Severity    */    \
/*  ---------               -------------------     ------------    */    \
   X(DTC_ANTENNA_OPEN,      0x800000 + 0x200513,    0x20            )     \
   X(DTC_ANTENNA_SHORT,     0x800000 + 0x200595,    0x20            )     \

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
#undef X
#define X(a,b,c)     a,
typedef enum Diag_DTC_Code_Id_tag
{
   DIAG_SUPPORT_DTC_TABLE
   NUM_FIXED_DTCS,
   INVALID_VALUE_OF_DTC
}Diag_DTC_Code_Id_t;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
void diag_dtc_first_failure_tests (void);
void diag_dtc_periodic_failure_tests_10ms (void);
void diag_dtc_periodic_failure_tests_1000ms (void);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file CAN_DIAG_DTC_CFG.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 01-May-2020 Pablo Luis Joaquim
 *   - Created initial file based in B7 - can_diag module
 *
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* CAN_DIAG_DTC_CFG_H */
