/*===========================================================================*/
/**
 * @file can_diag_rdi_callouts.c
 *
 * UDS Services callouts
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"
#include "can_diag.h"
#include "can_diag_rdi_cfg.h"

/* Include other necessary files */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/***************************************************************************//**
 *
 * @fn         diag_rdi_read_active_diag_session
 *
 * @brief      Determine whether diagnostic session is default or
 *             extended, and write appropriate value to buffer.
 *             Programming session is not possible.
 *
 * @param [in] dest_data_ptr - pointer to response buffer
 *             num_bytes - number of data bytes
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_rdi_read_active_diag_session (uint8_t *dest_data_ptr, uint8_t num_bytes)
{
   if (Diag_Is_Extended_Session())
   {
      dest_data_ptr[0] = 3; /* EXTENDED_DIAG_SESSION */
   }
   else
   {
      dest_data_ptr[0] = 1; /* DEFAULT_DIAG_SESSION */
   }
   return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         diag_rdi_read_diag_identification
 *
 * @brief      Handler for Diag service: Diagostic identification 22 F1 00
 *
 *
 * @param [in] uint8_t *dest_data_ptr - pointer to response buffer
 * @param [in] uint8_t num_bytes - number of data bytes
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_rdi_read_diag_identification(uint8_t *dest_data_ptr, uint8_t num_bytes)
{
    dest_data_ptr[0] = 0xFF;      /* Reserved                */
    dest_data_ptr[1] = 0x00;      /* Diagnostic Variant ID   */
    dest_data_ptr[2] = 0x01;      /* Diagnostic Version      */
    dest_data_ptr[3] = 0x00;      /* ECU ID                  */
    dest_data_ptr[4] = 0x87;
    dest_data_ptr[5] = 0x00;      /* Supplier ID             */
    dest_data_ptr[6] = 0x40;

    return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         diag_rdi_read_ecu_part_number
 *
 * @brief      Handler for Diag service: Ecu part Number 22 F1 32
 *
 *
 * @param [in] uint8_t *dest_data_ptr - pointer to response buffer
 * @param [in] uint8_t num_bytes - number of data bytes
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_rdi_read_ecu_part_number(uint8_t *dest_data_ptr, uint8_t num_bytes)
{
   dest_data_ptr[0] = 0x35;
   dest_data_ptr[1] = 0x33;
   dest_data_ptr[2] = 0x33;
   dest_data_ptr[3] = 0x36;
   dest_data_ptr[4] = 0x37;
   dest_data_ptr[5] = 0x35;
   dest_data_ptr[6] = 0x34;
   dest_data_ptr[7] = 0x37;
   dest_data_ptr[8] = 0x20;
   dest_data_ptr[9] = 0x20;

   return(RC_OK);
}


/***************************************************************************//**
 *
 * @fn         diag_rdi_read_diag_specifcation_info
 *
 * @brief      Handler for Diag service: Diag specification info   22 F1 0D
 *
 *
 * @param [in] uint8_t *dest_data_ptr - pointer to response buffer
 * @param [in] uint8_t num_bytes - number of data bytes
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_rdi_read_diag_specifcation_info(uint8_t *dest_data_ptr, uint8_t num_bytes)
{
   dest_data_ptr[0] = 0x82;
   dest_data_ptr[1] = 0x81;
   dest_data_ptr[2] = 0x81;
   dest_data_ptr[3] = 0x81;

   return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         diag_rdi_read_hard_supplier_identification
 *
 * @brief      Handler for Diag service: Hard supplier identification  22 F1 54
 *
 *
 * @param [in] uint8_t *dest_data_ptr - pointer to response buffer
 * @param [in] uint8_t num_bytes - number of data bytes
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_rdi_read_hard_supplier_identification(uint8_t *dest_data_ptr, uint8_t num_bytes)
{
   dest_data_ptr[0] = 0x00;
   dest_data_ptr[1] = 0x40;      /* Supplier : Delphi */

   return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         diag_rdi_read_soft_supplier_identification
 *
 * @brief      Handler for Diag service: Soft supplier identification  22 F1 55
 *
 *
 * @param [in] uint8_t *dest_data_ptr - pointer to response buffer
 * @param [in] uint8_t num_bytes - number of data bytes
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_rdi_read_soft_supplier_identification(uint8_t *dest_data_ptr, uint8_t num_bytes)
{
   dest_data_ptr[0] = 0x00;
   dest_data_ptr[1] = 0x40;      /* Supplier : Delphi */

   return(RC_OK);
}

/***************************************************************************//**
 *
 * @fn         diag_rdi_write_test_data
 *
 * @brief      Handler for Diag service: Proxy Data Write   2E 22 23
 *
 *
 * @param [in] uint8_t *data - pointer to data buffer for write
 * @param [in] uint8_t num_bytes - number of data bytes
 *
 * @return     response code - always RC_OK
 *
 ******************************************************************************/
uint8_t diag_rdi_write_test_data( uint8_t *data, uint8_t num_bytes)
{
   return(RC_OK);
}
