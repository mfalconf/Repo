/*===========================================================================*/
/**
 * @file can_tp.c
 *
 * This module handles the CAN network layer (Transport Protocol)
 * functionality as per ISO 15765-2
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2020 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"

#include "can_tp.h"
#include "can_tp_callouts.h"
#include "can_diag.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define TP_BUFFER_SIZE  CAN_DIAG_BUFFER_SIZE

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/* Transmit Variables*/
static uint8_t  TP_Tx_Message_Status;
static uint8_t  TP_Tx_Block_Size;
static uint8_t  TP_Tx_Block_Size_Constant;
static uint8_t  TP_Tx_Separation_Time_Min_Constant;
static uint8_t  TP_Tx_Separation_Time_min;   
static uint8_t  TP_Tx_Sequence_Number;
static uint8_t  TP_Transmit_Sub_State;
static uint16_t TP_Tx_Message_DLC;
static uint8_t  TP_Tx_Frame_Type;
static uint16_t TP_Tx_Index;
uint8_t  TP_Tx_Frame_DLC;

/* Receive Variables*/
static uint8_t  TP_Rx_Message_Status;
static uint8_t  TP_Rx_Block_Size;
static uint8_t  TP_Rx_Block_Size_Parameter;
static uint8_t  TP_Rx_Seperation_Time_Parameter;
static uint8_t  TP_Rx_Sequence_Number;
static uint8_t  TP_Receive_Sub_State;
static uint16_t TP_Rx_Message_DLC;
static uint8_t  TP_Rx_Frame_Type;
static uint16_t TP_Rx_Index;
static uint8_t  TP_Rx_Frame_DLC;
static uint16_t TP_Rx_Message_Length;

static uint16_t  TPN_As_Timer;
static uint16_t  TPN_Ar_Timer;
static uint16_t  TPN_Bs_Timer;
static uint16_t  TPN_Cr_Timer;
static uint8_t TP_State;
static uint16_t TP_Data_Count;
static uint8_t TP_Next_Loop_Count; 
static uint8_t Flow_Status;  
static uint8_t TP_Result;
static uint8_t TP_Change_Parameter_Result;
static uint8_t TP_Request_Type;

static bool_t Frame_Tx_Complete; 
static bool_t Frame_Available;
static bool_t Load_Consecutive_Frame;
static uint8_t TP_Tx_Buffer_Status;
static uint8_t TP_Rx_Buffer_Status;
static uint8_t TP_N_As_Timer_Control;
static uint8_t TP_N_Ar_Timer_Control;
static uint8_t TP_N_Bs_Timer_Control;
static uint8_t TP_N_Cr_Timer_Control;

/* TP_Buffer and FrameBuffer */
static uint8_t TP_Buffer[TP_BUFFER_SIZE];
uint8_t TP_Frame_Array[FRAME_DATA_SIZE];

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void TP_Transmit_Single_OR_First_Frame(void);
static void TP_Receive_Single_OR_First_Frame(void);
static void TP_Transmit_Consecutive_Frame(void);
static void TP_Receive_Consecutive_Frame(void);
static void TP_Check_Rx_Message_Length(void);
static void TP_Transmit_Flow_Control(void);
static void TP_Update_Timers(void);
static bool_t TP_Received_DLC_Check(void);
static uint8_t TP_STmin_Calculate(void);
static void TP_Idle_State_Process(void);
static void TP_Wait_For_SFORFF_TxConf_State_Process(void);
static void TP_Wait_For_FCFrame_Rx_State_Process(void);
static void TP_Transmit_CF_State_Process(void);
static void TP_Wait_For_CF_TxConf_State_Process(void);
static void TP_Wait_For_STmin_State_Process(void);
static void TP_Wait_For_FC_TXconf_State_Process(void);
static void TP_Rx_CF_State_Process(void);
static void TP_Wait_For_DataRead_State_Process(void);                        
static void TP_Tx_To_Idle_Init(uint8_t TP_Result);
static void TP_FC_Frame_Process(void);
static void TP_Rx_To_Idle_Init(uint8_t TP_Result);
static void TP_Transmit_Single_Frame(void);
static void TP_Transmit_First_Frame(void);
static void TP_Receive_Single_Frame(void);
static void TP_Receive_First_Frame(void);
static void TP_Tx_Load_CF_Data_Process(void);
static void TP_Tx_Load_Remaining_Bytes_OF_CF_Process(void);
static void TP_Tx_Load_Remaining_Bytes_OF_Last_CF_Process(void);
static void TP_Load_TL_Buffer_Start_NAs_Timer(void);
static void TP_Update_SN_and_BS(void);
static void TP_Tx_CF_Data_Process(void);
static void TP_Tx_Last_CF_Data_Process(void);
static void TP_Rx_Unload_CF_Data_Process(void);
static void TP_Rx_Unload_Remaining_Bytes_OF_CF_Process(void);
static void TP_Rx_Unload_Remaining_Bytes_OF_Last_CF_Process(void);
static void TP_Rx_CF_Data_Process(void);
static void TP_Rx_Last_CF_Data_Process(void);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*============================================================================*\
* FUNCTION:      TP_Init
* DESCRIPTION:   Read the message numbers from the VBM config table, Initialize
* the state to idle, transmit and recieve status init, buffer status  init,
* Timers disabling, loads the default value's of BS and STmin to
* variables.
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
void TP_Init(void)
{
    /* Reads the Message number/Index from the VBM config table */
    TP_State = TP_Idle_State;
    TP_Tx_Message_Status = TP_TRANSMIT_IDLE;
    TP_Rx_Message_Status = TP_RECEIVE_IDLE;
    TP_Tx_Buffer_Status = EMPTY;
    TP_Rx_Buffer_Status = EMPTY;
    Frame_Tx_Complete = FALSE;
    Frame_Available = FALSE;
    TP_N_As_Timer_Control = TIMER_STOP;
    TP_N_Ar_Timer_Control = TIMER_STOP;
    TP_N_Bs_Timer_Control = TIMER_STOP;
    TP_N_Cr_Timer_Control = TIMER_STOP;
    Flow_Status = CLEAR_TO_SEND;    
    /* default block size  for receive. */        
    TP_Rx_Block_Size_Parameter = TP_RX_BLOCK_SIZE_MAX;
    /* default STmin for receive. */     
    TP_Rx_Seperation_Time_Parameter = TP_RX_SEPARATION_TIME_MIN; 
    Load_Consecutive_Frame = FALSE;

}/* End of TP_Init*/

/*============================================================================*\
* FUNCTION:      TP_Periodic_Task
* DESCRIPTION:   Main task which handles both transmit and receive portion of 
*                Network  Layer
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/

void TP_Periodic_Task(void)
{
   //CD_Disable_All_Interrupts(TP_CHANNEL_NUMBER);

   TP_Update_Timers();

   switch(TP_State)
   {
      case TP_Idle_State:
         TP_Idle_State_Process();
         break;
      case TP_Wait_For_SFORFF_TxConf_State:
         TP_Wait_For_SFORFF_TxConf_State_Process();
         break;
      case TP_Wait_For_FCFrame_Rx_State:
         TP_Wait_For_FCFrame_Rx_State_Process();
         break;
      case TP_Transmit_CF_State:
         TP_Transmit_CF_State_Process();
         break;
      case TP_Wait_For_CF_TxConf_State:
         TP_Wait_For_CF_TxConf_State_Process();
         break;
      case TP_Wait_For_STmin_State:
         TP_Wait_For_STmin_State_Process();
         break;
      case TP_Wait_For_FC_TXconf_State:
         TP_Wait_For_FC_TXconf_State_Process();
         break;
      case TP_Rx_CF_State:
         TP_Rx_CF_State_Process();
         break;
      case TP_Wait_For_DataRead_State:
         TP_Wait_For_DataRead_State_Process();
         break;
      default:
        break;
   }

    //CD_Enable_All_Interrupts(TP_CHANNEL_NUMBER);

}/* End of TP_Periodic_Task*/

/*============================================================================*\
* FUNCTION:      TP_Idle_State_Process
* DESCRIPTION:   This function handles TP_Idle_State
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Idle_State_Process(void)
{
  if(Frame_Available == TRUE)
  {
      Frame_Available = FALSE;
      TP_Receive_Single_OR_First_Frame();
  }
}

/*============================================================================*\
* FUNCTION:      TP_Wait_For_SFORFF_TxConf_State_Process
* DESCRIPTION:   This function handles TP_Wait_For_SFORFF_TxConf_State
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Wait_For_SFORFF_TxConf_State_Process(void)
{
  if(Frame_Tx_Complete == TRUE)
  {
     Frame_Tx_Complete = FALSE;
     TP_N_As_Timer_Control = TIMER_STOP;
     if(TP_Tx_Frame_Type == SINGLE_FRAME)
     {
        TP_Result = N_OK;
        TP_Tx_To_Idle_Init(TP_Result);
     }
     else if(TP_Tx_Frame_Type == FIRST_FRAME)
     {
        TP_State = TP_Wait_For_FCFrame_Rx_State; 
     }
  }
  else if(TPN_As_Timer == 0)
  {
     TP_Result = N_TIMEOUT_A;     
     TP_Tx_To_Idle_Init(TP_Result);
  }

}

/*============================================================================*\
* FUNCTION:      TP_Wait_For_FCFrame_Rx_State_Process
* DESCRIPTION:   This function handles TP_Wait_For_FCFrame_Rx_State
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Wait_For_FCFrame_Rx_State_Process(void)
{
   uint8_t FlowControlStatus;

   /* Bs_Timer is decremented before checking for the FC.
      So by giving high priority to Frame availability than the Bs_Timer_Timeout
      ECU will send the response if it receives FC at last loop also. */

   if(Frame_Available == TRUE)
   {
      Frame_Available = FALSE;
      TP_Rx_Frame_Type = TP_Frame_Array[0] & FRAME_TYPE_MASK; 
      if(TP_Rx_Frame_Type == FLOW_CONTROL_FRAME)
      {
           TP_N_Bs_Timer_Control = TIMER_STOP;
           FlowControlStatus = TP_Frame_Array[0] & FLOW_STATUS_MASK; 
           if(FALSE ==  TP_Received_DLC_Check())
           {
              TP_Result = N_WRONG_DLC;
              TP_Tx_To_Idle_Init(TP_Result);
           }
           else
           {
              if(FlowControlStatus >= RESERVED_FCS)
              {
                 TP_Result = N_INVALID_FS;
                 TP_Tx_To_Idle_Init(TP_Result);
              }
              else if(FlowControlStatus == OVERFLOW)
              {
                 TP_Result = N_BUFFER_OVFLW;
                 TP_Tx_To_Idle_Init(TP_Result);
              }
              else if(FlowControlStatus == WAIT)
              {
                 TPN_Bs_Timer = N_Bs_TIMER_COUNT;
                 TP_N_Bs_Timer_Control = TIMER_RUN;
              }
              else if(FlowControlStatus == CLEAR_TO_SEND)
              {
                 TP_FC_Frame_Process();
              }
           }
      }
   }
   else if(TPN_Bs_Timer == 0)
   {
       TP_Result = N_TIMEOUTBs;
       TP_Tx_To_Idle_Init(TP_Result);
   }

}

/*============================================================================*\
* FUNCTION:      TP_Transmit_CF_State_Process
* DESCRIPTION:   This function handles TP_Transmit_CF_State
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Transmit_CF_State_Process(void)
{
    TP_Transmit_Consecutive_Frame();
}

/*============================================================================*\
* FUNCTION:      TP_Wait_For_CF_TxConf_State_Process
* DESCRIPTION:   This function handles TP_Wait_For_CF_TxConf_State
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Wait_For_CF_TxConf_State_Process(void)
{
    if((Frame_Tx_Complete == TRUE)||(Load_Consecutive_Frame == TRUE))
    {
        TP_N_As_Timer_Control = TIMER_STOP;
        Frame_Tx_Complete = FALSE;
        if(TP_Tx_Message_DLC == 0)
        {
            TP_Result = N_OK;
            TP_Tx_To_Idle_Init(TP_Result);
        }
        else if((TP_Tx_Block_Size_Constant!= 0) && (TP_Tx_Block_Size == 0))
        {
            TP_State = TP_Wait_For_FCFrame_Rx_State;
        }
        else if((TP_Tx_Separation_Time_Min_Constant == ZERO_LOOP_COUNT) ||
                (TP_Tx_Separation_Time_Min_Constant == ONE_LOOP_COUNT)) 
        {
            TP_Transmit_Consecutive_Frame();
            if(TP_Transmit_Sub_State == TP_TX_LOAD_CF_DATA) 
            {
                Load_Consecutive_Frame = FALSE;
            }
            else
			{
                Load_Consecutive_Frame = TRUE;
            }
        } 
        else if(TP_Tx_Separation_Time_Min_Constant == TWO_LOOP_COUNT)
        {    
            TP_State = TP_Transmit_CF_State;
        }
        else if(TP_Tx_Separation_Time_Min_Constant > TWO_LOOP_COUNT)
        {
            TP_Tx_Separation_Time_min--;
            TP_State = TP_Wait_For_STmin_State;
        }
    }
    else if(TPN_As_Timer == 0)
    {
        TP_Result = N_TIMEOUT_A;
        TP_Tx_To_Idle_Init(TP_Result);
    }
}

/*============================================================================*\
* FUNCTION:      TP_Wait_For_STmin_State_Process
* DESCRIPTION:   This function handles TP_Wait_For_STmin_State
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Wait_For_STmin_State_Process(void)
{
   TP_Tx_Separation_Time_min--;
   if(TP_Tx_Separation_Time_min <= 1)
   {
      TP_State = TP_Transmit_CF_State; 
      TP_Tx_Separation_Time_min = TP_Tx_Separation_Time_Min_Constant;
   }    
}

/*============================================================================*\
* FUNCTION:      TP_Wait_For_FC_TXconf_State_Process
* DESCRIPTION:   This function handles TP_Wait_For_FC_TXconf_State
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Wait_For_FC_TXconf_State_Process(void)
{
   if(Frame_Tx_Complete == TRUE)
   {
       Frame_Tx_Complete = FALSE;
       TP_N_Ar_Timer_Control = TIMER_STOP;
       TP_State = TP_Rx_CF_State;
       TPN_Cr_Timer = N_Cr_TIMER_COUNT;
       TP_N_Cr_Timer_Control = TIMER_RUN;
   }
   else if(TPN_Ar_Timer == 0)
   {
       TP_Result = N_TIMEOUT_A;
       TP_Rx_To_Idle_Init(TP_Result);
   }
}

/*============================================================================*\
* FUNCTION:      TP_Rx_CF_State_Process
* DESCRIPTION:   This function handles TP_Rx_CF_State
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Rx_CF_State_Process(void)
{

   if(Frame_Available == TRUE)
   {
      Frame_Available = FALSE;
      //TP_N_Cr_Timer_Control = TIMER_STOP;
      TP_Rx_Frame_Type = TP_Frame_Array[0] & FRAME_TYPE_MASK;
      if((TP_Rx_Frame_Type == SINGLE_FRAME) || 
         (TP_Rx_Frame_Type ==  FIRST_FRAME)) 
      {
          TP_Result = N_UNEXP_PDU;
          TP_Rx_To_Idle_Init(TP_Result); 
          TP_Receive_Single_OR_First_Frame();
      }
      else if(TP_Rx_Frame_Type == CONSECUTIVE_FRAME)
      {
          if(FALSE ==  TP_Received_DLC_Check())
          {
              TP_Result = N_WRONG_DLC;
              TP_Rx_To_Idle_Init(TP_Result); 
          }
          else
          {
              if(TP_Rx_Sequence_Number == (TP_Frame_Array[0] &
                SEQUENCE_NUMBER_MASK)) 
              {
                 TP_Receive_Sub_State = TP_RX_UNLOAD_CF_DATA;
                 TP_Receive_Consecutive_Frame();
                 TPN_Cr_Timer = N_Cr_TIMER_COUNT;
                 TP_N_Cr_Timer_Control = TIMER_RUN;
                 if(TP_Receive_Sub_State == TP_RX_UNLOAD_CF_DATA) 
                 {
                      TP_Check_Rx_Message_Length();   
                 }
              }
              else
              {
                 TP_Result = N_WRONG_SN;
                 TP_Rx_To_Idle_Init(TP_Result); 
              }
          }
      }
   }
   else if(TPN_Cr_Timer == 0)
   {
      TP_Result = N_TIMEOUTCr;
      TP_Rx_To_Idle_Init(TP_Result); 
   }

}

/*============================================================================*\
* FUNCTION:      TP_Wait_For_DataRead_State_Process
* DESCRIPTION:   This function handles TP_Wait_For_DataRead_State
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Wait_For_DataRead_State_Process(void)
{
  if(Frame_Available == TRUE)
  {
     Frame_Available = FALSE; 
     TP_Result = TP_BUFFER_OVER_FLOW;
     TP_Rx_To_Idle_Init(TP_Result); 
  }
  else if(TPN_Cr_Timer == 0)
  {
     TP_Result = N_TIMEOUTCr;
     TP_Rx_To_Idle_Init(TP_Result);
  }
  
  else
  {
    TP_Receive_Consecutive_Frame();
    if(TP_Receive_Sub_State == TP_RX_UNLOAD_CF_DATA)
    {
      TP_Check_Rx_Message_Length();
    }
  }
}

/*============================================================================*\
* FUNCTION:      TP_Tx_To_Idle_Init
* DESCRIPTION:   This function handles TP transmit variables initialization
* when transmit operation is completed suceesfully / unsuceesfully
* PARAMETERS:    TP Result
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Tx_To_Idle_Init(uint8_t TP_Result)
{
   TP_N_USData_Confirm(TP_Result);
   TP_State = TP_Idle_State;
   TP_Tx_Message_Status = TP_TRANSMIT_IDLE;
   TP_Tx_Buffer_Status = EMPTY;
   Frame_Tx_Complete = FALSE;
   TP_Tx_Block_Size_Constant = 0;
}
/*******************************************************************************
 * FUNCTION: TP_Reset_Tx                                                       *
 * DESCRIPTION: This function resets the Transmit status of TP                 *
 * PARAMETERS: None                                                            *
 * RETURN VALUE: None                                                          *
 *******************************************************************************/
void TP_Reset_Tx(void)
{
   TP_State = TP_Idle_State;
   TP_Tx_Message_Status = TP_TRANSMIT_IDLE;
   TP_Tx_Buffer_Status = EMPTY;
   Frame_Tx_Complete = FALSE;
}
/*============================================================================*\
* FUNCTION:      TP_FC_Frame_Process
* DESCRIPTION:   This function handles flow control parameter processing
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_FC_Frame_Process(void)
{
   TP_Tx_Block_Size_Constant = TP_Frame_Array[1];
   /* function to calcualte stmin */       
   TP_Tx_Separation_Time_Min_Constant =	TP_STmin_Calculate();  
   TP_Tx_Block_Size = TP_Tx_Block_Size_Constant;
   TP_Tx_Separation_Time_min =
   TP_Tx_Separation_Time_Min_Constant;
   TP_Transmit_Sub_State = TP_TX_LOAD_CF_DATA;
   TP_Transmit_Consecutive_Frame();
}

/*============================================================================*\
* FUNCTION:      TP_Rx_To_Idle_Init
* DESCRIPTION:   This function handles TP receive variables initialization
* when receive operation is completed suceesfully / unsuceesfully
* PARAMETERS:    TP Result
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Rx_To_Idle_Init(uint8_t TP_Result)
{
   TP_N_USData_Indication(TP_Rx_Message_DLC, TP_Result);
   TP_State = TP_Idle_State;
   TP_Rx_Message_Status = TP_RECEIVE_IDLE;
   TP_Rx_Buffer_Status = EMPTY;
}

/*******************************************************************************
 * FUNCTION: TP_Reset_Rx                                                       *
 * DESCRIPTION: This function resets the Receive status of TP                  *
 * PARAMETERS: None                                                            *
 * RETURN VALUE: None                                                          *
 *******************************************************************************/
void TP_Reset_Rx(void)
{
   Frame_Available = FALSE;
   TP_State = TP_Idle_State;
   TP_Rx_Message_Status = TP_RECEIVE_IDLE;
   TP_Rx_Buffer_Status = EMPTY;
}

/****************** end of TP_Periodic_Task Optimization **********************/
					

/*============================================================================*\
* FUNCTION:      TP_Transmit_Single_OR_First_Frame
* DESCRIPTION:   This function handles transmission of 'single' or 'first'
* frame
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Transmit_Single_OR_First_Frame(void)
{
   if(TP_Tx_Frame_Type == SINGLE_FRAME)
   {
      TP_Transmit_Single_Frame();
   }
   else if(TP_Tx_Frame_Type == FIRST_FRAME) 
   {
      TP_Transmit_First_Frame();
   }
   /* for CF1 count starts with '1'. Becomes '0' if it reaches 16 */
   TP_Tx_Sequence_Number = 1; 

   /* CCA API is called to transmit a frame */
   TP_State = TP_Wait_For_SFORFF_TxConf_State; 
   TPN_As_Timer = N_As_TIMER_COUNT;
   TP_N_As_Timer_Control = TIMER_RUN;

   TP_Can_Tx_Message(TP_Frame_Array);
}/* End of TP_Transmit_Single_OR_First_Frame*/
         
/*============================================================================*\
* FUNCTION:      TP_Transmit_Single_Frame
* DESCRIPTION:   This function handles transmission of 'single' frame
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Transmit_Single_Frame(void)
{
   uint8_t Frame_Array_Index,Data_Count ;
   /* store N_PCI  and message length in the first byte of Frame buffer */
   TP_Frame_Array[0] = SINGLE_FRAME |  TP_Tx_Message_DLC; 
   Data_Count = 1;
   for(Frame_Array_Index = 1; Frame_Array_Index <= TP_Tx_Message_DLC;
       Frame_Array_Index++)
   {
   /* copy the data bytes from TP buffer to frame buffer */
      TP_Frame_Array[Frame_Array_Index] = TP_Buffer[TP_Tx_Index];
      TP_Tx_Index++;
      Data_Count++; 
   }
   /* DLC of the frame to be transmitted: Data bytes + N_PCI */
   TP_Tx_Frame_DLC = TP_Tx_Message_DLC + 1; 
   if(PADDING_OPERATION == TRUE)
   {
      if(Data_Count <= CAN_FRAME_BYTES_UPPER_RANGE)
      {
         /* padd the remaining space in the frame buffer */
         for(Data_Count = Data_Count; Data_Count <= CAN_FRAME_BYTES_UPPER_RANGE; Data_Count++)
         {
            TP_Frame_Array[Data_Count] = PADDING_BYTE;
         }
         /* DLC of the frame to be transmitted: DLC Max bytes */
         TP_Tx_Frame_DLC = NW_DLC_MAX_BYTES; 
      }
   }
}

/*******************************************************************************
 * FUNCTION:  TP_Send_Negative_Response                                        *
 * DESCRIPTION:This function handles the transmission of negative response     *
 *              Dg calls this function                                         *
 * PARAMETERS: Service ID and Negative Response Code                           *
 * RETURN VALUE: None                                                          *
 *******************************************************************************/
void TP_Send_Negative_Response(uint8_t SID, uint8_t NRC)
{
   uint8_t Data_Count;
   TP_Tx_Message_DLC = 3;
   TP_Tx_Frame_Type = SINGLE_FRAME;
   TP_Frame_Array[0] = SINGLE_FRAME |  TP_Tx_Message_DLC; 
   TP_Frame_Array[1] = 0x7F;
   TP_Frame_Array[2] = SID;
   TP_Frame_Array[3] = NRC;

    TP_Tx_Frame_DLC = TP_Tx_Message_DLC + 1; 
    if(PADDING_OPERATION == TRUE)
    {
       /* padd the remaining space in the frame buffer */
         for(Data_Count = 4; Data_Count <= CAN_FRAME_BYTES_UPPER_RANGE;
             Data_Count++) 
         {
             TP_Frame_Array[Data_Count] = PADDING_BYTE;
         }
       /* DLC of the frame to be transmitted: DLC Max bytes */
          TP_Tx_Frame_DLC = NW_DLC_MAX_BYTES; 
    }
   TP_Tx_Sequence_Number = 1; 

   /* CCA API is called to transmit a frame */
   TP_State = TP_Wait_For_SFORFF_TxConf_State; 
   TPN_As_Timer = N_As_TIMER_COUNT;
   TP_N_As_Timer_Control = TIMER_RUN;

   TP_Can_Tx_Message(TP_Frame_Array);
}


/*============================================================================*\
* FUNCTION:      TP_Transmit_First_Frame
* DESCRIPTION:   This function handles transmission of 'first' frame
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Transmit_First_Frame(void)
{
    uint8_t Frame_Array_Index;
/*store N_PCI and message length in the first and second byte of Frame buffer*/
    TP_Frame_Array[0] = FIRST_FRAME |  ((TP_Tx_Message_DLC & 0X0F00) >> 8);
    TP_Frame_Array[1] = TP_Tx_Message_DLC & 0X00FF;
    for(Frame_Array_Index = 2; Frame_Array_Index <=
        CAN_FRAME_BYTES_UPPER_RANGE; Frame_Array_Index++)
    {
       TP_Frame_Array[Frame_Array_Index] = TP_Buffer[TP_Tx_Index];
       TP_Tx_Index++;
       TP_Tx_Message_DLC--; 
    }
    /* DLC of the frame to be  transmitted: DLC Max bytes */
    TP_Tx_Frame_DLC = NW_DLC_MAX_BYTES;      
}
                        
/*============================================================================*\
* FUNCTION:      TP_Receive_Single_OR_First_Frame
* DESCRIPTION:   This function handles reception of 'single' or 'first' frame
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Receive_Single_OR_First_Frame(void)
{
	/* first byte: MSB Nibble indicates frame type :-N_PCI */
    TP_Rx_Frame_Type = TP_Frame_Array[0] & FRAME_TYPE_MASK; 
    TP_Rx_Index = 0;
    TP_Request_Type = PHYSICAL_ADDRESS_TYPE;
    Frame_Tx_Complete = FALSE;
    if(TP_Rx_Frame_Type == SINGLE_FRAME)
    {
	   TP_Receive_Single_Frame();
    }
    else if(TP_Rx_Frame_Type == FIRST_FRAME)
    {
	   TP_Receive_First_Frame();
    }
    else
    {
    }
}/* End of TP_Receive_Single_OR_First_Frame*/

/*============================================================================*\
* FUNCTION:      TP_Receive_Single_Frame
* DESCRIPTION:   This function handles reception of 'single' frame
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Receive_Single_Frame(void)
{
    uint8_t Frame_Array_Index;

  	/* first byte: LSB Nibble indicates data length */
    TP_Rx_Message_DLC = TP_Frame_Array[0] & SINGLE_FRAME_DATA_LENGTH_MASK;
    if(FALSE ==  TP_Received_DLC_Check())
    {
       TP_Result = N_WRONG_DLC;
       TP_N_USData_Indication(TP_Rx_Message_DLC, TP_Result);
    }
    else
    {
       for(Frame_Array_Index = 1; Frame_Array_Index <= TP_Rx_Message_DLC;
           Frame_Array_Index++)
       {
          TP_Buffer[TP_Rx_Index] = TP_Frame_Array[Frame_Array_Index];
          TP_Rx_Index++;
       }
       TP_Result = N_OK;
       TP_N_USData_Indication(TP_Rx_Message_DLC, TP_Result);
    }
}

/*============================================================================*\
* FUNCTION:      TP_Receive_First_Frame
* DESCRIPTION:   This function handles reception of 'first' frame
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Receive_First_Frame(void)
{
    uint8_t Frame_Array_Index;

    TP_Rx_Message_DLC = (((TP_Frame_Array[0] &
    FIRST_FRAME_DATA_LENGTH_MSB_NIBBLE_MASK) << 8) | TP_Frame_Array[1]);
    TP_Rx_Message_Length =  TP_Rx_Message_DLC;
	if( (RECEIVE_MULTI_BUFFER_SUPPORT == FALSE) ||  
	    (TP_Rx_Message_DLC > TP_BUFFER_SIZE)  )
	{
	    TP_Result = TP_RX_LENGTH_INVALID;
        TP_N_USData_Indication(TP_Rx_Message_DLC, TP_Result);
        Flow_Status = OVERFLOW;
        TP_Transmit_Flow_Control();
        Flow_Status = CLEAR_TO_SEND;
        TP_State = TP_Idle_State; 
    }
   	else
	{
       if(TP_Rx_Message_DLC >= MINIMUM_FIRST_FRAME_DATA_LENGTH)
       {
          if(FALSE ==  TP_Received_DLC_Check())     
          {
             TP_Result = N_WRONG_DLC;
             TP_N_USData_Indication(TP_Rx_Message_DLC, TP_Result);
          }
          else
          {
             for(Frame_Array_Index = 2; Frame_Array_Index <=
                 CAN_FRAME_BYTES_UPPER_RANGE; Frame_Array_Index++)
             {
                 TP_Buffer[TP_Rx_Index] = TP_Frame_Array[Frame_Array_Index]; 
                 TP_Rx_Message_Length--;
                 TP_Rx_Index++;    
             }
             TP_Rx_Sequence_Number = 1; 
/* User call back  function to notify the first frame of multiframe message
 arrival */
             TP_N_USData_FF_Indication(TP_Rx_Message_DLC); 
             TP_Rx_Message_Status = TP_RECEIVE_START;
/* After receiveing first frame this API is called to transmit flow control 
frame */
             TP_Transmit_Flow_Control();        
          }
       }
	}
}

/*============================================================================*\
* FUNCTION:      TP_Transmit_Consecutive_Frame
* DESCRIPTION:   Handles the consecutive frame transmission with respect to
 total message length  and the TP buffer
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Transmit_Consecutive_Frame(void)
{
    switch(TP_Transmit_Sub_State)
    {
        case TP_TX_LOAD_CF_DATA:
		   TP_Tx_Load_CF_Data_Process();
           break;
        case TP_TX_LOAD_REMAINING_BYTES_OF_CF:
		   TP_Tx_Load_Remaining_Bytes_OF_CF_Process();
           break;
        case TP_TX_LOAD_REMAINING_BYTES_OF_LAST_CF:
		   TP_Tx_Load_Remaining_Bytes_OF_Last_CF_Process();
           break;
        default:
           break;
    }/* end of TP_Transmit_Sub_State switch */
}/* End of TP_Transmit_Consecutive_Frame*/

/*============================================================================*\
* FUNCTION:      TP_Tx_Load_CF_Data_Process
* DESCRIPTION:   Handles the consecutive frame transmission with respect to
* total message length  and the TP buffer
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Tx_Load_CF_Data_Process(void)
{
    TP_Frame_Array[0] = CONSECUTIVE_FRAME | TP_Tx_Sequence_Number; 
    TP_Data_Count = TP_BUFFER_SIZE - TP_Tx_Index;
    if(TP_Tx_Message_DLC >= CONSECUTIVE_FRAME_DATA_BYTE)
    {
	  TP_Tx_CF_Data_Process();
    }
    else if(TP_Tx_Message_DLC < CONSECUTIVE_FRAME_DATA_BYTE) 
    {
	  TP_Tx_Last_CF_Data_Process();
    }       
}

/*============================================================================*\
* FUNCTION:      TP_Tx_CF_Data_Process
* DESCRIPTION:   Checks the data availability in TP buffer and loads the CF 
* accordingly when CF is other than last CF
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Tx_CF_Data_Process(void)
{
    uint8_t Frame_Array_Index;

    if(TP_Data_Count < CONSECUTIVE_FRAME_DATA_BYTE)
    {
       TP_Next_Loop_Count = 1;
       for(Frame_Array_Index = 1; Frame_Array_Index <=
           TP_Data_Count; Frame_Array_Index++)
       {
          TP_Frame_Array[Frame_Array_Index] = TP_Buffer[TP_Tx_Index];
          TP_Tx_Index++;
          TP_Tx_Message_DLC--; 
          TP_Next_Loop_Count++;
       }
       TP_Transmit_Sub_State =  TP_TX_LOAD_REMAINING_BYTES_OF_CF;
       TP_Tx_Buffer_Status = EMPTY;
       TP_Transmit_Buffer_Empty();
       TP_Tx_Index = 0;
    } 
    else if(TP_Data_Count >= CONSECUTIVE_FRAME_DATA_BYTE)
    {
       for(Frame_Array_Index = 1; Frame_Array_Index <=
           CAN_FRAME_BYTES_UPPER_RANGE; Frame_Array_Index++)
       {
          TP_Frame_Array[Frame_Array_Index] = TP_Buffer[TP_Tx_Index];
          TP_Tx_Index++;
          TP_Tx_Message_DLC--; 
       }
       TP_Tx_Frame_DLC = NW_DLC_MAX_BYTES;
       
       TP_State = TP_Wait_For_CF_TxConf_State;
       TP_Update_SN_and_BS();
       TP_Load_TL_Buffer_Start_NAs_Timer();
    }
}

/*============================================================================*\
* FUNCTION:      TP_Tx_Last_CF_Data_Process
* DESCRIPTION:   Checks the data availability in TP buffer and loads the CF 
* accordingly for last CF
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Tx_Last_CF_Data_Process(void)
{
    uint8_t Frame_Array_Index, Data_Count, TempLoopCount;

    if(TP_Data_Count >= TP_Tx_Message_DLC)
    {
       Data_Count = 1;
       TempLoopCount =  TP_Tx_Message_DLC;
       for(Frame_Array_Index = 1; Frame_Array_Index <=
           TempLoopCount; Frame_Array_Index++)
       {
          TP_Frame_Array[Frame_Array_Index] =
          TP_Buffer[TP_Tx_Index];
          TP_Tx_Index++;
          TP_Tx_Message_DLC--;
          Data_Count++; 
       }
       TP_Tx_Frame_DLC = TempLoopCount + 1;
       if(PADDING_OPERATION == TRUE)
       {            
          for(Data_Count = Data_Count; Data_Count <=
              CAN_FRAME_BYTES_UPPER_RANGE; Data_Count++)
          {
              TP_Frame_Array[Data_Count] = PADDING_BYTE;
          }
          TP_Tx_Frame_DLC = NW_DLC_MAX_BYTES;
       }       
       
       TP_State = TP_Wait_For_CF_TxConf_State;
       TP_Load_TL_Buffer_Start_NAs_Timer();
    }
    else if(TP_Data_Count < TP_Tx_Message_DLC)
    {
       TP_Next_Loop_Count = 1;
       for(Frame_Array_Index = 1; Frame_Array_Index <=
           TP_Data_Count; Frame_Array_Index++)
       {
           TP_Frame_Array[Frame_Array_Index] =
           TP_Buffer[TP_Tx_Index];
           TP_Tx_Index++;
           TP_Tx_Message_DLC--; 
           TP_Next_Loop_Count++;
       }
       TP_Transmit_Sub_State = TP_TX_LOAD_REMAINING_BYTES_OF_LAST_CF;
       TP_Tx_Buffer_Status = EMPTY;
       TP_Transmit_Buffer_Empty();
       TP_Tx_Index = 0;
    }
}

/*============================================================================*\
* FUNCTION:      TP_Tx_Load_Remaining_Bytes_OF_CF_Process
* DESCRIPTION:   Handles the consecutive frame transmission with respect to
* remaining bytes of CF
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Tx_Load_Remaining_Bytes_OF_CF_Process(void)
{
  if(TP_Tx_Buffer_Status == FILLED) 
  {   
     for(TP_Next_Loop_Count = TP_Next_Loop_Count; TP_Next_Loop_Count <=
         CAN_FRAME_BYTES_UPPER_RANGE; TP_Next_Loop_Count++)
     {
        TP_Frame_Array[TP_Next_Loop_Count] = TP_Buffer[TP_Tx_Index];
        TP_Tx_Index++;
        TP_Tx_Message_DLC--; 
     }
     TP_Tx_Frame_DLC = NW_DLC_MAX_BYTES;
     
     TP_Transmit_Sub_State =  TP_TX_LOAD_CF_DATA;
     TP_State = TP_Wait_For_CF_TxConf_State;
     TP_Update_SN_and_BS();
     TP_Load_TL_Buffer_Start_NAs_Timer();
  }
}

/*============================================================================*\
* FUNCTION:      TP_Tx_Load_Remaining_Bytes_OF_Last_CF_Process
* DESCRIPTION:   Handles the consecutive frame transmission with respect to
* remaining bytes of last CF
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Tx_Load_Remaining_Bytes_OF_Last_CF_Process(void)
{
  uint8_t Data_Count;

  if(TP_Tx_Buffer_Status == FILLED) 
  {
     Data_Count = TP_Next_Loop_Count;
     TP_Tx_Frame_DLC = TP_Next_Loop_Count  + TP_Tx_Message_DLC;
     for(TP_Next_Loop_Count = TP_Next_Loop_Count; TP_Next_Loop_Count < TP_Tx_Frame_DLC; TP_Next_Loop_Count++)
     {
         TP_Frame_Array[TP_Next_Loop_Count] =
         TP_Buffer[TP_Tx_Index];
         TP_Tx_Index++;
         TP_Tx_Message_DLC--; 
         Data_Count++;
     }
	 if(PADDING_OPERATION == TRUE)
     {
        for(Data_Count = Data_Count; Data_Count <= CAN_FRAME_BYTES_UPPER_RANGE;
            Data_Count++)
        {
           TP_Frame_Array[Data_Count] = PADDING_BYTE;
        }
        TP_Tx_Frame_DLC = NW_DLC_MAX_BYTES;
     }
     
     TP_Transmit_Sub_State =  TP_TX_LOAD_CF_DATA;
     TP_State = TP_Wait_For_CF_TxConf_State;
     TP_Load_TL_Buffer_Start_NAs_Timer();
  }
}

/*============================================================================*\
* FUNCTION:      TP_Load_TL_Buffer_Start_NAs_Timer
* DESCRIPTION:   Loads the frame into VBM s/w buffer and starts the NAs timer
* counter.
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Load_TL_Buffer_Start_NAs_Timer(void)
{
  TPN_As_Timer = N_As_TIMER_COUNT;         
  TP_N_As_Timer_Control = TIMER_RUN;

  TP_Can_Tx_Message(TP_Frame_Array);
}

/*============================================================================*\
* FUNCTION:      TP_Update_SN_and_BS
* DESCRIPTION:   updates the sequence number and the block size parameters
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Update_SN_and_BS(void)
{
   TP_Tx_Sequence_Number++;
   if(TP_Tx_Sequence_Number == SEQUENCE_NUMBER_MAX)
   {
      TP_Tx_Sequence_Number = 0;
   }
   if(TP_Tx_Block_Size_Constant != 0)
   {
      TP_Tx_Block_Size--;
   }
}

/*============================================================================*\
* FUNCTION:      TP_Receive_Consecutive_Frame
* DESCRIPTION:   Handles the consecutive frame reception with respect to total
 message length  and the TP buffer
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Receive_Consecutive_Frame(void)
{
    switch(TP_Receive_Sub_State)
    {
        case TP_RX_UNLOAD_CF_DATA:
		   TP_Rx_Unload_CF_Data_Process();
           break; 
        case TP_RX_UNLOAD_REMAINING_BYTES_OF_CF:
		   TP_Rx_Unload_Remaining_Bytes_OF_CF_Process();
           break;
        case TP_RX_UNLOAD_REMAINING_BYTES_OF_LAST_CF:
		   TP_Rx_Unload_Remaining_Bytes_OF_Last_CF_Process();
           break;
        default:
           break;
    }/* end of TP_Receive_Sub_State switch */
}/* End of TP_Receive_Consecutive_Frame */

/*============================================================================*\
* FUNCTION:      TP_Rx_Unload_CF_Data_Process
* DESCRIPTION:   Handles the consecutive frame reception with respect to total
 message length  and the TP buffer
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Rx_Unload_CF_Data_Process(void)
{
    TP_Data_Count = TP_BUFFER_SIZE - TP_Rx_Index;
    if(TP_Rx_Message_Length >= CONSECUTIVE_FRAME_DATA_BYTE) 
    {	
	   TP_Rx_CF_Data_Process();
    }
    else if(TP_Rx_Message_Length < CONSECUTIVE_FRAME_DATA_BYTE)
    {
	   TP_Rx_Last_CF_Data_Process();
    }
}

/*============================================================================*\
* FUNCTION:      TP_Rx_CF_Data_Process
* DESCRIPTION:   Checks the memory availability in TP buffer and unloads the CF 
* accordingly when CF is other than last CF ( From VBM to TP Buffer)
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Rx_CF_Data_Process(void)
{
    uint8_t Frame_Array_Index;
    if(TP_Data_Count < CONSECUTIVE_FRAME_DATA_BYTE)
    {
       TP_Next_Loop_Count = 1;
       for(Frame_Array_Index = 1; Frame_Array_Index <=
           TP_Data_Count; Frame_Array_Index++)
       {
           TP_Buffer[TP_Rx_Index] = TP_Frame_Array[Frame_Array_Index];
           TP_Rx_Index++;
           TP_Rx_Message_Length--; 
           TP_Next_Loop_Count++;
       }
       TP_Receive_Sub_State =  TP_RX_UNLOAD_REMAINING_BYTES_OF_CF;
       TP_State = TP_Wait_For_DataRead_State;
       TP_Rx_Buffer_Status = FILLED;  
       TP_Receive_Buffer_Filled();
       TP_Rx_Index = 0;
    } 
    else if(TP_Data_Count >= CONSECUTIVE_FRAME_DATA_BYTE)
    {
       for(Frame_Array_Index = 1; Frame_Array_Index <=
           CAN_FRAME_BYTES_UPPER_RANGE; Frame_Array_Index++)
       {
          TP_Buffer[TP_Rx_Index] = TP_Frame_Array[Frame_Array_Index];
          TP_Rx_Index++;
          TP_Rx_Message_Length--; 
       }
    }
}

/*============================================================================*\
* FUNCTION:      TP_Rx_Last_CF_Data_Process
* DESCRIPTION:   Checks the memory availability in TP buffer and unloads the CF 
* accordingly for last CF  ( From VBM to TP Buffer)
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Rx_Last_CF_Data_Process(void)
{
    uint8_t TempLoopCount, Frame_Array_Index;

    if(TP_Data_Count >= TP_Rx_Message_Length)
    {
       TempLoopCount =  TP_Rx_Message_Length;
       for(Frame_Array_Index = 1; Frame_Array_Index <=
           TempLoopCount; Frame_Array_Index++)
       {
          TP_Buffer[TP_Rx_Index] = TP_Frame_Array[Frame_Array_Index];
          TP_Rx_Index++;
          TP_Rx_Message_Length--;
       }
    }
    else if(TP_Data_Count < TP_Rx_Message_Length)
    {
       TP_Next_Loop_Count = 1;
       for(Frame_Array_Index = 1; Frame_Array_Index <=
           TP_Data_Count; Frame_Array_Index++)
       {
          TP_Buffer[TP_Rx_Index] = TP_Frame_Array[Frame_Array_Index];
          TP_Rx_Index++;
          TP_Rx_Message_Length--; 
          TP_Next_Loop_Count++;
       }
       TP_Receive_Sub_State = TP_RX_UNLOAD_REMAINING_BYTES_OF_LAST_CF;
       TP_State = TP_Wait_For_DataRead_State; 
       TP_Rx_Buffer_Status = FILLED;
       TP_Receive_Buffer_Filled();
       TP_Rx_Index = 0;
    }
}

/*============================================================================*\
* FUNCTION:      TP_Rx_Unload_Remaining_Bytes_Of_CFProcess
* DESCRIPTION:   Handles the consecutive frame reception with respect to
* remaining bytes of CF
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Rx_Unload_Remaining_Bytes_OF_CF_Process(void)
{
   if(TP_Rx_Buffer_Status == EMPTY) 
   {   
      for(TP_Next_Loop_Count = TP_Next_Loop_Count; TP_Next_Loop_Count <= CAN_FRAME_BYTES_UPPER_RANGE; TP_Next_Loop_Count++)
      {
          TP_Buffer[TP_Rx_Index] = TP_Frame_Array[TP_Next_Loop_Count];
          TP_Rx_Index++;
          TP_Rx_Message_Length--; 
      }
      TP_Receive_Sub_State =  TP_RX_UNLOAD_CF_DATA;
      TP_State = TP_Rx_CF_State; 
   }
}

/*============================================================================*\
* FUNCTION:      TP_Rx_Unload_Remaining_Bytes_OF_Last_CF_Process
* DESCRIPTION:   Handles the consecutive frame reception with respect to
* remaining bytes of last CF
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Rx_Unload_Remaining_Bytes_OF_Last_CF_Process(void)
{
    uint8_t TempLoopCount;

    if(TP_Rx_Buffer_Status == EMPTY)
    {
       TempLoopCount =  TP_Rx_Message_Length;
       for(TP_Next_Loop_Count = TP_Next_Loop_Count; TP_Next_Loop_Count <= (TempLoopCount + 1); TP_Next_Loop_Count++)
       {
         TP_Buffer[TP_Rx_Index] = TP_Frame_Array[TP_Next_Loop_Count];
         TP_Rx_Index++;
         TP_Rx_Message_Length--;
       }
       TP_Receive_Sub_State =  TP_RX_UNLOAD_CF_DATA;
       TP_State = TP_Rx_CF_State;
    }
}

/*============================================================================*\
* FUNCTION:      TP_Transmit_Buffer_Filled
* DESCRIPTION:   Sets the TP buffer to true state. After filling the buffer,
* application will call the function to indicate TP layer that buffer has
* been filled.
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
void TP_Transmit_Buffer_Filled(void)
{
    TP_Tx_Buffer_Status = FILLED;
}/* End of TP_Transmit_Buffer_Filled*/

/*============================================================================*\
* FUNCTION:      TP_Receive_Buffer_Read
* DESCRIPTION:   Clears the TP buffer to false state. After emptying the buffer,
* application will call the function to indicate TP layer that buffer is
* emptied.
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
void TP_Receive_Buffer_Read(void)
{
    TP_Rx_Buffer_Status = EMPTY;
}/* End of TP_Receive_Buffer_Read */

/*============================================================================*\
* FUNCTION:      TP_Check_Rx_Message_Length
* DESCRIPTION:   This API checks for the remaining length. If all the bytes are
* received it goes to idle state. Otherwise it goes to a state to receive
* next CF
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Check_Rx_Message_Length(void)
{
    if(TP_Rx_Message_Length == 0)     
    {
        TP_N_Cr_Timer_Control = TIMER_STOP;
        TP_State = TP_Idle_State;
        TP_Rx_Message_Status = TP_RECEIVE_IDLE;
        TP_Rx_Buffer_Status = EMPTY;
        TP_Result = N_OK;           
        TP_N_USData_Indication(TP_Rx_Message_DLC, TP_Result);
    }
    else
    {
        if(TP_Rx_Block_Size_Parameter == 0)
        {
            TP_State = TP_Rx_CF_State;
        }
        else
        {
            TP_Rx_Block_Size--;
            if(TP_Rx_Block_Size == 0)
            {
                TP_State = TP_Wait_For_FC_TXconf_State;
                TP_Transmit_Flow_Control();                
            }

        }
        TP_Rx_Sequence_Number++;
        if(TP_Rx_Sequence_Number == SEQUENCE_NUMBER_MAX)
        {
            TP_Rx_Sequence_Number = 0;
        }
    }
}/* End of TP_Check_Rx_Message_Length */

/*============================================================================*\
* FUNCTION:      TP_Transmit_Flow_Control
* DESCRIPTION:   This API is responsible for framing the flowcontrol message
*                 and transmitting to the transmitter using VBM API's
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Transmit_Flow_Control(void)
{
    uint8_t Frame_Array_Index;
    /* frame a control-frame using modifiable parameters */
	/* store N_PCI and flow status, as first byte */
    TP_Frame_Array[0] = FLOW_CONTROL_FRAME | Flow_Status; 
    /* store ECU's BS parameter for receiving, as second byte */  
    TP_Frame_Array[1] = TP_Rx_Block_Size_Parameter; 
    /* store ECU's STmin  parameter for receiving, as third byte */        
    TP_Frame_Array[2] = TP_Rx_Seperation_Time_Parameter; 
    /* store BS to another variable */   
    TP_Rx_Block_Size = TP_Rx_Block_Size_Parameter;          
    TP_Tx_Frame_DLC = FLOW_CONTROL_N_PCI_PLUS_DATA_BYTE;
    if(PADDING_OPERATION == TRUE)
    {
        for(Frame_Array_Index = 3; Frame_Array_Index <=
            CAN_FRAME_BYTES_UPPER_RANGE; Frame_Array_Index++)
        {
            TP_Frame_Array[Frame_Array_Index] = PADDING_BYTE;
        }
        TP_Tx_Frame_DLC = NW_DLC_MAX_BYTES;
    }

    TP_State = TP_Wait_For_FC_TXconf_State;
    TPN_Ar_Timer = N_Ar_TIMER_COUNT;
    TP_N_Ar_Timer_Control = TIMER_RUN;
    
    TP_Can_Tx_Message(TP_Frame_Array);
    
}/* End of TP_Transmit_Flow_Control */

/*============================================================================*\
* FUNCTION:      TP_Received_DLC_Check
* DESCRIPTION:   This API checks for the received DLC.If the received DLC is
* less than the expected DLC it returns false. Otherwise it returns true.
* PARAMETERS:    None
* RETURN VALUE:  True/False
\*============================================================================*/
static bool_t TP_Received_DLC_Check(void)
{
    bool_t ReceivedDLCResult = FALSE;
#ifdef TP_FIXED_FRAME_DLC
	if( NW_DLC_MAX_BYTES == TP_Rx_Frame_DLC )
	{
	   ReceivedDLCResult = TRUE;
	}
	else
	{
	   ReceivedDLCResult = FALSE;
	}
    if( FALSE != ReceivedDLCResult )
	{
#endif
      switch(TP_Rx_Frame_Type)
      {
      case SINGLE_FRAME:
      if( TP_Rx_Message_DLC !=  0)
      {
         if(TP_Rx_Frame_DLC < (TP_Rx_Message_DLC + SINGLE_FRAME_N_PCI_BYTE))
         {
            ReceivedDLCResult =  FALSE;
         }
         else
         {
            ReceivedDLCResult =  TRUE;
         }
      }
	  else
	  {
	    ReceivedDLCResult =  FALSE;
	  }
      break;
      case FIRST_FRAME:
      if(TP_Rx_Frame_DLC < FIRST_FRAME_N_PCI_PLUS_DATA_BYTE)
      {
          ReceivedDLCResult =  FALSE;
      }
      else
      {
          ReceivedDLCResult =  TRUE;
      }
      break;
      case CONSECUTIVE_FRAME:
      if(TP_Rx_Message_Length >= CONSECUTIVE_FRAME_DATA_BYTE)
      {
          if(TP_Rx_Frame_DLC < CONSECUTIVE_FRAME_N_PCI_PLUS_DATA_BYTE)
          {
              ReceivedDLCResult =  FALSE;
          }
          else
          {
              ReceivedDLCResult =  TRUE;
          }
      }
      else
      {
          if(TP_Rx_Frame_DLC < (TP_Rx_Message_Length +
             CONSECUTIVE_FRAME_N_PCI_BYTE))
          {
              ReceivedDLCResult =  FALSE;
          }
          else
          {
              ReceivedDLCResult =  TRUE;
          }
      }
      break;
      case FLOW_CONTROL_FRAME:
      if(TP_Rx_Frame_DLC < FLOW_CONTROL_N_PCI_PLUS_DATA_BYTE)
      {
          ReceivedDLCResult =  FALSE;
      }
      else
      {
          ReceivedDLCResult =  TRUE;
      }
       break;
      default:
      break;
      }
#ifdef TP_FIXED_FRAME_DLC
	}
	else
	{
	}
#endif
	
    return(ReceivedDLCResult);
}/* End of TP_Received_DLC_Check */

/*============================================================================*\
* FUNCTION:      TP_Update_Timers
* DESCRIPTION:   If the timers are enabled, timercount for each timer is
* decremented. Timers are: N_As, N_Ar, N_Bs and N_Cr
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
static void TP_Update_Timers(void)
{
    if(TP_N_As_Timer_Control == TIMER_RUN)
    {
      if(TPN_As_Timer > 0)
      {
         TPN_As_Timer--;
      }
    }
    if(TP_N_Ar_Timer_Control == TIMER_RUN)
    {
      if(TPN_Ar_Timer > 0)
      {
          TPN_Ar_Timer--;
      }
    }
    if(TP_N_Bs_Timer_Control == TIMER_RUN)
    {
      if(TPN_Bs_Timer > 0)
      {
          TPN_Bs_Timer--;
      }
  }
    if(TP_N_Cr_Timer_Control == TIMER_RUN)
    {
      if(TPN_Cr_Timer > 0)
      {
          TPN_Cr_Timer--;
      }
    }
}/* End of TP_Update_Timers */

/*============================================================================*\
* FUNCTION:      TP_GetBufferSize
* DESCRIPTION:   User calls this API to get the size of the buffer.
* PARAMETERS:    None
* RETURN VALUE:  TP Buffer size
\*============================================================================*/
uint16_t TP_Get_Message_Buffer_Size(void)
{
   return (TP_BUFFER_SIZE);     /* size of the TP_Buffer as configured in the
 config file */
}/* End of TP_Get_Message_Buffer_Size */

/*============================================================================*\
* FUNCTION:      TP_GetBufferPointer
* DESCRIPTION:   User calls this API to get the pointer(address)of the
* TP_Buffer.
* PARAMETERS:    None
* RETURN VALUE:  Address of the TP buffer
\*============================================================================*/
uint8_t * TP_Get_Message_Buffer_Pointer(void)
{
   return(TP_Buffer);  /* returns the starting address of the TP buffer */
}/* End of TP_Get_Message_Buffer_Pointer */

/*============================================================================*\
* FUNCTION:      TP_Get_Request_Type
* DESCRIPTION:   User calls this API to get the type of
* request(physical/functional).
* PARAMETERS:    None
* RETURN VALUE:  Type of Request
\*============================================================================*/
uint8_t TP_Get_Request_Type(void)
{
   return(TP_Request_Type);  /* returns the type of request */
}/* End of TP_Get_Request_Type */


/*============================================================================*\
* FUNCTION:      TP_N_USData_Request
* DESCRIPTION:   User calls this API to transmit a message. It passes the length
* of the message to be transmitted. 
* PARAMETERS:    Transmit message length
* RETURN VALUE:  Nothing
\*============================================================================*/
void TP_N_USData_Request(uint16_t TPTransmitMessageLength)
{
   TP_Tx_Message_DLC = TPTransmitMessageLength;
   if(TP_Tx_Message_DLC <= MAXIMUM_SINGLE_FRAME_DATA_BYTE)
   {
        TP_Tx_Frame_Type = SINGLE_FRAME;
   }
   else
   {
        TP_Tx_Frame_Type = FIRST_FRAME;
   }
   TP_Tx_Message_Status = TP_TRANSMIT_START;
   TP_Tx_Index = 0; 
   if(TP_Tx_Buffer_Status == FILLED)
   {
      TP_Transmit_Single_OR_First_Frame();
      ////added by me
     // if((FIRST_FRAME == TP_Tx_Frame_Type)&&(TP_Tx_Message_DLC ))
     //   TP_Tx_Load_CF_Data_Process();
      ////added by me
   }
   else
   {   
      TP_Result = TP_BUFFER_NOT_FILLED;
      TP_N_USData_Confirm(TP_Result);
      TP_Tx_Message_Status = TP_TRANSMIT_IDLE;
   } 
}/* End of TP_N_USData_Request */

/*============================================================================*\
* FUNCTION:      TP_D_UUData_Confirm
* DESCRIPTION:   This is a callback function called by VBM after transmitting
* a message corresponding to TP. Flag is set to inform the TP about frame
* transmission completion.
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
void TP_D_UUData_Confirm(void)
{
    Frame_Tx_Complete = TRUE;
    TP_N_As_Timer_Control = TIMER_STOP;
    if((TP_State == TP_Wait_For_SFORFF_TxConf_State) && 
        (TP_Tx_Frame_Type == FIRST_FRAME)) 
    {
	   TP_N_USData_FF_Confirmation();
    } 
    if(((TP_State ==TP_Wait_For_SFORFF_TxConf_State) && 
        (TP_Tx_Frame_Type == FIRST_FRAME)) || 
        ((TP_Tx_Block_Size_Constant!= 0) && (TP_Tx_Block_Size == 0)))
    {
       TPN_Bs_Timer = N_Bs_TIMER_COUNT;
       TP_N_Bs_Timer_Control = TIMER_RUN;
       TP_Tx_Message_Status = WAITINGFORFLOWCONTROL;
       
    } 
    if( ( (TP_Tx_Message_Status == TP_TRANSMIT_START) && 
          (TP_Tx_Separation_Time_Min_Constant == 0)) || 
        (SINGLE_FRAME == TP_Tx_Frame_Type) || 
        ( (TP_State == TP_Wait_For_CF_TxConf_State) && (0 == TP_Tx_Message_DLC) ) )
    {
/* to transmit 2nd CF onwards if stmin =0......*/
/* to handle next request within loop time of response */
     TP_Periodic_Task();
    }
    if((TP_Rx_Message_Status == TP_RECEIVE_START) && 
       (TP_State == TP_Wait_For_FC_TXconf_State))
    {
	   /* to notify flow control tx so that cf's can be received(any time)*/
       TP_Periodic_Task();
    }
}/* End of TP_D_UUData_Confirm */

/*============================================================================*\
* FUNCTION:      TP_D_UUData_Indication_Physical
* DESCRIPTION:   This is a callback function called by CCA after receiving
* a message(Physical) corresponding to TP. If the ECU is transmitting, 
* and if it receives a frame it is ignored. Flag is set to inform the TP about 
* frame arrival.Data is copied from the software buffer to TP's Frame buffer.
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
void TP_D_UUData_Indication_Physical(uint8_t dlc, uint8_t* data)
{
    uint8_t	FlowControlStatus;
    uint8_t  FlowControlByteVal;
    //If the response is not pending, then only tp shall receive the new request as the same buffer is used for request n response 
    if(FALSE == TP_Is_Response_Pending())
    {
       if(TP_Tx_Message_Status != TP_TRANSMIT_START) 
       {
          Frame_Available = TRUE;

          TP_Rx_Frame_DLC = dlc;
          memcpy(TP_Frame_Array, data, dlc);

          FlowControlStatus = TP_Frame_Array[0] & FLOW_STATUS_MASK;
		  FlowControlByteVal = TP_Frame_Array[0] & FRAME_TYPE_MASK;
          if((TP_Tx_Message_Status == WAITINGFORFLOWCONTROL) &&
              (FlowControlStatus == CLEAR_TO_SEND) &&
              (FlowControlByteVal == FLOW_CONTROL_FRAME)) 
          {
              TP_Tx_Message_Status = TP_TRANSMIT_START;
          }
          if((TP_Rx_Message_Status == TP_RECEIVE_START))
          {
             TP_Periodic_Task();   /* to receive cf's......*/
          }
       }
    }
    else
    {
       //Ignore the request
    }
}/* End of TP_D_UUData_Indication_Physical */


#ifdef TP_DIAG_FUNCTIONAL_MSG_SUPPORT
/*============================================================================*\
* FUNCTION:      TP_D_UUData_Indication_Functional
* DESCRIPTION:   This is a callback function called by CCA after receiving
* a message(functional) corresponding to TP. If the ECU is transmitting, 
* and if it receives a frame it is ignored. Flag is set to inform the TP about
* frame arrival. Data is copied from the software buffer to TP's Frame buffer
* PARAMETERS:    None
* RETURN VALUE:  Nothing
\*============================================================================*/
void TP_D_UUData_Indication_Functional(uint8_t dlc, uint8_t* data)
{
    uint8_t Frame_Array_Index;
    //If the response is not pending, then only tp shall receive the new request as the same buffer is used for request n response 
    if(FALSE == TP_Is_Response_Pending())
    {
       if( (TP_Tx_Message_Status == TP_TRANSMIT_IDLE) &&
	       (TP_Rx_Message_Status == TP_RECEIVE_IDLE) )
       {
           TP_Rx_Frame_DLC = dlc;
           memcpy(TP_Frame_Array, data, dlc);

           TP_Rx_Frame_Type = TP_Frame_Array[0] & FRAME_TYPE_MASK;
           
           if(TP_Rx_Frame_Type == SINGLE_FRAME)
           {
               TP_Rx_Index = 0;
               TP_Rx_Message_DLC = TP_Frame_Array[0] &
               SINGLE_FRAME_DATA_LENGTH_MASK; 
               if(FALSE ==  TP_Received_DLC_Check())
               {
                  TP_Result = N_WRONG_DLC;
                  TP_N_USData_Indication(TP_Rx_Message_DLC, TP_Result);
               }
               else
               {
                   for(Frame_Array_Index = 1; Frame_Array_Index <=
                       TP_Rx_Message_DLC; Frame_Array_Index++)
                   {
                       TP_Buffer[TP_Rx_Index] = TP_Frame_Array[Frame_Array_Index]; 
                       TP_Rx_Index++;
                   }
                   TP_Request_Type = FUNCTIONAL_ADDRESS_TYPE;
                   TP_Result = N_OK;
                   TP_N_USData_Indication(TP_Rx_Message_DLC, TP_Result);
              }
           }
        }
     }
     else
     {
        
     }
}/* End of TP_D_UUData_Indication_Functional */ 
#endif

/*============================================================================*\
* FUNCTION:      TP_N_Change_Parameters_Request
* DESCRIPTION:   This API is called by user to change the parameter values of
* the parameters BlockSize and the Minimum SeparationTime
* PARAMETERS:    Parameter and its value.
* RETURN VALUE:  Nothing
\*============================================================================*/
void TP_N_Change_Parameters_Request(uint8_t Parameter, uint16_t ParameterValue)
{
    /* if it is in the multiframe  receive mode, change is not permitted */     
    if(TP_Rx_Message_Status != TP_RECEIVE_START) 
    {
        switch(Parameter)
        {
        case N_BLOCKSIZE:
            if(ParameterValue <= 0xff)
            {
                TP_Rx_Block_Size_Parameter = ParameterValue;
                TP_Change_Parameter_Result = N_OK_R;
                TP_N_Change_Parameter_Confirm(Parameter,
               TP_Change_Parameter_Result);
            }
            else
            {
                TP_Change_Parameter_Result = N_WRONG_VALUE;
                TP_N_Change_Parameter_Confirm(Parameter,
                TP_Change_Parameter_Result);
            }
            break;
        case N_SEPERATIONTIME:
            if(ParameterValue <= 0xff)
            {
                TP_Rx_Seperation_Time_Parameter = ParameterValue;
                TP_Change_Parameter_Result = N_OK_R;
                TP_N_Change_Parameter_Confirm(Parameter,
                TP_Change_Parameter_Result);
            }
            else
            {
                TP_Change_Parameter_Result = N_WRONG_VALUE;
                TP_N_Change_Parameter_Confirm(Parameter,
                TP_Change_Parameter_Result);
            }
            break;
        default:
            TP_Change_Parameter_Result = N_WRONG_PARAMETER;
            TP_N_Change_Parameter_Confirm(Parameter,
            TP_Change_Parameter_Result); 
            break;
        }
    }
    else
    {
        TP_Change_Parameter_Result = N_RX_ON;
        TP_N_Change_Parameter_Confirm(Parameter,
        TP_Change_Parameter_Result);
    }
}/* End of TP_N_Change_Parameters_Request */

/*============================================================================*\
* FUNCTION:      TP_STmin_Calculate
* DESCRIPTION:   
* PARAMETERS:    Parameter and its value.
* RETURN VALUE:  Nothing
\*============================================================================*/
static uint8_t TP_STmin_Calculate(void)
{
 uint8_t TP_STmin_Result, Remainder;
 if(TP_Frame_Array[2] != 0)
 {
     if( ( (TP_Frame_Array[2] >= 0x80) && (TP_Frame_Array[2] <= 0xF0) ) ||
	   	 ( (TP_Frame_Array[2] >= 0xFA) && (TP_Frame_Array[2] <= 0xFF) ) )
     {
	    TP_Frame_Array[2] = STmin_MAX_VALUE;
	 }
	 else if( (TP_Frame_Array[2] >= 0xF1) && 
	          (TP_Frame_Array[2] <= 0xF9) ) 
	 {
	    /* This check for STmin in Micro Seconds, currently STmin will set as 10 milli seconds*/
	    TP_Frame_Array[2] = STmin_ZERO; 
	 }
	 else
	 {
	 }
     
     TP_STmin_Result = TP_Frame_Array[2]/CALL_RATE;
     Remainder = TP_Frame_Array[2] % CALL_RATE;
     if(TP_Frame_Array[2] < CALL_RATE)
     {
        TP_STmin_Result = 1;
     }
     else
     {
        if(Remainder != 0)
        {
           TP_STmin_Result+= 1;
        }
     }    
 }
 else
 {
   if(STmin_ZERO == CALL_RATE)
   {
       TP_STmin_Result = 1;
   }
   else
   {
       TP_STmin_Result = 0;
   }
 }   
 return(TP_STmin_Result);
}/*/TP_STmin_Calculate*/
