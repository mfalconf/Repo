/*===========================================================================*/
/**
 * @file battery_monitor.h
 *
 * Implementes the logic for tha battery voltage managment
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2023 Mirgor Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
#ifndef BATTERY_MONITOR_H_
#define BATTERY_MONITOR_H_

#include <standard.h>
#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>
#include "clock_utils.h"
#include <console.h>
#include "battery_monitor.cfg"
#include "comm_pmic_65919.h"
#include "famp_pm_types.h"
#include "famp_pm.h"


#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */

typedef enum {
   BM_UNKNOWN = 0,
   BM_NORMAL_MODE,
   BM_RESTRICTED_MODE
} bmVoltageState_t;

void BM_State_Machine ();
bool BM_In_Restricted_Mode (void);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */

extern uint16_t correctedThresholdCounts[NUM_THRESHOLDS];

#endif /* BATTERY_MONITOR_H_ */
