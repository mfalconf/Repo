/*===========================================================================*/
/**
 * @file battery_monitor.c
 *
 * Implementes the logic for tha battery voltage managment
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2023 Mirgor Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

#include "battery_monitor.h"

/* Local function prototypes */
static void bm_updateInternalTimerValueIfIsSmaller(uint32_t);
static uint32_t bm_getCurrentTime();
static bool bm_timerElapsed();

/* Global variables */
uint32_t bm_timerCount;
uint16_t correctedThresholdCounts[NUM_THRESHOLDS];

#define bm_updateInternalTimerValue(x) (bm_timerCount = (bm_getCurrentTime() + x))

bmVoltageState_t bmVoltageState = BM_UNKNOWN;

#define bm_getMonitorState()            (bmVoltageState)
#define bm_setMonitorUnknownRange()     (bmVoltageState = BM_UNKNOWN)
#define bm_setMonitorNormalRange()      (bmVoltageState = BM_NORMAL_MODE)
#define bm_setMonitorLowVoltageRange()  (bmVoltageState = BM_RESTRICTED_MODE)
#define bm_setMonitorHighVoltageRange() (bmVoltageState = BM_RESTRICTED_MODE)


/* Implementations */
bool BM_In_Restricted_Mode (void) {
    return (bmVoltageState == BM_RESTRICTED_MODE);
}

static uint32_t bm_getCurrentTime() {

   uint64_t timeMs;

#ifdef BM_USE_SECONDS_TIMER
   return Seconds_get();
#else
   timeMs = ClockUtils_Get_Time();
   return timeMs;
#endif
}

static void bm_updateInternalTimerValueIfIsSmaller(uint32_t newValue) {

    uint32_t aux = bm_getCurrentTime();

    if (aux + newValue > bm_timerCount) {
        LOG_PRINT_VER(DEBUG_BM, "[BM] No timer update because the result is higher\n");
    }
    else {
        LOG_PRINT_VER(DEBUG_BM, "[BM] Update timer value\n");
        bm_updateInternalTimerValue(newValue);
    }
}


static bool bm_timerElapsed() {

   if (bm_timerCount == bm_getCurrentTime()) {
      LOG_PRINT_VER(DEBUG_BM, "[BM] Timer elapsed\n");
   }
   return (bm_timerCount <= bm_getCurrentTime());
}


void BM_State_Machine () {

    typedef enum {
        BM_NOT_READY = 0,
        BM_NORMAL,
        BM_LOW_VOLTAGE_WITH_IGNITION_DETECTED,
        BM_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED,
        BM_CRITICAL_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED,
        BM_LOW_VOLTAGE,
        BM_LOW_VOLTAGE_TO_NORMAL_DETECTED,
        BM_HIGH_VOLTAGE_DETECTED,
        BM_HIGH_VOLTAGE,
        BM_HIGH_VOLTAGE_TO_NORMAL_DETECTED
    } bmStates_t;

    static bmStates_t bmState = BM_NOT_READY;    

    int16_t batteryVoltage;

    batteryVoltage = get_Battery_Voltage();

    pmIgnitionLineState_t   bmIgnitionLineState;
    pmCanState_t            bmIgnitionCanState;

    bmIgnitionLineState = getIgnitionLine();
    bmIgnitionCanState = getIgnitionCan();

    switch (bmState) {

        case BM_NOT_READY:

            if (batteryVoltage >= 0) {
                LOG_PRINT_VER(DEBUG_BM, "[BM] ready\n");
                bm_setMonitorNormalRange();
                bmState = BM_NORMAL;
            }
            break;

        case BM_NORMAL:

            /* If batteryVoltage is -1, that means that the samples buffer in the driver is not
             * full, so we need to wait fow a while. Anyway, this situation should not ever 
             * happen
             */
            if (batteryVoltage < 0) {                
                bmState = BM_NOT_READY;
                bm_setMonitorUnknownRange();
                LOG_PRINT_VER(DEBUG_BM, "[BM] Stopped working, wait for it\n");
            }
            else if ( batteryVoltage  > correctedThresholdCounts[BM_TH_HIGH] ) {
                    bmState = BM_HIGH_VOLTAGE_DETECTED;
                    bm_updateInternalTimerValue(TIME_BM_TH_HIGH);
                    LOG_PRINT_VER(DEBUG_BM, "[BM] Possible HV detected\n");
            }
            else if ( bmIgnitionLineState || bmIgnitionCanState ) {

                if (batteryVoltage  < correctedThresholdCounts[BM_TH_LOW_WITH_IGNITION]) {
                    bmState = BM_LOW_VOLTAGE_WITH_IGNITION_DETECTED;
                    bm_updateInternalTimerValue(TIME_BM_TH_LOW_WITH_IGNITION);
                    LOG_PRINT_VER(DEBUG_BM, "[BM] Possible LV/WI detected\n");
                }
            }
            else {

                if (batteryVoltage  < correctedThresholdCounts[BM_TH_CRITICAL_LOW_WITHOUT_IGNITION]) {
                    bmState = BM_CRITICAL_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED;
                    bm_updateInternalTimerValue(TIME_BM_TH_CRITICAL_LOW_WITHOUT_IGNITION);
                    LOG_PRINT_VER(DEBUG_BM, "[BM] Possible CLV/WOI detected\n");
                }
                else if (batteryVoltage  < correctedThresholdCounts[BM_TH_LOW_WITHOUT_IGNITION]) {
                    bmState = BM_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED;
                    bm_updateInternalTimerValue(TIME_BM_TH_LOW_WITHOUT_IGNITION);
                    LOG_PRINT_VER(DEBUG_BM, "[BM] Possible LV/WOI detected\n");
                }
            }
            break;


        case BM_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED:

            /* Ignition signal was recovered ?*/
            if ( bmIgnitionLineState || bmIgnitionCanState ) {
                bmState = BM_LOW_VOLTAGE_WITH_IGNITION_DETECTED;
                bm_updateInternalTimerValueIfIsSmaller(TIME_BM_TH_LOW_WITH_IGNITION);
                LOG_PRINT_VER(DEBUG_BM, "[BM] Ignition recovered while LV detected, go to LV/WI detected\n");
            }
            else if (batteryVoltage  < correctedThresholdCounts[BM_TH_CRITICAL_LOW_WITHOUT_IGNITION]) {
                bmState = BM_CRITICAL_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED;
                bm_updateInternalTimerValueIfIsSmaller(TIME_BM_TH_CRITICAL_LOW_WITHOUT_IGNITION);
                LOG_PRINT_VER(DEBUG_BM, "[BM] LV/WOI detected, but now battery is in CLV range\n");
            }
            else if (batteryVoltage  > correctedThresholdCounts[BM_TH_LOW_WITHOUT_IGNITION]) {
                bmState = BM_NORMAL;
                LOG_PRINT_VER(DEBUG_BM, "[BM] False detection. Battery is in NR\n");
            }
            else if ( bm_timerElapsed() ) {
                bmState = BM_LOW_VOLTAGE;
                bm_setMonitorLowVoltageRange();
                LOG_PRINT_VER(DEBUG_BM, "[BM] LV/WOI confirmed. Must go to RM\n");
            }
            break;

        case BM_CRITICAL_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED:

            if ( bmIgnitionLineState || bmIgnitionCanState ) {
                bmState = BM_LOW_VOLTAGE_WITH_IGNITION_DETECTED;
                bm_updateInternalTimerValueIfIsSmaller(TIME_BM_TH_LOW_WITH_IGNITION);
                LOG_PRINT_VER(DEBUG_BM, "[BM] Ignition recovered while CLV detected, go to LV/WI detected\n");
            }
            else if (batteryVoltage  > correctedThresholdCounts[BM_TH_LOW_WITHOUT_IGNITION]) {
                bmState = BM_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED;
                bm_updateInternalTimerValueIfIsSmaller(TIME_BM_TH_LOW_WITHOUT_IGNITION);
                LOG_PRINT_VER(DEBUG_BM, "[BM] CLV/WOI detected, but now battery is in LV range\n");
            }
            else if ( bm_timerElapsed() ) {
                bmState = BM_LOW_VOLTAGE;
                bm_setMonitorLowVoltageRange();
                LOG_PRINT_VER(DEBUG_BM, "[BM] CLV/WOI confirmed. Must go to RM\n");
            }
            break;

        case BM_LOW_VOLTAGE_WITH_IGNITION_DETECTED:

            if ( (bmIgnitionLineState != PM_IGNITION_LINE_ON) && (bmIgnitionCanState != PM_IGNITION_CAN_ON) ) {

                if (batteryVoltage  < correctedThresholdCounts[BM_TH_CRITICAL_LOW_WITHOUT_IGNITION]) {
                    bmState = BM_CRITICAL_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED;
                    bm_updateInternalTimerValue(TIME_BM_TH_CRITICAL_LOW_WITHOUT_IGNITION);
                    LOG_PRINT_VER(DEBUG_BM, "[BM] Ignition lost while LV detected, go to CLV/WOI detected\n");
                }
                else if (batteryVoltage  < correctedThresholdCounts[BM_TH_LOW_WITHOUT_IGNITION]) {
                    bmState = BM_LOW_VOLTAGE_WITHOUT_IGNITION_DETECTED;
                    bm_updateInternalTimerValue(TIME_BM_TH_LOW_WITHOUT_IGNITION);
                    LOG_PRINT_VER(DEBUG_BM, "[BM] Ignition lost while LV detected, go to LV/WOI detected\n");
                }
                else {
                    bmState = BM_NORMAL;
                    LOG_PRINT_VER(DEBUG_BM, "[BM] Ignition lost while LV detected, but now we are in NR\n");
                }
            }

            else if (batteryVoltage  > correctedThresholdCounts[BM_TH_LOW_WITH_IGNITION]) {
                
                bmState = BM_NORMAL;
                LOG_PRINT_VER(DEBUG_BM, "[BM] False detection, battery is in NVR\n");
            }

            else if ( bm_timerElapsed() ) {
                
                bmState = BM_LOW_VOLTAGE;
                bm_setMonitorLowVoltageRange();
                LOG_PRINT_VER(DEBUG_BM, "[BM] LV/WI confirmed. Must go to RM\n");                
            }
            break;


        case BM_LOW_VOLTAGE:

            if (batteryVoltage  > correctedThresholdCounts[BM_TH_NORMAL_LOW]) {
                bmState = BM_LOW_VOLTAGE_TO_NORMAL_DETECTED;
                bm_updateInternalTimerValue(TIME_BM_TH_NORMAL_LOW);
                LOG_PRINT_VER(DEBUG_BM, "[BM] Possible NVR detected\n\n");
            }
            break;


        case BM_LOW_VOLTAGE_TO_NORMAL_DETECTED:

            if (batteryVoltage  < correctedThresholdCounts[BM_TH_NORMAL_LOW]) {
                bmState = BM_LOW_VOLTAGE;
                LOG_PRINT_VER(DEBUG_BM, "[BM] False recovery, battery is in LVR\n");
            }
            else if ( bm_timerElapsed() ) {
                bmState = BM_NORMAL;
                bm_setMonitorNormalRange();
                LOG_PRINT_VER(DEBUG_BM, "[BM] NRV confirmed. Must return go to NR\n");
            }
            break;


        case BM_HIGH_VOLTAGE_DETECTED:

            if (batteryVoltage  < correctedThresholdCounts[BM_TH_NORMAL_HIGH]) {
                bmState = BM_NORMAL;
                LOG_PRINT_VER(DEBUG_BM, "[BM] False detection, battery is in NR\n");
            }
            else if ( bm_timerElapsed() ) {
                bmState = BM_HIGH_VOLTAGE;
                bm_setMonitorHighVoltageRange();
                LOG_PRINT_VER(DEBUG_BM, "[BM] HV confirmed. Must go to RM\n");
            }
            break;

        case BM_HIGH_VOLTAGE:

            if (batteryVoltage  < correctedThresholdCounts[BM_TH_NORMAL_HIGH]) {
                bmState = BM_HIGH_VOLTAGE_TO_NORMAL_DETECTED;
                bm_updateInternalTimerValue(TIME_BM_TH_NORMAL_HIGH);
                LOG_PRINT_VER(DEBUG_BM, "[BM] Possible NVR detected\n");
            }
            break;

        case BM_HIGH_VOLTAGE_TO_NORMAL_DETECTED:

            if (batteryVoltage  > correctedThresholdCounts[BM_TH_NORMAL_HIGH]) {
                bmState = BM_HIGH_VOLTAGE;
                LOG_PRINT_VER(DEBUG_BM, "[BM] False recovery, Battery is in HVR\n");
            }
            else if ( bm_timerElapsed() ) {
                bmState = BM_NORMAL;
                bm_setMonitorNormalRange();
                LOG_PRINT_VER(DEBUG_BM, "[BM] NV confirmed. Must go to NVR\n");
            }
            break;

        default:
            break;

    }
}

