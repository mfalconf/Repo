/*===========================================================================*/
/**
 * @file timer_tick.c
 *
 * Timer Tick controller interface
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <antpwr.h>
#include <micbias.h>
#include <timedate.h>
#include <timer_tick.h>
#include <comm_protocol.h>
#include <console.h>
#include <watchdog.h>
#include <aswc.h>
#include <external_signals.h>
#include "drv/board/board.h"
#include "clock_utils.h"
#include "main_callouts.h"
#include "comm_pmic_65919.h"

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>

#include <xdc/std.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/System.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define TT_TASK_TIMING_US 10000

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
uint32_t prescaler_1sec;
uint32_t prescaler_50ms;
uint32_t prescaler_100ms;
uint32_t prescaler_300ms;

static uint8_t stack[0x1000];

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/***************************************************************************//**
*
* @fn         Timer10ms
*
* @brief      Called every 10mS
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void Timer10ms (void)
{
    ClockUtil_Update(10);
}

/***************************************************************************//**
*
* @fn         Timer50ms
*
* @brief      Called every 50mS
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void Timer50ms (void)
{
    ASWC_Update();
    PMIC_65919_Continuos_Conversion();
}

/***************************************************************************//**
*
* @fn         Timer100ms
*
* @brief      Called every 100mS
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void Timer100ms (void)
{
    ES_Update();
}

/***************************************************************************//**
*
* @fn         Timer300ms
*
* @brief      Called every 300mS
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void Timer300ms (void)
{
    AntPwr_Update();
    MicBias_Update();
}

/***************************************************************************//**
*
* @fn         Timer1sec
*
* @brief      Called every 1000mS
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void Timer1sec (void)
{
    TD_Update();
    WD_Update();
}

/***************************************************************************//**
*
* @fn         TT_Task
*
* @brief      This is the Timer_Tick task
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
static void TT_Task (UArg arg0, UArg arg1)
{
    bool running = true;

    /* The operating voltage set up is done only once */
    Board_SetOperatingVoltages();

    /*
        [Temporal FIX]
    */
    WD_Update();
    /*
        Some U-Boot reboots where caused by the IPU kicking
        the MSP Main's watchdog too late. This early kick
        is to ensure that software resets and restoring from
        IDLE states do not cause an early reboot in U-Boot or
        kernel starting stages.
    */

    while(running)
    {
        Timer10ms();
        if (prescaler_50ms++ >= 5)
        {
            Timer50ms();
            prescaler_50ms = 0;
        }
        if(prescaler_100ms++ >= 10)
        {
            Timer100ms();
            prescaler_100ms = 0;
        }
        if(prescaler_300ms++ >= 30)
        {
            Timer300ms();
            prescaler_300ms = 0;
        }
        if(prescaler_1sec++ >= 100)
        {
            Timer1sec();
            prescaler_1sec = 0;
        }

        /* TODO: Why the sleep is at the bottom when in the other threads is at the begining
         * Investigate if this can change anything
         */
        Task_sleep(TT_TASK_TIMING_US / Clock_tickPeriod);
        running = MN_Keep_Running(); /* Better check if we need to keep running after the sleep */
    }

    WD_Disable();

    /* Now we need to shutdown the ADC converter in order to save its current 
     * consumption
     */
    PMIC_65919_Shutdown_ADC();
}

/***************************************************************************//**
*
* @fn         TT_Init
*
* @brief      Initialize the Timer Tick interface
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void TT_Task_Init (void)
{
    Error_Block eb;
    Task_Params taskParams;

    Error_init(&eb);

    /* create main thread (interrupts not enabled in main on BIOS) */
    Task_Params_init(&taskParams);
    taskParams.instance->name = "time_tick";
    taskParams.arg0 = NULL;
    taskParams.arg1 = NULL;
    taskParams.stack = stack;
    taskParams.stackSize = 0x1000;
    taskParams.affinity = APP_CORE_NUM;
    Task_create(TT_Task, &taskParams, &eb);

    /********** Submodules init functions *********/
    prescaler_1sec = 0;
    prescaler_300ms = 0;
    prescaler_100ms = 0;
    prescaler_50ms = 0;
}
