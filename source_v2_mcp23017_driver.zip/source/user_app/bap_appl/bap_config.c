/*===========================================================================*/
/**
 * @file ops_config.c
 *
 * Configuration file for the BAP stack
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/* Bap header files */
#include "bap_types.h"
#include "bap_privatetypes.h"
#include "bap_balconfig.h"
#include "bap_bplconfig.h"
#include "bap_bclconfig.h"
#include "bap_config.h"
#include "bap.h"

/* OEM header files */
#ifdef BAP_USES_CAN
#include <can_appl.h>
#include "can_appl_volkswagen.h"
#endif

#include <bap_audio_defines.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

#ifndef BAP_ROM_CONST
#define BAP_ROM_CONST
#endif

#ifndef BAP_RAM_DATA_FAR
#define BAP_RAM_DATA_FAR
#endif

#ifndef BAP_ROM_DATA_FAR
#define BAP_ROM_DATA_FAR
#endif

#define SIZE_OF_BAP_AUDIO_GETALL_RESPONSE_BUFFER       300
#define SIZE_OF_BAP_TELEPHONY_GETALL_RESPONSE_BUFFER   40

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/* BAP LsgRamRow Table ******************************************************/
BAP_RAM_DATA_FAR BapLsgRamRow_ot BAP_LsgRamTable[]={

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = {
          .eLsgStatus             = BapLayerLsgStat_NoInit,
          .u16HeartbeatTimer      = 0,
          .eHeartbeatStatus       = BapBplStat_Stopped,
          .u8LastSentFctIndex     = 0,
          .BapBAPConfig_t         = {0, 0, 0, 0, 0, 0},
          .BAP_aru8FunctionList   = {0, 0, 0, 0, 0, 0, 0, 0},
          .fState                 = {0, 0, 0, 0, 0, 0, 0, 0},
     },

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = {
          .eLsgStatus             = BapLayerLsgStat_NoInit,
          .u16HeartbeatTimer      = 0,
          .eHeartbeatStatus       = BapBplStat_Stopped,
          .u8LastSentFctIndex     = 0,
          .BapBAPConfig_t         = {0, 0, 0, 0, 0, 0},
          .BAP_aru8FunctionList   = {0, 0, 0, 0, 0, 0, 0, 0},
          .fState                 = {0, 0, 0, 0, 0, 0, 0, 0},
     },

};

/*------- BAL ------*/

/*Here are the caches of the functions with cacheAvailable="true"*/
BAP_RAM_DATA_FAR uint8_t BAL_Cache1_aru[8]={0};
BAP_RAM_DATA_FAR BapBalRamRow_ot BAL_Cache1 = {

     .eDataStatus=BapBalDataStat_Invalid,
     .u8Value=(uint8_t) 0,
     .u16Value=(uint16_t) 0,
     .u32Value=(uint32_t) 0,
     .oBufferWithLength={8, &BAL_Cache1_aru},

};

/*------- BPL ------*/

/* BPL RAM Tabelle ************************************************************/
/* for all functions with maxRetryTimer>0                                 */
BAP_RAM_DATA_FAR BapBplRamRow_ot BAP_BplRamTable[] = {

     /* AUDIO */

     [BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx] = {
          .u16RetryOrProcessingTimer  =   0,
          .fRetryOrProcessingFlags     =   {0,0,0},
     },

};

/* BPL HeartbeatTimer *********************************************************/
/* one heartbeat timer per LSG                                                */
BAP_RAM_DATA_FAR uint16_t BAP_BplHeartbeatTimerTable[] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = 0,

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = 0,

};


/*------- BCL ------*/

/*------- RX-Buffer -------*/

/* AUDIO */

/* Rx Buffer for AUDIO Function BAPConfig lsg.id=0x31 fct.id=0x02 */
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_AUDIO_BAP_CONFIG[BAP_AUDIO_BAPCONFIG_RX_SIZE];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_AUDIO_BAP_CONFIG = {

    .flags = (BapBclRxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_AUDIO_BAP_CONFIG), &aru8BclRxBuffer_AUDIO_BAP_CONFIG},

};

/* Rx Buffer for AUDIO Function FunctionList lsg.id=0x31 fct.id=0x03*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_AUDIO_FUNCTION_LIST[BAP_AUDIO_FUNCTION_LIST_RX_SIZE];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_AUDIO_FUNCTION_LIST = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_AUDIO_FUNCTION_LIST), &aru8BclRxBuffer_AUDIO_FUNCTION_LIST},

};

/* Rx Buffer for AUDIO Function Mute lsg.id=0x31 fct.id=0x13*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_AUDIO_MUTE[BAP_AUDIO_MUTE_Opcode_SetGet_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_AUDIO_MUTE = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_AUDIO_MUTE), &aru8BclRxBuffer_AUDIO_MUTE},

};

/* Rx Buffer for AUDIO Function InfoList lsg.id=0x31 fct.id=0x16*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_AUDIO_INFO_LIST[BAP_AUDIO_INFO_LIST_Opcode_GetArray_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_AUDIO_INFO_LIST = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_AUDIO_INFO_LIST), &aru8BclRxBuffer_AUDIO_INFO_LIST},

};

/* Rx Buffer for AUDIO Function DedicatedAudioControl lsg.id=0x31 fct.id=0x17*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL[BAP_AUDIO_DEDICATED_AUDIO_CONTROL_Opcode_StartResult_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL), &aru8BclRxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL},

};

/* TELEPHONY */

/* Rx Buffer for TELEPHONY Function BAPConfig lsg.id=0x2B fct.id=0x02 */
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_TELEPHONY_BAP_CONFIG[BAP_TELEPHONY_BAPCONFIG_RX_SIZE];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_TELEPHONY_BAP_CONFIG = {

    .flags = (BapBclRxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_TELEPHONY_BAP_CONFIG), &aru8BclRxBuffer_TELEPHONY_BAP_CONFIG},

};

/* Rx Buffer for TELEPHONY Function FunctionList lsg.id=0x2B fct.id=0x03*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_TELEPHONY_FUNCTION_LIST[BAP_TELEPHONY_FUNCTION_LIST_RX_SIZE];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_TELEPHONY_FUNCTION_LIST = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_TELEPHONY_FUNCTION_LIST), &aru8BclRxBuffer_TELEPHONY_FUNCTION_LIST},

};

/* Rx Buffer for TELEPHONY Function ASG_Capabilities lsg.id=0x2B fct.id=0x10*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_TELEPHONY_ASG_CAPABILITIES[BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_SetGet_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_TELEPHONY_ASG_CAPABILITIES = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_TELEPHONY_ASG_CAPABILITIES), &aru8BclRxBuffer_TELEPHONY_ASG_CAPABILITIES},

};

/* Rx Buffer for TELEPHONY Function ASG_Config lsg.id=0x2B fct.id=0x11*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_TELEPHONY_ASG_CONFIG[BAP_TELEPHONY_ASG_CONFIG_Opcode_SetGet_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_TELEPHONY_ASG_CONFIG = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_TELEPHONY_ASG_CONFIG), &aru8BclRxBuffer_TELEPHONY_ASG_CONFIG},

};

/* Rx Buffer for TELEPHONY Function MFL Block Definition lsg.id=0x2B fct.id=0x12*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION[BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION), &aru8BclRxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION},

};

/* Rx Buffer for TELEPHONY Function FrameStatus lsg.id=0x2B fct.id=0x13*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_TELEPHONY_FRAME_STATUS[BAP_TELEPHONY_FRAME_STATUS_Opcode_SetGet_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_TELEPHONY_FRAME_STATUS = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_TELEPHONY_FRAME_STATUS), &aru8BclRxBuffer_TELEPHONY_FRAME_STATUS},

};

/* Rx Buffer for TELEPHONY Function FrameData lsg.id=0x2B fct.id=0x14*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_TELEPHONY_FRAME_DATA[BAP_TELEPHONY_FRAME_DATA_Opcode_GetArray_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_TELEPHONY_FRAME_DATA = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_TELEPHONY_FRAME_DATA), &aru8BclRxBuffer_TELEPHONY_FRAME_DATA},

};

/* Rx Buffer for TELEPHONY Function FrameDataAck lsg.id=0x2B fct.id=0x15*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_TELEPHONY_FRAME_DATA_ACK[BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Set_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_TELEPHONY_FRAME_DATA_ACK = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_TELEPHONY_FRAME_DATA_ACK), &aru8BclRxBuffer_TELEPHONY_FRAME_DATA_ACK},

};

/* Rx Buffer for TELEPHONY Function LsgStatus lsg.id=0x2B fct.id=0x17*/
BAP_RAM_DATA_FAR uint8_t aru8BclRxBuffer_TELEPHONY_LSG_STATUS[BAP_TELEPHONY_LSG_STATUS_Opcode_Set_Size];
BAP_RAM_DATA_FAR BapBclRxRamRow_ot BCL_RxBuffer_TELEPHONY_LSG_STATUS = {

  .flags = (BapBclRxRamRowFlags_ot){0},
  .eErrorCode = BapErr_OK,
  .eOpCode = (BapOpCodes_et) 0,
  .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclRxBuffer_TELEPHONY_LSG_STATUS), &aru8BclRxBuffer_TELEPHONY_LSG_STATUS},

};

/*------- TX-Buffer -------*/

/* AUDIO */

/* Tx Buffer for AUDIO Function GetAll lsg.id=0x31 fct.id=0x01 */
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_GET_ALL[SIZE_OF_BAP_AUDIO_GETALL_RESPONSE_BUFFER];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_GET_ALL = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_GET_ALL), &aru8BclTxBuffer_AUDIO_GET_ALL}

};

/* Tx Buffer for AUDIO Function BAPConfig lsg.id=0x31 fct.id=0x02 */
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_BAP_CONFIG[BAP_AUDIO_BAPCONFIG_TX_SIZE];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_BAP_CONFIG = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_BAP_CONFIG), &aru8BclTxBuffer_AUDIO_BAP_CONFIG}

};

/* Tx Buffer for AUDIO Function FunctionList lsg.id=0x31 fct.id=0x03*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_FUNCTION_LIST[BAP_AUDIO_FUNCTION_LIST_TX_SIZE];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_FUNCTION_LIST = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_FUNCTION_LIST),&aru8BclTxBuffer_AUDIO_FUNCTION_LIST},

};

/*Tx Buffer for AUDIO Function Heartbeat lsg.id=0x31 fct.id=4*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_HEARTBEAT[BAP_AUDIO_HEARTBEAT_TX_SIZE];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_HEARTBEAT = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_HEARTBEAT), &aru8BclTxBuffer_AUDIO_HEARTBEAT},

};

/*Tx Buffer for AUDIO Function FSG-Setup lsg.id=0x31 fct.id=0x0E*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_FSG_SETUP[BAP_AUDIO_FSG_SETUP_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_FSG_SETUP = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_FSG_SETUP), &aru8BclTxBuffer_AUDIO_FSG_SETUP},

};

/*Tx Buffer for AUDIO Function FSG-OperationState lsg.id=0x31 fct.id=0x0F*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_FSG_OPERATION_STATE[BAP_AUDIO_FSG_OPERATION_STATE_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_FSG_OPERATION_STATE = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_FSG_OPERATION_STATE), &aru8BclTxBuffer_AUDIO_FSG_OPERATION_STATE},

};

/*Tx Buffer for AUDIO Function activeSource lsg.id=0x31 fct.id=0x10*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_ACTIVE_SOURCE[BAP_AUDIO_ACTIVE_SOURCE_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_ACTIVE_SOURCE = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_ACTIVE_SOURCE), &aru8BclTxBuffer_AUDIO_ACTIVE_SOURCE},

};

/*Tx Buffer for AUDIO Function activeSourceName lsg.id=0x31 fct.id=0x11*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_ACTIVE_SOURCE_NAME[BAP_AUDIO_ACTIVE_SOURCE_NAME_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_ACTIVE_SOURCE_NAME = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_ACTIVE_SOURCE_NAME), &aru8BclTxBuffer_AUDIO_ACTIVE_SOURCE_NAME},

};

/*Tx Buffer for AUDIO Function CurrentVolume lsg.id=0x31 fct.id=0x12*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_CURRENT_VOLUME[BAP_AUDIO_CURRENT_VOLUME_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_CURRENT_VOLUME = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_CURRENT_VOLUME), &aru8BclTxBuffer_AUDIO_CURRENT_VOLUME},

};

/*Tx Buffer for AUDIO Function Mute lsg.id=0x31 fct.id=0x13*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_MUTE[BAP_AUDIO_MUTE_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_MUTE = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_MUTE), &aru8BclTxBuffer_AUDIO_MUTE},

};

/*Tx Buffer for AUDIO Function SourceState lsg.id=0x31 fct.id=0x14*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_SOURCE_STATE[BAP_AUDIO_SOURCE_STATE_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_SOURCE_STATE = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_SOURCE_STATE), &aru8BclTxBuffer_AUDIO_SOURCE_STATE},

};

/*Tx Buffer for AUDIO Function CurrentStationInfo lsg.id=0x31 fct.id=0x15*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_CURRENT_STATION_INFO[BAP_AUDIO_CURRENT_STATION_INFO_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_CURRENT_STATION_INFO = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_CURRENT_STATION_INFO), &aru8BclTxBuffer_AUDIO_CURRENT_STATION_INFO},

};

/*Tx Buffer for AUDIO Function InfoList lsg.id=0x31 fct.id=0x16*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_INFO_LIST[BAP_AUDIO_INFO_LIST_Opcode_StatusArray_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_INFO_LIST = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_INFO_LIST), &aru8BclTxBuffer_AUDIO_INFO_LIST},

};

/* Tx Buffer for AUDIO Function DedicatedAudioControl lsg.id=0x31 fct.id=0x17*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL[BAP_AUDIO_DEDICATED_AUDIO_CONTROL_Opcode_Result_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL), &aru8BclTxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL},

};

/* Tx Buffer for AUDIO Function InfoListType lsg.id=0x31 fct.id=0x1D*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_AUDIO_INFO_LIST_TYPE[BAP_AUDIO_INFO_LIST_TYPE_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_AUDIO_INFO_LIST_TYPE = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_AUDIO_INFO_LIST_TYPE), &aru8BclTxBuffer_AUDIO_INFO_LIST_TYPE},

};

/* TELEPHONY */

/* Tx Buffer for TELEPHONY Function GetAll lsg.id=0x2B fct.id=0x01 */
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_GET_ALL[SIZE_OF_BAP_TELEPHONY_GETALL_RESPONSE_BUFFER];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_GET_ALL = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_GET_ALL), &aru8BclTxBuffer_TELEPHONY_GET_ALL}

};

/* Tx Buffer for TELEPHONY Function BAPConfig lsg.id=0x2B fct.id=0x02 */
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_BAP_CONFIG[BAP_TELEPHONY_BAPCONFIG_TX_SIZE];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_BAP_CONFIG = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_BAP_CONFIG), &aru8BclTxBuffer_TELEPHONY_BAP_CONFIG}

};

/* Tx Buffer for TELEPHONY Function FunctionList lsg.id=0x2B fct.id=0x03*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_FUNCTION_LIST[BAP_TELEPHONY_FUNCTION_LIST_TX_SIZE];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_FUNCTION_LIST = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_FUNCTION_LIST),&aru8BclTxBuffer_TELEPHONY_FUNCTION_LIST},

};

/*Tx Buffer for TELEPHONY Function Heartbeat lsg.id=0x2B fct.id=0x04*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_HEARTBEAT[BAP_TELEPHONY_HEARTBEAT_TX_SIZE];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_HEARTBEAT = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_HEARTBEAT), &aru8BclTxBuffer_TELEPHONY_HEARTBEAT},

};

/*Tx Buffer for TELEPHONY Function FSG-OperationState lsg.id=0x2B fct.id=0x0F*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_FSG_OPERATION_STATE[BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_FSG_OPERATION_STATE = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_FSG_OPERATION_STATE), &aru8BclTxBuffer_TELEPHONY_FSG_OPERATION_STATE},

};

/*Tx Buffer for TELEPHONY Function ASG-Capabilities lsg.id=0x2B fct.id=0x10*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_ASG_CAPABILITIES[BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_ASG_CAPABILITIES = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_ASG_CAPABILITIES), &aru8BclTxBuffer_TELEPHONY_ASG_CAPABILITIES},

};

/*Tx Buffer for TELEPHONY Function ASG-Config lsg.id=0x2B fct.id=0x11*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_ASG_CONFIG[BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_ASG_CONFIG = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_ASG_CONFIG), &aru8BclTxBuffer_TELEPHONY_ASG_CONFIG},

};

/*Tx Buffer for TELEPHONY Function MFL Block Definition  lsg.id=0x2B fct.id=0x12*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION[BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION), &aru8BclTxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION},

};

/*Tx Buffer for TELEPHONY Function FrameStatus lsg.id=0x2B fct.id=0x13*/
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_FRAME_STATUS[BAP_TELEPHONY_FRAME_STATUS_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_FRAME_STATUS = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_FRAME_STATUS), &aru8BclTxBuffer_TELEPHONY_FRAME_STATUS},

};

/*Tx Buffer for TELEPHONY Function FrameData lsg.id=0x2B fct.id=0x14 */
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_FRAME_DATA[BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_FRAME_DATA = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_FRAME_DATA), &aru8BclTxBuffer_TELEPHONY_FRAME_DATA},

};

/*Tx Buffer for TELEPHONY Function FrameDataAck lsg.id=0x2B fct.id=0x15 */
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_FRAME_DATA_ACK[BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_FRAME_DATA_ACK = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_FRAME_DATA_ACK), &aru8BclTxBuffer_TELEPHONY_FRAME_DATA_ACK},

};

/*Tx Buffer for TELEPHONY Function Scrollbar lsg.id=0x2B fct.id=0x16 */
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_SCROLLBAR[BAP_TELEPHONY_SCROLLBAR_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_SCROLLBAR= {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_SCROLLBAR), &aru8BclTxBuffer_TELEPHONY_SCROLLBAR},

};   

/*Tx Buffer for TELEPHONY Function LsgStatus lsg.id=0x2B fct.id=0x17 */
BAP_RAM_DATA_FAR uint8_t aru8BclTxBuffer_TELEPHONY_LSG_STAUS[BAP_TELEPHONY_LSG_STATUS_Opcode_Status_Size];
BAP_RAM_DATA_FAR BapBclTxRamRow_ot BCL_TxBuffer_TELEPHONY_LSG_STATUS = {

    .flags = (BapBclTxRamRowFlags_ot){0},
    .eErrorCode = BapErr_OK,
    .eOpCode = (BapOpCodes_et) 0,
    .oBufferWithLength = (BapBufferWithLength_ot){(uint16_t) sizeof(aru8BclTxBuffer_TELEPHONY_LSG_STAUS), &aru8BclTxBuffer_TELEPHONY_LSG_STAUS},

};

/* BAP BCL Inhibit Timer Table **********************************************/
/* one entry per TxCanId                                                    */
BAP_RAM_DATA_FAR BapInhibitRamRow_ot BAP_InhibitRamTable[] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = {
          .u16InhibitTimer      = 0,
          .u8HeuristikLsgIndex  = 0,
          .u8HeuristikFctIndex  = 0,
          .oHeuristikFlags      = {0,0},
     },

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = {
          .u16InhibitTimer      = 0,
          .u8HeuristikLsgIndex  = 0,
          .u8HeuristikFctIndex  = 0,
          .oHeuristikFlags      = {0,0},
     },

};


/* BAP BCL Inihibit ROM table ***********************************************/
BAP_ROM_DATA_FAR BapInhibitRomRow_ot BAP_ROM_CONST BAP_InhibitRomTable [] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = {
          .u16ConfiguredInhibitTime   =   1,
          .canMsgId                   =   BAP_AUDIO_ID,
          .u16MapCanIdToLsgTableIndex =   BapLsg_AUDIO_Idx,
          .u8MapCanIdToLsgSize        =   1,
          .u16MapCanIdByLsgTableIndex =   BapLsg_AUDIO_Fct_StartIdx,
          .u8MapCanIdByLsgSize        =   BapLsg_AUDIO_FctSize,
          .canInterfaceChannel        =   1,
     },

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = {
          .u16ConfiguredInhibitTime   =   1,
          .canMsgId                   =   BAP_Telefon_04_ID,
          .u16MapCanIdToLsgTableIndex =   BapLsg_TELEPHONY_Idx,
          .u8MapCanIdToLsgSize        =   1,
          .u16MapCanIdByLsgTableIndex =   BapLsg_TELEPHONY_Fct_StartIdx,
          .u8MapCanIdByLsgSize        =   BapLsg_TELEPHONY_FctSize,
          .canInterfaceChannel        =   1,
     },

};

/* BAP BCL InterTelegram Timer mapping table ******************************/
BAP_ROM_DATA_FAR BapInterTelegramTimerMapRow_ot BAP_ROM_CONST BAP_InterTelegramTimerMappingTable[] = {

     /* AUDIO */

     [BapFct_AUDIO_FUNCTION_LIST_Idx] = {
          .lsgId  = BapLsg_AUDIO_Id,
          .fctId  = BapFct_AUDIO_FUNCTION_LIST_Id
     },

     [BapFct_AUDIO_INFO_LIST_Idx] = {
          .lsgId  = BapLsg_AUDIO_Id,
          .fctId  = BapFct_AUDIO_INFO_LIST_Id
     },

     /* TELEPHONY */

     [BapFct_TELEPHONY_FUNCTION_LIST_Idx] = {
          .lsgId  = BapLsg_TELEPHONY_Id,
          .fctId  = BapFct_TELEPHONY_FUNCTION_LIST_Id
     },
     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx] = {
          .lsgId  = BapLsg_TELEPHONY_Id,
          .fctId  = BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Id
     },

};

/* BAP BCL InterTelegram Timer Table ****************************************/
BAP_RAM_DATA_FAR uint16_t BAP_u16InterTelegramTimerTable[] = {

     /* AUDIO */

     [BapFct_AUDIO_FUNCTION_LIST_Idx]   = 0,
     [BapFct_AUDIO_INFO_LIST_Idx]       = 0,

     /* TELEPHONY */

     [BapFct_TELEPHONY_FUNCTION_LIST_Idx]         = 0,
     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx]  = 0,
     [BapFct_TELEPHONY_FRAME_DATA_Idx]  = 0,

};

/* BAP BCL CanTxSegmentation Table ******************************************/
BAP_RAM_DATA_FAR BapCanTxSegmentationRamRow_ot BAP_u16CanTxSegmentationTable[] = {

     /* AUDIO */

     [BapFct_AUDIO_GET_ALL_Idx] = {
          .flags = {0},
          .u16BclTxBufferByteOffset = 0,
          .eSelectedSegmentationChannel = BapSegType_ChannelOne,
     },
     [BapFct_AUDIO_FUNCTION_LIST_Idx] = {
          .flags = {0},
          .u16BclTxBufferByteOffset = 0,
          .eSelectedSegmentationChannel = BapSegType_ChannelTwo,
     },
     [BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx] = {
          .flags = {0},
          .u16BclTxBufferByteOffset = 0,
          .eSelectedSegmentationChannel = BapSegType_ChannelTwo,
     },
     [BapFct_AUDIO_CURRENT_STATION_INFO_Idx] = {
          .flags = {0},
          .u16BclTxBufferByteOffset = 0,
          .eSelectedSegmentationChannel = BapSegType_ChannelTwo,
     },
     [BapFct_AUDIO_INFO_LIST_Idx] = {
          .flags = {0},
          .u16BclTxBufferByteOffset = 0,
          .eSelectedSegmentationChannel = BapSegType_ChannelOne,
     },

     /* TELEPHONY */

     [BapFct_TELEPHONY_GET_ALL_Idx] = {
          .flags = {0},
          .u16BclTxBufferByteOffset = 0,
          .eSelectedSegmentationChannel = BapSegType_ChannelOne,
     },
     [BapFct_TELEPHONY_FUNCTION_LIST_Idx] = {
          .flags = {0},
          .u16BclTxBufferByteOffset = 0,
          .eSelectedSegmentationChannel = BapSegType_ChannelTwo,
     },
     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx] = {
          .flags = {0},
          .u16BclTxBufferByteOffset = 0,
          .eSelectedSegmentationChannel = BapSegType_ChannelOne,
     },
     [BapFct_TELEPHONY_FRAME_DATA_Idx] = {
          .flags = {0},
          .u16BclTxBufferByteOffset = 0,
          .eSelectedSegmentationChannel = BapSegType_ChannelOne,
     },

};

/* BAP BCL CanRxSegmentation table ******************************************/
BAP_RAM_DATA_FAR BapCanRxSegmentationRamRow_ot BAP_u16CanRxSegmentationTable[] = {

     /* AUDIO */

     [BapFct_AUDIO_FUNCTION_LIST_Idx] = {
          .flags                     = {0},
          .u16BclRxBufferByteOffset  =  0,
     },
     [BapFct_AUDIO_INFO_LIST_Idx] = {
          .flags                     = {0},
          .u16BclRxBufferByteOffset  =  0,
     },

     /* TELEPHONY */

     [BapFct_TELEPHONY_FUNCTION_LIST_Idx] = {
          .flags                     = {0},
          .u16BclRxBufferByteOffset  =  0,
     },
     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx] = {
          .flags                     = {0},
          .u16BclRxBufferByteOffset  =  0,
     },
     [BapFct_TELEPHONY_FRAME_DATA_Idx] = {
          .flags                     = {0},
          .u16BclRxBufferByteOffset  =  0,
     },

};

/* BCL CAN tables for dynamic channel allocation with segmentation ************/

#ifdef BAP_USES_SEGMENTATION
#define BAP_Uses_SegmentationTables(x) x

BAP_RAM_DATA_FAR BapCanTxDynSegChannels_ot BAP_CanTxSegmentationChannels[] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = {
          .arpoTxDynSegChannels = {NULL, NULL, NULL, NULL},
     },

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = {
          .arpoTxDynSegChannels = {NULL, NULL, NULL, NULL},
     },   

};

BAP_ROM_DATA_FAR const BapCanMsgId_t BAP_ROM_CONST BAP_CanTxMsgIdToSegChannelMappingTable[] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = BAP_AUDIO_ID,

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = BAP_Telefon_04_ID,

};

BAP_RAM_DATA_FAR BapCanRxDynSegChannels_ot  BAP_CanRxSegmentationChannels[] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = {
          .arpoRxDynSegChannels = {NULL, NULL, NULL, NULL},
     },

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = {
          .arpoRxDynSegChannels = {NULL, NULL, NULL, NULL},
     }

};

BAP_ROM_DATA_FAR const BapCanMsgId_t BAP_ROM_CONST BAP_CanRxMsgIdToSegChannelMappingTable[] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = BAP_ASG_07_ID,

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = BAP_ASG_07_ID,

};

#else
#define BAP_Uses_SegmentationTables(x)
#endif

/* CAN Tx ROM Table *********************************************************/
BAP_ROM_DATA_FAR BapCanTxRomRow_ot BAP_ROM_CONST BAP_CanTxRomTable[] = {

     /* AUDIO */

     [BapFct_AUDIO_GET_ALL_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_ChannelOne,
          .poCanTxRamRow         =   &BAP_u16CanTxSegmentationTable[BapFct_AUDIO_GET_ALL_Idx],
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_GET_ALL,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(&BAP_CanTxSegmentationChannels[BapLsg_AUDIO_Idx]),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_GET_ALL_Idx]),
     },
     [BapFct_AUDIO_BAP_CONFIG_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_BAP_CONFIG,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_BAP_CONFIG_Idx]),
     },
     [BapFct_AUDIO_FUNCTION_LIST_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_ChannelTwo,
          .poCanTxRamRow         =   &BAP_u16CanTxSegmentationTable[BapFct_AUDIO_FUNCTION_LIST_Idx],
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_FUNCTION_LIST,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(&BAP_CanTxSegmentationChannels[BapLsg_AUDIO_Idx]),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_FUNCTION_LIST_Idx]),
     },
     [BapFct_AUDIO_HEARTBEAT_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_HEARTBEAT,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_HEARTBEAT_Idx]),
     },
     [BapFct_AUDIO_FSG_SETUP_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_FSG_SETUP,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_FSG_SETUP_Idx]),
     },
     [BapFct_AUDIO_FSG_OPERATION_STATE_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_FSG_OPERATION_STATE,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_FSG_OPERATION_STATE_Idx]),
     },
     [BapFct_AUDIO_ACTIVE_SOURCE_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_ACTIVE_SOURCE,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_ACTIVE_SOURCE_Idx]),
     },
     [BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_ChannelTwo,
          .poCanTxRamRow         =   &BAP_u16CanTxSegmentationTable[BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx],
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_ACTIVE_SOURCE_NAME,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(&BAP_CanTxSegmentationChannels[BapLsg_AUDIO_Idx]),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx]),
     },
     [BapFct_AUDIO_CURRENT_VOLUME_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_CURRENT_VOLUME,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_CURRENT_VOLUME_Idx]),
     },
     [BapFct_AUDIO_MUTE_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_MUTE,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_MUTE_Idx]),
     },
     [BapFct_AUDIO_SOURCE_STATE_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_SOURCE_STATE,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_SOURCE_STATE_Idx]),
     },
     [BapFct_AUDIO_CURRENT_STATION_INFO_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_ChannelOne,
          .poCanTxRamRow         =   &BAP_u16CanTxSegmentationTable[BapFct_AUDIO_CURRENT_STATION_INFO_Idx],
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_CURRENT_STATION_INFO,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(&BAP_CanTxSegmentationChannels[BapLsg_AUDIO_Idx]),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_CURRENT_STATION_INFO_Idx]),
     },
     [BapFct_AUDIO_INFO_LIST_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_ChannelTwo,
          .poCanTxRamRow         =   &BAP_u16CanTxSegmentationTable[BapFct_AUDIO_INFO_LIST_Idx],
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_INFO_LIST,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(&BAP_CanTxSegmentationChannels[BapLsg_AUDIO_Idx]),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_INFO_LIST_Idx]),
     },
     [BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx]),
     },
     [BapFct_AUDIO_INFO_LIST_TYPE_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_AUDIO_INFO_LIST_TYPE,
          .u8InhibitIndex        =   BapLsg_AUDIO_Idx,
          .canMsgId              =   BAP_AUDIO_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_AUDIO_INFO_LIST_TYPE_Idx]),
     },

     /* TELEPHONY */

     [BapFct_TELEPHONY_GET_ALL_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_ChannelOne,
          .poCanTxRamRow         =   &BAP_u16CanTxSegmentationTable[BapFct_TELEPHONY_GET_ALL_Idx],
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_GET_ALL,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(&BAP_CanTxSegmentationChannels[BapLsg_TELEPHONY_Idx]),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_GET_ALL_Idx]),     
     },
     [BapFct_TELEPHONY_BAP_CONFIG_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_BAP_CONFIG,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_BAP_CONFIG_Idx]),
     },
     [BapFct_TELEPHONY_FUNCTION_LIST_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_ChannelTwo,
          .poCanTxRamRow         =   &BAP_u16CanTxSegmentationTable[BapFct_TELEPHONY_FUNCTION_LIST_Idx],
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_FUNCTION_LIST,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(&BAP_CanTxSegmentationChannels[BapLsg_TELEPHONY_Idx]),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_FUNCTION_LIST_Idx]),
     },
     [BapFct_TELEPHONY_HEARTBEAT_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_HEARTBEAT,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_HEARTBEAT_Idx]),
     },
     [BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_FSG_OPERATION_STATE,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx]),
     },
     [BapFct_TELEPHONY_ASG_CAPABILITIES_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_ASG_CAPABILITIES,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_ASG_CAPABILITIES_Idx]),
     },
     [BapFct_TELEPHONY_ASG_CONFIG_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_ASG_CONFIG,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_ASG_CONFIG_Idx]),
     },
     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_ChannelOne,
          .poCanTxRamRow         =   &BAP_u16CanTxSegmentationTable[BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx],
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(&BAP_CanTxSegmentationChannels[BapLsg_TELEPHONY_Idx]),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx]),
     },
     [BapFct_TELEPHONY_FRAME_STATUS_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_FRAME_STATUS,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_FRAME_STATUS_Idx]),
     },
     [BapFct_TELEPHONY_FRAME_DATA_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_ChannelOne,
          .poCanTxRamRow         =   &BAP_u16CanTxSegmentationTable[BapFct_TELEPHONY_FRAME_DATA_Idx],
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_FRAME_DATA,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(&BAP_CanTxSegmentationChannels[BapLsg_TELEPHONY_Idx]),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_FRAME_DATA_Idx]),
     },
     [BapFct_TELEPHONY_FRAME_DATA_ACK_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_FRAME_DATA_ACK,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_FRAME_DATA_ACK_Idx]),
     },
     [BapFct_TELEPHONY_SCROLLBAR_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_SCROLLBAR,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_SCROLLBAR_Idx]),
     },
     [BapFct_TELEPHONY_LSG_STATUS_Idx] = {
          .canInterfaceChannel   =   1,
          .eSegmentationType     =   BapSegType_Unsegmented,
          .poCanTxRamRow         =   (BapCanTxSegmentationRamRow_pot) NULL,
          .poBclTxRamRow         =   (BapBclTxRamRow_pot) &BCL_TxBuffer_TELEPHONY_LSG_STATUS,
          .u8InhibitIndex        =   BapLsg_TELEPHONY_Idx,
          .canMsgId              =   BAP_Telefon_04_ID,
          .poTxDynSegChannels    =   BAP_Uses_SegmentationTables(NULL),
          .poFctRomRow           =   (BapFctRomRow_pot) (&BAP_FctRomTables[BapFct_TELEPHONY_LSG_STATUS_Idx]),
     },
     
};

/* CAN Rx ROM Table *********************************************************/
BAP_ROM_DATA_FAR BapCanRxRomRow_ot BAP_ROM_CONST BAP_CanRxRomTable[] = {

     /* AUDIO */

     [BapFct_AUDIO_GET_ALL_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_GET_ALL_Id,
          .u16Size                =   0,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot) NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_BAP_CONFIG_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_BAP_CONFIG_Id,
          .u16Size                =   BAP_AUDIO_BAPCONFIG_RX_SIZE,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) &BCL_RxBuffer_AUDIO_BAP_CONFIG,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_FUNCTION_LIST_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_FUNCTION_LIST_Id,
          .u16Size                =   BAP_AUDIO_FUNCTION_LIST_RX_SIZE,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_ChannelOneTwoThreeFour,
          .u16IntertelegramTime   =   10,
          .poCanRxRamRow          =   &BAP_u16CanRxSegmentationTable[BapFct_AUDIO_FUNCTION_LIST_Idx],
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) &BCL_RxBuffer_AUDIO_FUNCTION_LIST,
          .pu16InterTelegramTimer =   &BAP_u16InterTelegramTimerTable[BapFct_AUDIO_FUNCTION_LIST_Idx],
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(&BAP_CanRxSegmentationChannels[BapLsg_AUDIO_Idx]),
     },
     [BapFct_AUDIO_HEARTBEAT_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_HEARTBEAT_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_FSG_SETUP_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_FSG_SETUP_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_FSG_OPERATION_STATE_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_FSG_OPERATION_STATE_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_ACTIVE_SOURCE_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_ACTIVE_SOURCE_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_ACTIVE_SOURCE_NAME_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_CURRENT_VOLUME_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_CURRENT_VOLUME_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_MUTE_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_MUTE_Id,
          .u16Size                =   BAP_AUDIO_MUTE_Opcode_Status_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)&BCL_RxBuffer_AUDIO_MUTE,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_SOURCE_STATE_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_SOURCE_STATE_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_CURRENT_STATION_INFO_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_CURRENT_STATION_INFO_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_INFO_LIST_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_INFO_LIST_Id,
          .u16Size                =   BAP_AUDIO_INFO_LIST_Opcode_GetArray_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_ChannelOneTwoThreeFour,
          .u16IntertelegramTime   =   20,
          .poCanRxRamRow          =   &BAP_u16CanRxSegmentationTable[BapFct_AUDIO_INFO_LIST_Idx],
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)&BCL_RxBuffer_AUDIO_INFO_LIST,
          .pu16InterTelegramTimer =   &BAP_u16InterTelegramTimerTable[BapFct_AUDIO_INFO_LIST_Idx],
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(&BAP_CanRxSegmentationChannels[BapLsg_AUDIO_Idx]),
     },
     [BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Id,
          .u16Size                =   BAP_AUDIO_DEDICATED_AUDIO_CONTROL_Opcode_StartResult_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)&BCL_RxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_AUDIO_INFO_LIST_TYPE_Idx] = {
          .lsgId                  =   BapLsg_AUDIO_Id,
          .fctId                  =   BapFct_AUDIO_INFO_LIST_TYPE_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },

     /* TELEPHONY */

     [BapFct_TELEPHONY_GET_ALL_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_GET_ALL_Id,
          .u16Size                =   0,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),          
     },
     [BapFct_TELEPHONY_BAP_CONFIG_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_BAP_CONFIG_Id,
          .u16Size                =   BAP_TELEPHONY_BAPCONFIG_RX_SIZE,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) &BCL_RxBuffer_TELEPHONY_BAP_CONFIG,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_TELEPHONY_FUNCTION_LIST_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_FUNCTION_LIST_Id,
          .u16Size                =   BAP_TELEPHONY_FUNCTION_LIST_RX_SIZE,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_ChannelOneTwoThreeFour,
          .u16IntertelegramTime   =   10,
          .poCanRxRamRow          =   &BAP_u16CanRxSegmentationTable[BapFct_TELEPHONY_FUNCTION_LIST_Idx],
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) &BCL_RxBuffer_TELEPHONY_FUNCTION_LIST,
          .pu16InterTelegramTimer =   &BAP_u16InterTelegramTimerTable[BapFct_TELEPHONY_FUNCTION_LIST_Idx],
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(&BAP_CanRxSegmentationChannels[BapLsg_TELEPHONY_Idx]),
     },
     [BapFct_TELEPHONY_HEARTBEAT_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_HEARTBEAT_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_FSG_OPERATION_STATE_Id,
          .u16Size                =   1,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_TELEPHONY_ASG_CAPABILITIES_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_ASG_CAPABILITIES_Id,
          .u16Size                =   BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_SetGet_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)&BCL_RxBuffer_TELEPHONY_ASG_CAPABILITIES,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_TELEPHONY_ASG_CONFIG_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_ASG_CONFIG_Id,
          .u16Size                =   BAP_TELEPHONY_ASG_CONFIG_Opcode_SetGet_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)&BCL_RxBuffer_TELEPHONY_ASG_CONFIG,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Id,
          .u16Size                =   BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_ChannelOneTwoThreeFour,
          .u16IntertelegramTime   =   10,
          .poCanRxRamRow          =   &BAP_u16CanRxSegmentationTable[BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx],
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) &BCL_RxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION,
          .pu16InterTelegramTimer =   &BAP_u16InterTelegramTimerTable[BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx],
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(&BAP_CanRxSegmentationChannels[BapLsg_AUDIO_Idx]),
     },
     [BapFct_TELEPHONY_FRAME_STATUS_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_FRAME_STATUS_Id,
          .u16Size                =   BAP_TELEPHONY_FRAME_STATUS_Opcode_SetGet_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)&BCL_RxBuffer_TELEPHONY_FRAME_STATUS,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_TELEPHONY_FRAME_DATA_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_FRAME_DATA_Id,
          .u16Size                =   BAP_TELEPHONY_FRAME_DATA_Opcode_GetArray_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_ChannelOneTwoThreeFour,
          .u16IntertelegramTime   =   10,
          .poCanRxRamRow          =   &BAP_u16CanRxSegmentationTable[BapFct_TELEPHONY_FRAME_DATA_Idx],
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)&BCL_RxBuffer_TELEPHONY_FRAME_DATA,
          .pu16InterTelegramTimer =   &BAP_u16InterTelegramTimerTable[BapFct_TELEPHONY_FRAME_DATA_Idx],
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(&BAP_CanRxSegmentationChannels[BapLsg_AUDIO_Idx]),
     },
     [BapFct_TELEPHONY_FRAME_DATA_ACK_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_FRAME_DATA_ACK_Id,
          .u16Size                =   BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Set_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)&BCL_RxBuffer_TELEPHONY_FRAME_DATA_ACK,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_TELEPHONY_SCROLLBAR_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_SCROLLBAR_Id,
          .u16Size                =   BAP_TELEPHONY_SCROLLBAR_Opcode_Get_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot) NULL,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },
     [BapFct_TELEPHONY_LSG_STATUS_Idx] = {
          .lsgId                  =   BapLsg_TELEPHONY_Id,
          .fctId                  =   BapFct_TELEPHONY_LSG_STATUS_Id,
          .u16Size                =   BAP_TELEPHONY_LSG_STATUS_Opcode_Set_Size,
          .canInterfaceChannel    =   1,
          .eSegmentationType      =   BapSegType_Unsegmented,
          .u16IntertelegramTime   =   0,
          .poCanRxRamRow          =   (BapCanRxSegmentationRamRow_pot)   NULL,
          .poBclRxRamRow          =   (BapBclRxRamRow_pot)&BCL_RxBuffer_TELEPHONY_LSG_STATUS,
          .pu16InterTelegramTimer =   NULL,
          .canMsgId               =   BAP_ASG_07_ID,
          .poRxDynSegChannels     =   BAP_Uses_SegmentationTables(NULL),
     },

};

/* CAN Rx Ringbuffer **********************************************************/
BAP_RAM_DATA_FAR
BapCanRxBuffer_ot BAP_CanRxRingBuffer[] = {
     {
          .canInterfaceChannel   = 0,
          .canMsgId              = 0,
          .aru8Data              = {0, 0, 0, 0, 0, 0, 0, 0},
          .u8Length              = 0,
     },
     {
          .canInterfaceChannel   = 0,
          .canMsgId              = 0,
          .aru8Data              = {0, 0, 0, 0, 0, 0, 0, 0},
          .u8Length              = 0,
     },
     {
          .canInterfaceChannel   = 0,
          .canMsgId              = 0,
          .aru8Data              = {0, 0, 0, 0, 0, 0, 0, 0},
          .u8Length              = 0,
     },
};

BAP_RAM_DATA_FAR
uint8_t BAP_u8CanRxRingBufferReadOffset = 0;
BAP_RAM_DATA_FAR
volatile uint8_t BAP_u8CanRxRingBufferWriteOffset = 0;


#ifdef BAP_USES_STATUS_ALL
#define BAP_Uses_Status_All(x) x
#else
#define BAP_Uses_Status_All(x)
#endif

/* BCL bus indirection Rx table*********************************************/
BAP_ROM_DATA_FAR BapBusIndirectionTxRomRow_ot BAP_ROM_CONST BAP_BusIndTxTable[] = {

     /* AUDIO */

     [BapFct_AUDIO_GET_ALL_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_GET_ALL_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_GET_ALL,
          .u16BufferSize                = SIZE_OF_BAP_AUDIO_GETALL_RESPONSE_BUFFER,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_TRUE),
     },

     [BapFct_AUDIO_BAP_CONFIG_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_BAP_CONFIG_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_BAP_CONFIG,
          .u16BufferSize                = BAP_AUDIO_BAPCONFIG_TX_SIZE,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_AUDIO_FUNCTION_LIST_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_FUNCTION_LIST_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_FUNCTION_LIST,
          .u16BufferSize                = BAP_AUDIO_FUNCTION_LIST_TX_SIZE,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_TRUE),
     },
     [BapFct_AUDIO_HEARTBEAT_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_HEARTBEAT_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_HEARTBEAT,
          .u16BufferSize                = BAP_AUDIO_HEARTBEAT_TX_SIZE,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_AUDIO_FSG_SETUP_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_FSG_SETUP_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_FSG_SETUP,
          .u16BufferSize                = BAP_AUDIO_FSG_SETUP_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_AUDIO_FSG_OPERATION_STATE_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_FSG_OPERATION_STATE_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_FSG_OPERATION_STATE,
          .u16BufferSize                = BAP_AUDIO_FSG_OPERATION_STATE_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_AUDIO_ACTIVE_SOURCE_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_ACTIVE_SOURCE_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_ACTIVE_SOURCE,
          .u16BufferSize                = BAP_AUDIO_ACTIVE_SOURCE_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_ACTIVE_SOURCE_NAME,
          .u16BufferSize                = BAP_AUDIO_ACTIVE_SOURCE_NAME_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_TRUE),
     },
     [BapFct_AUDIO_CURRENT_VOLUME_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_CURRENT_VOLUME_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_CURRENT_VOLUME,
          .u16BufferSize                = BAP_AUDIO_CURRENT_VOLUME_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_AUDIO_MUTE_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_MUTE_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_MUTE,
          .u16BufferSize                = BAP_AUDIO_MUTE_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_AUDIO_SOURCE_STATE_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_SOURCE_STATE_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_SOURCE_STATE,
          .u16BufferSize                = BAP_AUDIO_SOURCE_STATE_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_AUDIO_CURRENT_STATION_INFO_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_CURRENT_STATION_INFO_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_CURRENT_STATION_INFO,
          .u16BufferSize                = BAP_AUDIO_CURRENT_STATION_INFO_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_TRUE),
     },
     [BapFct_AUDIO_INFO_LIST_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_INFO_LIST_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_INFO_LIST,
          .u16BufferSize                = BAP_AUDIO_INFO_LIST_Opcode_StatusArray_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_TRUE),
     },
     [BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL,
          .u16BufferSize                = BAP_AUDIO_DEDICATED_AUDIO_CONTROL_Opcode_Result_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_AUDIO_INFO_LIST_TYPE_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_AUDIO_INFO_LIST_TYPE_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_AUDIO_INFO_LIST_TYPE,
          .u16BufferSize                = BAP_AUDIO_INFO_LIST_TYPE_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },

     /* TELEPHONY */

     [BapFct_TELEPHONY_GET_ALL_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_GET_ALL_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_GET_ALL,
          .u16BufferSize                = SIZE_OF_BAP_TELEPHONY_GETALL_RESPONSE_BUFFER,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_TRUE),
     },
     [BapFct_TELEPHONY_BAP_CONFIG_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_BAP_CONFIG_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_BAP_CONFIG,
          .u16BufferSize                = BAP_TELEPHONY_BAPCONFIG_TX_SIZE,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_TELEPHONY_FUNCTION_LIST_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_FUNCTION_LIST_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_FUNCTION_LIST,
          .u16BufferSize                = BAP_TELEPHONY_FUNCTION_LIST_TX_SIZE,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_TRUE),
     },
     [BapFct_TELEPHONY_HEARTBEAT_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_HEARTBEAT_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_HEARTBEAT,
          .u16BufferSize                = BAP_AUDIO_HEARTBEAT_TX_SIZE,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_FSG_OPERATION_STATE,
          .u16BufferSize                = BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_TELEPHONY_ASG_CAPABILITIES_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_ASG_CAPABILITIES_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_ASG_CAPABILITIES,
          .u16BufferSize                = BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_TELEPHONY_ASG_CONFIG_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_ASG_CONFIG_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_ASG_CONFIG,
          .u16BufferSize                = BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION,
          .u16BufferSize                = BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_TRUE),
     },
     [BapFct_TELEPHONY_FRAME_STATUS_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_FRAME_STATUS_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_FRAME_STATUS,
          .u16BufferSize                = BAP_TELEPHONY_FRAME_STATUS_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_TELEPHONY_FRAME_DATA_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_FRAME_DATA_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_FRAME_DATA,
          .u16BufferSize                = BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_TRUE),
     },
     [BapFct_TELEPHONY_FRAME_DATA_ACK_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_FRAME_DATA_ACK_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_FRAME_DATA_ACK,
          .u16BufferSize                = BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_TELEPHONY_SCROLLBAR_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_SCROLLBAR_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_SCROLLBAR,
          .u16BufferSize                = BAP_TELEPHONY_SCROLLBAR_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },
     [BapFct_TELEPHONY_LSG_STATUS_Idx] = {
          .eInterfaceType               = BapIft_Can,
          .poCanTx                      = (BapCanTxRomRow_pot) &BAP_CanTxRomTable[BapFct_TELEPHONY_LSG_STATUS_Idx],
          .poBclTxRamRow                = (BapBclTxRamRow_pot)&BCL_TxBuffer_TELEPHONY_LSG_STATUS,
          .u16BufferSize                = BAP_TELEPHONY_LSG_STATUS_Opcode_Status_Size,
          .bDataTypeSupportsVarLength   = BAP_Uses_Status_All(BAP_FALSE),
     },

};

/* BCL bus indirection Rx table *********************************************/
BAP_ROM_DATA_FAR BapBusIndirectionRxRomRow_ot BAP_ROM_CONST BAP_BusIndRxTable[]={

     /* AUDIO */

     [BapFct_AUDIO_GET_ALL_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_GET_ALL_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_AUDIO_BAP_CONFIG_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_BAP_CONFIG_Idx],
          .poBclRxRamRow    =   (BapBclRxRamRow_pot) &BCL_RxBuffer_AUDIO_BAP_CONFIG,
     },
     [BapFct_AUDIO_FUNCTION_LIST_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_FUNCTION_LIST_Idx],
          .poBclRxRamRow    =   (BapBclRxRamRow_pot) &BCL_RxBuffer_AUDIO_FUNCTION_LIST,
     },
     [BapFct_AUDIO_HEARTBEAT_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_HEARTBEAT_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_AUDIO_FSG_SETUP_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_FSG_SETUP_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_AUDIO_FSG_OPERATION_STATE_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_FSG_OPERATION_STATE_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_AUDIO_ACTIVE_SOURCE_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_ACTIVE_SOURCE_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_AUDIO_CURRENT_VOLUME_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_CURRENT_VOLUME_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_AUDIO_MUTE_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_MUTE_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_AUDIO_MUTE,
     },
     [BapFct_AUDIO_SOURCE_STATE_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_SOURCE_STATE_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_AUDIO_CURRENT_STATION_INFO_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_CURRENT_STATION_INFO_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_AUDIO_INFO_LIST_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_INFO_LIST_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_AUDIO_INFO_LIST,
     },
     [BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_AUDIO_DEDICATED_AUDIO_CONTROL,
     },
     [BapFct_AUDIO_INFO_LIST_TYPE_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_AUDIO_INFO_LIST_TYPE_Idx],
          .poBclRxRamRow    =   NULL,
     },

     /* TELEPHONY */

     [BapFct_TELEPHONY_GET_ALL_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_GET_ALL_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_TELEPHONY_BAP_CONFIG_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_BAP_CONFIG_Idx],
          .poBclRxRamRow    =   (BapBclRxRamRow_pot) &BCL_RxBuffer_TELEPHONY_BAP_CONFIG,
     },
     [BapFct_TELEPHONY_FUNCTION_LIST_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_FUNCTION_LIST_Idx],
          .poBclRxRamRow    =   (BapBclRxRamRow_pot) &BCL_RxBuffer_TELEPHONY_FUNCTION_LIST,
     },
     [BapFct_TELEPHONY_HEARTBEAT_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_HEARTBEAT_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_TELEPHONY_ASG_CAPABILITIES_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_ASG_CAPABILITIES_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_TELEPHONY_ASG_CAPABILITIES,
     },
     [BapFct_TELEPHONY_ASG_CONFIG_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_ASG_CONFIG_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_TELEPHONY_ASG_CONFIG,
     },
     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_TELEPHONY_MFL_BLOCK_DEFINITION,
     },
     [BapFct_TELEPHONY_FRAME_STATUS_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_FRAME_STATUS_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_TELEPHONY_FRAME_STATUS,
     },
     [BapFct_TELEPHONY_FRAME_DATA_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_FRAME_DATA_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_TELEPHONY_FRAME_DATA,
     },
     [BapFct_TELEPHONY_FRAME_DATA_ACK_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_FRAME_DATA_ACK_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_TELEPHONY_FRAME_DATA_ACK,
     },
     [BapFct_TELEPHONY_SCROLLBAR_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_SCROLLBAR_Idx],
          .poBclRxRamRow    =   NULL,
     },
     [BapFct_TELEPHONY_LSG_STATUS_Idx] = {
          .eInterfaceType   =   BapIft_Can,
          .poCanRx          =   (BapCanRxRomRow_pot) &BAP_CanRxRomTable[BapFct_TELEPHONY_LSG_STATUS_Idx],
          .poBclRxRamRow    =   &BCL_RxBuffer_TELEPHONY_LSG_STATUS,
     },

};

/* MapCanIdToLsgRomRow Table ********************************************************/

BAP_ROM_DATA_FAR BapMapCanIdToLsg_ot BAP_ROM_CONST BAP_MapCanIdToLsgRomRowTable[] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = {
          .poLsgRomRow              = &BAP_LsgRomTables[BapLsg_AUDIO_Idx],
          .aroMapCanIdByLsgTable    = &BAP_MapCanIdByLsgToCanTxRomRowTable[BapLsg_AUDIO_Fct_StartIdx],
          .u8MapCanIdByLsgSize      = BapLsg_AUDIO_FctSize,
     },

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = {
          .poLsgRomRow              = &BAP_LsgRomTables[BapLsg_TELEPHONY_Idx],
          .aroMapCanIdByLsgTable    = &BAP_MapCanIdByLsgToCanTxRomRowTable[BapLsg_TELEPHONY_Fct_StartIdx],
          .u8MapCanIdByLsgSize      = BapLsg_TELEPHONY_FctSize,          
     }

};

/* MapCanIdByLsgToCanTxRomRow Table ******************************************************/
BAP_ROM_DATA_FAR BapMapCanIdByLsg_ot BAP_ROM_CONST BAP_MapCanIdByLsgToCanTxRomRowTable[] = {

     /* AUDIO */

     [BapFct_AUDIO_GET_ALL_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_GET_ALL_Idx],
     },

     [BapFct_AUDIO_BAP_CONFIG_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_BAP_CONFIG_Idx],
     },

     [BapFct_AUDIO_FUNCTION_LIST_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_FUNCTION_LIST_Idx],
     },

     [BapFct_AUDIO_HEARTBEAT_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_HEARTBEAT_Idx],
     },

     [BapFct_AUDIO_FSG_SETUP_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_FSG_SETUP_Idx],
     },

     [BapFct_AUDIO_FSG_OPERATION_STATE_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_FSG_OPERATION_STATE_Idx],
     },

     [BapFct_AUDIO_ACTIVE_SOURCE_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_ACTIVE_SOURCE_Idx],
     },

     [BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx],
     },

     [BapFct_AUDIO_CURRENT_VOLUME_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_CURRENT_VOLUME_Idx],
     },

     [BapFct_AUDIO_MUTE_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_MUTE_Idx],
     },

     [BapFct_AUDIO_SOURCE_STATE_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_SOURCE_STATE_Idx],
     },

     [BapFct_AUDIO_CURRENT_STATION_INFO_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_CURRENT_STATION_INFO_Idx],
     },

     [BapFct_AUDIO_INFO_LIST_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_INFO_LIST_Idx],
     },

     [BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx],
     },

     [BapFct_AUDIO_INFO_LIST_TYPE_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_AUDIO_INFO_LIST_TYPE_Idx],
     },

     /* TELEPHONY */

     [BapFct_TELEPHONY_GET_ALL_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_GET_ALL_Idx],
     },

     [BapFct_TELEPHONY_BAP_CONFIG_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_BAP_CONFIG_Idx],
     },

     [BapFct_TELEPHONY_FUNCTION_LIST_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_FUNCTION_LIST_Idx],
     },

     [BapFct_TELEPHONY_HEARTBEAT_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_HEARTBEAT_Idx],
     },

     [BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx],
     },

     [BapFct_TELEPHONY_ASG_CAPABILITIES_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_ASG_CAPABILITIES_Idx],
     },

     [BapFct_TELEPHONY_ASG_CONFIG_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_ASG_CONFIG_Idx],
     },

     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx],
     },

     [BapFct_TELEPHONY_FRAME_STATUS_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_FRAME_STATUS_Idx],
     },

     [BapFct_TELEPHONY_FRAME_DATA_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_FRAME_DATA_Idx],
     },

     [BapFct_TELEPHONY_FRAME_DATA_ACK_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_FRAME_DATA_ACK_Idx],
     },

     [BapFct_TELEPHONY_SCROLLBAR_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_SCROLLBAR_Idx],
     },
     [BapFct_TELEPHONY_LSG_STATUS_Idx] = {
          .poCanTxRomRow = &BAP_CanTxRomTable[BapFct_TELEPHONY_LSG_STATUS_Idx],
     },

};

/* Global BAP ROM table ****************************************************/
/* Contains the ROM configuration for all layers per function ID         **/
BAP_ROM_DATA_FAR BapFctRomRow_ot BAP_ROM_CONST BAP_FctRomTables[] = {

     /* AUDIO Functions */

     [BapFct_AUDIO_GET_ALL_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_GET_ALL_Id,
          .eFunctionClass             = BapFctCls_Cache,
          .u8OpCodeSendMask           = 0x10, /* Opcode: StatusAll = 4 (1 << 4) */
          .u8OpCodeReceiveMask        = 0x02, /* Opcode: GetAll = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_ByteSequence,
          .u16TxSize                  = SIZE_OF_BAP_AUDIO_GETALL_RESPONSE_BUFFER,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 0,
          .nMaxRetryCounter           = 0,
          .nMaxRetryOrProcessingTime  = 100,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_GET_ALL_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_GET_ALL_Idx,

     },
     [BapFct_AUDIO_BAP_CONFIG_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_BAP_CONFIG_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x19, /* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3), Reset = 0 (1 << 0)*/
          .u8OpCodeReceiveMask        = 0x02, /* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_FixedByteSequence,
          .u16RxSize                  = BAP_AUDIO_BAPCONFIG_RX_SIZE,
          .eTxDataType                = BapDt_FixedByteSequence,
          .u16TxSize                  = BAP_AUDIO_BAPCONFIG_TX_SIZE,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_BAP_CONFIG_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_BAP_CONFIG_Idx,

     },
     [BapFct_AUDIO_FUNCTION_LIST_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_FUNCTION_LIST_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_FixedByteSequence,
          .u16RxSize                  = BAP_AUDIO_FUNCTION_LIST_RX_SIZE,
          .eTxDataType                = BapDt_FixedByteSequence,
          .u16TxSize                  = BAP_AUDIO_FUNCTION_LIST_TX_SIZE,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_FUNCTION_LIST_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_FUNCTION_LIST_Idx,

     },
     [BapFct_AUDIO_HEARTBEAT_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_HEARTBEAT_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Int8,
          .u16RxSize                  = 1,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_AUDIO_HEARTBEAT_TX_SIZE,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_HEARTBEAT_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_HEARTBEAT_Idx,

     },
     [BapFct_AUDIO_FSG_SETUP_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_FSG_SETUP_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_AUDIO_FSG_SETUP_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_FSG_SETUP_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_FSG_SETUP_Idx,

     },
     [BapFct_AUDIO_FSG_OPERATION_STATE_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_FSG_OPERATION_STATE_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_AUDIO_FSG_OPERATION_STATE_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_FSG_OPERATION_STATE_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_FSG_OPERATION_STATE_Idx,

     },
     [BapFct_AUDIO_ACTIVE_SOURCE_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_ACTIVE_SOURCE_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_ByteSequence,
          .u16TxSize                  = BAP_AUDIO_ACTIVE_SOURCE_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_ACTIVE_SOURCE_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_ACTIVE_SOURCE_Idx,

     },
     [BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_ACTIVE_SOURCE_NAME_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_ByteSequence,
          .u16TxSize                  = BAP_AUDIO_ACTIVE_SOURCE_NAME_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_ACTIVE_SOURCE_NAME_Idx,

     },
     [BapFct_AUDIO_CURRENT_VOLUME_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_CURRENT_VOLUME_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_ByteSequence,
          .u16TxSize                  = BAP_AUDIO_CURRENT_VOLUME_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_CURRENT_VOLUME_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_CURRENT_VOLUME_Idx,

     },
     [BapFct_AUDIO_MUTE_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_MUTE_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x06,/* Opcode: Get = 1 (1 << 1) SetGet = 2 (1 << 2) */
          .eRxDataType                = BapDt_Int8,
          .u16RxSize                  = BAP_AUDIO_MUTE_Opcode_SetGet_Size,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_AUDIO_MUTE_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_MUTE_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_MUTE_Idx,

     },
     [BapFct_AUDIO_SOURCE_STATE_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_SOURCE_STATE_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_AUDIO_SOURCE_STATE_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_SOURCE_STATE_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_SOURCE_STATE_Idx,

     },
     [BapFct_AUDIO_CURRENT_STATION_INFO_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_CURRENT_STATION_INFO_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_ByteSequence,
          .u16TxSize                  = BAP_AUDIO_CURRENT_STATION_INFO_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_CURRENT_STATION_INFO_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_CURRENT_STATION_INFO_Idx,

     },
     [BapFct_AUDIO_INFO_LIST_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_INFO_LIST_Id,
          .eFunctionClass             = BapFctCls_Array,
          .u8OpCodeSendMask           = 0x18,/* Opcode: StatusArray = 4 (1 << 4), ArrayChanged = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: GetArray = 1 (1 << 1) */
          .eRxDataType                = BapDt_ByteSequence, /* GetArray -> ArrayHeader = 5 bytes */
          .u16RxSize                  = BAP_AUDIO_INFO_LIST_Opcode_GetArray_Size,
          .eTxDataType                = BapDt_ByteSequence,
          .u16TxSize                  = BAP_AUDIO_INFO_LIST_Opcode_StatusArray_Size, /* Revisar esto ultimo */
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 0,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_INFO_LIST_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_INFO_LIST_Idx,

     },
     [BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Id,
          .eFunctionClass             = BapFctCls_Method,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Processing = 3 (1 << 3), Result = 4 (1 << 4) */
          .u8OpCodeReceiveMask        = 0x0E,/* Opcode: CNF_Processing = 3 (1 << 3) StartResult = 2(1 << 2), Abort = (1 << 1)*/
          .eRxDataType                = BapDt_FixedByteSequence,
          .u16RxSize                  = BAP_AUDIO_DEDICATED_AUDIO_CONTROL_Opcode_StartResult_Size,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_AUDIO_DEDICATED_AUDIO_CONTROL_Opcode_Result_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 0,
          .nMaxRetryCounter           = 0,
          .nMaxRetryOrProcessingTime  = 10,
          .poBplRamRow                = &BAP_BplRamTable[BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx],
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Idx,

     },
     [BapFct_AUDIO_INFO_LIST_TYPE_Idx] = {

          .lsgId                      = BapLsg_AUDIO_Id,
          .fctId                      = BapFct_AUDIO_INFO_LIST_TYPE_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_AUDIO_INFO_LIST_TYPE_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_AUDIO_INFO_LIST_TYPE_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_AUDIO_INFO_LIST_TYPE_Idx,

     },

     /* Telephony Functions */

     [BapFct_TELEPHONY_GET_ALL_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_GET_ALL_Id,
          .eFunctionClass             = BapFctCls_Cache,
          .u8OpCodeSendMask           = 0x10, /* Opcode: StatusAll = 4 (1 << 4) */
          .u8OpCodeReceiveMask        = 0x02, /* Opcode: GetAll = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_ByteSequence,
          .u16TxSize                  = SIZE_OF_BAP_TELEPHONY_GETALL_RESPONSE_BUFFER,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 0,
          .nMaxRetryCounter           = 0,
          .nMaxRetryOrProcessingTime  = 100,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_GET_ALL_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_GET_ALL_Idx,    

     },
     [BapFct_TELEPHONY_BAP_CONFIG_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_BAP_CONFIG_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x19, /* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3), Reset = 0 (1 << 0)*/
          .u8OpCodeReceiveMask        = 0x02, /* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_FixedByteSequence,
          .u16RxSize                  = BAP_TELEPHONY_BAPCONFIG_RX_SIZE,
          .eTxDataType                = BapDt_FixedByteSequence,
          .u16TxSize                  = BAP_TELEPHONY_BAPCONFIG_TX_SIZE,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_BAP_CONFIG_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_BAP_CONFIG_Idx,   

     },
     [BapFct_TELEPHONY_FUNCTION_LIST_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_FUNCTION_LIST_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_FixedByteSequence,
          .u16RxSize                  = BAP_AUDIO_FUNCTION_LIST_RX_SIZE,
          .eTxDataType                = BapDt_FixedByteSequence,
          .u16TxSize                  = BAP_AUDIO_FUNCTION_LIST_TX_SIZE,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_FUNCTION_LIST_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_FUNCTION_LIST_Idx,

     },
     [BapFct_TELEPHONY_HEARTBEAT_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_HEARTBEAT_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Int8,
          .u16RxSize                  = 1,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_TELEPHONY_HEARTBEAT_TX_SIZE,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_HEARTBEAT_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_HEARTBEAT_Idx,

     },
     [BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_FSG_OPERATION_STATE_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 1 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = 0,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_FSG_OPERATION_STATE_Idx,

     },
     [BapFct_TELEPHONY_ASG_CAPABILITIES_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_ASG_CAPABILITIES_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x06,/* Opcode: Get = 1 (1 << 1) SetGet = 2 (1 << 2) */
          .eRxDataType                = BapDt_FixedByteSequence,
          .u16RxSize                  = BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_SetGet_Size,
          .eTxDataType                = BapDt_FixedByteSequence,
          .u16TxSize                  = BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_ASG_CAPABILITIES_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_ASG_CAPABILITIES_Idx,

     },
     [BapFct_TELEPHONY_ASG_CONFIG_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_ASG_CONFIG_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x06,/* Opcode: Get = 1 (1 << 1) SetGet = 2 (1 << 2) */
          .eRxDataType                = BapDt_FixedByteSequence,
          .u16RxSize                  = BAP_TELEPHONY_ASG_CONFIG_Opcode_SetGet_Size,
          .eTxDataType                = BapDt_FixedByteSequence,
          .u16TxSize                  = BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_ASG_CONFIG_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_ASG_CONFIG_Idx,

     },
     [BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x06,/* Opcode: Get = 1 (1 << 1) SetGet = 2 (1 << 2) */
          .eRxDataType                = BapDt_FixedByteSequence,
          .u16RxSize                  = BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Size,
          .eTxDataType                = BapDt_FixedByteSequence,
          .u16TxSize                  = BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Idx,

     },
     [BapFct_TELEPHONY_FRAME_STATUS_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_FRAME_STATUS_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x06,/* Opcode: Get = 1 (1 << 1) SetGet = 2 (1 << 2) */
          .eRxDataType                = BapDt_FixedByteSequence,
          .u16RxSize                  = BAP_TELEPHONY_FRAME_STATUS_Opcode_SetGet_Size,
          .eTxDataType                = BapDt_FixedByteSequence,
          .u16TxSize                  = BAP_TELEPHONY_FRAME_STATUS_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_FRAME_STATUS_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_FRAME_STATUS_Idx,

     },
     [BapFct_TELEPHONY_FRAME_DATA_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_FRAME_DATA_Id,
          .eFunctionClass             = BapFctCls_Array,
          .u8OpCodeSendMask           = 0x10,/* Opcode: StatusArray = 4 (1 << 4) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: GetArray = 1 (1 << 1) */
          .eRxDataType                = BapDt_ByteSequence, /* GetArray -> ArrayHeader = 5 bytes */
          .u16RxSize                  = BAP_TELEPHONY_FRAME_DATA_Opcode_GetArray_Size,
          .eTxDataType                = BapDt_ByteSequence,
          .u16TxSize                  = BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Size, /* Revisar esto ultimo */
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 0,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_FRAME_DATA_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_FRAME_DATA_Idx,

     },
     [BapFct_TELEPHONY_FRAME_DATA_ACK_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_FRAME_DATA_ACK_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x01,/* Opcode: Set = 1 (1 << 0) */
          .eRxDataType                = BapDt_Int8,
          .u16RxSize                  = BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Set_Size,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_FRAME_DATA_ACK_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_FRAME_DATA_ACK_Idx,

     },
     [BapFct_TELEPHONY_SCROLLBAR_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_SCROLLBAR_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x02,/* Opcode: Get = 2 (1 << 1) */
          .eRxDataType                = BapDt_Void,
          .u16RxSize                  = BAP_TELEPHONY_SCROLLBAR_Opcode_Get_Size,
          .eTxDataType                = BapDt_FixedByteSequence,
          .u16TxSize                  = BAP_TELEPHONY_SCROLLBAR_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_SCROLLBAR_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_SCROLLBAR_Idx,

     },
     [BapFct_TELEPHONY_LSG_STATUS_Idx] = {

          .lsgId                      = BapLsg_TELEPHONY_Id,
          .fctId                      = BapFct_TELEPHONY_LSG_STATUS_Id,
          .eFunctionClass             = BapFctCls_Property,
          .u8OpCodeSendMask           = 0x18,/* Opcode: Status = 4 (1 << 4), HeatbeatStatus = 3 (1 << 3) */
          .u8OpCodeReceiveMask        = 0x01,/* Opcode: Set = 1 (1 << 0) */
          .eRxDataType                = BapDt_Int8,
          .u16RxSize                  = BAP_TELEPHONY_LSG_STATUS_Opcode_Set_Size,
          .eTxDataType                = BapDt_Int8,
          .u16TxSize                  = BAP_TELEPHONY_LSG_STATUS_Opcode_Status_Size,
          .poBalRamRow                = NULL,
          .bHeartbeatOn               = 1,
          .nMaxRetryCounter           = 4,
          .nMaxRetryOrProcessingTime  = 30,
          .poBplRamRow                = NULL,
          .u8TxTableSize              = 1,
          .u16BusTxTableIndex         = BapFct_TELEPHONY_LSG_STATUS_Idx,
          .u8RxTableSize              = 1,
          .u16BusRxTableIndex         = BapFct_TELEPHONY_LSG_STATUS_Idx,

     },

};

/*  BAP configuration table ************************************************/
BAP_ROM_DATA_FAR const uint8_t BAP_ROM_CONST BAP_BAPConfigTable[][BAP_FCTID_BAPCONFIG_SIZE] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = {

          [BAPConfig_PV_Major] = 3,
          [BAPConfig_PV_Minor] = 0,
          [BAPConfig_SG_Major] = BapLsg_AUDIO_Id,
          [BAPConfig_SG_Minor] = 0,
          [BAPConfig_DF_Major] = 3,
          [BAPConfig_DF_Minor] = 1,

     },

     /* TELEPHONY */

     [BapLsg_TELEPHONY_Idx] = {

          [BAPConfig_PV_Major] = 3,
          [BAPConfig_PV_Minor] = 0,
          [BAPConfig_SG_Major] = BapLsg_TELEPHONY_Id,
          [BAPConfig_SG_Minor] = 0,
          [BAPConfig_DF_Major] = 3,
          [BAPConfig_DF_Minor] = 1,       

     }

};

/* Global BAP ROM table ****************************************************/
BAP_ROM_DATA_FAR BapLsgRomRow_ot BAP_ROM_CONST BAP_LsgRomTables[] = {

     /* AUDIO */

     [BapLsg_AUDIO_Idx] = {

          .lsgId                  = BapLsg_AUDIO_Id,
          .u8BAPConfigTableSize   = 1,
          .u8BAPConfigTableIndex  = BapLsg_AUDIO_Idx,
          .BAP_aru8FunctionList   = {0x38,0x03,0xFF,0x04,0x00,0x00,0x00,0x00},
          .pu16HeartbeatTimer     = &BAP_BplHeartbeatTimerTable[BapLsg_AUDIO_Idx],
          .u8TaskTimeMs           = 10,
          .u8Heartbeat            = 10,
          .u8FctRomTableSize      = BapLsg_AUDIO_FctSize,
          .u16FctRomIndex         = BapLsg_AUDIO_Fct_StartIdx,
          .u16CanRxRomTableSize   = BapLsg_AUDIO_FctSize,
          .u16CanRxRomTableIndex  = BapLsg_AUDIO_Fct_StartIdx,
          .bUseDLC8               = BAP_FALSE,
          .poLsgRamRow            = &BAP_LsgRamTable[BapLsg_AUDIO_Idx],
          .u16CanTxRomTableSize   = BapLsg_AUDIO_FctSize,
          .u16CanTxRomTableIndex  = BapLsg_AUDIO_Fct_StartIdx,
     #if defined(BAP_ASG) && defined(BAP_FSG)
          .eSGType                = BapSG_FSG,
     #endif

     },

     /* TELEPHONY*/

     [BapLsg_TELEPHONY_Idx] = {

          .lsgId                  = BapLsg_TELEPHONY_Id,
          .u8BAPConfigTableSize   = 1,
          .u8BAPConfigTableIndex  = BapLsg_TELEPHONY_Idx,
          .BAP_aru8FunctionList   = {0x78,0x01,0xFF,0x00,0x00,0x00,0x00,0x00},    
          .pu16HeartbeatTimer     = &BAP_BplHeartbeatTimerTable[BapLsg_TELEPHONY_Idx],
          .u8TaskTimeMs           = 10,
          .u8Heartbeat            = 10,
          .u8FctRomTableSize      = BapLsg_TELEPHONY_FctSize,
          .u16FctRomIndex         = BapLsg_TELEPHONY_Fct_StartIdx,
          .u16CanRxRomTableSize   = BapLsg_TELEPHONY_FctSize,
          .u16CanRxRomTableIndex  = BapLsg_TELEPHONY_Fct_StartIdx,
          .bUseDLC8               = BAP_FALSE,
          .poLsgRamRow            = &BAP_LsgRamTable[BapLsg_TELEPHONY_Idx],
          .u16CanTxRomTableSize   = BapLsg_TELEPHONY_FctSize,
          .u16CanTxRomTableIndex  = BapLsg_TELEPHONY_Fct_StartIdx,
     #if defined(BAP_ASG) && defined(BAP_FSG)
          .eSGType                = BapSG_FSG,
     #endif

     },
};

/* BAP table with pointer to the current solution (because of Multiconfig) ************/
BAP_RAM_DATA_FAR BapLsgRomRow_pot BAP_pLsgRomTable[] = {
     &BAP_LsgRomTables[BapLsg_AUDIO_Idx],
     &BAP_LsgRomTables[BapLsg_TELEPHONY_Idx],
};


/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/


