/*===========================================================================*/
/**
 * @file bap_audio_appl.c
 *
 * BAP FSG Application for AUDIO
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2022 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <bap_audio_appl.h>
#include <bap_audio_utils.h>
#include <project_def.h>
#include <console.h>
#include <bit_utils.h>
#include <shadow_storage.h>
#include <aswc.h>

#include <bap.h>
#include <bap_appl.h>
#include <bap_defines.h>
#include <bap_types.h>
#include <xdc/runtime/Error.h>
#include <string.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <bap_config.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/**
 * Duration in 10ms of the method
 * Usually a method calculates something
 * Here the following value is simply counted down
 */
#define METHOD_LENGTH   1

/* Struct used to hold OpCode information */
typedef struct FctMessage_t
{
    Type_T          opType;
    uint16_t        opSize;
    uint8_t*        opPrms;
}FctMessage_T;

/* Struct used to handle property function data */
typedef struct BapLsg_AUDIO_FctProperty_Handle_t
{
    fctId_t                     fctId;
    FctMessage_T*               fctMsgs;
}AUDIO_FctProperty_Handle_t;

/* Enum defining states for method function */
typedef enum
{
    METHOD_NO_REQUEST,
    METHOD_PROCESSING_CNF_REQUEST,
    METHOD_ABORT_REQUEST
}MethodState_t;

/* Function pointer to OpCode callback */
typedef void (*BAP_AUDIO_Opcode_CbkPtr)(uint8_t *, uint16_t);

/* Struct used to handle property function data */
typedef struct BapLsg_AUDIO_FctMethod_Handle_t
{
    fctId_t                         fctId;
    uint8_t                         processingCntr;
    MethodState_t                   methodState;
    BAP_AUDIO_Opcode_CbkPtr*        fctCbks;
    FctMessage_T*                   fctMsgs;
}AUDIO_FctMethod_Handle_t;

#define MAX_REQ_INDEX   4

/* Struct used to handle array function data */
typedef struct BapLsg_AUDIO_FctArray_Handle_t
{
    fctId_t                         fctId;
    uint8_t                         getArrayRequested;
    uint8_t                         reqIndexIdx;
    uint8_t                         reqIndex[MAX_REQ_INDEX+1];
    BAP_AUDIO_Opcode_CbkPtr*        fctCbks;
    FctMessage_T*                   fctMsgs;
}AUDIO_FctArray_Handle_t;

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*
 *
 * Declaration of parameters of a specific opcode
 *
 * To be used by:
 *
 * - DECLARE_FCT_PARAMS
 *
 */
#define DECLARE_OPCODE_PARAMS(FCT, OPTYPE, TYPE,SIZE, PARAMETER)    static PARAMETER BAP_##FCT##_##OPTYPE##_Data = (PARAMETER){0};

/*
 *
 * Declaration of parameters of all opcodes supported by function
 *
 * To be used by:
 *
 * - BAP_AUDIO_SPECIFIC_PROPERTY_TABLE
 * - BAP_AUDIO_METHOD_TABLE
 * - BAP_AUDIO_ARRAY_TABLE
 *
 */
#define DECLARE_FCT_PARAMS(LSG,FCT,CLS,ID, OPCODES) OPCODES(DECLARE_OPCODE_PARAMS)

/*
 *
 * Declaration of callback for a specific opcode
 *
 * To be used by:
 *
 * - DECLARE_FCT_CALLBACKS
 *
 */
#define DECLARE_OPCODE_CALLBACKS(FCT, OPTYPE, TYPE, SIZE, PARAMETER) static void BAP_##FCT##_##OPTYPE##_Cbk(uint8_t *, uint16_t);

/*
 *
 * Declaration of callbacks for all opcodes supported by a given function
 *
 * To be used by:
 *
 * - BAP_AUDIO_METHOD_TABLE
 * - BAP_AUDIO_ARRAY_TABLE
 *
 */
#define DECLARE_FCT_CALLBACKS(LSG,FCT,CLS,ID,OPCODES) OPCODES(DECLARE_OPCODE_CALLBACKS)

/*
 *
 * Declaration of element in function pointer array. This function pointer array element
 * points to a correspondent opcode callback
 *
 * To be used by:
 *
 * - DEFINE_OPCODE_CBK_VECTOR
 *
 */
#define DEFINE_OPCODE_CBK_ELEMENT(FCT, OPTYPE, TYPE, SIZE, PARAMETER)  [OPTYPE] =                                   \
                                                                    {                                               \
                                                                        &BAP_##FCT##_##OPTYPE##_Cbk                 \
                                                                    },                                              \

/*
 *
 * Declaration of function pointer array of function. This array contains callbacks
 * for all opcodes supported by function
 *
 * To be used by:
 *
 * - BAP_AUDIO_METHOD_TABLE
 * - BAP_AUDIO_ARRAY_TABLE
 *
 */
#define DEFINE_OPCODE_CBK_VECTOR(LSG,FCT,CLS,ID,OPCODES)    static BAP_AUDIO_Opcode_CbkPtr BAP_##LSG##_##FCT##_Cbks[] =     \
                                                            {                                                               \
                                                                 OPCODES(DEFINE_OPCODE_CBK_ELEMENT)                         \
                                                            };

/*
 *
 * Declaration of element in msg array. This elemnt has data for a given opcode
 *
 * To be used by:
 *
 * - DEFINE_FCT_VECTOR
 *
 */
#define DEFINE_OPCODE_ELEMENT(FCT, OPTYPE, TYPE, SIZE, PARAMETER)   [OPTYPE] =                                      \
                                                                    {                                               \
                                                                        TYPE,                                       \
                                                                        SIZE,                                       \
                                                                        (uint8_t *) &BAP_##FCT##_##OPTYPE##_Data    \
                                                                    },                                              \

/*
 *
 * Declaration of msg array of function. Each element of this array
 * contains data about supportes opcodes
 *
 * To be used by:
 *
 * - BAP_AUDIO_SPECIFIC_PROPERTY_TABLE
 * - BAP_AUDIO_METHOD_TABLE
 * - BAP_AUDIO_ARRAY_TABLE
 *
 */
#define DEFINE_FCT_VECTOR(LSG,FCT,CLS,ID,OPCODES)  static FctMessage_T BAP_##LSG##_##FCT##_Msgs[] =         \
                                                   {                                                        \
                                                        OPCODES(DEFINE_OPCODE_ELEMENT)                      \
                                                   };                                                       \



/*
 *
 * Declaration of array containing data of property functions
 *
 * To be used by:
 *
 * - BAP_AUDIO_SPECIFIC_PROPERTY_TABLE
 *
 */
#define DEFINE_PROPERTY_HANDLE_ELEMENT(LSG,FCT,CLS,ID,OPCODES)  [BAP_##LSG##_Property_##FCT##_Idx] =        \
                                                                {                                           \
                                                                    BapFct_##LSG##_##FCT##_Id,              \
                                                                    &(BAP_##LSG##_##FCT##_Msgs[0]),         \
                                                                },                                          \

/*
 *
 * Declaration of array containing data of property functions
 *
 * To be used by:
 *
 * - BAP_AUDIO_METHOD_TABLE
 *
 */
#define DEFINE_METHOD_HANDLE_ELEMENT(LSG,FCT,CLS,ID,OPCODES)    [BAP_##LSG##_Method_##FCT##_Idx] =          \
                                                                {                                           \
                                                                    BapFct_##LSG##_##FCT##_Id,              \
                                                                    0,                                      \
                                                                    METHOD_NO_REQUEST,                      \
                                                                    &(BAP_##LSG##_##FCT##_Cbks[0]),         \
                                                                    &(BAP_##LSG##_##FCT##_Msgs[0]),         \
                                                                },

/*
 *
 * Declaration of array containing data of array functions
 *
 * To be used by:
 *
 * - BAP_AUDIO_ARRAY_TABLE
 *
 */
#define DEFINE_ARRAY_HANDLE_ELEMENT(LSG,FCT,CLS,ID,OPCODES)     [BAP_##LSG##_Array_##FCT##_Idx] =           \
                                                                {                                           \
                                                                    BapFct_##LSG##_##FCT##_Id,              \
                                                                    0,                                      \
                                                                    0,                                      \
                                                                    {0},                                    \
                                                                    &(BAP_##LSG##_##FCT##_Cbks[0]),         \
                                                                    &(BAP_##LSG##_##FCT##_Msgs[0]),         \
                                                                },


///////////////

/* Declare objects related to property functions */

BAP_AUDIO_SPECIFIC_PROPERTY_TABLE(DECLARE_FCT_PARAMS)

BAP_AUDIO_SPECIFIC_PROPERTY_TABLE(DEFINE_FCT_VECTOR)

static AUDIO_FctProperty_Handle_t audioFctPropertyData[BAP_AUDIO_Property_NumFcts] = {
  BAP_AUDIO_SPECIFIC_PROPERTY_TABLE(DEFINE_PROPERTY_HANDLE_ELEMENT)
};

/* Declare objects related to method function */

BAP_AUDIO_METHOD_TABLE(DECLARE_FCT_PARAMS)

BAP_AUDIO_METHOD_TABLE(DECLARE_FCT_CALLBACKS)

BAP_AUDIO_METHOD_TABLE(DEFINE_FCT_VECTOR)

BAP_AUDIO_METHOD_TABLE(DEFINE_OPCODE_CBK_VECTOR)

static AUDIO_FctMethod_Handle_t audioFctMethodData[BAP_AUDIO_Method_NumFcts] = {
  BAP_AUDIO_METHOD_TABLE(DEFINE_METHOD_HANDLE_ELEMENT)
};

/* Declare objects related to array functions */

BAP_AUDIO_ARRAY_TABLE(DECLARE_FCT_PARAMS)

BAP_AUDIO_ARRAY_TABLE(DECLARE_FCT_CALLBACKS)

BAP_AUDIO_ARRAY_TABLE(DEFINE_FCT_VECTOR)

BAP_AUDIO_ARRAY_TABLE(DEFINE_OPCODE_CBK_VECTOR)

static AUDIO_FctArray_Handle_t audioFctArrayData[BAP_AUDIO_Array_NumFcts] = {
  BAP_AUDIO_ARRAY_TABLE(DEFINE_ARRAY_HANDLE_ELEMENT)
};

/* 64 bit field used to flag pending status request of property functions */
static uint64_t statusFlags = 0;

/* 64 bit field used to flag pending requests of method functions */
static uint64_t processingFlags = 0;

/* 64 bit field used to flag pending statusArray request of array functions */
static uint64_t statusArrayFlags = 0;

/* 64 bit field used to flag pending changedArray request of array functions */
static uint64_t changedArrayFlags = 0;

/* Mask used to set and clear flags
 * This is used because the bit fields are of
 * 64 bit. So, doing, for example:
 *
 * statusFlags = 0
 * statusFlags |= 1 << 40;
 *
 * (1 << 40)will be interpreted like 0
 *
 */
static uint64_t mask = 1;

/* Preset list */
static uint32_t  garu32PresetList[NUM_MAX_PRESETS] = {0};

/* Current number of presets available in the preset list */
static uint16_t gu16CurrentNumPresets = 0;

/* Global semaphore for locking and unlocking access to preset list */
static Semaphore_Handle presetListSem = NULL;

/* Global flag for locking and unlocking array content sending */
static bool_t gbLockArrayData = BAP_FALSE;

/* Global flag for locking and unlocking array content change */
static bool_t gbLockArrayChanged = BAP_FALSE;


/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/* Function-like macros to access data from property function */

/* Obtain function-Id of property function */
#define bap_audio_appl_getFctId(fct)                 audioFctPropertyData[fct].fctId
/* Check if the property has a given Function-Id */
#define bap_audio_appl_isFctId(fct, fctId)           (bap_audio_appl_getFctId(fct) == fctId)
/* Get Opcode data type from a given property function */
#define bap_audio_appl_getOpType(fct, opcode)        ((audioFctPropertyData[fct].fctMsgs)[opcode]).opType
/* Get Opcode data size from a given property function */
#define bap_audio_appl_getOpSize(fct, opcode)        ((audioFctPropertyData[fct].fctMsgs)[opcode]).opSize
/* Get Opcode parameters from a given property function */
#define bap_audio_appl_getParams(fct, opcode)        ((audioFctPropertyData[fct].fctMsgs)[opcode]).opPrms
/* Get pending status requests for property function */
#define bap_audio_appl_getPendingStatusFlags()       (statusFlags)
/* Check if there are pending status requests for property function */
#define bap_audio_appl_isPendingStatusFlags()        (bap_audio_appl_getPendingStatusFlags() != 0)
/* Get idx of first property that has a pending status request */
#define bap_audio_appl_getNextStatusFlag()           (BitUtils_CountTrailingZeros64(bap_audio_appl_getPendingStatusFlags()))
/* Query status request for property function */
#define bap_audio_appl_setStatusFlag(idx)            {                          \
                                                        mask    = 1;            \
                                                        mask  <<= idx;          \
                                                        statusFlags |= mask;    \
                                                     }
/* Clear pending status request for property function */
#define bap_audio_appl_clrStatusFlag(idx)            {                          \
                                                        mask    = 1;            \
                                                        mask  <<= idx;          \
                                                        statusFlags &= ~mask;   \
                                                     }

/* Function-like macros to access data from method function */

/* Obtain function-Id of method function */
#define bap_audio_appl_method_getFctId(fct)                         audioFctMethodData[fct].fctId
/* Check if the method has a given Function-Id */
#define bap_audio_appl_method_isFctId(fct, fctId)                   (bap_audio_appl_method_getFctId(fct) == fctId)
/* Get state of method function */
#define bap_audio_appl_method_getState(fct)                         (audioFctMethodData[fct].methodState)
/* Set state to method function */
#define bap_audio_appl_method_setState(fct, x)                      (audioFctMethodData[fct].methodState = x)
/* Get current value of processing counter of method function */
#define bap_audio_appl_method_getCntr(fct)                          (audioFctMethodData[fct].processingCntr)
/* Decrease processing counter of method function */
#define bap_audio_appl_method_useCntr(fct)                          (audioFctMethodData[fct].processingCntr--)
/* Decrease processing counter of method function */
#define bap_audio_appl_method_isCntr(fct)                           (bap_audio_appl_method_getCntr(fct) != 0)
/* Set processing counter of method function */
#define bap_audio_appl_method_setCntr(fct, x)                       (audioFctMethodData[fct].processingCntr = x)
/* Invoke Opcode callback from a given method function */
#define bap_audio_appl_method_getOpCbk(fct, opcode, data, length)   (audioFctMethodData[fct].fctCbks[opcode])(data,length);
/* Get Opcode data type from a given method function */
#define bap_audio_appl_method_getOpType(fct, opcode)                ((audioFctMethodData[fct].fctMsgs)[opcode]).opType
/* Get Opcode data size from a given method function */
#define bap_audio_appl_method_getOpSize(fct, opcode)                ((audioFctMethodData[fct].fctMsgs)[opcode]).opSize
/* Get Opcode parameters from a given method function */
#define bap_audio_appl_method_getParams(fct, opcode)                ((audioFctMethodData[fct].fctMsgs)[opcode]).opPrms
/* Get pending requests for method function */
#define bap_audio_appl_method_getPendingRequestFlags()              (processingFlags)
/* Get pending requests for method function */
#define bap_audio_appl_method_isPendingRequestFlags()               (bap_audio_appl_method_getPendingRequestFlags() != 0)
/* Get idx of first method that has a pending request */
#define bap_audio_appl_method_getNextRequestFlag()                  (BitUtils_CountTrailingZeros64(bap_audio_appl_method_getPendingRequestFlags()))
/* Query request for method function */
#define bap_audio_appl_method_setRequestFlag(idx)                   {                               \
                                                                        mask    = 1;                \
                                                                        mask  <<= idx;              \
                                                                        processingFlags |= mask;    \
                                                                    }
/* Clear pending request for method function */
#define bap_audio_appl_method_clrRequestFlag(idx)                   {                               \
                                                                        mask    = 1;                \
                                                                        mask  <<= idx;              \
                                                                        processingFlags &= ~mask;   \
                                                                    }

/* Function-like macros to access data from array function */

/* Obtain function-Id of array function */
#define bap_audio_appl_array_getFctId(fct)                          audioFctArrayData[fct].fctId
/* Check if the method has a given Function-Id */
#define bap_audio_appl_array_isFctId(fct, fctId)                    (bap_audio_appl_array_getFctId(fct) == fctId)
/* Invoke Opcode callback from a given array function */
#define bap_audio_appl_array_getOpCbk(fct, opcode, data, length)    (audioFctArrayData[fct].fctCbks[opcode])(data,length);
/* Get Opcode data type from a given array function */
#define bap_audio_appl_array_getOpType(fct, opcode)                 ((audioFctArrayData[fct].fctMsgs)[opcode]).opType
/* Get Opcode data size from a given array function */
#define bap_audio_appl_array_getOpSize(fct, opcode)                 ((audioFctArrayData[fct].fctMsgs)[opcode]).opSize
/* Get Opcode parameters from a given array function */
#define bap_audio_appl_array_getParams(fct, opcode)                 ((audioFctArrayData[fct].fctMsgs)[opcode]).opPrms

/* Get pending statusArray requests for array function */
#define bap_audio_appl_array_getPendingStatusArrayFlags()           (statusArrayFlags)
/* Get pending changedArray requests for array function */
#define bap_audio_appl_array_getPendingChangedArrayFlags()          (changedArrayFlags)
/* Is pending statusArray requests for array function */
#define bap_audio_appl_array_isPendingStatusArrayFlags()            (bap_audio_appl_array_getPendingStatusArrayFlags() != 0)
/* Is pending changedArray requests for array function */
#define bap_audio_appl_array_isPendingChangedArrayFlags()           (bap_audio_appl_array_getPendingChangedArrayFlags() != 0)

/* Get idx of first array that has a pending statusArray request */
#define bap_audio_appl_array_getNextStatusArrayFlag()               (BitUtils_CountTrailingZeros64(bap_audio_appl_array_getPendingStatusArrayFlags()))
/* Get idx of first array that has a pending changedArray request */
#define bap_audio_appl_array_getNextChangedArrayFlag()              (BitUtils_CountTrailingZeros64(bap_audio_appl_array_getPendingChangedArrayFlags()))

/* Query statusArray request for array function */
#define bap_audio_appl_array_setStatusArrayFlag(idx)                {                                       \
                                                                        mask    = 1;                        \
                                                                        mask  <<= idx;                      \
                                                                        statusArrayFlags |= mask;           \
                                                                    }
/* Query changedArray request for array function */
#define bap_audio_appl_array_setChangedArrayFlag(idx)               {                                       \
                                                                        mask    = 1;                        \
                                                                        mask  <<= idx;                      \
                                                                        changedArrayFlags |= mask;          \
                                                                    }

/* Clear pending statusArray request for array function */
#define bap_audio_appl_array_clrStatusArrayFlag(idx)                {                                       \
                                                                        mask    = 1;                        \
                                                                        mask  <<= idx;                      \
                                                                        statusArrayFlags &= ~mask;          \
                                                                    }
/* Clear pending changedArray request for array function */
#define bap_audio_appl_array_clrChangedArrayFlag(idx)               {                                       \
                                                                        mask    = 1;                        \
                                                                        mask  <<= idx;                      \
                                                                        changedArrayFlags &= ~mask;         \
                                                                    }


/* Obtain IdxSize parameter from ArrayHeader.Mode */
#define bap_audio_appl_arrayHeader_getIdxSize(header)   ((header->mode) & (INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_MASK)) >> INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_SHIFT
/* Obtain Unknown parameter from ArrayHeader.Mode */
#define bap_audio_appl_arrayHeader_getUnknownParam(header)  ((header->mode) & (INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_MASK)) >> INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_SHIFT
/* Obtain PosTransmit parameter from ArrayHeader.Mode */
#define bap_audio_appl_arrayHeader_getPosTransmit(header)   ((header->mode) & (INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_MASK)) >> INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_SHIFT
/* Obtain ArrayDirection parameter from ArrayHeader.Mode */
#define bap_audio_appl_arrayHeader_getArrayDir(header)   ((header->mode) & (INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_MASK)) >> INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_SHIFT
/* Obtain RecordAdress parameter from ArrayHeader.Mode */
#define bap_audio_appl_arrayHeader_getRecorAddress(header)   ((header->mode) & (INFOLIST_ARRAYHEADER_MODE_RECORDADRESS_MASK))

/* Init send routines for property function */
BapError_et BAP_AUDIO_Property_InitSend(AUDIO_Fct_Property_Idx_t idx);

/* Send routines for property functions */
BapError_et BAP_AUDIO_Property_Send(AUDIO_Fct_Property_Idx_t idx);

/* Send routine for method functions */
BapError_et BAP_AUDIO_Method_Send(AUDIO_Fct_Method_Idx_t idx, OpCode_T op);

/* Send routin for array functions */
BapError_et BAP_AUDIO_Array_Send(AUDIO_Fct_Array_Idx_t idx, OpCode_T op);

/* Custom function to serialize variable parameters for ByteSequence type Functions*/
void BAP_SerializeByteSequence(uint8_t idx, uint8_t *pVar, uint16_t * pLength, OpCode_T op);

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Sem_Init
 *
 * @brief      Initialize preset list semaphore
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Sem_Init(void)
{
    presetListSem = Semaphore_create(1, NULL, NULL);
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Task
 *
 * @brief      Cyclical AUDIO Task
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
BapError_et BAP_AUDIO_Task(void)
{
    BapError_et eErr = BapErr_OK;

    /* Property functions task */
    BAP_AUDIO_Property_Task();

    /* Array functions task */
    BAP_AUDIO_Array_Task();

    /* Method functions task */
    BAP_AUDIO_Method_Task();

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Property_Init
 *
 * @brief      Init value for all AUDIO Property Fcts
 *
 * @param [in] void
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_AUDIO_Property_Init(void)
{
    BapError_et eErr = BapErr_OK;
    AUDIO_Fct_Property_Idx_t fctPropertyIdx;

    for(fctPropertyIdx = BAP_AUDIO_Property_FSG_SETUP_Idx; fctPropertyIdx < BAP_AUDIO_Property_NumFcts;fctPropertyIdx++)
    {
        eErr = BAP_AUDIO_Property_InitSend(fctPropertyIdx);

        if(BapErr_OK != eErr)
        {
            return eErr;
        }
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Property_InitValues
 *
 * @brief      Init value for all AUDIO Property Fcts
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Property_InitValues(void)
{
    AUDIO_Fct_Property_Idx_t fctPropertyIdx;

    for(fctPropertyIdx = BAP_AUDIO_Property_FSG_SETUP_Idx; fctPropertyIdx < BAP_AUDIO_Property_NumFcts;fctPropertyIdx++)
    {
        BAP_AUDIO_Property_SetInitialValue(fctPropertyIdx);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Property_Task
 *
 * @brief      Periodical AUDIO task to process Property functions
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Property_Task(void)
{
    AUDIO_Fct_Property_Idx_t fctPropertyIdx;

    /* While there are pending status requests */
    while(bap_audio_appl_isPendingStatusFlags())
    {
        /* Get the first pending request */
        fctPropertyIdx = (AUDIO_Fct_Property_Idx_t)bap_audio_appl_getNextStatusFlag();

        LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_Property_Task > fctPropertyIdx = %x  \n",fctPropertyIdx);

        /* Process pending request */
        BAP_AUDIO_Property_Send(fctPropertyIdx);

        /* Clear pending request */
        bap_audio_appl_clrStatusFlag(fctPropertyIdx);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Array_Task
 *
 * @brief      Periodical AUDIO task to process Array functions
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Array_Task(void)
{
    AUDIO_Fct_Array_Idx_t fctArrayIdx;
    uint8_t statusArray = 0;
    uint8_t *changedArray;

    /* While there are pending statusArray requests */
    while(bap_audio_appl_array_isPendingStatusArrayFlags())
    {
        /* Get the first pending request */
        fctArrayIdx = (AUDIO_Fct_Array_Idx_t)bap_audio_appl_array_getNextStatusArrayFlag();

        LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_Array_Task > statusArray > fctArrayIdx = %x  \r\n",fctArrayIdx);

        if((gbLockArrayChanged == BAP_FALSE) && (gbLockArrayData == BAP_FALSE))
        {
            /* Lock array data */
            gbLockArrayData = BAP_TRUE;

            /* Call Opcode Cbk for StatusArray */
            BAP_AUDIO_Array_Opcode_Cbk(fctArrayIdx, Opcode_StatusArray,&statusArray,1);

            /* Send status array */
            BAP_AUDIO_Array_Send(fctArrayIdx, Opcode_StatusArray);
        }

        /* Clear pending request */
        bap_audio_appl_array_clrStatusArrayFlag(fctArrayIdx);
    }

    /* While there are pending changedArray requests */
    while(bap_audio_appl_array_isPendingChangedArrayFlags())
    {
        /* Get the first pending changedArray request */
        fctArrayIdx = (AUDIO_Fct_Array_Idx_t)bap_audio_appl_array_getNextChangedArrayFlag();

        LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_Array_Task > changedArray > fctArrayIdx = %x  \r\n",fctArrayIdx);

        if((gbLockArrayChanged == BAP_FALSE) && (gbLockArrayData == BAP_FALSE))
        {
            /* Lock array changed */
            gbLockArrayChanged = BAP_TRUE;

            /* Call Opcode Cbk for StatusArray */
            BAP_AUDIO_Array_Opcode_Cbk(fctArrayIdx, Opcode_ChangedArray,changedArray,5);

            /* Send changed array request for function */
            BAP_AUDIO_Array_Send(fctArrayIdx, Opcode_ChangedArray);
        }

        /* Clear pending changed array request */
        bap_audio_appl_array_clrChangedArrayFlag(fctArrayIdx);
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Property_Task
 *
 * @brief      Periodical AUDIO task to process Method functions
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Method_Task(void)
{
    AUDIO_Fct_Method_Idx_t fctMethodIdx;
    uint8_t controlResult = 0;
    static uint8_t selectedFrequencyDelayTimer = 0;
    uint16_t fsgHandle;
    char arrElementString[FREQUENCY_STRING_SIZE];


    /* While there are pending requests */
    if(bap_audio_appl_method_isPendingRequestFlags())
    {
        /* Get the first pending request */
        fctMethodIdx = (AUDIO_Fct_Method_Idx_t)bap_audio_appl_method_getNextRequestFlag();

        selectedFrequencyDelayTimer = 0;

        /* Analyze method state */
        switch(bap_audio_appl_method_getState(fctMethodIdx))
        {
            case METHOD_NO_REQUEST:

                /*
                 *
                 * There is nothing to be done in this state
                 *
                 * The task will pass to other state through indication from
                 * the BAP stack
                 *
                 */

                break;

            case METHOD_PROCESSING_CNF_REQUEST:

                /*
                 * The processing state will be indicated by the BAP stack
                 * until the result opcode request is sended
                 * */

                /* While the FSG is processing the method result */
                if(bap_audio_appl_method_isCntr(fctMethodIdx))
                {
                    /* Request the BAP stack to send a processing */
                    BAP_AUDIO_Method_Send(fctMethodIdx,Opcode_Processing);
                }
                else
                {
                    LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_Method_Task > Send Result Idx: %d  \n",fctMethodIdx);

                    BAP_AUDIO_Method_Opcode_Cbk(fctMethodIdx, Opcode_Result,&controlResult,1);

                    /* Method processing finished, send result */
                    BAP_AUDIO_Method_Send(fctMethodIdx,Opcode_Result);

                    selectedFrequencyDelayTimer = SELECTED_FREQUENCY_DELAY_TIME;

                    /* Clear pending request */
                    bap_audio_appl_method_clrRequestFlag(fctMethodIdx);
                
                }

                /* Set no request state */
                bap_audio_appl_method_setState(fctMethodIdx, METHOD_NO_REQUEST);

                break;

            case METHOD_ABORT_REQUEST:
                /* Method was aborted by the ASG, so send an error */

                /* Set no request state state */
                bap_audio_appl_method_setState(fctMethodIdx, METHOD_NO_REQUEST);

                break;
        }
    }

    if(selectedFrequencyDelayTimer > 0)
    {
        selectedFrequencyDelayTimer--;
        if(selectedFrequencyDelayTimer == 0)
        {
            fsgHandle = BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle;

            if(BAP_AUDIO_DEDICATED_AUDIO_CONTROL_GetListEntry(fsgHandle, arrElementString) == 1)
            {
                Shadow_Server_Storage_Set(SHADOW_AudioRepetition_SelectedFrequency, (uint8_t *)arrElementString);
            }
        }
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Acknowledge
 *
 * @brief      Is called when an Acknowledge is generated in BAP
 *             for AUDIO LSG
 *
 * @param [in] void
 *
 * @return     void
 *Void
 ******************************************************************************/
void BAP_AUDIO_Acknowledge(fctId_t aFctId, BapAcknowledge_et aeAcknowledge)
{
        if(aFctId == BapFct_AUDIO_INFO_LIST_Id)
        {
            switch(aeAcknowledge)
            {
                case BapAck_Array_Changed:

                    /* Changed Array message was acknowledge by BAP */
                    gbLockArrayChanged = BAP_FALSE;

                    /* Update Current Station Info message with new FSG Handle*/
                    BAP_AUDIO_CURRENT_STATION_INFO_Update();

                    break;

                case BapAck_Array_Data:

                    /* Status Array message was acknowledge by BAP */
                    gbLockArrayData = BAP_FALSE;

                    break;

                case BapAck_Array_Error:
                    break;

                default:
                    break;
            }
        }
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_IndicationVoid
 *
 * @brief      Is called when an Void indication arrives
 *             for AUDIO
 *
 * @param [in] void
 *
 * @return     void
 *_
 ******************************************************************************/
void BAP_AUDIO_IndicationVoid(fctId_t aFctId, BapIndication_et aeIndication)
{
    OpCode_T opCode;
    uint8_t dummy = 0;

    LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_IndicationVoid > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_IndicationVoid > aeIndication = %x  \n",aeIndication);

    switch(aFctId)
    {
        case BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Id:

            if ((BapInd_Processing_CNF == aeIndication) ||
                (BapInd_Abort == aeIndication))
            {
                opCode = BAP_AUDIO_Map_Ind_to_Opcode[aeIndication];
                BAP_AUDIO_Method_Opcode_Cbk(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx,
                                            opCode,&dummy,0);
            }

        break;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_IndicationInt8
 *
 * @brief      Is called when an Int8 indication arrives
 *             for AUDIO
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_IndicationInt8(fctId_t aFctId,
                              BapIndication_et aeIndication,
                              uint8_t au8Value)
{
}

/***************************************************************************//**
 *
 * @fn         BAP_OPS_IndicationByteSequence
 *
 * @brief      Is called when an Void indication arrives
 *             for OPS
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_IndicationByteSequence(fctId_t aFctId
                                    , BapIndication_et aeIndication
                                    , const volatile_ptr_t apValue
                                    , uint16_t au16Length)
{
    OpCode_T opCode;

    LOG_PRINT(DEBUG_BAP,"BAP_AUDIO_IndicationByteSequence > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP,"BAP_AUDIO_IndicationByteSequence > aeIndication = %x  \n",aeIndication);
    LOG_PRINT(DEBUG_BAP,"BAP_AUDIO_IndicationByteSequence > au16Length = %x  \n",au16Length);

    switch(aFctId)
    {
        case BapFct_AUDIO_DEDICATED_AUDIO_CONTROL_Id:

            if(aeIndication == BapInd_StartResult)
            {
                opCode = BAP_AUDIO_Map_Ind_to_Opcode[aeIndication];
                BAP_AUDIO_Method_Opcode_Cbk(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx,
                                            opCode,(uint8_t *)apValue,au16Length);
            }

        break;

        case BapFct_AUDIO_INFO_LIST_Id:

            if(aeIndication == BapInd_DataGet)
            {
                opCode = BAP_AUDIO_Map_Ind_to_Opcode[aeIndication];

                BAP_AUDIO_Array_Opcode_Cbk(BAP_AUDIO_Array_INFO_LIST_Idx,
                                           opCode, (uint8_t *)apValue,au16Length);
            }

        break;

        default:

        break;
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_OPS_IndicationError
 *
 * @brief      Is called when an Error indication arrives
 *             for OPS
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_IndicationError(fctId_t aFctId
                             , BapError_et aeErrorCode)
{
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Property_InitSend
 *
 * @brief      Initial send of a property class function
 *
 * @param [in] AUDIO_Fct_Property_Idx_t
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_AUDIO_Property_InitSend(AUDIO_Fct_Property_Idx_t idx)
{
    BapError_et eErr = BapErr_OK;
    uint8_t pVar[MAX_LEN];
    uint16_t aLength;

    switch(bap_audio_appl_getOpType(idx,Opcode_Status))
    {
        case Type_Int8:
            eErr = BAP_InitSendInt8(BapLsg_AUDIO_Id,
                                    bap_audio_appl_getFctId(idx),
                                    bap_audio_appl_getParams(idx,Opcode_Status));
            break;

        case Type_Int16:
            eErr = BAP_InitSendInt16(BapLsg_AUDIO_Id,
                                     bap_audio_appl_getFctId(idx),
                                     bap_audio_appl_getParams(idx,Opcode_Status));
            break;

        case Type_Int32:
            eErr = BAP_InitSendInt32(BapLsg_AUDIO_Id,
                                     bap_audio_appl_getFctId(idx),
                                     bap_audio_appl_getParams(idx,Opcode_Status));
            break;

        case Type_FixedByteSequence:
            eErr = BAP_InitSendByteSequence(BapLsg_AUDIO_Id,
                                            bap_audio_appl_getFctId(idx),
                                            bap_audio_appl_getParams(idx,Opcode_Status),
                                            bap_audio_appl_getOpSize(idx,Opcode_Status));
            break;

        case Type_ByteSequence:
            BAP_SerializeByteSequence(idx,pVar,&aLength,Opcode_Status);
            eErr = BAP_InitSendByteSequence(BapLsg_AUDIO_Id,
                                            bap_audio_appl_getFctId(idx),
                                            pVar,
                                            aLength);
            break;
    }

    if(eErr != BapErr_OK)
    {
        LOG_PRINT(DEBUG_BAP, "BAP LSG: AUDIO (%x) FCT: ActiveSource (%x) InitSend -> eErr = %x \n",
                  BapLsg_AUDIO_Id, BapFct_AUDIO_ACTIVE_SOURCE_Id, eErr);
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Property_SetInitialValue
 *
 * @brief      Set initial value for a property class funciton
 *
 * @param [in] AUDIO_Fct_Property_Idx_t
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Property_SetInitialValue(AUDIO_Fct_Property_Idx_t idx)
{
    memset(bap_audio_appl_getParams(idx,Opcode_Status), 0x00, bap_audio_appl_getOpSize(idx,Opcode_Status));

    if(idx == BAP_AUDIO_Property_INFO_LIST_TYPE_Idx)
    {
        memset(bap_audio_appl_getParams(idx,Opcode_Status), InfoListType_PresetList, bap_audio_appl_getOpSize(idx,Opcode_Status));
    }
}




/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Property_Send
 *
 * @brief      Request status of a property class function
 *
 * @param [in] AUDIO_Fct_Property_Idx_t
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_AUDIO_Property_Send(AUDIO_Fct_Property_Idx_t idx)
{
    BapError_et eErr = BapErr_OK;
    uint8_t pVar[MAX_LEN];
    uint16_t aLength;

    LOG_PRINT(DEBUG_BAP,"Sending property = %d \n",idx);

    switch(bap_audio_appl_getOpType(idx,Opcode_Status))
    {
        case Type_Int8:
            eErr = BAP_SendInt8(BapLsg_AUDIO_Id,
                                bap_audio_appl_getFctId(idx),
                                BAP_AUDIO_Map_OpCode_to_Req[Opcode_Status],
                                bap_audio_appl_getParams(idx,Opcode_Status));
            break;

        case Type_Int16:
            eErr = BAP_SendInt16(BapLsg_AUDIO_Id,
                                 bap_audio_appl_getFctId(idx),
                                 BAP_AUDIO_Map_OpCode_to_Req[Opcode_Status],
                                 bap_audio_appl_getParams(idx,Opcode_Status));
            break;

        case Type_Int32:
            eErr = BAP_SendInt32(BapLsg_AUDIO_Id,
                                 bap_audio_appl_getFctId(idx),
                                 BAP_AUDIO_Map_OpCode_to_Req[Opcode_Status],
                                 bap_audio_appl_getParams(idx,Opcode_Status));
            break;

        case Type_FixedByteSequence:
            eErr = BAP_SendByteSequence(BapLsg_AUDIO_Id,
                                        bap_audio_appl_getFctId(idx),
                                        BAP_AUDIO_Map_OpCode_to_Req[Opcode_Status],
                                        bap_audio_appl_getParams(idx,Opcode_Status),
                                        bap_audio_appl_getOpSize(idx,Opcode_Status));
            break;

        case Type_ByteSequence:
            BAP_SerializeByteSequence((uint8_t)idx,pVar,&aLength,Opcode_Status);
            eErr = BAP_SendByteSequence(BapLsg_AUDIO_Id,
                                        bap_audio_appl_getFctId(idx),
                                        BAP_AUDIO_Map_OpCode_to_Req[Opcode_Status],
                                        pVar,
                                        aLength);
            break;
    }

    if(eErr != BapErr_OK)
    {
        LOG_PRINT(DEBUG_BAP, "BAP LSG: AUDIO (%x) FCT: ActiveSource (%x) InitSend -> eErr = %x \n",
                  BapLsg_AUDIO_Id, BapFct_AUDIO_ACTIVE_SOURCE_Id, eErr);
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Method_Send
 *
 * @brief      Request opcode send of a method class function
 *
 * @param [in] AUDIO_Fct_Method_Idx_t
 *             OpCode_T
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_AUDIO_Method_Send(AUDIO_Fct_Method_Idx_t idx, OpCode_T op)
{
    BapError_et eErr = BapErr_OK;
    uint8_t pVar[MAX_LEN];
    uint16_t aLength;

    switch(bap_audio_appl_method_getOpType(idx,op))
    {
        case Type_Int8:
            eErr = BAP_SendInt8(BapLsg_AUDIO_Id,
                                bap_audio_appl_method_getFctId(idx),
                                BAP_AUDIO_Map_OpCode_to_Req[op],
                                bap_audio_appl_method_getParams(idx,op));
            break;

        case Type_Int16:
            eErr = BAP_SendInt16(BapLsg_AUDIO_Id,
                                 bap_audio_appl_getFctId(idx),
                                 BAP_AUDIO_Map_OpCode_to_Req[op],
                                 bap_audio_appl_getParams(idx,op));
            break;

        case Type_Int32:
            eErr = BAP_SendInt32(BapLsg_AUDIO_Id,
                                 bap_audio_appl_getFctId(idx),
                                 BAP_AUDIO_Map_OpCode_to_Req[op],
                                 bap_audio_appl_getParams(idx,op));
            break;

        case Type_FixedByteSequence:
            eErr = BAP_SendByteSequence(BapLsg_AUDIO_Id,
                                        bap_audio_appl_getFctId(idx),
                                        BAP_AUDIO_Map_OpCode_to_Req[op],
                                        bap_audio_appl_getParams(idx,op),
                                        bap_audio_appl_getOpSize(idx,op));
            break;

        case Type_ByteSequence:
            BAP_SerializeByteSequence((uint8_t)idx,pVar,&aLength,op);
            eErr = BAP_SendByteSequence(BapLsg_AUDIO_Id,
                                        bap_audio_appl_getFctId(idx),
                                        BAP_AUDIO_Map_OpCode_to_Req[op],
                                        pVar,
                                        aLength);
            break;
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Array_Send
 *
 * @brief      Request opcode send of an array class function
 *
 * @param [in] AUDIO_Fct_Array_Idx_t
 *             OpCode_T
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_AUDIO_Array_Send(AUDIO_Fct_Array_Idx_t idx, OpCode_T op)
{
    BapError_et eErr = BapErr_OK;
    uint8_t pVar[MAX_LEN];
    uint16_t aLength;

    switch(bap_audio_appl_array_getOpType(idx,op))
    {
        case Type_Int8:
            eErr = BAP_SendInt8(BapLsg_AUDIO_Id,
                                bap_audio_appl_array_getFctId(idx),
                                BAP_AUDIO_Map_OpCode_to_Req[op],
                                bap_audio_appl_array_getParams(idx,op));
            break;

        case Type_Int16:
            eErr = BAP_SendInt16(BapLsg_AUDIO_Id,
                                 bap_audio_appl_array_getFctId(idx),
                                 BAP_AUDIO_Map_OpCode_to_Req[op],
                                 bap_audio_appl_array_getParams(idx,op));
            break;

        case Type_Int32:
            eErr = BAP_SendInt32(BapLsg_AUDIO_Id,
                                 bap_audio_appl_array_getFctId(idx),
                                 BAP_AUDIO_Map_OpCode_to_Req[op],
                                 bap_audio_appl_array_getParams(idx,op));
            break;

        case Type_FixedByteSequence:
            eErr = BAP_SendByteSequence(BapLsg_AUDIO_Id,
                                        bap_audio_appl_array_getFctId(idx),
                                        BAP_AUDIO_Map_OpCode_to_Req[op],
                                        bap_audio_appl_array_getParams(idx,op),
                                        bap_audio_appl_array_getOpSize(idx,op));
            break;

        case Type_ByteSequence:

            BAP_SerializeByteSequence((uint8_t)idx,pVar,&aLength,op);

            eErr = BAP_SendByteSequence(BapLsg_AUDIO_Id,
                                        bap_audio_appl_array_getFctId(idx),
                                        BAP_AUDIO_Map_OpCode_to_Req[op],
                                        pVar,
                                        aLength);
            break;
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_SerializeByteSequence
 *
 * @brief      Serialize paraeters of a variable ByteSequence function.
 *             This function is "ugly" but handle two special cases of
 *             functions with variable length parameters ("strings")
 *
 * @param [in] AUDIO_Fct_Property_Idx_t
 *             uint8_t *
 *             uint8_t *
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_SerializeByteSequence(uint8_t idx, uint8_t *pVar, uint16_t * pLength, OpCode_T op)
{
    uint8_t nBytes = 0;
    uint8_t i;

    switch(idx)
    {
        case BAP_AUDIO_Property_CURRENT_STATION_INFO_Idx:

            i = 0;
            nBytes = BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[0] + 1;
            memcpy(&(pVar[i]),&(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[0]),nBytes);
            i += nBytes;

            nBytes = BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText2[0] + 1;
            memcpy(&(pVar[i]),&(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText2[0]),nBytes);
            i += nBytes;

            nBytes = BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText3[0] + 1;
            memcpy(&(pVar[i]),&(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText3[0]),nBytes);
            i += nBytes;

            memcpy(&(pVar[i]),&(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.stationInfoSwitches),1);
            i += 1;
            memcpy(&(pVar[i]),&(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle),2);
            i += 2;

            *pLength = i;

            break;

        case BAP_AUDIO_Property_ACTIVE_SOURCE_NAME_Idx:

            i = 0;
            nBytes = BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[0] + 1;
            memcpy(&(pVar[i]),&(BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[0]),nBytes);
            i += nBytes;
            *pLength = i;

            break;

        case BAP_AUDIO_Array_INFO_LIST_Idx:

            if(op == Opcode_StatusArray)
            {
                BAP_INFO_LIST_Serialize_StatusArray_Data(pVar,pLength);
            }

            if(op == Opcode_ChangedArray)
            {
                BAP_INFO_LIST_Serialize_ChangedArray_Data(pVar,pLength);
            }

            break;
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_FSG_SETUP_Update
 *
 * @brief      Update FSG Setup function
 *
 * @param [in] uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_FSG_SETUP_Update(uint8_t data)
{
    BAP_FSG_SETUP_Opcode_Status_Data.maxVolume = data;

    bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_FSG_SETUP_Idx);

    LOG_PRINT(DEBUG_BAP,"Max volume (step) = %d \n",BAP_FSG_SETUP_Opcode_Status_Data.maxVolume);
}


/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_ACTIVE_SOURCE_Update
 *
 * @brief      Update active source function
 *
 * @param [in] uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_ACTIVE_SOURCE_Update(void)
{
    uint8_t currentSource;

    /* Obtain current source from shadow storage */
    Shadow_Client_Storage_Get(SHADOW_AudioRepetition_CurrentSource,&currentSource);

    if(currentSource < HU_NUM_SRC)
    {
        BAP_ACTIVE_SOURCE_Opcode_Status_Data.audioSource = BAP_AUDIO_ACTIVE_SOURCE_Map_Audio_Source[currentSource];
        BAP_ACTIVE_SOURCE_Opcode_Status_Data.channelID = 0x00;
        BAP_ACTIVE_SOURCE_Opcode_Status_Data.number = 0x00;

        if(currentSource == HU_SRC_TUNER_FM || currentSource == HU_SRC_TUNER_AM)
        {
            /* Set list available for this sources */
            /* The list is a preset list so it will always be available */
            BAP_ACTIVE_SOURCE_Opcode_Status_Data.listAvailable = 1;

            /* Query changedArray request for InfoList */
            bap_audio_appl_array_setChangedArrayFlag(BAP_AUDIO_Array_INFO_LIST_Idx);

            /* Check if current station is in presetList */
            BAP_ACTIVE_SOURCE_Opcode_Status_Data.number = BAP_AUDIO_ACTIVE_SOURCE_Calculate_Number();

            /* For this source, the list type is a preset list */
            BAP_AUDIO_INFO_LIST_TYPE_Update(InfoListType_PresetList);
        }
        else
        {
            /* For other sources there is no available list */
            BAP_ACTIVE_SOURCE_Opcode_Status_Data.listAvailable = 0;
        }

        /* Query status request for Active source */
        bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_ACTIVE_SOURCE_Idx);

        /* Print function parameters */
        LOG_PRINT(DEBUG_BAP,"audioSource = %x \n",BAP_ACTIVE_SOURCE_Opcode_Status_Data.audioSource);
        LOG_PRINT(DEBUG_BAP,"listAvailable = %x \n",BAP_ACTIVE_SOURCE_Opcode_Status_Data.listAvailable);
        LOG_PRINT(DEBUG_BAP,"channelID = %x \n",BAP_ACTIVE_SOURCE_Opcode_Status_Data.channelID);
        LOG_PRINT(DEBUG_BAP,"number = %x \n",BAP_ACTIVE_SOURCE_Opcode_Status_Data.number);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_ACTIVE_SOURCE_Calculate_Number
 *
 * @brief      Calculate number parameter
 *
 * @param [in] uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
uint8_t BAP_AUDIO_ACTIVE_SOURCE_Calculate_Number(void)
{
    char aru8TunedFrequency[FREQUENCY_STRING_SIZE];
    uint32_t u32TunedFrequency;
    uint8_t i = 0;
    uint8_t number = 0;

    /* Obtain tunedFrequency from shadow signal (string) */
    Shadow_Client_Storage_Get(SHADOW_AudioRepetition_TunedFrequency,(uint8_t *)aru8TunedFrequency);

    /* Obtain numerical value from tunedFrequency signal */
    BAP_AUDIO_Utils_StringToInt(&u32TunedFrequency, aru8TunedFrequency);

    for(i = 0; i < gu16CurrentNumPresets; i++)
    {
        if(u32TunedFrequency == garu32PresetList[i])
        {
            number = gu16CurrentNumPresets - i;
        }
    }

    return number;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_ACTIVE_SOURCE_NAME_Update
 *
 * @brief      Update active source name function
 *
 * @param [in] uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_ACTIVE_SOURCE_NAME_Update(uint8_t data)
{
    /* Analyze current source */
    switch(data)
    {
        case HU_SRC_IDLE:
        case HU_SRC_TUNER_AM:
        case HU_SRC_TUNER_FM:
        case HU_SRC_AUX:
            /* For this sources there is no source name */
            BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[0] = 0x00;
            break;

        case HU_SRC_USB:
        case HU_SRC_CARPLAY:
        case HU_SRC_ANDROID_AUTO:
            /* Set USB Icon */
            BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[0] = 0x03;
            BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[1] = 0xEE;
            BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[2] = 0x81;
            BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[3] = 0xBC;
            break;

        case HU_SRC_BTA:
            /* Set Bluetooth Icon */
            BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[0] = 0x03;
            BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[1] = 0xEF;
            BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[2] = 0x9F;
            BAP_ACTIVE_SOURCE_NAME_Opcode_Status_Data.sourceName[3] = 0xBE;
            break;
    }

    /* Query status request for Active source name */
    bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_ACTIVE_SOURCE_NAME_Idx);

    /* Print function parameters */
    LOG_PRINT(DEBUG_BAP,"Source Name = %s \n",BAP_AUDIO_ACTIVE_SOURCE_Map_Source_Name[data]);

}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_CURRENT_VOLUME_Update
 *
 * @brief      Update current volume function
 *
 * @param [in] uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_CURRENT_VOLUME_Update(uint8_t* data)
{
    /* 1st byte indicates current volume */
    BAP_CURRENT_VOLUME_Opcode_Status_Data.volume = data[0];

    /* 2nd byte indicates changing flag */
    BAP_CURRENT_VOLUME_Opcode_Status_Data.changingVolume = (bool_t)data[1];

    /* Query status request for Current volume */
    bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_CURRENT_VOLUME_Idx);

    /* Print function parameters */
    LOG_PRINT(DEBUG_BAP,"Volume = %d \n", BAP_CURRENT_VOLUME_Opcode_Status_Data.volume);
    LOG_PRINT(DEBUG_BAP,"Changing volume = %d \n", BAP_CURRENT_VOLUME_Opcode_Status_Data.changingVolume);
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_ACTIVE_MUTE_Update
 *
 * @brief      Update mute function
 *
 * @param [in] uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_MUTE_Update(void)
{
    bool_t muteState;
    uint8_t playState;

    /* Get Global mute shadow signal */
    Shadow_Client_Storage_Get(SHADOW_AudioRepetition_MuteSts,(uint8_t *)&muteState);

    /* If the media stream is muted, set mute without checking play status */
    if(muteState == true)
    {
        BAP_MUTE_Opcode_Status_Data.muteState = MuteState_Muted;
    }
    else
    {
        /* If the global stream is unmuted, check the play status of the current source */
        Shadow_Client_Storage_Get(SHADOW_AudioRepetition_PlayState,(uint8_t *)&playState);

        /* Map mute state */
        BAP_MUTE_Opcode_Status_Data.muteState = BAP_AUDIO_MUTE_Map_Mute_State[playState];
    }

    /* Query status request for Mute*/
    bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_MUTE_Idx);

    /* Print function parameters */
    LOG_PRINT(DEBUG_BAP,"muteState = %d \n", BAP_MUTE_Opcode_Status_Data.muteState);

}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_SOURCE_STATE_Update
 *
 * @brief      Update source state function
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_SOURCE_STATE_Update(void)
{
    uint8_t shuffleSts;
    uint8_t repeatSts;

    /* Obtain paratemers from shadow storage */
    Shadow_Client_Storage_Get(SHADOW_AudioRepetition_ShuffleSts,&shuffleSts);
    Shadow_Client_Storage_Get(SHADOW_AudioRepetition_RepeatSts,&repeatSts);

    /* Map state info */
    BAP_SOURCE_STATE_Opcode_Status_Data.stateInfo = BAP_AUDIO_SOURCE_STATE_Map_State_Info[repeatSts][shuffleSts];

    /* Query status request for Source state*/
    bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_SOURCE_STATE_Idx);

    /* Print function parameters */
    LOG_PRINT(DEBUG_BAP,"stateInfo = %d \n", BAP_SOURCE_STATE_Opcode_Status_Data.stateInfo);
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_CURRENT_STATION_INFO_Update
 *
 * @brief      Update current station info function
 *
 * @param [in] uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_CURRENT_STATION_INFO_Update(void)
{
    uint8_t currentSource;
    uint8_t currentSourceNameSize;
    char songName[SONG_NAME_STRING_SIZE];
    char artistName[ARTIST_NAME_STRING_SIZE];
    char albumName[ALBUM_NAME_STRING_SIZE];
    char psn[PSN_STRING_SIZE];
    char tunedFrequency[FREQUENCY_STRING_SIZE];
    char radioText[RADIO_TEXT_STRING_SIZE];
    uint8_t songNameSize;
    uint8_t artistNameSize;
    uint8_t albumNameSize;
    uint8_t psnSize;
    uint8_t radioTextSize;
    uint8_t tunedFrequencySize;
    uint8_t ficSize;

    /* Obtain current source from shadow storage */
    Shadow_Client_Storage_Get(SHADOW_AudioRepetition_CurrentSource,&currentSource);

    /* Analyze current source */
    switch(currentSource)
    {

        case HU_SRC_TUNER_AM:
        case HU_SRC_TUNER_FM:

            /*For tuner sources, parameters are: Tuned Frequency, PSN, RadioText */
            Shadow_Client_Storage_Get(SHADOW_AudioRepetition_PSN,(uint8_t *)psn);
            Shadow_Client_Storage_Get(SHADOW_AudioRepetition_RadioText,(uint8_t *)radioText);
            Shadow_Client_Storage_Get(SHADOW_AudioRepetition_TunedFrequency,(uint8_t *)tunedFrequency);

            /* Obtain string size from parameters */
            psnSize = (strlen(psn));
            radioTextSize = (strlen(radioText));
            tunedFrequencySize = (strlen(tunedFrequency));

            /* Print parameters */
            LOG_PRINT(DEBUG_BAP,"PSN = %s \n", psn);
            LOG_PRINT(DEBUG_BAP,"Radio Text = %s \n", radioText);
            LOG_PRINT(DEBUG_BAP,"Tuned Frequency = %s \n", tunedFrequency);
            LOG_PRINT(DEBUG_BAP,"PSN Size = %d \n", psnSize);
            LOG_PRINT(DEBUG_BAP,"Radio Text Size = %d \n", radioTextSize);
            LOG_PRINT(DEBUG_BAP,"Tuned Frequency Size = %d \n", tunedFrequencySize);

            /* Set infoText1 parameter with priority: PSN, RadioText, TunedFrequency */
            if(psnSize != 0)
            {
                psnSize = (psnSize < (MAX_STRING_DATA_SIZE)) ? psnSize : (MAX_STRING_DATA_SIZE);

                BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[0] = psnSize;
                memcpy((BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1 + 1),psn,psnSize);
            }
            else if(radioTextSize != 0)
            {
                radioTextSize = (radioTextSize < (MAX_STRING_DATA_SIZE)) ? radioTextSize : (MAX_STRING_DATA_SIZE);

                BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[0] = radioTextSize;
                memcpy((BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1 + 1),radioText,radioTextSize);
            }
            else if(tunedFrequencySize != 0)
            {
                if(BAP_AUDIO_Utils_Encode_Frequency(tunedFrequency) != ENCODE_FREQUENCY_SUCCESS)
                {
                    return;
                }

                tunedFrequencySize = strlen(tunedFrequency);
                tunedFrequencySize = (tunedFrequencySize < (MAX_STRING_FREQ_SIZE)) ? tunedFrequencySize : (MAX_STRING_FREQ_SIZE);
                ficSize = tunedFrequencySize + FREQ_INFO_SIZE;

                BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[0] = ficSize;
                memcpy((BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1 + 1),tunedFrequency,tunedFrequencySize);
                BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[tunedFrequencySize + 1] = 0x20;
                BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[tunedFrequencySize + 2] = 0xEF;
                BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[tunedFrequencySize + 3] = 0xA1;
                BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[tunedFrequencySize + 4] = (currentSource == HU_SRC_TUNER_AM) ? 0x8B : 0x8A;
            }
            else
            {
                BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[0] = 0x00;
            }

            /* This parameters are not used for this source */
            memset(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText2,0x00,1);
            memset(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText3,0x00,1);
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.stationInfoSwitches = 0x00;

            /* Query status request for Current station info */
            bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_CURRENT_STATION_INFO_Idx);

            break;

        case HU_SRC_USB:
        case HU_SRC_BTA:

            /*For USB/BTA parameters are: Song, Artist, Album */
            Shadow_Client_Storage_Get(SHADOW_AudioRepetition_SongName,(uint8_t *)songName);
            Shadow_Client_Storage_Get(SHADOW_AudioRepetition_ArtistName,(uint8_t *)artistName);
            Shadow_Client_Storage_Get(SHADOW_AudioRepetition_AlbumName,(uint8_t *)albumName);

            /* Obtain string size from parameters, limit if necessary */
            songNameSize = (strlen(songName));
            songNameSize = (songNameSize < (MAX_STRING_DATA_SIZE)) ? songNameSize : (MAX_STRING_DATA_SIZE);
            artistNameSize = (strlen(artistName));
            artistNameSize = (artistNameSize < (MAX_STRING_DATA_SIZE)) ? artistNameSize : (MAX_STRING_DATA_SIZE);
            albumNameSize = (strlen(albumName));
            albumNameSize = (albumNameSize < (MAX_STRING_DATA_SIZE)) ? albumNameSize : (MAX_STRING_DATA_SIZE);

            /* Set infoText1 with Artist data */
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[0] = artistNameSize;
            memcpy((BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1 + 1),artistName,artistNameSize);

            /* Set infoText2 with Song data */
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText2[0] = songNameSize;
            memcpy((BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText2 + 1),songName,songNameSize);

            /* Set infoText2 with Album data */
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText3[0] = albumNameSize;
            memcpy((BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText3 + 1),albumName,albumNameSize);

            /* This parameter is not used */
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.stationInfoSwitches = 0x00;

            /* This parameter only has meaning wheh source is Tuner */
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle = 0x0000;

            /* Query status request for Current station info */
            bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_CURRENT_STATION_INFO_Idx);

            break;

        case HU_SRC_ANDROID_AUTO:
        case HU_SRC_CARPLAY:

            /*For AA/CP parameter is: Source Name */
            currentSourceNameSize = strlen(BAP_AUDIO_ACTIVE_SOURCE_Map_Source_Name[currentSource]);
            currentSourceNameSize = (currentSourceNameSize < (MAX_STRING_DATA_SIZE)) ? currentSourceNameSize : (MAX_STRING_DATA_SIZE);

            /* Set infoText1 with SourceName */
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1[0] = currentSourceNameSize;
            memcpy((BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1 + 1),BAP_AUDIO_ACTIVE_SOURCE_Map_Source_Name[currentSource],currentSourceNameSize);

            memset(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText2,0x00,1);
            memset(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText3,0x00,1);
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.stationInfoSwitches = 0x00;
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle = 0x0000;

            /* Query status request for Current station info */
            bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_CURRENT_STATION_INFO_Idx);

            break;

        case HU_SRC_IDLE:
        case HU_SRC_AUX:

            /*For AUX source there are not parameters */
            memset(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText1,0x00,1);
            memset(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText2,0x00,1);
            memset(BAP_CURRENT_STATION_INFO_Opcode_Status_Data.infoText3,0x00,1);
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.stationInfoSwitches = 0x00;
            BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle = 0x0000;

            /* Query status request for Current station info */
            bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_CURRENT_STATION_INFO_Idx);

            break;

        default:

            break;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_ACTIVE_SOURCE_Calculate_Number
 *
 * @brief      Calculate number parameter
 *
 * @param [in] uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
uint16_t BAP_AUDIO_CURRENT_STATION_INFO_Calculate_FsgHandle(void)
{
    char aru8TunedFrequency[FREQUENCY_STRING_SIZE];
    uint32_t u32TunedFrequency;
    uint8_t i = 0;
    uint16_t fsgHandle = 0;

    /* Obtain tunedFrequency from shadow signal (string) */
    Shadow_Client_Storage_Get(SHADOW_AudioRepetition_TunedFrequency,(uint8_t *)aru8TunedFrequency);

    /* Obtain numerical value from tunedFrequency signal */
    BAP_AUDIO_Utils_StringToInt(&u32TunedFrequency, aru8TunedFrequency);

    if(gu16CurrentNumPresets > 0)
    {
        if(u32TunedFrequency < garu32PresetList[gu16CurrentNumPresets-1])
        {
            fsgHandle = 1;
        }
        else if(u32TunedFrequency >= garu32PresetList[0])
        {
            fsgHandle = 1;
        }
        else
        {
            fsgHandle = gu16CurrentNumPresets;
            for(i = (gu16CurrentNumPresets - 1); i > 0; i--)
            {
                if((u32TunedFrequency < garu32PresetList[i-1])
                && (u32TunedFrequency >= garu32PresetList[i]))
                {
                    fsgHandle = i + 1;
                }
            }
        }
    }

    return fsgHandle;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_INFO_LIST_TYPE_Update
 *
 * @brief      Update info list type function
 *
 * @param [in] uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_INFO_LIST_TYPE_Update(uint8_t listType)
{
    /* Set list type */
    BAP_INFO_LIST_TYPE_Opcode_Status_Data.type = (ListType_T)listType;

    /* Query status request for InfoListType */
    bap_audio_appl_setStatusFlag(BAP_AUDIO_Property_INFO_LIST_TYPE_Idx);
}


/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Method_Opcode_Cbk
 *
 * @brief      Invoke opcode callback supported by method function
 *
 * @param [in] AUDIO_Fct_Method_Idx_t - Method function index
 *             OpCode_T - Opcode
 *             uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Method_Opcode_Cbk(AUDIO_Fct_Method_Idx_t idx, OpCode_T op, uint8_t * data, uint16_t length)
{
    LOG_PRINT(DEBUG_BAP,"BAP AUDIO Fct Idx = %x, Opcode Cbk = %x Length = %x \n",
              idx,op,length);
    bap_audio_appl_method_getOpCbk(idx, op, data,length)
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Array_Opcode_Cbk
 *
 * @brief      Invoke opcode callback supported by array function
 *
 * @param [in] AUDIO_Fct_Array_Idx_t - Array function index
 *             OpCode_T - Opcode
 *             uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Array_Opcode_Cbk(AUDIO_Fct_Array_Idx_t idx, OpCode_T op, uint8_t * data, uint16_t length)
{
    bap_audio_appl_array_getOpCbk(idx, op, data,length)
}

/***************************************************************************//**
 *
 * @fn         BAP_DEDICATED_AUDIO_CONTROL_Opcode_StartResult_Cbk
 *
 * @brief      Invoke opcode "StartResult" callback for "DedicatedAudioControl"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_DEDICATED_AUDIO_CONTROL_Opcode_StartResult_Cbk(uint8_t* data, uint16_t length)
{
    ControlType_T controlType;
    uint16_t aux_data16;
    MethodState_t methodState;
    uint8_t shift = 0;
    Shadow_AudioRep_CurrSrc_T src;
    uint16_t fsgHandle;
    char arrElementString[FREQUENCY_STRING_SIZE];

    /* Get method state */
    methodState = bap_audio_appl_method_getState(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx);

    /* Only process request if there is no a previous one being processed */
    if(!bap_audio_appl_method_isPendingRequestFlags())
    {
        /* Get control type received */
        controlType = (ControlType_T)data[0];
        BAP_DEDICATED_AUDIO_CONTROL_Opcode_StartResult_Data.controlType = controlType;

        /* Check control type */
        switch(controlType)
        {
            case ControlType_Next:
            case ControlType_Prev:

                /* Obtain current source from shadow storage */
                Shadow_Client_Storage_Get(SHADOW_AudioRepetition_CurrentSource, (uint8_t *)&src);

                /* For this sources Next/Prev control must be done */
                if((src == HU_SRC_USB)
                || (src == HU_SRC_BTA)
                || (src == HU_SRC_AUX)
                || (src == HU_SRC_CARPLAY)
                || (src == HU_SRC_ANDROID_AUTO))
                {
                    /* Use SWC to send command to Android */
                    aux_data16 = 0;
                    shift = (controlType == ControlType_Next) ? ASWC_Key_Next : ASWC_Key_Prev;
                    aux_data16 |= (1 << shift);
                    /* Set shadow storage with SWCSts */
                    Shadow_Server_Storage_Set(SHADOW_SWCSts, (uint8_t *)&aux_data16);


                    /* Update current source */
                    BAP_AUDIO_ACTIVE_SOURCE_Update();
                }
                else if(src == HU_SRC_TUNER_AM || (src == HU_SRC_TUNER_FM))
                {
                    /* Calculate current preset element that must be displaying*/
                    /* FSG Handle parameter points to the current element when info list is displayed */
                    /* This parameter only has meaning wheh source is Tuner */
                    BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle = BAP_AUDIO_CURRENT_STATION_INFO_Calculate_FsgHandle();

                    fsgHandle = BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle;

                    if(controlType == ControlType_Next)
                    {
                        fsgHandle = fsgHandle + 1;
                        fsgHandle = (fsgHandle > gu16CurrentNumPresets) ? 1 : fsgHandle;
                    }
                    else
                    {
                        if(BAP_ACTIVE_SOURCE_Opcode_Status_Data.number != 0)
                        {
                            if(fsgHandle > 1)
                            {
                                fsgHandle = fsgHandle - 1;
                            }
                            else
                            {
                                fsgHandle = gu16CurrentNumPresets;
                            }
                        }
                    }

                    BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle = fsgHandle;

                    BAP_AUDIO_CURRENT_STATION_INFO_Update();
                }

                /* Set method state to processing */
                bap_audio_appl_method_setState(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx,
                                            METHOD_PROCESSING_CNF_REQUEST);

                /* Set processing counter */
                bap_audio_appl_method_setCntr(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx, METHOD_LENGTH);

                /* Query request for Dedicated Audio Control */
                bap_audio_appl_method_setRequestFlag(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx);

            break;

            case ControlType_SelectListEntry:

                /* If control type is SelectListEntry */
                /* aditionalControlInformation is interpreted as fsgHandle */
                memcpy(&(BAP_DEDICATED_AUDIO_CONTROL_Opcode_StartResult_Data.aditionalControlInformation),&(data[1]),2);
                fsgHandle = BAP_DEDICATED_AUDIO_CONTROL_Opcode_StartResult_Data.aditionalControlInformation;
                
                if(fsgHandle != BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle)
                {
                    BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle = fsgHandle;

                    BAP_AUDIO_CURRENT_STATION_INFO_Update();

                    /* Set method state to processing */
                    bap_audio_appl_method_setState(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx,
                                                METHOD_PROCESSING_CNF_REQUEST);

                    /* Set processing counter */
                    bap_audio_appl_method_setCntr(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx, METHOD_LENGTH);

                    /* Query request for Dedicated Audio Control */
                    bap_audio_appl_method_setRequestFlag(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx);
                }
                else
                {
                
                    BAP_DEDICATED_AUDIO_CONTROL_Opcode_Result_Data = AudioControlResult_NotSuccesful;

                    /* Method processing finished, send result */
                    BAP_AUDIO_Method_Send(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx,Opcode_Result);    
                }
                
            break;

            default:
            break;
        }
    }
}

uint8_t BAP_AUDIO_DEDICATED_AUDIO_CONTROL_GetListEntry(uint16_t fsgHandle, char* presetEntry)
{
    uint8_t ret = 0;

    if((fsgHandle > NUM_MAX_PRESETS)       ||
       (fsgHandle > gu16CurrentNumPresets) ||
       (fsgHandle == 0))
    {
        ret = 0;
    }
    else
    {
        /* Obtain string from required preset list entry */
        BAP_AUDIO_Utils_IntToString(garu32PresetList[fsgHandle-1], presetEntry,0);
        ret = 1;
    }

    return ret;
}


/***************************************************************************//**
 *
 * @fn         BAP_DEDICATED_AUDIO_CONTROL_Opcode_Result_Cbk
 *
 * @brief      Invoke opcode "Result" callback for "DedicatedAudioControl"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_DEDICATED_AUDIO_CONTROL_Opcode_Result_Cbk(uint8_t* data, uint16_t length)
{
    ControlType_T controlType;
    uint16_t aux_data16;
    Shadow_AudioRep_CurrSrc_T src;
    uint16_t fsgHandle;
    char arrElementString[FREQUENCY_STRING_SIZE];

    /* Get control type */
    controlType = BAP_DEDICATED_AUDIO_CONTROL_Opcode_StartResult_Data.controlType;

    switch(controlType)
    {
        case ControlType_Next:
        case ControlType_Prev:

            /* Obtain current source from shadow storage */
            Shadow_Client_Storage_Get(SHADOW_AudioRepetition_CurrentSource, (uint8_t *)&src);

            if((src == HU_SRC_USB)
            || (src == HU_SRC_BTA)
            || (src == HU_SRC_AUX)
            || (src == HU_SRC_CARPLAY)
            || (src == HU_SRC_ANDROID_AUTO))
            {
                aux_data16 = 0;
                Shadow_Server_Storage_Set(SHADOW_SWCSts, (uint8_t *)&aux_data16);
            }
            else if(src == HU_SRC_TUNER_AM || (src == HU_SRC_TUNER_FM))
            {                
                fsgHandle = BAP_CURRENT_STATION_INFO_Opcode_Status_Data.fsgHandle;
            }

            BAP_DEDICATED_AUDIO_CONTROL_Opcode_Result_Data = AudioControlResult_Succesful;

        break;

        case ControlType_SelectListEntry:

            BAP_DEDICATED_AUDIO_CONTROL_Opcode_Result_Data = AudioControlResult_Succesful;

        break;

    }

    /* Set state to indicate that the request processing finished */
    bap_audio_appl_method_setState(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx,
                                   METHOD_NO_REQUEST);
}

/***************************************************************************//**
 *
 * @fn         BAP_DEDICATED_AUDIO_CONTROL_Opcode_Processing_Cbk
 *
 * @brief      Invoke opcode "Processing" callback for "DedicatedAudioControl"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_DEDICATED_AUDIO_CONTROL_Opcode_Processing_Cbk(uint8_t* data, uint16_t length)
{
    /* Decrease processing counter */
    bap_audio_appl_method_useCntr(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx);
    bap_audio_appl_method_setState(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx, METHOD_PROCESSING_CNF_REQUEST);

    LOG_PRINT(DEBUG_BAP,"BAP_DEDICATED_AUDIO_CONTROL_Opcode_Processing_Cbk > methodState = %d \r\n", bap_audio_appl_method_getState(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx));
    LOG_PRINT(DEBUG_BAP,"BAP_DEDICATED_AUDIO_CONTROL_Opcode_Processing_Cbk > processCntr = %d \r\n", bap_audio_appl_method_getCntr(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx));
}

/***************************************************************************//**
 *
 * @fn         BAP_DEDICATED_AUDIO_CONTROL_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "DedicatedAudioControl"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_DEDICATED_AUDIO_CONTROL_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_DEDICATED_AUDIO_CONTROL_Opcode_Abort_Cbk
 *
 * @brief      Invoke opcode "Abort" callback for "DedicatedAudioControl"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_DEDICATED_AUDIO_CONTROL_Opcode_Abort_Cbk(uint8_t* data, uint16_t length)
{
    bap_audio_appl_method_setState(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx,
                                   METHOD_ABORT_REQUEST);
    bap_audio_appl_method_setRequestFlag(BAP_AUDIO_Method_DEDICATED_AUDIO_CONTROL_Idx);
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Opcode_GetArray_Cbk
 *
 * @brief      Invoke opcode "GetArray" callback for "InfoList"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Opcode_GetArray_Cbk(uint8_t* data, uint16_t length)
{
    /* Decode array header parameter */
    BAP_INFO_LIST_Decode_Array_Header(&BAP_INFO_LIST_Opcode_GetArray_Data,data);

    /* Query StatusArray request for InfoList */
    bap_audio_appl_array_setStatusArrayFlag(BAP_AUDIO_Array_INFO_LIST_Idx);

    /* Print header parameter */
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_GetArray_Cbk > ArrayHeader > Mode = %d \n",BAP_INFO_LIST_Opcode_GetArray_Data.mode);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_GetArray_Cbk > ArrayHeader > Elements = %d  \n",BAP_INFO_LIST_Opcode_GetArray_Data.elements);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_GetArray_Cbk > ArrayHeader > Start = %d \n",BAP_INFO_LIST_Opcode_GetArray_Data.start);
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Get_Array_Header_Prms
 *
 * @brief      Get all parameters from Array Header
 *
 * @param [in]  ArrayHeader_T*   header - Array header
 * @param [out] ArrayHeaderPrms* headerPrms - Array header parameters
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Get_Array_Header_Prms(ArrayHeader_T* header, ArrayHeaderPrms_T* headerPrms)
{
    /* Get internal parameters from array header */
    headerPrms->arrayDirection  = BAP_INFO_LIST_Get_Array_Header_Direction(header);
    headerPrms->idxSize         = BAP_INFO_LIST_Get_Array_Header_IdxSize(header);
    headerPrms->unknownParam    = BAP_INFO_LIST_Get_Array_Header_UnknownParam(header);
    headerPrms->posTransmit     = BAP_INFO_LIST_Get_Array_Header_PosTransmit(header);
    headerPrms->start           = BAP_INFO_LIST_Get_Array_Header_Start(header);
    headerPrms->elements        = BAP_INFO_LIST_Get_Array_Header_Elements(header);
    headerPrms->recordAddress   = BAP_INFO_LIST_Get_Array_Header_RecordAddress(header);
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Set_Array_Header_Prms
 *
 * @brief      Set all parameters from Array Header
 *
 * @param [in]  ArrayHeader_T*   header - Array header
 * @param [out] ArrayHeaderPrms* headerPrms - Array header parameters
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Set_Array_Header_Prms(ArrayHeader_T* header, ArrayHeaderPrms_T* headerPrms)
{
    /* Set internal parameters to array header */
    BAP_INFO_LIST_Set_Array_Header_Direction(header,headerPrms->arrayDirection);
    BAP_INFO_LIST_Set_Array_Header_IdxSize(header,headerPrms->idxSize);
    BAP_INFO_LIST_Set_Array_Header_UnknownParam(header, headerPrms->unknownParam);
    BAP_INFO_LIST_Set_Array_Header_PosTransmit(header,headerPrms->posTransmit);
    BAP_INFO_LIST_Set_Array_Header_Start(header,headerPrms->start);
    BAP_INFO_LIST_Set_Array_Header_Elements(header,headerPrms->elements );
    BAP_INFO_LIST_Set_Array_Header_RecordAddress(header,headerPrms->recordAddress);
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Get_Array_Header_Direction
 *
 * @brief      Get ArrayDirection parameter from Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 *
 * @return     ArrayDirection_T - Array direction
 *
 ******************************************************************************/
ArrayDirection_T BAP_INFO_LIST_Get_Array_Header_Direction(ArrayHeader_T* header)
{
    uint8_t arrayDir;

    /* Get 'Array Direction' parameter from Array Header */
    arrayDir = bap_audio_appl_arrayHeader_getArrayDir(header);
    if(arrayDir == INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_FW)
    {
        return ArrayDirection_Forward;
    }
    else
    {
        return ArrayDirection_Backward;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Set_Array_Header_Direction
 *
 * @brief      Set ArrayDirection parameter in Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] ArrayDirection_T - Array header direction
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Set_Array_Header_Direction(ArrayHeader_T* header, ArrayDirection_T direction)
{
    /* Set 'Array Direction' parameter to Array Header */
    header->mode &= ~(INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_MASK);
    if(direction == ArrayDirection_Forward)
    {
        header->mode |= (INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_FW << INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_SHIFT);
    }
    else
    {
        header->mode |= (INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_BW << INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_SHIFT);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Get_Array_Header_IdxSize
 *
 * @brief      Get ArrayDirection parameter from Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 *
 * @return     ArrayIndexSize_T - Array index size
 *
 ******************************************************************************/
ArrayIndexSize_T BAP_INFO_LIST_Get_Array_Header_IdxSize(ArrayHeader_T* header)
{
    uint8_t idxSize;

    idxSize = bap_audio_appl_arrayHeader_getIdxSize(header);
    if(idxSize == INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_16BITS)
    {
        return ArrayIndexSize_16Bits;
    }
    else
    {
        return ArrayIndexSize_8Bits;
    }
}


/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Set_Array_Header_IdxSize
 *
 * @brief      Set Array Idx size parameter in Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] ArrayIndexSize_T - Array idx size
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Set_Array_Header_IdxSize(ArrayHeader_T* header, ArrayIndexSize_T idxSize)
{
    header->mode &= ~(INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_MASK);
    if(idxSize == ArrayIndexSize_16Bits)
    {
        header->mode |= (INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_16BITS << INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_SHIFT);
    }
    else
    {
        header->mode |= (INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_8BITS << INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_SHIFT);
    }
}


/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Get_Array_Header_UnknownParam
 *
 * @brief      Get Unknown parameter from Array Header. The BAP AUDIO documenta
 *             tion refers the definition of this parameter to another documenta
 *             tion that we don't posess but we know by reverse engineerin that
 *             we need to take this but into account
 *
 * @param [in] ArrayHeader_T* - Array header
 *
 * @return     ArrayIndexSize_T - Array index size
 *
 ******************************************************************************/
bool_t BAP_INFO_LIST_Get_Array_Header_UnknownParam(ArrayHeader_T* header)
{
    uint8_t unknownParam;

    unknownParam = bap_audio_appl_arrayHeader_getUnknownParam(header);

    if(unknownParam == INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_ENABLE)
    {
        return true;
    }

    return false;
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Set_Array_Header_UnknownParam
 *
 * @brief      Set Unknown parameter from Array Header. The BAP AUDIO documenta
 *             tion refers the definition of this parameter to another documenta
 *             tion that we don't posess but we know by reverse engineerin that
 *             we need to take this but into account
 *
 * @param [in] ArrayHeader_T* - Array header
 *
 * @return     ArrayIndexSize_T - Array index size
 *
 ******************************************************************************/
void BAP_INFO_LIST_Set_Array_Header_UnknownParam(ArrayHeader_T* header, bool_t unknownPrm)
{
    header->mode &= ~(INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_MASK);

    if(unknownPrm == true)
    {
        header->mode |= (INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_ENABLE << INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_SHIFT);
    }
    else
    {
        header->mode |= (INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_DISABLE << INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_SHIFT);
    }
}


/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Get_Array_Header_PosTransmit
 *
 * @brief      Get PosTransmit parameter from Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 *
 * @return     bool_t - Position transmitted
 *
 ******************************************************************************/
bool_t BAP_INFO_LIST_Get_Array_Header_PosTransmit(ArrayHeader_T* header)
{
    uint8_t posTransmit;

    posTransmit = bap_audio_appl_arrayHeader_getPosTransmit(header);
    if(posTransmit == INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_TRANSMITTED)
    {
        return true;
    }

    return false;
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Set_Array_Header_PosTransmit
 *
 * @brief      Set PosTransmit parameter from Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] bool_t         - Transmit position with array
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Set_Array_Header_PosTransmit(ArrayHeader_T* header, bool_t posTransmit)
{
    header->mode &= ~(INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_MASK);

    if(posTransmit == true)
    {
        header->mode |= (INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_TRANSMITTED << INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_SHIFT);
    }
    else
    {
        header->mode |= (INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_NOTTRANSMITTED << INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_SHIFT);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Get_Array_Header_Start
 *
 * @brief      Get Start parameter from Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 *
 * @return     uint16_t - Start position
 *
 ******************************************************************************/
uint16_t BAP_INFO_LIST_Get_Array_Header_Start(ArrayHeader_T* header)
{
    return (header->start);
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Set_Array_Header_Start
 *
 * @brief      Set Start parameter to Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] uint16_t       - Start index of array
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Set_Array_Header_Start(ArrayHeader_T* header, uint16_t start)
{
    header->start = start;
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Get_Array_Header_Elements
 *
 * @brief      Get Elements parameter from Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 *
 * @return     uint16_t - Elements
 *
 ******************************************************************************/
uint16_t BAP_INFO_LIST_Get_Array_Header_Elements(ArrayHeader_T* header)
{
    return (header->elements);
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Set_Array_Header_Elements
 *
 * @brief      Set Elements parameter to Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] uint16_t       - Elements from array
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Set_Array_Header_Elements(ArrayHeader_T* header, uint16_t elements)
{
    header->elements = elements;
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Get_Array_Header_RecordAdress
 *
 * @brief      Get RecordAdress parameter from Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 *
 * @return     uint16_t - RecordAdress
 *
 ******************************************************************************/
ArrayRecordAddress_T BAP_INFO_LIST_Get_Array_Header_RecordAddress(ArrayHeader_T* header)
{
    return (ArrayRecordAddress_T)(bap_audio_appl_arrayHeader_getRecorAddress(header));
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Set_Array_Header_RecordAdress
 *
 * @brief      Set RecordAdress parameter to Array Header
 *
 * @param [in] ArrayHeader_T*       - Array header
 * @param [in] ArrayRecordAddress_T - RecordAddress
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Set_Array_Header_RecordAddress(ArrayHeader_T* header, ArrayRecordAddress_T recordAddress)
{
    header->mode &= ~(INFOLIST_ARRAYHEADER_MODE_RECORDADRESS_MASK);
    header->mode |= recordAddress;
}


/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Decode_Array_Header
 *
 * @brief      Decode Array Header from data byte sequence
 *
 * @param [in] ArrayHeader_T * - array header to decode
 *             uint8_t * - data byte sequence
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Decode_Array_Header(ArrayHeader_T *header, uint8_t * data)
{
    BAP_INFO_LIST_Decode_Array_Header_Mode(header, data);

    BAP_INFO_LIST_Decode_Array_Header_Start(header,data);

    BAP_INFO_LIST_Decode_Array_Header_Elements(header, data);
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Decode_Array_Header_Mode
 *
 * @brief      Decode ArrayHeader "Mode" parameter from data byte sequence
 *
 * @param [in] ArrayHeader_T * - array header to decode
 *             uint8_t * - data byte sequence
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Decode_Array_Header_Mode(ArrayHeader_T *header, uint8_t *data)
{
    header->mode = data[INFOLIST_ARRAYHEADER_MODE_IDX];
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Decode_Array_Header_Start
 *
 * @brief      Decode ArrayHeader "Mode" parameter from data byte sequence
 *
 * @param [in] ArrayHeader_T * - array header to decode
 *             uint8_t * - data byte sequence
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Decode_Array_Header_Start(ArrayHeader_T *header, uint8_t *data)
{
    uint8_t idxSize;

    idxSize = bap_audio_appl_arrayHeader_getIdxSize(header);

    if(idxSize == INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_16BITS)
    {
        header->start = (data[INFOLIST_ARRAYHEADER_START_16BITS_LSB_IDX])
                    | (data[INFOLIST_ARRAYHEADER_START_16BITS_MSB_IDX] << 8);

    }
    else
    {
        header->start = data[INFOLIST_ARRAYHEADER_START_8BITS_IDX];
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Decode_Array_Header_Elements
 *
 * @brief      Decode ArrayHeader "Elements" parameter from data byte sequence
 *
 * @param [in] ArrayHeader_T * - array header to decode
 *             uint8_t * - data byte sequence
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Decode_Array_Header_Elements(ArrayHeader_T *header, uint8_t *data)
{
    uint8_t idxSize;

    idxSize = bap_audio_appl_arrayHeader_getIdxSize(header);

    if(idxSize == INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_16BITS)
    {
        header->elements = (data[INFOLIST_ARRAYHEADER_ELEMENTS_16BITS_LSB_IDX])
                        | (data[INFOLIST_ARRAYHEADER_ELEMENTS_16BITS_MSB_IDX] << 8);
    }
    else
    {
        header->elements = data[INFOLIST_ARRAYHEADER_ELEMENTS_8BITS_IDX];
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Opcode_StatusArray_Cbk
 *
 * @brief      Invoke opcode "StatusArray" callback for "InfoList"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Opcode_StatusArray_Cbk(uint8_t* data, uint16_t length)
{
    ArrayHeaderPrms_T getArrayHeaderPrms;
    ArrayHeaderPrms_T statusArrayHeaderPrms;

    /* Get Array Header parameters from GetArray message */
    BAP_INFO_LIST_Get_Array_Header_Prms(&BAP_INFO_LIST_Opcode_GetArray_Data, &getArrayHeaderPrms);

    /* Set TotalListElements for StatusArray message */

    // The totalNumList elements must be the size of the array
    BAP_INFO_LIST_Opcode_StatusArray_Data.totalNumListElements = gu16CurrentNumPresets;

    /* Set ArrayHeader for StatusArray message */

    // Set idx size to 8 bits
    statusArrayHeaderPrms.idxSize = ArrayIndexSize_8Bits;

    // Set to Transmit element position
    statusArrayHeaderPrms.posTransmit = true;

    // Direction is the same as received from GetArray message
    statusArrayHeaderPrms.arrayDirection = getArrayHeaderPrms.arrayDirection;

    // Unknow parameter (bit4) must be the same as received from GetArray message
    statusArrayHeaderPrms.unknownParam = getArrayHeaderPrms.unknownParam;

    // Record Adress: Transmit all elements
    statusArrayHeaderPrms.recordAddress = ArrayRecordAdress_All;

    // The value of start in a StatusArray message has to be equal from
    //the GetArray message
    statusArrayHeaderPrms.start = getArrayHeaderPrms.start;

    // The value of elements in a StatusArray message must be the
    // same as the one in GetArray message but taking in consideration
    // the boundaries of the array
    statusArrayHeaderPrms.elements = BAP_INFO_LIST_CalculateElements(&getArrayHeaderPrms, gu16CurrentNumPresets);

    // Set header parameters in message data
    BAP_INFO_LIST_Set_Array_Header_Prms(&(BAP_INFO_LIST_Opcode_StatusArray_Data.arrayHeader), &statusArrayHeaderPrms);

    /* Set ArrayData for StatusArray message */
    BAP_INFO_LIST_Set_Array_Data(gu16CurrentNumPresets,&statusArrayHeaderPrms,&BAP_INFO_LIST_Opcode_StatusArray_Data.arrayData);

    /* Print parameters */
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_StatusArray_Cbk > totalNumListElements = %x \r\n",BAP_INFO_LIST_Opcode_StatusArray_Data.totalNumListElements);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_StatusArray_Cbk > header > start = %x \r\n",statusArrayHeaderPrms.start);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_StatusArray_Cbk > header >elements = %x \r\n",statusArrayHeaderPrms.elements);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_StatusArray_Cbk > header > mode = %x \r\n",BAP_INFO_LIST_Opcode_StatusArray_Data.arrayHeader.mode);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_StatusArray_Cbk > header > mode > idxSize = %x \r\n",statusArrayHeaderPrms.idxSize);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_StatusArray_Cbk > header > mode > unknownParam = %x \r\n",statusArrayHeaderPrms.unknownParam);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_StatusArray_Cbk > header > mode >posTransmit = %x \r\n",statusArrayHeaderPrms.posTransmit);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_StatusArray_Cbk > header > mode > arrayDirection = %x \r\n",statusArrayHeaderPrms.arrayDirection);
    LOG_PRINT(DEBUG_BAP,"BAP_INFO_LIST_Opcode_StatusArray_Cbk > header > mode >recordAddress = %x \r\n",statusArrayHeaderPrms.recordAddress);
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Set_Array_Data
 *
 * @brief      Set BAP Array data from list as specified in Header
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Set_Array_Data(uint16_t totalNumListElements, ArrayHeaderPrms_T * headerPrms, Array_T * array)
{
    uint16_t i;
    uint16_t idx;
    uint16_t initialElement;
    uint8_t arrElementSize;
    uint16_t arrayIndex;
    uint16_t defaultFirstElement;
    bool_t unknwnPrm;
    uint8_t currentSource;
    char arrElementString[FREQUENCY_STRING_SIZE];

    // First element of the response if start element received is 0x0000
    // depends on the array direction
    defaultFirstElement = (headerPrms->arrayDirection == ArrayDirection_Forward) ? 1 : totalNumListElements;

    // If the start element received is 0x0000 use the default first element
    initialElement = (headerPrms->start > 0) ? (headerPrms->start) : defaultFirstElement;

    // Obtain value of unknownPrm bit
    unknwnPrm = (headerPrms->start > 0) ? (headerPrms->unknownParam) : false;

    for(i = 0; i < headerPrms->elements; i++)
    {

        idx = (headerPrms->arrayDirection == ArrayDirection_Forward) ? (initialElement + i) : (initialElement - i);

        if(unknwnPrm == true)
        {
            idx = (headerPrms->arrayDirection == ArrayDirection_Forward) ? (idx + 1) : (idx -1);
        }

        // Requested index goes from 1,...,N
        // Array range is 0,....,N-1
        arrayIndex = idx - 1;

        /* Set Type and Attributes from element */
        array->entry[i].typeAndAttributes = 0x31;

        /* Set position */
        array->entry[i].pos = idx;

        /* Obtain current source from shadow storage */
        Shadow_Client_Storage_Get(SHADOW_AudioRepetition_CurrentSource,&currentSource);

        /* Set name */
        BAP_AUDIO_Utils_Encode_FrequencyNumber(garu32PresetList[arrayIndex],arrElementString);
        arrElementSize = strlen(arrElementString);
        arrElementSize = (arrElementSize < (MAX_STRING_FREQ_SIZE)) ? arrElementSize : (MAX_STRING_FREQ_SIZE);
        array->entry[i].name[0] = arrElementSize + 4;
        memcpy((array->entry[i].name + 1),arrElementString,arrElementSize);
        array->entry[i].name[arrElementSize + 1] = 0x20;
        array->entry[i].name[arrElementSize + 2] = 0xEF;
        array->entry[i].name[arrElementSize + 3] = 0xA1;
        array->entry[i].name[arrElementSize + 4] = (currentSource == HU_SRC_TUNER_AM) ? 0x8B : 0x8A;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_CalculateElements
 *
 * @brief      Receive arrayHeader parameters from a GetArray request and
 *             calculate the total number of elements that can be sended
 *             in the statusArray response
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
uint16_t BAP_INFO_LIST_CalculateElements(ArrayHeaderPrms_T * headerPrms, uint16_t totalNumListElements)
{
    uint16_t elements;
    int16_t lastElement;
    int16_t firstElement;
    bool_t unknwnPrm;

    unknwnPrm = (headerPrms->start > 0) ? (headerPrms->unknownParam) : false;

    // Obtain array request direction from header
    if(headerPrms->arrayDirection == ArrayDirection_Forward)
    {
        // The first element is the start element
        firstElement = (headerPrms->start > 0) ? (headerPrms->start) : 1;

        // Taking in consideration that the 'unknownParam'
        // that determines if the answer must include
        // the start element or not
        if(unknwnPrm == true)
        {
            firstElement += 1;
        }

        elements = 0;
        if(firstElement <= totalNumListElements)
        {
            // Calculate the index of the last element requested
            // When direction is forward include the start element
            lastElement = firstElement + headerPrms->elements -1;
            // Valid indexes of the array goes from [1,...,totalNumListElements]
            // Limit the elements parameter taking in consideration the array boundaries
            elements = (lastElement <= totalNumListElements) ? (headerPrms->elements) : (totalNumListElements - firstElement + 1);
        }
    }
    else
    {
        // The last element is the start element
        lastElement = (headerPrms->start > 0) ? (headerPrms->start) : totalNumListElements;

        // Taking in consideration that the 'unknownParam'
        // that determines if the answer must include
        // the start element or not
        if(unknwnPrm == true)
        {
            lastElement -= 1;
        }

        elements = 0;
        if(lastElement > 0)
        {
            // Calculate the index of the last element requested
            // When direction is backward don't include the start element
            firstElement = lastElement - headerPrms->elements + 1;
            // Valid indexes of the array goes from [1,...,totalNumListElements]
            // Limit the elements parameter taking in consideration the array boundaries
            elements = (firstElement > 0) ? (headerPrms->elements) : (lastElement);
        }
    }


    // Limit required elements to SIZE_ARRAY if necessary
    // Max number of elements that can be sended in a BAP
    // StatusArray message
    if(elements > SIZE_ARRAY)
    {
        elements = SIZE_ARRAY;
    }

    return elements;
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Serialize_Data
 *
 * @brief      Serialize BAP Info List data for StatusArray message
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Serialize_StatusArray_Data(uint8_t * pVar, uint16_t* pLength)
{
    uint16_t nBytes = 0;

    /* Serialize totalNumListElements */
    memcpy(&(pVar[nBytes]),&(BAP_INFO_LIST_Opcode_StatusArray_Data.totalNumListElements),sizeof(uint16_t));
    nBytes+=2;

    /* Serialize array header */
    nBytes += BAP_INFO_LIST_Serialize_ArrayHeader(&(pVar[nBytes]), &(BAP_INFO_LIST_Opcode_StatusArray_Data.arrayHeader));

    /* Serialize array data */
    nBytes += BAP_INFO_LIST_Serialize_ArrayData(&pVar[nBytes], &(BAP_INFO_LIST_Opcode_StatusArray_Data.arrayHeader),
                                           &(BAP_INFO_LIST_Opcode_StatusArray_Data.arrayData));

    /* Return the total number of serialized bytes */
    *pLength = nBytes;
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Serialize_ChangedArray_Data
 *
 * @brief      Serialize BAP Info List data for StatusArray message
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Serialize_ChangedArray_Data(uint8_t * pVar, uint16_t* pLength)
{
    uint16_t nBytes = 0;

    /* Serialize array header */
    nBytes += BAP_INFO_LIST_Serialize_ArrayHeader(&(pVar[nBytes]), &(BAP_INFO_LIST_Opcode_ChangedArray_Data));

    /* Return the total number of serialized bytes */
    *pLength = nBytes;
}


/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Serialize_ArrayHeader
 *
 * @brief      Serialize BAP Info List ArrayHeader parameter in a
 *             uint8_t array
 *
 * @param [out] uint8_t*         - Serialized data
 * @param [in]  ArrayHeader_T*   - Array header to be serialized
 *
 * @return     uint16_t - Serialized length
 *
 ******************************************************************************/
uint16_t BAP_INFO_LIST_Serialize_ArrayHeader(uint8_t * pVar, ArrayHeader_T * header)
{
    uint16_t i;
    uint16_t u16Length;
    ArrayIndexSize_T idxSize;

    i = 0;

    // Serialize ArrayHeader.Mode parameter
    memcpy(&pVar[i],&(header->mode),sizeof(header->mode));
    i+=sizeof(header->mode);

    // Serialize ArrayHeader.Start parameter
    // IdxSize bit from ArrayHeader.Mode must be analyzed
    idxSize = BAP_INFO_LIST_Get_Array_Header_IdxSize(header);
    if(idxSize == ArrayIndexSize_16Bits)
    {
        // If ArrayHeader.Mode.IdxSize is 16 bit
        // The two bytes of Start goes in the message
        memcpy(&pVar[i],&(header->start),sizeof(header->start));
        i+=sizeof(header->start);

        // If ArrayHeader.Mode.IdxSize is 16 bit
        // The two bytes of Elements goes in the message
        memcpy(&pVar[i],&(header->elements),sizeof(header->elements));
        i+=sizeof(header->elements);
    }
    else
    {
        // If ArrayHeader.Mode.IdxSize is 8 bit
        // Only the LSB of ArrayHeader.Start
        // goes on the message
        pVar[i] = (uint8_t)(header->start & 0x00FF);
        i+=1;

        // If ArrayHeader.Mode.IdxSize is 8 bit
        // Only the LSB of ArrayHeader.Elements
        // goes on the message
        pVar[i] = (uint8_t)(header->elements & 0x00FF);
        i+=1;
    }

    u16Length = i;

    return u16Length;
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Serialize_ArrayData
 *
 * @brief      Serialize BAP Info List ArrayData parameter in a
 *             uint8_t array
 *
 * @param [out] uint8_t*         - Serialized data
 * @param [in]  ArrayHeader_T*   - Array header of the Array data to be
 *                                 serialized
 *
 * @return     uint16_t - Serialized length
 *
 ******************************************************************************/
uint16_t BAP_INFO_LIST_Serialize_ArrayData(uint8_t* pVar, ArrayHeader_T* header, Array_T* data)
{
    uint16_t nBytes;
    uint16_t entryNameBytes;
    uint16_t elements;
    uint16_t i;
    ArrayRecordAddress_T recordAddress;
    bool_t posTransmit;
    ArrayIndexSize_T idxSize;

    /* Serialize ArrayData parameter */

    // ArrayHeader.Elements is needed to loop through the data
    elements = BAP_INFO_LIST_Get_Array_Header_Elements(header);
    // ArrayHeader.Mode.RecordAddress must be analyzed
    recordAddress = BAP_INFO_LIST_Get_Array_Header_RecordAddress(header);
    // ArrayHeader.Mode.PosTransmit must be analyzed
    posTransmit = BAP_INFO_LIST_Get_Array_Header_PosTransmit(header);
    // IdxSize bit from ArrayHeader.Mode must be analyzed
    idxSize = BAP_INFO_LIST_Get_Array_Header_IdxSize(header);

    // Initialize byte counter
    nBytes = 0;

    // Loop through all the data entry
    for(i = 0; i < elements; i++)
    {
        // Serialize Data.Entry[i].Pos parameter if:
        //
        //  - Header.Mode.posTransmit is TRUE
        //    AND
        //  - Header.Mode.recordAddress is 'All' or 'PosOnly'
        //
        if( (  (recordAddress == ArrayRecordAdress_All)
            || (recordAddress == ArrayRecordAdress_PosOnly))
            && (posTransmit == true))
        {
            if(idxSize == ArrayIndexSize_16Bits)
            {
                // If ArrayHeader.Mode.IdxSize is 16 bit
                // The two bytes of Data.Entry[j].Pos goes in the message
                memcpy(&pVar[nBytes],&(data->entry[i].pos),sizeof(data->entry[i].pos));
                nBytes+=sizeof(data->entry[i].pos);
            }
            else
            {
                pVar[nBytes] = (uint8_t)(data->entry[i].pos & 0x00FF);
                nBytes+=1;
            }
        }

        // Serialize Data.Entry[i].typeAndAttributes parameter if:
        //
        //  - Header.Mode.recordAddress is 'All' or 'TypeAndAttributes'
        //
        if((recordAddress == ArrayRecordAdress_All)
        || (recordAddress == ArrayRecordAdress_TypeAndAttributes))
        {
            memcpy(&pVar[nBytes],&(data->entry[i].typeAndAttributes),sizeof(data->entry[i].typeAndAttributes));
            nBytes+=sizeof(data->entry[i].typeAndAttributes);
        }

        // Serialize Data.Entry[i].name parameter if:
        //
        //  - Header.Mode.recordAddress is 'All' or 'NameOnly'
        //
        if((recordAddress == ArrayRecordAdress_All)
        || (recordAddress == ArrayRecordAdress_NameOnly))
        {
            entryNameBytes = data->entry[i].name[0] + 1;
            memcpy(&(pVar[nBytes]),&(data->entry[i].name[0]),entryNameBytes);
            nBytes += entryNameBytes;
        }
    }

    return nBytes;
}



/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Opcode_ChangedArray_Cbk
 *
 * @brief      Invoke opcode "ChangedArray" callback for "InfoList"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Opcode_ChangedArray_Cbk(uint8_t* data, uint16_t length)
{
    BAP_INFO_LIST_Opcode_ChangedArray_Data.mode = 0x80;
    BAP_INFO_LIST_Opcode_ChangedArray_Data.start = 0x0000;
    BAP_INFO_LIST_Opcode_ChangedArray_Data.elements = NUM_MAX_PRESETS;
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Decode_PresetList
 *
 * @brief      Decode Preset List from received data
 *
 * @param [in] uint8_t* - data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Decode_PresetList(uint8_t *data)
{
    uint32_t newPresetList[NUM_MAX_PRESETS];
    uint8_t newlistSize;

    /* Decode preset list received from shadow storage */
    newlistSize = BAP_AUDIO_Utils_Encode_FrequencyList((char *)data, PRESET_LIST_DELIMITER, newPresetList, NUM_MAX_PRESETS);

    /* Update preset list with new list decoded */
    BAP_AUDIO_INFO_LIST_Update_PresetList(newPresetList,newlistSize);

    /* Query Changed Array request for InfoList */
    bap_audio_appl_array_setChangedArrayFlag(BAP_AUDIO_Array_INFO_LIST_Idx);
}


/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_INFO_LIST_Update_PresetList
 *
 * @brief      Update Preset List if necessary
 *
 * @param [in] uint8_t* - data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_INFO_LIST_Update_PresetList(uint32_t newList[], uint8_t newSize)
{
    uint8_t i = 0;
    uint8_t j = 0;
    uint32_t temp;

    /* Get access to preset list */
    Semaphore_pend(presetListSem, BIOS_WAIT_FOREVER);

    /* First, clean the current preset list */
    memset(garu32PresetList,0x0000,NUM_MAX_PRESETS*sizeof(uint32_t));

    /* Set preset list with new values */
    for(i = 0; i < newSize; i++)
    {
        garu32PresetList[i] = newList[i];
    }

    /* Update the current number of presets available */
    gu16CurrentNumPresets = newSize;

    if (newSize)
    {
        /* Revert order of array */
        i = 0;
        j = newSize - 1;

        while(i<j){
            //swap
            temp = garu32PresetList[i];
            garu32PresetList[i] = garu32PresetList[j];
            garu32PresetList[j] = temp;

            //update i and j
            i++;
            j--;
        }
    }

    /* Release access to resource */
    Semaphore_post(presetListSem);
}

/***************************************************************************//**
 *
 * @fn         BAP_INFO_LIST_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "InfoList"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_INFO_LIST_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{
}
