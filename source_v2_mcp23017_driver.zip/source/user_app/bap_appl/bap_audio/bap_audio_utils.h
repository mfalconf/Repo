#ifndef SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_UTILS_H_
#define SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_UTILS_H_
/*===========================================================================*/
/**
 * @file bap_audio_utils.h
 *
 * Function definitions of the BAP AUDIO utils
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <string.h>
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include <tuner_band_cfg.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

#define SONG_NAME_STRING_SIZE   128
#define ALBUM_NAME_STRING_SIZE  128
#define ARTIST_NAME_STRING_SIZE 128

#define PSN_STRING_SIZE         16
#define RADIO_TEXT_STRING_SIZE  128
#define FREQUENCY_STRING_SIZE   16

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/* Type used to indicates if the BAP_AUDIO_Utils_StringToInt
 * succeeded, or why it failed */
typedef enum
{
    STR_TO_INT_SUCCESS,
    STR_TO_INT_OVERFLOW,
    STR_TO_INT_UNDERFLOW,
    STR_TO_INT_INCONVERTIBLE
}str_to_int_errno;

/* Type used to indicates if the BAP_AUDIO_Utils_Encode_Frequency
 * succeeded, or why it failed */
typedef enum
{
    ENCODE_FREQUENCY_SUCCESS,
    ENCODE_FREQUENCY_INCONVERTIBLE,
    ENCODE_FREQUENCY_INVALID,
}encode_freq_errno;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

encode_freq_errno   BAP_AUDIO_Utils_Encode_Frequency(char * freq_string);
encode_freq_errno   BAP_AUDIO_Utils_Encode_FrequencyNumber(uint32_t freq_number, char* freq_string);
void                BAP_AUDIO_Utils_Encode_AM_Frequency(uint32_t freq_number, char * freq_string);
void                BAP_AUDIO_Utils_Encode_FM_Frequency(uint32_t freq_number, char * freq_string);
uint8_t             BAP_AUDIO_Utils_Encode_FrequencyList(char *list, char *listDelimiter, uint32_t decodedList[], uint8_t maxlistSize);


str_to_int_errno    BAP_AUDIO_Utils_StringToInt(uint32_t *n, char *s);
void                BAP_AUDIO_Utils_IntToString(uint32_t x, char* str, uint8_t d);
void                BAP_AUDIO_Utils_ReverseString(char* str, int len);
char                BAP_AUDIO_Utils_GetNthDigit(int x, int n);

#endif /* SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_UTILS_H_ */
