/*
 * bap_ops_defines.h
 *
 *  Created on: 21 jul. 2022
 *      Author: lrobles
 */

#ifndef SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_DEFINES_H_
#define SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_DEFINES_H_

#include <bap_audio/bap_audio_acfg.h>
#include <bap_defines.h>

/*
 *
 * Define all opcodes size in a function table
 *
 * To be used by:
 *
 * - DEFINE_OPCODES_SIZE_FOR_ALL_FCT
 *
 */
#undef DEFINE_OPCODES_SIZE_FOR_EACH_FCT
#define DEFINE_OPCODES_SIZE_FOR_EACH_FCT(FCT, OPTYPE, TYPE, SIZE, PARAMETER) BAP_AUDIO_##FCT##_##OPTYPE##_Size = SIZE,

/*
 *
 * Define opcodes size for all function in LSG table
 *
 * To be used by:
 *
 * - BAP_AUDIO_FUNCTION_TABLE
 *
 */
#define DEFINE_OPCODES_SIZE_FOR_ALL_FCT(LSG,FCT,CLS,ID,OPCODES) OPCODES(DEFINE_OPCODES_SIZE_FOR_EACH_FCT)

typedef enum BAP_AUDIO_Opcode_Size_t
{
    BAP_AUDIO_FUNCTION_TABLE(DEFINE_OPCODES_SIZE_FOR_ALL_FCT)
}BAP_AUDIO_Opcode_Size_T;

/**
 * Named index for ALL the functions in AUDIO control device
 */
#define ENUMERATE_AUDIO_FUNCTIONS(LSG,FCT,CLS,ID,OPCODES)    BAP_##LSG##_##FCT##_Idx,
typedef enum BAP_AUDIO_Fct_Idx_t
{
   BAP_AUDIO_FUNCTION_TABLE(ENUMERATE_AUDIO_FUNCTIONS)
   BAP_AUDIO_NumFcts,
}AUDIO_Fct_Idx_T;

/**
 * Named index for PROPERTY functions in AUDIO control device
 */
#define ENUMERATE_AUDIO_SPECIFIC_PROPERTY_FUNCTIONS(LSG,FCT,CLS,ID, OPCODES)    BAP_##LSG##_Property_##FCT##_Idx,
typedef enum BAP_AUDIO_Fct_Property_Idx_t
{
    BAP_AUDIO_PROPERTY_TABLE(ENUMERATE_AUDIO_SPECIFIC_PROPERTY_FUNCTIONS)
    BAP_AUDIO_Property_NumFcts,
}AUDIO_Fct_Property_Idx_t;

/**
 * Named index for ARRAY function in AUDIO control device
 */
#define ENUMERATE_AUDIO_ARRAY_FUNCTIONS(LSG,FCT,CLS,ID,OPCODES) BAP_##LSG##_Array_##FCT##_Idx,
typedef enum BAP_AUDIO_Fct_Array_Idx_t
{
   BAP_AUDIO_ARRAY_TABLE(ENUMERATE_AUDIO_ARRAY_FUNCTIONS)
   BAP_AUDIO_Array_NumFcts,
}AUDIO_Fct_Array_Idx_t;

/**
 * Named index for METHOD function in AUDIO control device
 */
#define ENUMERATE_AUDIO_METHOD_FUNCTIONS(LSG,FCT,CLS,ID,OPCODES) BAP_##LSG##_Method_##FCT##_Idx,
typedef enum BAP_AUDIO_Fct_Method_Idx_t
{
    BAP_AUDIO_METHOD_TABLE(ENUMERATE_AUDIO_METHOD_FUNCTIONS)
    BAP_AUDIO_Method_NumFcts,
}AUDIO_Fct_Method_Idx_t;

#endif /* SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_DEFINES_H_ */
