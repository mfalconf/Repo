/*
 * bap_audio_appl.h
 *
 *  Created on: 20 jul. 2022
 *      Author: lrobles
 */

#ifndef SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_APPL_H_
#define SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_APPL_H_
/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include <project_def.h>
#include <console.h>
#include <common_definitions.h>

#include <bap.h>
#include <bap_appl.h>
#include <bap_defines.h>
#include <bap_types.h>
#include <bap_audio_acfg.h>
#include <bap_audio_defines.h>

#include <xdc/runtime/Error.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

static AudioSource_T BAP_AUDIO_ACTIVE_SOURCE_Map_Audio_Source[HU_NUM_SRC] =
{
    [HU_SRC_IDLE]           =   {AudioSource_NoSource},
    [HU_SRC_TUNER_FM]       =   {AudioSource_TunerFM},
    [HU_SRC_TUNER_AM]       =   {AudioSource_TunerAM},
    [HU_SRC_AUX]            =   {AudioSource_Aux},
    [HU_SRC_USB]            =   {AudioSource_USB},
    [HU_SRC_BTA]            =   {AudioSource_BT},
    [HU_SRC_ANDROID_AUTO]   =   {AudioSource_AA},
    [HU_SRC_CARPLAY]        =   {AudioSource_CP},
};

static char * BAP_AUDIO_ACTIVE_SOURCE_Map_Source_Name[HU_NUM_SRC] =
{
    [HU_SRC_IDLE]           =   {"No source"},
    [HU_SRC_TUNER_FM]       =   {"Tuner FM"},
    [HU_SRC_TUNER_AM]       =   {"Tuner AM"},
    [HU_SRC_AUX]            =   {"Aux Player"},
    [HU_SRC_USB]            =   {"USB Player"},
    [HU_SRC_BTA]            =   {"BT Player"},
    [HU_SRC_ANDROID_AUTO]   =   {"Android Auto"},
    [HU_SRC_CARPLAY]        =   {"Apple Carplay"},
};

static MuteState_T BAP_AUDIO_MUTE_Map_Mute_State[HU_NUM_PLAY_STATE] =
{
    [HU_PLAY_STATE_IDLE]    =   {MuteState_Unmuted},
    [HU_PLAY_STATE_STOP]    =   {MuteState_Muted},
    [HU_PLAY_STATE_PAUSE]   =   {MuteState_Muted},
    [HU_PLAY_STATE_PLAY]    =   {MuteState_Unmuted},
};

static StateInfo_T BAP_AUDIO_SOURCE_STATE_Map_State_Info[HU_NUM_REPEAT_STS][HU_NUM_SHUFFLE_STS] =
{
    [HU_REPEAT_STS_OFF][HU_SHUFFLE_STS_OFF]     =   {StateInfo_Unknown},
    [HU_REPEAT_STS_OFF][HU_SHUFFLE_STS_ALL]     =   {StateInfo_Mix},
    [HU_REPEAT_STS_OFF][HU_SHUFFLE_STS_GROUP]   =   {StateInfo_Mix},

    [HU_REPEAT_STS_ONE][HU_SHUFFLE_STS_OFF]     =   {StateInfo_Repeat},
    [HU_REPEAT_STS_ONE][HU_SHUFFLE_STS_ALL]     =   {StateInfo_RepeatMix},
    [HU_REPEAT_STS_ONE][HU_SHUFFLE_STS_GROUP]   =   {StateInfo_RepeatMix},

    [HU_REPEAT_STS_ALL][HU_SHUFFLE_STS_OFF]     =   {StateInfo_Repeat},
    [HU_REPEAT_STS_ALL][HU_SHUFFLE_STS_ALL]     =   {StateInfo_RepeatMix},
    [HU_REPEAT_STS_ALL][HU_SHUFFLE_STS_GROUP]   =   {StateInfo_RepeatMix},

    [HU_REPEAT_STS_GROUP][HU_SHUFFLE_STS_OFF]   =   {StateInfo_Repeat},
    [HU_REPEAT_STS_GROUP][HU_SHUFFLE_STS_ALL]   =   {StateInfo_RepeatMix},
    [HU_REPEAT_STS_GROUP][HU_SHUFFLE_STS_GROUP] =   {StateInfo_RepeatMix},
};

static BapRequest_et BAP_AUDIO_Map_OpCode_to_Req[NUM_OPCODES] =
{
     /* Opcodes from Property class functions */
     [Opcode_Status]     = {BapReq_Data},

     /* Opcodes from Method class functions */
     [Opcode_Processing] = {BapReq_Processing},
     [Opcode_Result]     = {BapReq_Result},
     [Opcode_Abort]      = {BapReq_Abort},

     /* Opcodes from Array class functions */
     [Opcode_StatusArray]   = {BapReq_Data},
     [Opcode_ChangedArray]  = {BapReq_Changed},
};

static OpCode_T BAP_AUDIO_Map_Ind_to_Opcode[] =
{
     [BapInd_Start]          = {Opcode_Start},
     [BapInd_StartResult]    = {Opcode_StartResult},
     [BapInd_Abort]          = {Opcode_Abort},
     [BapInd_Processing_CNF] = {Opcode_Processing},
     [BapInd_DataGet]        = {Opcode_GetArray}
};

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/* BAP AUDIO Task functions */
void        BAP_AUDIO_Sem_Init              (void);
BapError_et BAP_AUDIO_Task                  (void);
BapError_et BAP_AUDIO_Property_Init         (void);
void        BAP_AUDIO_Property_InitValues   (void);
void        BAP_AUDIO_Property_Task         (void);
void        BAP_AUDIO_Array_Task            (void);
void        BAP_AUDIO_Method_Task           (void);

/* BAP AUDIO Acknowledge function */
void BAP_AUDIO_Acknowledge            (fctId_t aFctId, BapAcknowledge_et aeAcknowledge);


/* BAP AUDIO Indication functions */
void BAP_AUDIO_IndicationVoid         (fctId_t aFctId, BapIndication_et aeIndication);
void BAP_AUDIO_IndicationInt8         (fctId_t aFctId, BapIndication_et aeIndication, uint8_t au8Value);
void BAP_AUDIO_IndicationByteSequence (fctId_t aFctId, BapIndication_et aeIndication, const volatile_ptr_t apValue, uint16_t au16Length);
void BAP_AUDIO_IndicationError        (fctId_t aFctId, BapError_et aeErrorCode);

/* BAP AUDIO Functions update functions */
void BAP_AUDIO_FSG_SETUP_Update                 (uint8_t data);
void BAP_AUDIO_ACTIVE_SOURCE_Update             (void);
void BAP_AUDIO_ACTIVE_SOURCE_NAME_Update        (uint8_t data);
void BAP_AUDIO_CURRENT_VOLUME_Update            (uint8_t* data);
void BAP_AUDIO_MUTE_Update                      (void);
void BAP_AUDIO_SOURCE_STATE_Update              (void);
void BAP_AUDIO_CURRENT_STATION_INFO_Update      (void);
void BAP_AUDIO_DEDICATED_AUDIO_CONTROL_Update   (void);
void BAP_AUDIO_INFO_LIST_TYPE_Update            (uint8_t listType);

uint8_t BAP_AUDIO_ACTIVE_SOURCE_Calculate_Number(void);
uint16_t BAP_AUDIO_CURRENT_STATION_INFO_Calculate_FsgHandle(void);
uint8_t BAP_AUDIO_DEDICATED_AUDIO_CONTROL_GetListEntry(uint16_t fsgHandle, char * listEntry);


void                 BAP_INFO_LIST_Get_Array_Header_Prms(ArrayHeader_T* header, ArrayHeaderPrms_T* headerPrms);
ArrayDirection_T     BAP_INFO_LIST_Get_Array_Header_Direction(ArrayHeader_T* header);
ArrayIndexSize_T     BAP_INFO_LIST_Get_Array_Header_IdxSize(ArrayHeader_T* header);
bool_t               BAP_INFO_LIST_Get_Array_Header_UnknownParam(ArrayHeader_T* header);
bool_t               BAP_INFO_LIST_Get_Array_Header_PosTransmit(ArrayHeader_T* header);
uint16_t             BAP_INFO_LIST_Get_Array_Header_Start(ArrayHeader_T* header);
uint16_t             BAP_INFO_LIST_Get_Array_Header_Elements(ArrayHeader_T* header);
ArrayRecordAddress_T BAP_INFO_LIST_Get_Array_Header_RecordAddress(ArrayHeader_T* header);

void    BAP_INFO_LIST_Set_Array_Header_Prms(ArrayHeader_T* header, ArrayHeaderPrms_T* headerPrms);
void    BAP_INFO_LIST_Set_Array_Header_Direction(ArrayHeader_T* header, ArrayDirection_T direction);
void    BAP_INFO_LIST_Set_Array_Header_IdxSize(ArrayHeader_T* header, ArrayIndexSize_T idxSize);
void    BAP_INFO_LIST_Set_Array_Header_UnknownParam(ArrayHeader_T* header, bool_t unknownParam);
void    BAP_INFO_LIST_Set_Array_Header_PosTransmit(ArrayHeader_T* header, bool_t posTransmit);
void    BAP_INFO_LIST_Set_Array_Header_Start(ArrayHeader_T* header, uint16_t start);
void    BAP_INFO_LIST_Set_Array_Header_Elements(ArrayHeader_T* header, uint16_t elements);
void    BAP_INFO_LIST_Set_Array_Header_RecordAddress(ArrayHeader_T* header, ArrayRecordAddress_T recordAdress);

void BAP_INFO_LIST_Set_Array_Data(uint16_t totalNumListElements, ArrayHeaderPrms_T * headerPrms, Array_T * array);

uint16_t BAP_INFO_LIST_CalculateElements(ArrayHeaderPrms_T * headerPrms, uint16_t totalNumListElements);


void BAP_INFO_LIST_Serialize_StatusArray_Data(uint8_t * pVar, uint16_t* pLength);
uint16_t BAP_INFO_LIST_Serialize_ArrayHeader(uint8_t* pVar, ArrayHeader_T* header);
uint16_t BAP_INFO_LIST_Serialize_ArrayData(uint8_t* pVar, ArrayHeader_T* header, Array_T* data);

void BAP_INFO_LIST_Serialize_ChangedArray_Data(uint8_t * pVar, uint16_t* pLength);

void BAP_INFO_LIST_Decode_Array_Header(ArrayHeader_T *header, uint8_t * data);
void BAP_INFO_LIST_Decode_Array_Header_Mode(ArrayHeader_T *header, uint8_t *data);
void BAP_INFO_LIST_Decode_Array_Header_Start(ArrayHeader_T *header, uint8_t *data);
void BAP_INFO_LIST_Decode_Array_Header_Elements(ArrayHeader_T *header, uint8_t *data);

void BAP_INFO_LIST_Decode_PresetList(uint8_t *data);
void BAP_AUDIO_INFO_LIST_Update_PresetList(uint32_t newList[],uint8_t newSize);

void BAP_AUDIO_Method_Opcode_Cbk    (AUDIO_Fct_Method_Idx_t idx, OpCode_T op, uint8_t * data, uint16_t length);
void BAP_AUDIO_Array_Opcode_Cbk     (AUDIO_Fct_Array_Idx_t idx, OpCode_T op, uint8_t * data, uint16_t length);


#endif /* SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_APPL_H_ */
