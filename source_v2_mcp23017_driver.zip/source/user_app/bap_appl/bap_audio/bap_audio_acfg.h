/*
 * bap_ops_acfg.h
 *
 *  Created on: 20 jul. 2022
 *      Author: lrobles
 */

#ifndef SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_ACFG_H_
#define SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_ACFG_H_

#define MAX_STRING_SIZE 49
#define MAX_STRING_DATA_SIZE MAX_STRING_SIZE-1
#define FREQ_INFO_SIZE 4
#define MAX_STRING_FREQ_SIZE (MAX_STRING_DATA_SIZE - FREQ_INFO_SIZE)

#define BAP_AUDIO_BAPCONFIG_RX_SIZE     6
#define BAP_AUDIO_BAPCONFIG_TX_SIZE     6

#define BAP_AUDIO_FUNCTION_LIST_RX_SIZE 8
#define BAP_AUDIO_FUNCTION_LIST_TX_SIZE 8

#define BAP_AUDIO_HEARTBEAT_TX_SIZE     1

/* Info List (0x16) macros */

// ArrayHeader.Mode

#define INFOLIST_ARRAYHEADER_MODE_IDX   0

#define INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_SHIFT               7
#define INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_MASK                0x80
#define INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_8BITS               0
#define INFOLIST_ARRAYHEADER_MODE_INDEXSIZE_16BITS              1

#define INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_SHIFT           6
#define INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_MASK            0x40
#define INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_TRANSMITTED     1
#define INFOLIST_ARRAYHEADER_MODE_ARRAYPOSITION_NOTTRANSMITTED 0

#define INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_SHIFT          5
#define INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_MASK           0x20
#define INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_FW             0
#define INFOLIST_ARRAYHEADER_MODE_ARRAYDIRECTION_BW             1

#define INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_SHIFT           4
#define INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_MASK            0x10
#define INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_ENABLE          1
#define INFOLIST_ARRAYHEADER_MODE_UNKNOWN_PARAM_DISABLE         0

#define INFOLIST_ARRAYHEADER_MODE_RECORDADRESS_MASK             0xF

#define INFOLIST_ARRAYHEADER_START_16BITS_LSB_IDX               1
#define INFOLIST_ARRAYHEADER_START_16BITS_MSB_IDX               2
#define INFOLIST_ARRAYHEADER_START_8BITS_IDX                    1

#define INFOLIST_ARRAYHEADER_ELEMENTS_16BITS_LSB_IDX            3
#define INFOLIST_ARRAYHEADER_ELEMENTS_16BITS_MSB_IDX            4
#define INFOLIST_ARRAYHEADER_ELEMENTS_8BITS_IDX                 3

#define SELECTED_FREQUENCY_DELAY_TIME 100   //x10ms

/* Fsg Setup (0xE) data type */

typedef struct __attribute__ ((__packed__)) FsgSetup_Tag
{
    uint8_t maxVolume;
}FSGSetup_T;

/* Fsg Operation State (0xF) data type */

typedef enum OpState_Tag
{
    OpState_NormalOperation = 0x00,
    OpState_Off             = 0x01,
    OpState_KL15_FollowUp   = 0x02,
    OpState_Defect          = 0x0F
}OpState_T;

typedef struct __attribute__ ((__packed__)) FsgOperationState_Tag
{
    OpState_T opState;
}FSGOperationState_T;

/* Active Source (0x10) data types */

typedef enum AudioSource_Tag
{
    AudioSource_NoSource    = 0x00,
    AudioSource_TunerFM     = 0x01,
    AudioSource_TunerAM     = 0x02,
    AudioSource_Aux         = 0x0E,
    AudioSource_USB         = 0x10,
    AudioSource_BT          = 0xFF,
    AudioSource_AA          = 0xFF,
    AudioSource_CP          = 0xFF,
}AudioSource_T;

typedef struct __attribute__ ((__packed__)) ActiveSource_Tag
{
    AudioSource_T audioSource;
    uint8_t listAvailable;
    uint8_t number;
    uint8_t channelID;
}ActiveSource_T;

/* Active Source Name (0x11) data types */

typedef struct __attribute__ ((__packed__)) SourceName_Tag
{
    char sourceName[MAX_STRING_SIZE];
}SourceName_T;

/* Current volume (0x12) data types */

typedef struct __attribute__ ((__packed__)) CurrentVolume_Tag
{
    uint8_t volume;
    bool_t  changingVolume;
}CurrentVolume_T;

/* Mute (0x13) data types */

typedef enum MuteState_Tag
{
    MuteState_Unmuted   = 0x00,
    MuteState_Muted     = 0x01,
}MuteState_T;

typedef struct __attribute__ ((__packed__)) Mute_Tag
{
    MuteState_T  muteState;
}Mute_T;

/* Source state (0x14) data types */

typedef enum StateInfo_Tag
{
    StateInfo_Unknown   = 0x00,
    StateInfo_Scan      = 0x01,
    StateInfo_Mix       = 0x02,
    StateInfo_Repeat    = 0x03,
    StateInfo_RepeatMix = 0x04,
}StateInfo_T;

typedef struct __attribute__ ((__packed__)) SourceState_Tag
{
    StateInfo_T  stateInfo;
}SourceState_T;

/* Current station info (0x15) data types */

typedef struct __attribute__ ((__packed__)) CurrentStationInfo_Tag
{
    char        infoText1[MAX_STRING_SIZE];
    char        infoText2[MAX_STRING_SIZE];
    char        infoText3[MAX_STRING_SIZE];
    uint8_t     stationInfoSwitches;
    uint16_t    fsgHandle;
}CurrentStationInfo_T;

/* InfoList (0x17) data types */

typedef struct __attribute__ ((__packed__)) ArrayHeader_Tag
{
    uint8_t     mode;
    uint16_t    start;
    uint16_t    elements;
}ArrayHeader_T;

typedef enum ArrayRecordAddress_Tag
{
    ArrayRecordAdress_All                       = 0x0,
    ArrayRecordAdress_Inserted                  = 0x0,
    ArrayRecordAdress_Deleted                   = 0x0,
    ArrayRecordAdress_NameOnly                  = 0x1,
    ArrayRecordAdress_TypeAndAttributes         = 0x2,
    ArrayRecordAdress_AttributesOnly            = 0x4,
    ArrayRecordAdress_TypeAndAttributesAndName  = 0x7,
    ArrayRecordAdress_PosOnly                   = 0xF,
}ArrayRecordAddress_T;

typedef enum ArrayDirection_Tag
{
    ArrayDirection_Backward = 0,
    ArrayDirection_Forward = 1,
}ArrayDirection_T;

typedef enum ArrayIndexSize_Tag
{
    ArrayIndexSize_8Bits = 0,
    ArrayIndexSize_16Bits = 1,
}ArrayIndexSize_T;

typedef struct __attribute__ ((__packed__)) ArrayHeaderPrms_Tag
{
    ArrayRecordAddress_T    recordAddress;
    ArrayDirection_T        arrayDirection;
    ArrayIndexSize_T        idxSize;
    bool_t                  posTransmit;
    bool_t                  unknownParam;
    uint16_t                start;
    uint16_t                elements;
}ArrayHeaderPrms_T;

typedef enum SingleEntryType_Tag
{
    SingleEntryType_Unknown     = 0x00,
    SingleEntryType_Directory   = 0x01,
    SingleEntryType_Filename    = 0x02,
    SingleEntryType_StationName = 0x03,
    SingleEntryType_Reserved    = 0x04,
}SingleEntryType_T;

typedef enum SingleEntryAttributes_Tag
{
    SingleEntryAttributes_NotSelectable   = 0x00,
    SingleEntryAttributes_Selectable      = 0x01,
    SingleEntryAttributes_Reserved        = 0x02,
}SingleEntryAttributes_T;

typedef struct __attribute__ ((__packed__)) SingleEntry_Tag
{
    uint16_t                    pos;
    uint8_t                     typeAndAttributes;
    char                        name[MAX_STRING_SIZE];
}SingleEntry_T;

#define SIZE_ARRAY 6

typedef struct __attribute__ ((__packed__)) Array_Tag
{
    SingleEntry_T   entry[SIZE_ARRAY];
}Array_T;

typedef struct __attribute__ ((__packed__)) InfoList_StatusArray_Tag
{
    ArrayHeader_T   arrayHeader;
    uint16_t        totalNumListElements;
    Array_T         arrayData;
}InfoList_StatusArray_T;

/* Dedicated audio control (0x17) data types */

typedef enum DedicatedAudioControl_Result_Tag
{
    AudioControlResult_Succesful        = 0x00,
    AudioControlResult_NotSuccesful     = 0x01,
    AudioControlResult_AbortSuccesful   = 0x02,
    AudioControlResult_AbortNotSuccesful= 0x03,
}DedicatedAudioControl_Result_T;

typedef enum ControlType_Tag
{
    ControlType_SelectListEntry = 0x00,
    ControlType_Next            = 0x01,
    ControlType_Prev            = 0x02,
    ControlType_FastForward     = 0x03,
    ControlType_FastBackward    = 0x04,
    ControlType_ChannelUp       = 0x05,
    ControlType_ChannelDown     = 0x06,
}ControlType_T;

typedef struct __attribute__ ((__packed__)) DedicatedAudioControl_StartResult_Tag
{
    ControlType_T   controlType;
    uint16_t        aditionalControlInformation;
}DedicatedAudioControl_StartResult_T;

/* InfoList Type (0x1D) datatypes */
typedef enum ListType_Tag
{
    InfoListType_Unknown        = 0x00,
    InfoListType_TrackList      = 0x01,
    InfoListType_PresetList     = 0x02,
    InfoListType_ReceptionList  = 0x03,
    InfoListType_AutoStoreList  = 0x04,
    InfoListType_FileList       = 0x05,
    InfoListType_CDList         = 0x05,
    InfoListType_Reserved       = 0x06,
}ListType_T;

typedef struct __attribute__ ((__packed__)) InfoListType_Tag
{
    ListType_T      type;
}InfoListType_T;

/* BAP General data types */

typedef enum AUDIO_Error_t
{
    NoError = 0,
    Err   = 1,
}Error_T;

typedef enum OpCode_t
{
    Opcode_Get = 0,
    Opcode_Set,
    Opcode_SetGet,
    Opcode_Status,
    Opcode_HeartbeatStatus,
    Opcode_Start,
    Opcode_Abort,
    Opcode_StartResult,
    Opcode_Processing,
    Opcode_Result,
    Opcode_GetArray,
    Opcode_StatusArray,
    Opcode_ChangedArray,
    Opcode_Error,
    Opcode_Reset,
    NUM_OPCODES,
}OpCode_T;


typedef enum Type_t
{
    Type_Void = 0,
    Type_ByteSequence,
    Type_FixedByteSequence,
    Type_Int8,
    Type_Int16,
    Type_Int32,
}Type_T;

typedef enum FctClass_t
{
    FctClass_Cache,
    FctClass_Property,
    FctClass_Array,
    FctClass_Method,
}FctClass_T;

/* LSG Tables */

#define BAP_AUDIO_TABLE(LSG)                                                     \
    LSG( AUDIO,       0x31)                                                      \

/* FCT Tables */

#define BAP_AUDIO_CACHE_TABLE(FCT)                                                                                              \
    /*   LSG           FCT Name                 Fct-Class                Fct-Id Opcode Table                            */      \
    FCT( AUDIO,        GET_ALL,                 FctClass_Cache,          0x01,  BAP_AUDIO_GET_ALL_TABLE                 )       \

#define BAP_AUDIO_COMMON_PROPERTY_TABLE(FCT)                                                                                    \
    /*   LSG           FCT Name                 Fct-Class                Fct-Id Opcode Table                            */      \
    FCT( AUDIO,        BAP_CONFIG,              FctClass_Property,       0x02,  BAP_AUDIO_BAP_CONFIG_TABLE              )       \
    FCT( AUDIO,        FUNCTION_LIST,           FctClass_Property,       0x03,  BAP_AUDIO_FUNCTION_LIST_TABLE           )       \
    FCT( AUDIO,        HEARTBEAT,               FctClass_Property,       0x04,  BAP_AUDIO_HEARTBEAT_TABLE               )       \

#define BAP_AUDIO_SPECIFIC_PROPERTY_TABLE(FCT)                                                                                  \
    /*   LSG           FCT Name                 Fct-Class                Fct-Id Opcode Table                            */      \
    FCT( AUDIO,        FSG_SETUP,               FctClass_Property,       0x0E,  BAP_AUDIO_FSG_SETUP_TABLE               )       \
    FCT( AUDIO,        FSG_OPERATION_STATE,     FctClass_Property,       0x0F,  BAP_AUDIO_FSG_OPERATION_STATE_TABLE     )       \
    FCT( AUDIO,        ACTIVE_SOURCE,           FctClass_Property,       0x10,  BAP_AUDIO_ACTIVE_SOURCE_TABLE           )       \
    FCT( AUDIO,        ACTIVE_SOURCE_NAME,      FctClass_Property,       0x11,  BAP_AUDIO_ACTIVE_SOURCE_NAME_TABLE      )       \
    FCT( AUDIO,        CURRENT_VOLUME,          FctClass_Property,       0x12,  BAP_AUDIO_CURRENT_VOLUME_TABLE          )       \
    FCT( AUDIO,        MUTE,                    FctClass_Property,       0x13,  BAP_AUDIO_MUTE_TABLE                    )       \
    FCT( AUDIO,        SOURCE_STATE,            FctClass_Property,       0x14,  BAP_AUDIO_SOURCE_STATE_TABLE            )       \
    FCT( AUDIO,        CURRENT_STATION_INFO,    FctClass_Property,       0x15,  BAP_AUDIO_CURRENT_STATION_INFO_TABLE    )       \
    FCT( AUDIO,        INFO_LIST_TYPE,          FctClass_Property,       0x1D,  BAP_AUDIO_INFO_LIST_TYPE_TABLE          )       \

#define BAP_AUDIO_ARRAY_TABLE(FCT)                                                                                              \
    /*   LSG           FCT Name                 Fct-Class                Fct-Id Opcode Table                            */      \
    FCT( AUDIO,        INFO_LIST,               FctClass_Array,          0x16,  BAP_AUDIO_INFO_LIST_TABLE               )       \

#define BAP_AUDIO_METHOD_TABLE(FCT)                                                                                             \
    /*   LSG           FCT Name                 Fct-Class                Fct-Id Opcode Table                            */      \
    FCT( AUDIO,        DEDICATED_AUDIO_CONTROL, FctClass_Method,         0x17,  BAP_AUDIO_DEDICATED_AUDIO_CONTROL_TABLE )       \

#define BAP_AUDIO_CUSTOM_TABLE(FCT)


#define BAP_AUDIO_PROPERTY_TABLE(FCT)                                            \
    BAP_AUDIO_COMMON_PROPERTY_TABLE(FCT)                                         \
    BAP_AUDIO_SPECIFIC_PROPERTY_TABLE(FCT)                                       \

#define BAP_AUDIO_FUNCTION_TABLE(FCT)                                            \
    BAP_AUDIO_CACHE_TABLE(FCT)                                                   \
    BAP_AUDIO_PROPERTY_TABLE(FCT)                                                \
    BAP_AUDIO_ARRAY_TABLE(FCT)                                                   \
    BAP_AUDIO_METHOD_TABLE(FCT)                                                  \

/* FCT/Opcode Tables */

#define BAP_AUDIO_GET_ALL_TABLE(OPCODE)                                                                                                                 \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  GET_ALL,                    Opcode_GetAll,              Type_Void,               0,              uint8_t                                )   \
   OPCODE(  GET_ALL,                    Opcode_StatusAll,           Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  GET_ALL,                    Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_BAP_CONFIG_TABLE(OPCODE)                                                                                                              \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  BAP_CONFIG,                 Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  BAP_CONFIG,                 Opcode_Status,              Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  BAP_CONFIG,                 Opcode_HeartbeatStatus,     Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  BAP_CONFIG,                 Opcode_Reset,               Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  BAP_CONFIG,                 Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_FUNCTION_LIST_TABLE(OPCODE)                                                                                                           \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  FUNCTION_LIST,              Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  FUNCTION_LIST,              Opcode_Status,              Type_Int8,               0,              uint8_t                                )   \
   OPCODE(  FUNCTION_LIST,              Opcode_HeartbeatStatus,     Type_Int8,               0,              uint8_t                                )   \
   OPCODE(  FUNCTION_LIST,              Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_HEARTBEAT_TABLE(OPCODE)                                                                                                               \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  HEARTBEAT,                  Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  HEARTBEAT,                  Opcode_Status,              Type_Int8,               0,              uint8_t                                )   \
   OPCODE(  HEARTBEAT,                  Opcode_HeartbeatStatus,     Type_Int8,               0,              uint8_t                                )   \
   OPCODE(  HEARTBEAT,                  Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_FSG_SETUP_TABLE(OPCODE)                                                                                                               \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  FSG_SETUP,                  Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  FSG_SETUP,                  Opcode_Status,              Type_Int8,               1,              FSGSetup_T                             )   \
   OPCODE(  FSG_SETUP,                  Opcode_HeartbeatStatus,     Type_Int8,               1,              FSGSetup_T                             )   \
   OPCODE(  FSG_SETUP,                  Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_FSG_OPERATION_STATE_TABLE(OPCODE)                                                                                                     \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  FSG_OPERATION_STATE,        Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  FSG_OPERATION_STATE,        Opcode_Status,              Type_Int8,               1,              FSGOperationState_T                    )   \
   OPCODE(  FSG_OPERATION_STATE,        Opcode_HeartbeatStatus,     Type_Int8,               1,              FSGOperationState_T                    )   \
   OPCODE(  FSG_OPERATION_STATE,        Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_ACTIVE_SOURCE_TABLE(OPCODE)                                                                                                           \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  ACTIVE_SOURCE,              Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  ACTIVE_SOURCE,              Opcode_Status,              Type_FixedByteSequence,  4,              ActiveSource_T                         )   \
   OPCODE(  ACTIVE_SOURCE,              Opcode_HeartbeatStatus,     Type_FixedByteSequence,  4,              ActiveSource_T                         )   \
   OPCODE(  ACTIVE_SOURCE,              Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_ACTIVE_SOURCE_NAME_TABLE(OPCODE)                                                                                                      \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  ACTIVE_SOURCE_NAME,         Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  ACTIVE_SOURCE_NAME,         Opcode_Status,              Type_ByteSequence,       49,             SourceName_T                           )   \
   OPCODE(  ACTIVE_SOURCE_NAME,         Opcode_HeartbeatStatus,     Type_ByteSequence,       49,             SourceName_T                           )   \
   OPCODE(  ACTIVE_SOURCE_NAME,         Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_CURRENT_VOLUME_TABLE(OPCODE)                                                                                                          \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  CURRENT_VOLUME,             Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  CURRENT_VOLUME,             Opcode_Status,              Type_FixedByteSequence,  2,              CurrentVolume_T                        )   \
   OPCODE(  CURRENT_VOLUME,             Opcode_HeartbeatStatus,     Type_FixedByteSequence,  2,              CurrentVolume_T                        )   \
   OPCODE(  CURRENT_VOLUME,             Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_MUTE_TABLE(OPCODE)                                                                                                                    \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  MUTE,                       Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  MUTE,                       Opcode_SetGet,              Type_Int8,               1,              Mute_T                                 )   \
   OPCODE(  MUTE,                       Opcode_Status,              Type_Int8,               1,              Mute_T                                 )   \
   OPCODE(  MUTE,                       Opcode_HeartbeatStatus,     Type_Int8,               1,              Mute_T                                 )   \
   OPCODE(  MUTE,                       Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_SOURCE_STATE_TABLE(OPCODE)                                                                                                            \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  SOURCE_STATE,               Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  SOURCE_STATE,               Opcode_Status,              Type_Int8,               1,              SourceState_T                          )   \
   OPCODE(  SOURCE_STATE,               Opcode_HeartbeatStatus,     Type_Int8,               1,              SourceState_T                          )   \
   OPCODE(  SOURCE_STATE,               Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_CURRENT_STATION_INFO_TABLE(OPCODE)                                                                                                    \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  CURRENT_STATION_INFO,       Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  CURRENT_STATION_INFO,       Opcode_Status,              Type_ByteSequence,       150,            CurrentStationInfo_T                   )   \
   OPCODE(  CURRENT_STATION_INFO,       Opcode_HeartbeatStatus,     Type_ByteSequence,       150,            CurrentStationInfo_T                   )   \
   OPCODE(  CURRENT_STATION_INFO,       Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

/* ArrayHeaderSize = Mode (1 byte) + Start (2 byte) + Elements (2 byte) = 5 bytes */
/* SIngleEntrySize = Pos  (2 bytes) + Type (0.5 byte) + Attributes (0.5 byte) + Name (49 bytes) = 52 bytes */
/* StatusArraySize = TotalNumListElements (2 byte) + ArrayHeaderSize (5 bytes) + SIZE_ARRAY*(SingleEntrySize (52 bytes))
 *
 * SIZE_ARRAY <= (Nmax = 6)
 *
 * StatusArraySizeMin = 7 bytes
 * StatusArraySize = 7 + N*52 bytes
 * StatusArraySizeMax = 319 bytes
 *
 * 59 < StatusArraySize < 319
 *
 * */

#define BAP_AUDIO_INFO_LIST_TABLE(OPCODE)                                                                                                               \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  INFO_LIST,                  Opcode_GetArray,            Type_ByteSequence,       5,              ArrayHeader_T                          )   \
   OPCODE(  INFO_LIST,                  Opcode_StatusArray,         Type_ByteSequence,       319,            InfoList_StatusArray_T                 )   \
   OPCODE(  INFO_LIST,                  Opcode_ChangedArray,        Type_ByteSequence,       5,              ArrayHeader_T                          )   \
   OPCODE(  INFO_LIST,                  Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_DEDICATED_AUDIO_CONTROL_TABLE(OPCODE)                                                                                                 \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  DEDICATED_AUDIO_CONTROL,    Opcode_Processing,          Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  DEDICATED_AUDIO_CONTROL,    Opcode_Result,              Type_Int8,               1,              DedicatedAudioControl_Result_T         )   \
   OPCODE(  DEDICATED_AUDIO_CONTROL,    Opcode_StartResult,         Type_FixedByteSequence,  3,              DedicatedAudioControl_StartResult_T    )   \
   OPCODE(  DEDICATED_AUDIO_CONTROL,    Opcode_Abort,               Type_Void,               0,              uint8_t                                )   \
   OPCODE(  DEDICATED_AUDIO_CONTROL,    Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_GENERAL_INFO_SWITCHES_TABLE(OPCODE)                                                                                                   \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  GENERAL_INFO_SWITCHES,      Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  GENERAL_INFO_SWITCHES,      Opcode_SetGet,              Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  GENERAL_INFO_SWITCHES,      Opcode_Status,              Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  GENERAL_INFO_SWITCHES,      Opcode_HeartbeatStatus,     Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  GENERAL_INFO_SWITCHES,      Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_TA_INFO_TABLE(OPCODE)                                                                                                                 \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  TA_INFO,                    Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  TA_INFO,                    Opcode_Status,              Type_ByteSequence,       32,             uint8_t                                )   \
   OPCODE(  TA_INFO,                    Opcode_HeartbeatStatus,     Type_ByteSequence,       32,             uint8_t                                )   \
   OPCODE(  TA_INFO,                    Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_TA_ESCAPE_TABLE(OPCODE)                                                                                                               \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  TA_ESCAPE,                  Opcode_Processing,          Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  TA_ESCAPE,                  Opcode_Result,              Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  TA_ESCAPE,                  Opcode_StartResult,         Type_Void,               0,              uint8_t                                )   \
   OPCODE(  TA_ESCAPE,                  Opcode_Abort,               Type_Void,               0,              uint8_t                                )   \
   OPCODE(  TA_ESCAPE,                  Opcode_Error,               Type_Int8,               1,              Error_T                                )   \


#define BAP_AUDIO_INFO_STATES_TABLE(OPCODE)                                                                                                             \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  INFO_STATES,                Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  INFO_STATES,                Opcode_Status,              Type_ByteSequence,       1,              uint8_t                                )   \
   OPCODE(  INFO_STATES,                Opcode_HeartbeatStatus,     Type_ByteSequence,       1,              uint8_t                                )   \
   OPCODE(  INFO_STATES,                Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_INFO_LIST_TYPE_TABLE(OPCODE)                                                                                                          \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  INFO_LIST_TYPE,             Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  INFO_LIST_TYPE,             Opcode_Status,              Type_Int8,               1,              InfoListType_T                         )   \
   OPCODE(  INFO_LIST_TYPE,             Opcode_HeartbeatStatus,     Type_Int8,               1,              InfoListType_T                         )   \
   OPCODE(  INFO_LIST_TYPE,             Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_AUDIO_SAVE_STATION_TABLE(OPCODE)                                                                                                          \
    /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
    OPCODE(  SAVE_STATION,               Opcode_Processing,          Type_Int8,               1,              uint8_t                                )   \
    OPCODE(  SAVE_STATION,               Opcode_Result,              Type_Int8,               1,              uint8_t                                )   \
    OPCODE(  SAVE_STATION,               Opcode_StartResult,         Type_Void,               0,              uint8_t                                )   \
    OPCODE(  SAVE_STATION,               Opcode_Abort,               Type_Void,               0,              uint8_t                                )   \
    OPCODE(  SAVE_STATION,               Opcode_Error,               Type_Int8,               1,              Error_T                                )   \


#endif /* SOURCE_USER_APP_BAP_APPL_BAP_AUDIO_BAP_AUDIO_ACFG_H_ */
