/*===========================================================================*/
/**
 * @file bap_audio_utils.c
 *
 * BAP utils functions for AUDIO protocol
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2022 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include <bap_audio_utils.h>
#include <console.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/* Default base used to convert string to int when calling strtol() function */
#define STRING_TO_INT_DEFAULT_BASE     10

/* AM frequency constraints */
#define AM_MIN_FREQUENCY_kHz          RADIO_AM_LOWER_LIMIT     // 530  kHz
#define AM_MAX_FREQUENCY_kHz          RADIO_AM_UPPER_LIMIT     // 1710 kHz

/* Position of decimal point for AM frequency (0 means no decimal point) */
#define AM_FREQUENCY_DP_DIGIT_kHz       0

/* FM frequency constraints */
#define FM_MIN_FREQUENCY_kHz          RADIO_FM_LOWER_LIMIT   // 79.1  MHz
#define FM_MAX_FREQUENCY_kHz          RADIO_FM_UPPER_LIMIT   // 108.0 MHz

/* FM mid frequency
 * this frequency is relevant because it changes
 * the decimal point position for FM frequency string
 */
#define FM_MID_FREQUENCY_kHz         100000   // 100.0 MHz

/* Position of decimal point for FM */
#define FM_FREQUENCY_DP_DIGIT_kHz         2

/* Number of digits of int part for FM frequency
 * lower than FM_MID_FREQUENCY_kHz
 */
#define FM_LOW_FREQUENCY_IPART_MHz        2

/* Number of digits of int part for FM frequency
 * higher than FM_MID_FREQUENCY_kHz
 */
#define FM_HIGH_FREQUENCY_IPART_MHz       3

#define MAX_NUMBER_ELEMENTS     10

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/* This variable is used to obtain 10^x faster without using pow(10,x)*/
static int powersof10[] = {1, 10, 100, 1000, 10000, 100000, 1000000};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Utils_Encode_Frequency
 *
 * @brief      Encode string representing frequency number in kHz to the
 *             required unit by BAP
 *
 * @param[in/out] freq_string - String representing frequency in kHz unit
 *
 * @return     str_to_int_errno - Indicates if the operation succeeded,
 *             or why it failed.
 *
 ******************************************************************************/
encode_freq_errno BAP_AUDIO_Utils_Encode_Frequency(char * freq_string)
{
    uint32_t freq_number = 0;

   /* Check if the string was converted to a valid number */
   if(BAP_AUDIO_Utils_StringToInt(&freq_number,freq_string) != STR_TO_INT_SUCCESS)
   {
       return ENCODE_FREQUENCY_INCONVERTIBLE;
   }

   /* Check the frequency number to know the band */
   if(BAP_AUDIO_Utils_Encode_FrequencyNumber(freq_number,freq_string) != ENCODE_FREQUENCY_SUCCESS)
   {
       return ENCODE_FREQUENCY_INVALID;
   }

   return ENCODE_FREQUENCY_SUCCESS;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Utils_Encode_Frequency
 *
 * @brief      Encode frequencia number in kHz to a string representin the
 *             required unit by BAP
 *
 * @param[in/out] freq_string - String representing frequency in kHz uBAP_AUDIO_nit
 *
 * @return     str_to_int_errno - Indicates if the operation succeeded,
 *             or why it failed.
 *
 ******************************************************************************/
encode_freq_errno BAP_AUDIO_Utils_Encode_FrequencyNumber(uint32_t freq_number, char * freq_string)
{
   /* Check if the string is in a valid AM/FM band */
   if((freq_number < AM_MIN_FREQUENCY_kHz)
      || ((freq_number > AM_MAX_FREQUENCY_kHz) && (freq_number < FM_MIN_FREQUENCY_kHz))
      || ((freq_number > FM_MAX_FREQUENCY_kHz))
   )
   {
       return ENCODE_FREQUENCY_INVALID;
   }

   /* Check if the frequency is in the AM band */
   if((freq_number >= AM_MIN_FREQUENCY_kHz)
      && (freq_number <= AM_MAX_FREQUENCY_kHz))
   {
       BAP_AUDIO_Utils_Encode_AM_Frequency(freq_number, freq_string);
   }

   /* Check if the frequency is in the FM band */
   if((freq_number >= FM_MIN_FREQUENCY_kHz)
      && (freq_number <= FM_MAX_FREQUENCY_kHz))
   {
       BAP_AUDIO_Utils_Encode_FM_Frequency(freq_number, freq_string);
   }

   return ENCODE_FREQUENCY_SUCCESS;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Utils_Encode_AM_Frequency
 *
 * @brief      Encode AM frequency in kHz to string in KHz
 *
 * @param[out] freq_string - String representing frequency in kHz unit
 *
 * @param[in]  freq_number - Int epresenting the frequency in kHz
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Utils_Encode_AM_Frequency(uint32_t freq_number, char * freq_string)
{
    BAP_AUDIO_Utils_IntToString(freq_number, freq_string,AM_FREQUENCY_DP_DIGIT_kHz);
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Utils_Encode_FM_Frequency
 *
 * @brief      Encode FM frequency in kHz to string in MHz with decimal
 *             point
 *
 * @param[out] freq_string - String representing frequency in MHz unit
 *
 * @param[in]  freq_number - Int representing the frequency in kHz
 *
 *     The function checks if freq_number is less or greater than 100000 kHz
 *     to know where the decimal point will be in the output string
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_AUDIO_Utils_Encode_FM_Frequency(uint32_t freq_number, char * freq_string)
{
    uint8_t i = 0;

    if(freq_number < FM_MID_FREQUENCY_kHz)
    {
        BAP_AUDIO_Utils_IntToString(freq_number, freq_string,FM_LOW_FREQUENCY_IPART_MHz);
        i = FM_LOW_FREQUENCY_IPART_MHz;
        freq_string[i++] = '.';
        freq_string[i++] = BAP_AUDIO_Utils_GetNthDigit(freq_number,FM_FREQUENCY_DP_DIGIT_kHz);
    }
    else
    {
        BAP_AUDIO_Utils_IntToString(freq_number, freq_string,FM_HIGH_FREQUENCY_IPART_MHz);
        i = FM_HIGH_FREQUENCY_IPART_MHz;
        freq_string[i++] = '.';
        freq_string[i++] = BAP_AUDIO_Utils_GetNthDigit(freq_number,FM_FREQUENCY_DP_DIGIT_kHz);
    }
    freq_string[i++] = '\0';
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Utils_StringToInt
 *
 * @brief      Convert string s to int out.
 *
 * @param[out] out - The converted int. Cannot be NULL.
 *
 * @param[in]  s - Input string to be converted.
 *
 *     The format is the same as strtol,
 *     except that the following are inconvertible:
 *
 *     - empty string
 *     - leading whitespace
 *     - any trailing characters that are not part of the number
 *
 *     Cannot be NULL.
 *
 * @return     str_to_int_errno - Indicates if the operation succeeded,
 *             or why it failed.
 *
 ******************************************************************************/
str_to_int_errno BAP_AUDIO_Utils_StringToInt(uint32_t *out, char *s)
{
    char *end;

    /* Check if the first byte is a space or an empty string */
    if (s[0] == '\0' || isspace(s[0]))
        return STR_TO_INT_INCONVERTIBLE;

    errno = 0;
    long l = strtol(s, &end, STRING_TO_INT_DEFAULT_BASE);

    /* Both checks are needed because INT_MAX == LONG_MAX is possible. */
    if (l > INT_MAX || (errno == ERANGE && l == LONG_MAX))
        return STR_TO_INT_OVERFLOW;

    if (l < INT_MIN || (errno == ERANGE && l == LONG_MIN))
        return STR_TO_INT_UNDERFLOW;

    if (*end != '\0')
        return STR_TO_INT_INCONVERTIBLE;

    *out = l;

    return STR_TO_INT_SUCCESS;
}

/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Utils_IntToString
 *
 * @brief      Convert Int to String
 *
 * @param[in/out]  char* - String to reverse
 *
 * @param[in]      Int   - String length
 *
 * @param[out]     char* - String representation of Int
 *
 * @param[in]      d     - Number of most significant digits
 *                         represented in string.
 *
 *                         x = 1234
 *
 *                         d = 0 -> All number digits -> str = "1234"
 *
 *                         d = 2 -> str = "12"
 *
 * @return         Int   - Number of digits from Int
 *
 ******************************************************************************/
void BAP_AUDIO_Utils_IntToString(uint32_t x, char* str, uint8_t d)
{
    int i = 0;

    // While number x is greater than 0
    while (x) {
        str[i++] = (x % 10) + '0';
        x = x / 10;
    }

    // If number of digits required is more, then
    // add 0s at the beginning
    while (i < d)
        str[i++] = '0';

    // Reverse string
    BAP_AUDIO_Utils_ReverseString(str, i);
    if(d > 0)
    {
        str[d] = '\0';
    }
    else
    {
        str[i] = '\0';
    }
}


/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Utils_ReverseString
 *
 * @brief      Reverse strings
 *
 * @param[in/out]  char* - String to reverse
 *
 * @param[in]      Int   - String length
 *
 * @return         void
 *
 ******************************************************************************/
void BAP_AUDIO_Utils_ReverseString(char* str, int len)
{
    int i = 0, j = len - 1, temp;
    while (i < j)
    {
        temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }
}


/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Utils_GetNthDigit
 *
 * @brief      Get Nth digit from Int number x
 *
 * @param[in]  Int - number x to get Nth digit from
 *
 * @param[in]  Int - Nth digit desired from  where N = 0
 *                   is least significant digit
 *
 * @return     char- Nth digit from x
 *
 ******************************************************************************/
char BAP_AUDIO_Utils_GetNthDigit(int x, int n)
{
    return ((x / powersof10[n]) % 10) + '0';
}


/***************************************************************************//**
 *
 * @fn         BAP_AUDIO_Utils_Encode_Frequency_List
 *
 * @brief      Encode string representing a list with frequency numbers in kHz
 *             to the required unit by BAP. Each frequency contained in the
 *             input string will be added as an element to the list.
 *             E.g.
 *
 *             freq_list_string = "88100|107900|97300|98100"
 *             delimiter = "|"
 *
 *             freq_list[] = {  "88.1",
 *                              "107.9",
 *                              "97.3",
 *                              "98.1"};
 *
 * @param[in]     freq_string - String representing a list of frequency in kHz unit
 * @param[in]     list_delimiter - String representing delimiter of freq_string
 * @param[in]     list_size - max size of freq_list
 * @param[in/out] freq_string - String representing a list of frequency in kHz unit
 *
 * @return     str_to_int_errno - Indicates if the operation succeeded,
 *             or why it failed.
 *
 ******************************************************************************/
uint8_t BAP_AUDIO_Utils_Encode_FrequencyList(char *list, char *listDelimiter, uint32_t decodedList[], uint8_t maxlistSize)
{
    char * listElement;
    uint8_t numElements = 0;
    uint32_t listElementNumber;

    // Extract the first token
    listElement = strtok(list, listDelimiter);

    // Loop through the string to extract all other tokens
    while( listElement != NULL )
    {
       // If the extracted element is valid, encode it
       if(BAP_AUDIO_Utils_StringToInt(&listElementNumber,listElement) != STR_TO_INT_SUCCESS)
       {
           break;
       }

       // Copy obtained element in the output list
       decodedList[numElements] = listElementNumber;

       // Count the obtained element
       numElements++;

       // If the number of obtained elements exceed the max.size
       //of the output break from the loop
       if(numElements == maxlistSize)
       {
           break;
       }

       // Attempt to obtain next element
       listElement = strtok(NULL, listDelimiter);
    }

    // If the number of obtained elements is less than the max.size
    // of the output list, fill the rest of the output list with 0
    memset(decodedList+numElements,0x0000,(maxlistSize-numElements)*sizeof(uint32_t));

    return numElements;
}

