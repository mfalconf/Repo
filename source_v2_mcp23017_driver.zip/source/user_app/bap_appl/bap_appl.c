/*===========================================================================*/
/**
 * @file bap_appl.c
 *
 * BAP Appl module that communicates with the BAP stack
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <project_def.h>
#include <console.h>
#include <can.h>
#include <bap.h>
#include <bap_appl.h>
#include <bap_defines.h>
#include <bap_types.h>

#include <xdc/runtime/Error.h>

#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

#include <can_appl.h>

#include <bap_config.h>
#include <bap_util.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

#define BAP_STACK_SIZE  0x1000  /* 4096 bytes */
#define BAP_TASK_SLEEP  10000   /* 10 ms */

#define BAP_APPL_STATE_NOT_INITIALIZED  0
#define BAP_APPL_STATE_RUNNING          1
#define BAP_APPL_STATE_SHUTDOWN         2
#define BAP_APPL_STATE_ERROR            3

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

uint8_t stackBap[BAP_STACK_SIZE];

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

static void Bap_Task_Thread(UArg arg0, UArg arg1);

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         Bap_Task_Init
 *
 * @brief      Initialization of BAP task
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Bap_Task_Init(void)
{
#if (USE_BAP == 1)
    Error_Block eb;
    Task_Params taskParams;
    Task_Handle task_h;

    LOG_PRINT_INFO(DEBUG_BAP,"Creating BAP task\n");

    Error_init(&eb);

    /* Create Bap Task thread (interrupts not enabled in main on BIOS) */
    Task_Params_init(&taskParams);
    taskParams.instance->name = "bap_task";
    taskParams.arg0 = NULL;
    taskParams.arg1 = NULL;
    taskParams.stack = stackBap;
    taskParams.stackSize = BAP_STACK_SIZE;
    task_h = Task_create(Bap_Task_Thread, &taskParams, &eb);
    if (NULL == task_h)
    {
        LOG_PRINT_ERR(1,"Couldn't create BAP task\n");
    }
    else
    {
        LOG_PRINT_INFO(1,"BAP Task thread created successfully\n");
    }
#endif
}

/***************************************************************************//**
 *
 * @fn         Bap_Task_Thread
 *
 * @brief      Bap Task Thread. BAP main loop
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void Bap_Task_Thread(UArg arg0, UArg arg1)
{
    BapError_et eErr;
    bool_t running = true;
    uint8_t currentCanStatus;
    uint8_t bapApplState = BAP_APPL_STATE_NOT_INITIALIZED;

    LOG_PRINT(DEBUG_BAP, "Initializing Bap Thread \n");

    while(!Can_Initialized())
    {
        LOG_PRINT(DEBUG_BAP,"Waiting for CAN to initialize \r\n");
        Task_sleep(BAP_TASK_SLEEP / Clock_tickPeriod);
    }

    BAP_AUDIO_Sem_Init();
    BAP_TELEPHONY_Sem_Init();

    while(running)
    {
        currentCanStatus = CanAppl_Volkswagen_GetOperationalMode_Status();
        LOG_PRINT(DEBUG_BAP,"BAP Appl > CurrentCanStatus = %d \r\n",currentCanStatus);
        LOG_PRINT(DEBUG_BAP,"BAP Appl > BapApplState  = %d \r\n",bapApplState);

        switch(bapApplState)
        {
            case BAP_APPL_STATE_NOT_INITIALIZED:

                if(currentCanStatus == IGN_ON)
                {
                    eErr = Bap_Appl_Init();

                    if(BapErr_OK != eErr)
                    {
                        LOG_PRINT(ERROR_BAP, "Bap_Appl_Init -> eErr = %d  \n", eErr);
                        bapApplState = BAP_APPL_STATE_ERROR;
                        break;
                    }

                    bapApplState = BAP_APPL_STATE_RUNNING;
                }

            break;

            case BAP_APPL_STATE_RUNNING:

                if(currentCanStatus != IGN_ON)
                {
                    eErr = Bap_Appl_Shutdown();

                    if(BapErr_OK != eErr)
                    {
                        LOG_PRINT(ERROR_BAP, "Bap_Appl_Shutdown -> eErr = %d  \n", eErr);
                        bapApplState = BAP_APPL_STATE_ERROR;
                        break;
                    }

                    bapApplState = BAP_APPL_STATE_NOT_INITIALIZED;
                }
                else
                {
                    /* Cyclic call to the BAP Application */
                    eErr = Bap_Appl_Task();

                    if(BapErr_OK != eErr)
                    {
                        LOG_PRINT(ERROR_BAP, "Bap_Appl_Task -> eErr = %d  \n", eErr);
                        bapApplState = BAP_APPL_STATE_ERROR;
                        break;
                    }

                    /* Trigger BAP stack */
                    BAP_Task();
                }

            break;

            case BAP_APPL_STATE_ERROR:

                eErr = Bap_Appl_Shutdown();

                if(BapErr_OK != eErr)
                {
                    LOG_PRINT(ERROR_BAP, "Bap_Appl_Init -> eErr = %d  \n", eErr);
                }

                eErr = Bap_Appl_Init();

                if(BapErr_OK != eErr)
                {
                    LOG_PRINT(ERROR_BAP, "Bap_Appl_Init -> eErr = %d  \n", eErr);
                    break;
                }

                bapApplState = BAP_APPL_STATE_RUNNING;

            break;
        }

        Task_sleep(BAP_TASK_SLEEP / Clock_tickPeriod);
    }

    /* TODO: Check why we can't send all threads to sleep. The ipu1 crashes if we try it
    * We should call 
    * running = MN_Keep_Running();
    */
   LOG_PRINT(DEBUG_BAP, "Shutdown Bap Thread \n");
}

/***************************************************************************//**
 *
 * @fn         Bap_Appl_Init
 *
 * @brief      Initialize BAP Appl
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
BapError_et Bap_Appl_Init(void)
{
    BapError_et eErr;

    /* Init AUDIO (FSG) */
    if(((eErr = BAP_Init_LSG(BapLsg_AUDIO_Id)) != BapErr_OK))
    {
        LOG_PRINT(ERROR_BAP, "BAP_Init_LSG -> lsgId = %x eErr = %d  \n", BapLsg_AUDIO_Id, eErr);
        return eErr;
    }

    /* Init Telephony (FSG) */
    if(((eErr = BAP_Init_LSG(BapLsg_TELEPHONY_Id)) != BapErr_OK))
    {
        LOG_PRINT(ERROR_BAP, "BAP_Init_LSG -> lsgId = %x eErr = %d  \n", BapLsg_TELEPHONY_Id, eErr);
        return eErr;
    }

    return BapErr_OK;
}

/***************************************************************************//**
 *
 * @fn         BAP_Init_LSG
 *
 * @brief      Initialize LSG from given LSG Id
 *
 * @param [in] lsgId_t aLsgId
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_Init_LSG(lsgId_t aLsgId)
{
    BapError_et eErr = BapErr_OK;
	DBGVAR BapLsgRomRow_pot poLsgRomRow = BAP_GetLsgRomRow(aLsgId);
    BapLayerLsgStatus_et lsgStatus;

    lsgStatus = poLsgRomRow->poLsgRamRow->eLsgStatus;

    switch(lsgStatus)
    {
        case BapLayerLsgStat_NoInit:

            /* Init BAP AUDIO LSG only if the LSG is not already initialized. 
            If the LSG is already initialized BAP_Init is not called and the 
            LSG is restarted*/
            eErr = BAP_Init(aLsgId);

            if(eErr != BapErr_OK)
            {
                LOG_PRINT(ERROR_BAP, "BAP_Init -> eErr = %d  \n", eErr);
                return eErr;
            }
            else
            {
                /* Start LSG */
                eErr = BAP_Start_LSG(aLsgId);

                if(eErr != BapErr_OK)
                {
                    LOG_PRINT(ERROR_BAP, "BAP_Start_LSG -> eErr = %d  \n", eErr);
                }
            }

        break;

        case BapLayerLsgStat_Initialized:

            /* Start LSG */
            eErr = BAP_Start_LSG(aLsgId);

            if(eErr != BapErr_OK)
            {
                LOG_PRINT(ERROR_BAP, "BAP_Start_LSG -> eErr = %d  \n", eErr);
            }

        break;

        case BapLayerLsgStat_Running:
            LOG_PRINT(DEBUG_BAP, "BAP_AUDIO_Init -> LSG is running \n");
        break;

        case BapLayerLsgStat_WaitForOrInvalidConfig:
            eErr = BapErr_InvalidState;
        break;
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_Start_LSG
 *
 * @brief      Start LSG from given LSG Id
 *
 * @param [in] lsgId_t aLsgId
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_Start_LSG(lsgId_t aLsgId)
{
    BapError_et eErr = BapErr_OK;

    /* Init value for all Property Fcts */
    eErr = BAP_Property_Init(aLsgId);

    if(eErr != BapErr_OK)
    {
        LOG_PRINT(ERROR_BAP, "BAP_AUDIO_Property_Init -> eErr = %d  \n", eErr);
    }
    else
    {
        /* Start BAP AUDIO LSG */
        eErr = BAP_Start(aLsgId);

        if(eErr != BapErr_OK)
        {
            LOG_PRINT(ERROR_BAP, "BAP_Start -> eErr = %d  \n", eErr);
        }
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_Property_InitValues
 *
 * @brief      Set initial values for a given LSG Id
 *
 * @param [in] lsgId_t aLsgId
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_Property_InitValues(lsgId_t aLsgId)
{
    if(aLsgId == BapLsg_AUDIO_Id)
    {
        BAP_AUDIO_Property_InitValues();
    }else if(aLsgId == BapLsg_TELEPHONY_Id)
    {
        BAP_TELEPHONY_Property_InitValues();
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_Property_Init
 *
 * @brief      Send initial values for a given LSG Id
 *
 * @param [in] lsgId_t aLsgId
 *
 * @return     void
 *
 ******************************************************************************/
BapError_et BAP_Property_Init(lsgId_t aLsgId)
{
    BapError_et eErr = BapErr_OK;

    if(aLsgId == BapLsg_AUDIO_Id)
    {
        eErr = BAP_AUDIO_Property_Init();
    }else if(aLsgId == BapLsg_TELEPHONY_Id)
    {
        eErr = BAP_TELEPHONY_Property_Init();
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         Bap_Appl_Shutdown
 *
 * @brief      Shutdown BAP Appl
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
BapError_et Bap_Appl_Shutdown(void)
{
    BapError_et eErr;

    eErr = BAP_Shutdown_LSG(BapLsg_AUDIO_Id);

    if(BapErr_OK != eErr)
    {
        LOG_PRINT(ERROR_BAP, "BAP_Shutdown(AUDIO) -> eErr = %d  \n", eErr);
        return eErr;
    }

    eErr = BAP_Shutdown_LSG(BapLsg_TELEPHONY_Id);

    if(BapErr_OK != eErr)
    {
        LOG_PRINT(ERROR_BAP, "BAP_Shutdown(PHONE) -> eErr = %d  \n", eErr);
        return eErr;
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_Shutdown_LSG
 *
 * @brief      Shutdown LSG from given LSG Id
 *
 * @param [in] lsgId_t aLsgId
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_Shutdown_LSG(lsgId_t aLsgId)
{
    BapError_et eErr;
	bool_t lsgStatus = BAP_GetLsgState(aLsgId);

    if(lsgStatus == BAP_TRUE)
    {
        eErr = BAP_Shutdown(aLsgId);

        if(BapErr_OK != eErr)
        {
            LOG_PRINT(ERROR_BAP, "BAP_Shutdown(AUDIO) -> eErr = %d  \n", eErr);
            return eErr;
        }
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         Bap_Appl_Task
 *
 * @brief      Cyclical BAP Appl Task
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
BapError_et Bap_Appl_Task(void)
{
    BapError_et eErr;

    eErr = BAP_AUDIO_Task();

    if(BapErr_OK != eErr)
    {
        LOG_PRINT(ERROR_BAP, "BAP_AUDIO_Task -> eErr = %d  \n", eErr);
    }

    eErr = BAP_TELEPHONY_Task();

    if(BapErr_OK != eErr)
    {
        LOG_PRINT(ERROR_BAP, "BAP_TELEPHONY_Task -> eErr = %d  \n", eErr);
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_Acknowledge
 *
 * @brief      Is called when an Void indication arrives
 *             See BAP API documentation for details
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_Acknowledge(lsgId_t aLsgId, fctId_t aFctId,
                     BapAcknowledge_et aeAcknowledge)
{
    LOG_PRINT(DEBUG_BAP, "BAP_Acknowledge > aLsgId = %x  \n",aLsgId);
    LOG_PRINT(DEBUG_BAP, "BAP_Acknowledge > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP, "BAP_Acknowledge > aeAcknowledge = %d  \n",aeAcknowledge);

    switch(aLsgId)
    {
        case BapLsg_AUDIO_Id:
            BAP_AUDIO_Acknowledge(aFctId,aeAcknowledge);
        break;

        case BapLsg_TELEPHONY_Id:
            BAP_TELEPHONY_Acknowledge(aFctId,aeAcknowledge);
        break;

        default:

        break;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_IndicationVoid
 *
 * @brief      Is called when an Void indication arrives
 *             See BAP API documentation for details
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_IndicationVoid(lsgId_t aLsgId, fctId_t aFctId
                        , BapIndication_et aeIndication)
{

    LOG_PRINT(DEBUG_BAP, "BAP_IndicationVoid > aLsgId = %x  \n",aLsgId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationVoid > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationVoid > aeIndication = %d  \n",aeIndication);

    switch(aLsgId)
    {
        case BapLsg_AUDIO_Id:
            BAP_AUDIO_IndicationVoid(aFctId,aeIndication);
        break;

        case BapLsg_TELEPHONY_Id:
            BAP_TELEPHONY_IndicationVoid(aFctId,aeIndication);
        break;

        default:

        break;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_IndicationInt8
 *
 * @brief      Is called when an Int8 indication arrives
 *             See BAP API documentation for details
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_IndicationInt8(lsgId_t aLsgId, fctId_t aFctId
                        , BapIndication_et aeIndication, uint8_t au8Value)
{

    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt8 > aLsgId = %x  \n",aLsgId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt8 > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt8 > aeIndication = %d  \n",aeIndication);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt8 > au8Value = %d  \n",au8Value);

    switch(aLsgId)
    {
        case BapLsg_AUDIO_Id:
            BAP_AUDIO_IndicationInt8(aFctId,aeIndication,au8Value);
        break;

        case BapLsg_TELEPHONY_Id:
            BAP_TELEPHONY_IndicationInt8(aFctId,aeIndication,au8Value);
        break;

        default:

        break;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_IndicationInt16
 *
 * @brief      Is called when an Int16 indication arrives
 *             See BAP API documentation for details
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_IndicationInt16(lsgId_t aLsgId, fctId_t aFctId
                         , BapIndication_et aeIndication, uint16_t au16Value)
{

    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt16 > aLsgId = %x  \n",aLsgId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt16 > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt16 > aeIndication = %d  \n",aeIndication);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt16 > au16Value = %d  \n",au16Value);

    switch(aLsgId)
    {
        case BapLsg_AUDIO_Id:
        /* Is not required in this application since AUDIO
         *  does not support the data type */
        break;

        case BapLsg_TELEPHONY_Id:
        /* Is not required in this application since TELEPHONY
         *  does not support the data type */    
        break;

        default:

        break;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_IndicationInt32
 *
 * @brief      Is called when an Int32 indication arrives
 *             See BAP API documentation for details
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_IndicationInt32(lsgId_t aLsgId, fctId_t aFctId
                         , BapIndication_et aeIndication, uint32_t au32Value)
{

    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt32 > aLsgId = %x  \n",aLsgId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt32 > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt32 > aeIndication = %d  \n",aeIndication);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationInt32 > au32Value = %d  \n",au32Value);

    switch(aLsgId)
    {

        case BapLsg_AUDIO_Id:
        /* Is not required in this application since AUDIO
         *  does not support the data type */
        break;

        case BapLsg_TELEPHONY_Id:
        /* Is not required in this application since TELEPHONY
         *  does not support the data type */    
        break;

        default:

        break;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_IndicationByteSequence
 *
 * @brief      Called when a byte sequence indication arrives
 *             See BAP API documentation for details
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_IndicationByteSequence(lsgId_t aLsgId, fctId_t aFctId
                                , BapIndication_et aeIndication
                                , const volatile_ptr_t apValue
                                , uint16_t au16Length)
{

    LOG_PRINT(DEBUG_BAP,"BAP_IndicationByteSequence > aLsgId = %x  \n",aLsgId);
    LOG_PRINT(DEBUG_BAP,"BAP_IndicationByteSequence > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP,"BAP_IndicationByteSequence > aeIndication = %x  \n",aeIndication);
    LOG_PRINT(DEBUG_BAP,"BAP_IndicationByteSequence > au16Length = %x  \n",au16Length);

    switch(aLsgId)
    {
        case BapLsg_AUDIO_Id:
            BAP_AUDIO_IndicationByteSequence(aFctId,aeIndication,apValue,au16Length);
        break;

        case BapLsg_TELEPHONY_Id:
            BAP_TELEPHONY_IndicationByteSequence(aFctId,aeIndication,apValue,au16Length);
        break;

        default:

        break;
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_IndicationError
 *
 * @brief      Called when a byte sequence indication arrives
 *             See BAP API documentation for details
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_IndicationError(lsgId_t aLsgId, fctId_t aFctId
                         , BapError_et aeErrorCode)
{
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationError > aLsgId = %x  \n",aLsgId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationError > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP, "BAP_IndicationError > aeErrorCode = %x  \n",aeErrorCode);

    switch(aLsgId)
    {

        case BapLsg_AUDIO_Id:
        /* Is not required in this application since AUDIO
         *  does not support the data type */
        break;

        case BapLsg_TELEPHONY_Id:
        /* Is not required in this application since TELEPHONY
         *  does not support the data type */
        break;

        default:

        break;

    }

}

/**
 * Sendet die Diagnosemeldungen von BAP auf den CAN aus.
 * Details siehe BAP-API-Doku
 */
enum BapError_t BAP_SendDebugInfo(const uint8_t pDebugInfo[8])
{
    enum BapError_t bapErr = BapErr_OK;

    return bapErr;
}


/***************************************************************************//**
 *
 * @fn         BAP_InitSendInt8
 *
 * @brief      Initial status request for Int8 type function
 *
 * @param [in] lsgId_t
 *             fctId_t
 *             uint8_t *
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_InitSendInt8(lsgId_t aLsgId, fctId_t aFctId,uint8_t *pVar)
{
    uint8_t     au8Data;
    BapError_et eErr = BapErr_OK;

    au8Data = pVar[0];

    eErr = BAP_InitSendBufferInt8(aLsgId, aFctId, au8Data);

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_InitSendInt16
 *
 * @brief      Initial status request for Int16 type function
 *
 * @param [in] lsgId_t
 *             fctId_t
 *             uint8_t *
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_InitSendInt16(lsgId_t aLsgId, fctId_t aFctId,uint8_t *pVar)
{
    uint16_t     au16Data;
    BapError_et eErr = BapErr_OK;

    au16Data = pVar[0] | (pVar[1] << 8);

    eErr = BAP_InitSendBufferInt16(aLsgId, aFctId, au16Data);

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_InitSendInt32
 *
 * @brief      Initial status request for Int32 type function
 *
 * @param [in] lsgId_t
 *             fctId_t
 *             uint8_t *
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_InitSendInt32(lsgId_t aLsgId, fctId_t aFctId,uint8_t *pVar)
{
    uint32_t au32Data;
    BapError_et eErr = BapErr_OK;

    au32Data = pVar[0] | (pVar[1] << 8) | (pVar[2] << 16) | (pVar[3] << 24);;

    eErr = BAP_InitSendBufferInt32(aLsgId, aFctId, au32Data);

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_InitSendByteSequence
 *
 * @brief      Initial status request for Int32 type function
 *
 * @param [in] lsgId_t
 *             fctId_t
 *             uint8_t *
 *             uint8_t
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_InitSendByteSequence(lsgId_t aLsgId, fctId_t aFctId,uint8_t *pVar,uint8_t aLength)
{
    uint8_t     au8ArrayData[MAX_LEN];
    BapError_et eErr = BapErr_OK;
    uint8_t i;

    if(aLength > MAX_LEN)
    {
        eErr = BapErr_BadDataLength;
    }
    else
    {
        for(i = 0; i < aLength;i++)
        {
            au8ArrayData[i] = pVar[i];
        }

        eErr = BAP_InitSendBufferByteSequence(aLsgId, aFctId, au8ArrayData, aLength);
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_SendInt8
 *
 * @brief      Send request for Int8 type opcode
 *
 * @param [in] lsgId_t
 *             fctId_t
 *             BapRequest_et
 *             uint8_t *
 *
 * @return     void
 *
 ******************************************************************************/
BapError_et BAP_SendInt8(lsgId_t aLsgId, fctId_t aFctId, BapRequest_et aeRequest, uint8_t *pVar)
{
    uint8_t     au8Data;
    BapError_et eErr = BapErr_OK;

    au8Data = pVar[0];

    eErr = BAP_RequestInt8(aLsgId, aFctId, aeRequest, au8Data);

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_SendInt16
 *
 * @brief      Send request for Int16 type opcode
 *
 * @param [in] lsgId_t
 *             fctId_t
 *             BapRequest_et
 *             uint8_t *
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_SendInt16(lsgId_t aLsgId, fctId_t aFctId, BapRequest_et aeRequest, uint8_t *pVar)
{
    uint16_t     au16Data;
    BapError_et eErr = BapErr_OK;

    au16Data = pVar[0] | (pVar[1] << 8);

    eErr = BAP_RequestInt16(aLsgId, aFctId, aeRequest, au16Data);

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_SendInt32
 *
 * @brief      Status request for Int32 type opcode
 *
 * @param [in] lsgId_t
 *             fctId_t
 *             BapRequest_et
 *             uint8_t *
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_SendInt32(lsgId_t aLsgId, fctId_t aFctId, BapRequest_et aeRequest, uint8_t *pVar)
{
    uint32_t     au32Data;
    BapError_et eErr = BapErr_OK;

    au32Data = pVar[0] | (pVar[1] << 8) | (pVar[2] << 16) | (pVar[3] << 24);

    eErr = BAP_RequestInt32(aLsgId, aFctId, aeRequest, au32Data);

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_SendIntByteSequence
 *
 * @brief      Status request for ByteSequence type opcode
 *
 * @param [in] lsgId_t
 *             fctId_t
 *             BapRequest_et
 *             uint8_t *
 *             uint8_t
 *
 * @return     void
 *
 ******************************************************************************/
BapError_et BAP_SendByteSequence(lsgId_t aLsgId, fctId_t aFctId, BapRequest_et aeRequest, uint8_t *pVar,uint8_t aLength)
{
    uint8_t     au8ArrayData[MAX_LEN];
    BapError_et eErr = BapErr_OK;
    uint8_t i;

    if(aLength > MAX_LEN)
    {
        eErr = BapErr_BadDataLength;
    }
    else
    {
        for(i = 0; i < aLength;i++)
        {
            au8ArrayData[i] = pVar[i];
        }

        eErr = BAP_RequestByteSequence(aLsgId, aFctId, aeRequest, au8ArrayData, aLength);
    }

    return eErr;
}






