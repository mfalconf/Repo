/*===========================================================================*/
/**
 * @file bap_appl_acfg.h
 *
 * Declaration of Logical control devices and the functions implemented by the
 * BAP Application
 *------------------------------------------------------------------------------
 *
 * Copyright 2022 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

#ifndef SOURCE_USER_APP_BAP_APPL_BAP_APPL_ACFG_H_
#define SOURCE_USER_APP_BAP_APPL_BAP_APPL_ACFG_H_

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include "bap_audio/bap_audio_acfg.h"
#include "bap_audio/bap_audio_defines.h"
#include "bap_telephony/bap_telephony_acfg.h"
#include "bap_telephony/bap_telephony_defines.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define X-MACROS
 *===========================================================================*/

#define BAP_LSG_TABLE(LSG)       \
   BAP_AUDIO_TABLE(LSG)          \
   BAP_TELEPHONY_TABLE(LSG)      \

/* Declare one FCT Catalog per LSG declared in BAP_LSG_LIST */
#define BAP_FUNCTION_TABLE(FCT)              \
   BAP_AUDIO_FUNCTION_TABLE(FCT)             \
   BAP_TELEPHONY_FUNCTION_TABLE(FCT)         \

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

#endif /* SOURCE_USER_APP_BAP_APPL_BAP_APPL_ACFG_H_ */
