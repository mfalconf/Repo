/*===========================================================================*/
/**
 * @file bap_bcl_can_interface.c
 *
 * This file contains the adaptation of the BCL CANUBS implementation
 * to the CAN driver
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2022 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/* Systemincludes mit <...> */
#include <stdlib.h>
#include <string.h>

#include "project_def.h"

/* Bibliotheken von externen Herstellen mit <...> */

/* Eigene Header-Dateien "..." */
#if (USE_BAP == 1)
#include "bap_canubs.h"
#include "bap_bclconfig.h"

#include <can.h>

#include <console.h>

#ifdef BAP_RUNTIME_TEST
#include "sw_timer.h"
#endif /*BAP_RUNTIME_TEST */

#ifndef BAP_USES_CAN
#error Die mit BAPgen konfigurierte Datenfestlegung enthaelt kein CAN.
#endif

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*  This function is documented in bap_canubs.h */
BAP_FAR bool_t
BAP_CANUBS_TxData(BapCanInterfaceChannel_t aCanInterfaceChannel
    , BapCanMsgId_t aCanMsgId
    , const ptr_t apData
    , uint8_t au8Length)
{
    DBGVAR bool_t bResult = BAP_TRUE;

    Can_Tx_Message(aCanMsgId,(uint8_t *)apData, au8Length);

    return bResult;
}


/*  This function is documented in bap_canubs.h */
BAP_FAR bool_t
BAP_CANUBS_IsReadyForTx(BapCanInterfaceChannel_t aCanInterfaceChannel
    , BapCanMsgId_t aCanMsgId)
{
    DBGVAR bool_t bResult = BAP_TRUE;

    return bResult;
}

/*  This function is documented in bap_canubs.h */
BAP_FAR void
BAP_CANUBS_InitReadyForTx(BapCanInterfaceChannel_t aCanInterfaceChannel
    , BapCanMsgId_t aCanMsgId)
{
}

void disableint(uint8_t* u8InterruptFlag){
}

void restoreint(uint8_t au8RestoreValue){
}

#endif


