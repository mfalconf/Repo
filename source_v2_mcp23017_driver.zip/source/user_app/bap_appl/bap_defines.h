/*===========================================================================*/
/**
 * @file bap_defines.h
 *
 * This file contains all #defines to adapt the BAP-SSW
 * to the respective control unit type. With the help of macro switches
 * individual functionalities are switched on or off. In order to
 * the SW is optimally adapted to the available resources
 * customized.
 *------------------------------------------------------------------------------
 *
 * Copyright 2022 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
#ifndef SOURCE_USER_APP_BAP_APPL_BAP_DEFINES_H_
#define SOURCE_USER_APP_BAP_APPL_BAP_DEFINES_H_

#ifdef __cplusplus
extern "C" {
#endif

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include <bap_appl_acfg.h>

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/**
 * Macro when using CAN communication
 */
#define BAP_USES_CAN


/**
 * Type Definition des Steuergeraetes
 */
#define BAP_USES_16BIT_CAN_MESSAGE_HANDLE

/**
 * Type Definition of the control unit
 */
#define BAP_SGTYPE_IS_ASG_AND_LARGE_FSG

/**
 * XML version info MAJOR. Together with the BAP_XML_VERSION_MINOR, results in the version.
 */
#define BAP_XML_VERSION_MAJOR 1

/**
 * XML version info MINOR. Together with BAP_XML_VERSION_MAJOR, results in the version
 */
#define BAP_XML_VERSION_MINOR 23

/**
 * Number of rows in the BAP_CanTxRomTable
 */
#define BAP_CAN_TX_ROM_TABLE_ROWS ((uint16_t)BapNumFcts)

/**
 * Number of rows in the BAP_CanRxRomTable
 */
#define BAP_CAN_RX_ROM_TABLE_ROWS ((uint16_t)BapNumFcts)

/**
 * Number of rows in the BAP_InhibitRamTable
 */
#define BAP_INHIBIT_ROWS ((uint16_t)BapNumLsgs)

/**
 * Number of rows in the BAP_CanTxSegmentationChannels
 */
#define BAP_CAN_TX_SEGMENTATION_CHANNELS ((uint16_t)BapNumLsgs)

/**
 * Number of rows in the BAP_CanRxSegmentationChannels
 */
#define BAP_CAN_RX_SEGMENTATION_CHANNELS ((uint16_t)BapNumLsgs)

/**
 * Contains the number of elements of BAP_CanRxRingBuffer.
 */
#define BAP_CAN_RX_RING_BUFFER_SIZE ((uint8_t)3)

/**
 * Number of rows in the BAP_u16InterTelegramTimerTable
 */
#define BAP_INTER_TELEGRAM_TIMER_ROWS ((uint16_t)BapNumFcts)

/**
 *  Holds the number of rows contained in the BAP_LsgRomTables table.
 */
#define BAP_LSG_ROM_TABLE_ROWS ((uint8_t)BapNumLsgs)

/**
 * Holds the number of rows that the table BAP_pLsgRomTable contains.
 */
#define BAP_P_LSG_ROM_TABLE_ROWS ((uint8_t)BapNumLsgs)

/**
 * Contains the number of elements of BAP_FctRomTable.
 */
#define BAP_FCT_ROM_TABLE_ROWS ((uint16_t)BapNumFcts)

/**
 * Contains the number of elements of BAP_BAPConfigTable.
 */
#define BAP_BAPCONFIG_TABLE_ROWS ((uint8_t)BapNumLsgs)

/**
 * Holds the number of rows that the table BAP_MapCanIdToLsgRomRowTable contains.
 */
#define BAP_MAP_CANID_TO_LSGROMROW_TABLE_ROWS ((uint16_t)BapNumLsgs)

/**
 * Holds the number of rows that the table BAP_MapCanIdByLsgToCanTxRomRowTable contains.
 */
#define BAP_MAP_CANIDBYLSG_TO_CANTXROMROW_TABLE_ROWS ((uint16_t)BapNumFcts)

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/**
 *  This listing contains the fileds of BAPConfigTable
 */
typedef enum BapConfig_t
{
    BAPConfig_PV_Major,
    BAPConfig_PV_Minor,
    BAPConfig_SG_Major,
    BAPConfig_SG_Minor,
    BAPConfig_DF_Major,
    BAPConfig_DF_Minor,
}BapConfig_et;

/**
 *  This listing contains all error codes from BAP.
 *  These are returned as a return value in function calls
 */
 typedef enum BapError_t
 {
     /**
     * The function call was successful.
     */
     BapErr_OK = 0x00,

     /* BCL error messages */
     /**
     * Sequence message received without previous start message
     * @remarks
     * As of BAP 1.4, this error code only occurs if after triggering
     * sequence messages follow the BapErr_TimeoutSegmentation error.
     *
     * In previous versions, the error always occurred when a sequence message
     * was received without a start message.
     *
     * Reason for the change: The dynamic channel assignment allows that a
     * CAN-Id/Segmentation channel can now address several LSGs, which are on
     * different physical control units can be realized.
     *
     * Sending a segmented message would have meant that
     * Very many error messages in the currently unaddressed control unit
     * would have been triggered.
     */
     BapErr_IllegalSequence = 0x12,

     /**
     * Unexpected sequence number received.
     */
     BapErr_SequenceNumber = 0x13,

     /**
     * Follow-up message not received in time.
     * The intertelegram time was violated.
     */
     BapErr_TimeoutSegmentation = 0x14,

     /**
     * Data element does not fit in BCL Rx buffer
     */
     BapErr_OversizeSegmentation  = 0x15,

     /**
     * Fewer data bytes were received during data reception than would have been required.
     *
     * @example
     * In the ASG, function 17 is defined as Int16.
     * In the FSG, function 17 is defined as Int8.
     * Data is transmitted via CAN with the variable DLC switched on.
     * The ASG thus receives 3 bytes (2 bytes header + 1 byte user data).
     * Since 1 byte of user data is not sufficient to fill a 16-bit value, the
     * Discarded message and reported this error.
     */
     BapErr_BadDataLength = 0x16,

     /**
     * Buffer overflow when receiving data.
     * If the ring buffer size is correctly configured, this error must not occur.
     */
     BapErr_ReceivedDataLost = 0x17,

     /* BPL error messages */
     /**
     * ASG time monitoring heartbeat - cache was set invalid
     */
     BapErr_TimeoutHeartbeat = 0x21,

     /**
     * All retry's were unsuccessful.
     */
     BapErr_RetryNotSuccessful = 0x22,

     /**
      * The processing message from the FSG did not arrive in the ASG in time
      * Is triggered by the same functionality in the BPL as BapErr_RetryNotSuccessful
      */
     BapErr_ProcessingTimeout = 0x38,

     /**
     * The service was not executed because too many internal services are pending.
     * More detailed description in the return values ​​of the individual functions.
     */
     BapErr_Busy = 0x23,

     /**
     * The maximum expected response time was exceeded without the request
     * could be sent.
     *
     * @remarks This error can also occur with unsegmented messages.
     * @remarks The error only occurs in the ASG.
     */
     BapErr_RequestTimeout = 0x24,


     /* BAL error messages */
     /**
     * The protocol version of the FSG does not match that of the ASG.
     */
     BapErr_IncompatibleProtocolVersion = 0x32,

     /**
     * The data definition of the FSG does not match that of the ASG.
     */
     BapErr_IncompatibleDataSpecification = 0x33,

     /**
     * The data in the cache is invalid.
     * @remarks:
     * Occurs only in the ASG as an asynchronous error.
     */
     BapErr_CacheInvalid = 0x34,

     /**
     * The data in the cache is invalid.
     * @remarks:
     * Occurs only in the ASG as an asynchronous error.
     */
     BapErr_GetAllMessageCorrupted = 0x39,

     /**
     * At least one send buffer was not initialized.
     * @remarks:
     * Occurs only in the FSG as a synchronous error.
     */
     BapErr_SendBufferNotInitialized = 0x3A,

     /**
     * This operation is not allowed in this state.
     * @remarks
     * This error often occurs when BAP_Init or BAP_Start has not been called
     * or after BAP_Shutdown was called.
     * In the ASG, all request calls fail as long as no BAP_Config has been received.
     */
     BapErr_InvalidState = 0x35,

     /**
     * There is no cache for the requested cache access for the specified function ID.
     */
     BapErr_CacheNotAvailable = 0x36,

     /**
     * One of the passed parameters is invalid.
     * (Null pointer, invalid FctId or LsgId, request type not for this function class
     * allowed, data type of the function and function ID do not match)
     */
     BapErr_InvalidArg = 0x37
}BapError_et;

#ifdef BAP_NOT_USES_NAMED_IDS
/** The data type for the identification of a logical control device  */
typedef uint8_t lsgId_t;
/** The data type for the identification of a function of a logical control device */
typedef uint8_t fctId_t;

#else
/**
 * Symbolic names for LSGs and functions are used.
 */
#define BAP_USES_NAMED_IDS

/**
 * Named identifiers for all logical control devices
 */
#define DEFINE_ALL_LSG_ID(LSG,ID)     BapLsg_##LSG##_Id = ID,
typedef enum BapLsgId_t
{
  BapLsg_Reserved   = 0x00,
  BAP_LSG_TABLE(DEFINE_ALL_LSG_ID)
}lsgId_t;

/**
 * Named identifiers for the functions of all logic control devices
 */
#define DEFINE_ALL_FCT_ID_FROM_EACH_LSG(LSG,FCT,CLS,ID,OPCODES)     BapFct_##LSG##_##FCT##_Id = ID,
typedef enum BapFct_t
{
  BapFct_Reserved = 0x00,
  BAP_FUNCTION_TABLE(DEFINE_ALL_FCT_ID_FROM_EACH_LSG)
}fctId_t;


/**
 * Named index for all logic control devices
 */
#define ENUMERATE_ALL_LSG_IDX(LSG,ID)     BapLsg_##LSG##_Idx,
typedef enum BapLsgIdx_t
{
  BAP_LSG_TABLE(ENUMERATE_ALL_LSG_IDX)
  BapNumLsgs
}lsgIdx_t;

/**
 * Named index for the functions of all logic control devices
 */
#define DEFINE_ALL_FCT_IDX_FROM_EACH_LSG(LSG,FCT,CLS,ID,OPCODES)     BapFct_##LSG##_##FCT##_Idx,
typedef enum BapFctIdx_t
{
    /* Include FCT_CATALOG of all LSG */
    BAP_FUNCTION_TABLE(DEFINE_ALL_FCT_IDX_FROM_EACH_LSG)
    BapNumFcts
}fctIdx_t;

/**
 * Named size for the functions of ALL logic control devices
 */
#define DEFINE_FCT_SIZE_FROM_EACH_LSG(LSG,ID)   BapLsg_##LSG##_FctSize = BAP_##LSG##_NumFcts,
typedef enum BapLsgFctSize_t
{
    BAP_LSG_TABLE(DEFINE_FCT_SIZE_FROM_EACH_LSG)
}lsgFctSize_t;

/**
 * Named initial index and last for the functions of ALL logic control devices
 */
#define DEFINE_INITIAL_AND_LAST_FCT_IDX_FOR_EACH_LSG(LSG,ID)    BapLsg_##LSG##_Fct_StartIdx,BapLsg_##LSG##_Fct_EndIdx = BapLsg_##LSG##_Fct_StartIdx + BapLsg_##LSG##_FctSize - 1,
typedef enum BapLsg_FctIdx_t
{
    BAP_LSG_TABLE(DEFINE_INITIAL_AND_LAST_FCT_IDX_FOR_EACH_LSG)
}lsg_FctIdx_t;

#endif
#ifdef __cplusplus
}
#endif

#endif /* SOURCE_USER_APP_BAP_APPL_BAP_DEFINES_H_ */
