/*===========================================================================*/
/**
 * @file bap_telephony_acfg.h
 *
 * BAP Telephony functions definition 
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2023 Mirgor Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
#ifndef SOURCE_USER_APP_BAP_APPL_BAP_TELEPHONY_BAP_TELEPHONY_ACFG_H_
#define SOURCE_USER_APP_BAP_APPL_BAP_TELEPHONY_BAP_TELEPHONY_ACFG_H_

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include "../bap_audio/bap_audio_acfg.h"
#include <common_definitions.h>

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*------------------------ BAP UHV LSG Macros---------------------- */

/* BAP Config (0x02) macros */

#define BAP_TELEPHONY_BAPCONFIG_RX_SIZE 6
#define BAP_TELEPHONY_BAPCONFIG_TX_SIZE 6

/* FUnction list (0x03) macros*/

#define BAP_TELEPHONY_FUNCTION_LIST_RX_SIZE 8
#define BAP_TELEPHONY_FUNCTION_LIST_TX_SIZE 8

/* Heartbeat macros */

#define BAP_TELEPHONY_HEARTBEAT_TX_SIZE     1

/* ASG_Capabilities (0x10) macros */

#define ASG_CAPABILITIES_DISPLAY_SIZE_CLASS_IDX             0
#define ASG_CAPABILITIES_NUM_LIST_ELEMENTS_IDX              1
#define ASG_CAPABILITIES_NUM_LIST_ELEMENTS_DEFAULT_VALUE    3

/* ASG_Config (0x11) macros*/

#define ASG_CONFIG_VERSION_MAJOR_IDX    0
#define ASG_CONFIG_VERSION_MINOR_IDX    1

#define ASG_CONFIG_VERSION_MAJOR        1
#define ASG_CONFIG_VERSION_MINOR        0

/* MFL_Block definition (0x12) macros*/

#define MFL_BLOCK_DEFINITION_NO_KEYS                0x00
#define MFL_BLOCK_DEFINITION_ALL                    0x01
#define MFL_BLOCK_DEFINITION_UP_DOWN                0x02
#define MFL_BLOCK_DEFINITION_LEFT_RIGHT             0x03
#define MFL_BLOCK_DEFINITION_UP_DOWN_LEFT_RIGHT_OK  0x04
#define MFL_BLOCK_DEFINITION_ROTARY1                0x05
#define MFL_BLOCK_DEFINITION_ROTARY2                0x06
#define MFL_BLOCK_DEFINITION_OK                     0x07
#define MFL_BLOCK_DEFINITION_BACK                   0x08
#define MFL_BLOCK_DEFINITION_RESERVED               0x09

#define MFL_BLOCK_DEFINITION_KEY_BLOCK_0_IDX        0
#define MFL_BLOCK_DEFINITION_KEY_BLOCK_1_IDX        1
#define MFL_BLOCK_DEFINITION_KEY_BLOCK_2_IDX        2
#define MFL_BLOCK_DEFINITION_KEY_BLOCK_3_IDX        3
#define MFL_BLOCK_DEFINITION_KEY_BLOCK_4_IDX        4
#define MFL_BLOCK_DEFINITION_KEY_BLOCK_5_IDX        5
#define MFL_BLOCK_DEFINITION_KEY_BLOCK_6_IDX        6
#define MFL_BLOCK_DEFINITION_KEY_BLOCK_7_IDX        7

/* FrameStatus (0x13) macros*/

// FrameStatus.FrameId macros

#define FRAME_STATUS_FRAME_ID_NO_FRAME              0x00

#define FRAME_STATUS_FRAME_ID_DEVICE_INFO           0x01

#define FRAME_STATUS_FRAME_ID_DETERMINED_BY_FSG     0xFE
#define FRAME_STATUS_FRAME_ID_RELEASE_ALL_FRAMES    0xFF

// FrameStatus.relativePriority macros

#define FRAME_STATUS_RELATIVE_PRIORITY_LOW          0x00
#define FRAME_STATUS_RELATIVE_PRIORITY_HIGH         0x01


// FrameStatus.MFL_Assigned.MFL_Blocks macros
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_0_BIT         0
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_1_BIT         1
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_2_BIT         2
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_3_BIT         3
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_4_BIT         4
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_5_BIT         5
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_6_BIT         6
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_7_BIT         7

#define FRAME_STATUS_MFL_BLOCKS_NO_KEY_MASK             0x00
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_0_MASK        0x01
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_1_MASK        0x02
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_2_MASK        0x04
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_3_MASK        0x08
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_4_MASK        0x10
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_5_MASK        0x20
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_6_MASK        0x40
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_7_MASK        0x80

#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_NOT_ASSIGNED  0
#define FRAME_STATUS_MFL_BLOCKS_KEY_BLOCK_ASSIGNED      1

/* FrameData (0x14) macros*/

// FrameData.ListElementOnTop macros
#define FRAME_DATA_LIST_ELEMENT_ON_TOP_DEFAULT_VALUE    0x00

// FrameData.ArrayHeader macros 
#define FRAME_DATA_ARRAYHEADER_MODE_IDX   0

#define FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_SHIFT               7
#define FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_MASK                0x80
#define FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_8BITS               0
#define FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_16BITS              1

#define FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_SHIFT           6
#define FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_MASK            0x40
#define FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_TRANSMITTED     1
#define FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_NOTTRANSMITTED 0

#define FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_SHIFT          5
#define FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_MASK           0x20
#define FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_FW             0
#define FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_BW             1

#define FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_SHIFT           4
#define FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_MASK            0x10
#define FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_ENABLE          1
#define FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_DISABLE         0

#define FRAME_DATA_ARRAYHEADER_MODE_RECORDADRESS_MASK             0xF

#define FRAME_DATA_ARRAYHEADER_START_16BITS_LSB_IDX               1
#define FRAME_DATA_ARRAYHEADER_START_16BITS_MSB_IDX               2
#define FRAME_DATA_ARRAYHEADER_START_8BITS_IDX                    1

#define FRAME_DATA_ARRAYHEADER_ELEMENTS_16BITS_LSB_IDX            3
#define FRAME_DATA_ARRAYHEADER_ELEMENTS_16BITS_MSB_IDX            4
#define FRAME_DATA_ARRAYHEADER_ELEMENTS_8BITS_IDX                 3

// FrameData.Start macros 
#define FRAME_DATA_ARRAY_HEADER_START_DEFAULT_VALUE     0x00

// FrameData.Elements macros 
#define FRAME_DATA_ARRAY_HEADER_ELEMENTS_DEFAULT_VALUE  0x04

// FrameData.Data macros
#define FRAME_DATA_MAX_ARRAY_ELEMENTS   7
#define FRAME_DATA_MAX_STRING_SIZE      94

#define FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK  0x00

#define FRAME_DATA_ATTRIBUTES_SELECTABLE_SHIFT  0
#define FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK   0x01
#define FRAME_DATA_ATTRIBUTES_SELECTABLE        1
#define FRAME_DATA_ATTRIBUTES_NOT_SELECTABLE    0

#define FRAME_DATA_ATTRIBUTES_FOCUSED_SHIFT  1
#define FRAME_DATA_ATTRIBUTES_FOCUSED_MASK   0x02
#define FRAME_DATA_ATTRIBUTES_FOCUSED        1
#define FRAME_DATA_ATTRIBUTES_NOT_FOCUSED    0

#define FRAME_DATA_ATTRIBUTES_VISIBLE_SHIFT  7
#define FRAME_DATA_ATTRIBUTES_VISIBLE_MASK   0x80
#define FRAME_DATA_ATTRIBUTES_VISIBLE        1
#define FRAME_DATA_ATTRIBUTES_NOT_VISIBLE    0

#define FRAME_DATA_ARRAY_NAME_SIZE_INDEX             0
#define FRAME_DATA_ARRAY_NAME_DATA_INITIAL_INDEX     1

/* Scrollbar (0x16) macros*/

// Scrollbar.Attributes macros
#define SCROLLBAR_ATTRIBUTES_VERTICAL_SCROLLBAR_AND_NAVIGATION_ARROWS_SHIFT             0
#define SCROLLBAR_ATTRIBUTES_VERTICAL_SCROLLBAR_AND_NAVIGATION_ARROWS_MASK              0x01
#define SCROLLBAR_ATTRIBUTES_VERTICAL_SCROLLBAR_AND_NAVIGATION_ARROWS_SHOW              1
#define SCROLLBAR_ATTRIBUTES_VERTICAL_SCROLLBAR_AND_NAVIGATION_ARROWS_NOT_SHOW          0 

#define SCROLLBAR_ATTRIBUTES_ENDLESS_LIST_SHIFT                                         1
#define SCROLLBAR_ATTRIBUTES_ENDLESS_LIST_MASK                                          0x02
#define SCROLLBAR_ATTRIBUTES_ENDLESS_LIST                                               1
#define SCROLLBAR_ATTRIBUTES_NO_ENDLESS_LIST                                            0

#define SCROLLBAR_ATTRIBUTES_POP_UP_FRAME_SHIFT                                         2
#define SCROLLBAR_ATTRIBUTES_POP_UP_FRAME_MASK                                          0x04
#define SCROLLBAR_ATTRIBUTES_POP_UP_FRAME                                               1
#define SCROLLBAR_ATTRIBUTES_NO_POP_UP_FRAME                                            0

#define SCROLLBAR_ATTRIBUTES_NOTHING            0x00

// Scrollbar.SliderLength macros
#define SCROLLBAR_SLIDER_LENGTH_MIN_VALUE       0   // %
#define SCROLLBAR_SLIDER_LENGTH_STEP            1   // %
#define SCROLLBAR_SLIDER_LENGTH_MAX_VALUE       100 // %
#define SCROLLBAR_SLIDER_LENGTH_NOT_VISIBLE     SCROLLBAR_SLIDER_LENGTH_MIN_VALUE
#define SCROLLBAR_SLIDER_LENGTH_DEFAULT_VALUE   0x0A

// Scrollbar.SliderPosition macros
#define SCROLLBAR_SLIDER_POSITION_MIN_VALUE         0   // %
#define SCROLLBAR_SLIDER_POSITION_STEP              1   // %
#define SCROLLBAR_SLIDER_POSITION_MAX_VALUE         100 // %
#define SCROLLBAR_SLIDER_POSITION_TOP_OF_LIST       SCROLLBAR_SLIDER_POSITION_MIN_VALUE
#define SCROLLBAR_SLIDER_POSITION_BOTTOM_OF_LIST    SCROLLBAR_SLIDER_POSITION_MAX_VALUE

/* LsgStatus (0x17) macros*/

#define LSG_STATUS_NOT_ALIVE    0
#define LSG_STATUS_ALIVE        1
#define LSG_STATUS_OPCODE_STATUS_DELAYED_TIME    500 //x10ms (5s)

/*-------------- BAP Telephony Frame macros----------------------- */

#define CLUSTER_NUM_ROWS    4

/* Connection status frame (Frame-Id 0x01) macros */
#define FRAME_ID_DEVICE_INFO_NUM_ROWS                           CLUSTER_NUM_ROWS
#define FRAME_ID_DEVICE_INFO_CONNECTED_NETWORK_STRENGTH_ROW     0
#define FRAME_ID_DEVICE_INFO_CONNECTED_ICONS_ROW                3
#define FRAME_ID_DEVICE_INFO_BATTERY_ICON_POSITION              0
#define FRAME_ID_DEVICE_INFO_BLUETOOTH_ICON_POSITION            4
#define FRAME_ID_DEVICE_INFO_MISSED_CALL_ICON_POSITION          8
#define FRAME_ID_DEVICE_INFO_MISSED_CALL_CNT_POSITION           12

#define FRAME_ID_DEVICE_INFO_DELIMITER_TOKEN    "|"
#define FRAME_ID_DEVICE_INFO_EMPTY_ROW          ""

#define FRAME_ID_DEVICE_INFO_SRC_CARPLAY        "CarPlay"
#define FRAME_ID_DEVICE_INFO_SRC_ANDROIDAUTO    "Android Auto"

#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_SIZE                    3
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_LAST_ITEM               0x20
/* Network Strength icon byte code in UTF-8 */
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_0            { 0xEF, 0xA0, 0x88 }
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_1            { 0xEF, 0xA0, 0x89 }
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_2            { 0xEF, 0xA0, 0x8A }
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_3            { 0xEF, 0xA0, 0x8B }
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_4            { 0xEF, 0xA0, 0x8C }

/* Network Strength icon byte code in UTF-8 */
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_0            { 0xEF, 0xA0, 0x83 }
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_1            { 0xEF, 0xA0, 0x84 }
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_2            { 0xEF, 0xA0, 0x85 }
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_3            { 0xEF, 0xA0, 0x86 }
#define CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_4            { 0xEF, 0xA0, 0x87 }

/* Battery Level icon byte code in UTF-8 */
#define CONNECTION_STATUS_ICON_BATTERY_SIZE         4
#define CONNECTION_STATUS_ICON_BATTERY_LEVEL_0      { 0xEF, 0xB0, 0x84, 0x20 }
#define CONNECTION_STATUS_ICON_BATTERY_LEVEL_1      { 0xEF, 0xB0, 0x83, 0x20 }
#define CONNECTION_STATUS_ICON_BATTERY_LEVEL_2      { 0xEF, 0xB0, 0x82, 0x20 }
#define CONNECTION_STATUS_ICON_BATTERY_LEVEL_3      { 0xEF, 0xB0, 0x81, 0x20 }
#define CONNECTION_STATUS_ICON_BATTERY_LEVEL_4      { 0xEF, 0xB0, 0x80, 0x20 }
#define CONNECTION_STATUS_ICON_BATTERY_LEVEL_5      { 0xEF, 0xB0, 0x80, 0x20 }

/* Bluetooth icon byte code in UTF-8 */
#define CONNECTION_STATUS_ICON_BLUETOOTH_SIZE       4
#define CONNECTION_STATUS_ICON_BLUETOOTH            { 0xEF, 0x9F, 0xBE, 0x20 }

/* Missed call icon byte code in UTF-8*/
#define CONNECTION_STATUS_ICON_MISSED_CALL_SIZE    4
#define CONNECTION_STATUS_ICON_MISSED_CALL         { 0xEF, 0x9F, 0xBD, 0x20 } /* TODO: Get real bytes */

#define CONNECTION_STATUS_MIN_MISSED_CALLS         0
#define CONNECTION_STATUS_MAX_MISSED_CALLS         9

/* Recent calls frame (Frame-Id 0x02) macros*/
#define RECENT_CALLS_LIST_ELEMENTS          RECENT_CALLS_LIST_NUM_MAX_ELEMENTS + 2 
#define RECENT_CALLS_LIST_HEADER_IDX        0
#define RECENT_CALLS_LIST_FOOTER_IDX        RECENT_CALLS_LIST_ELEMENTS - 1
#define RECENT_CALLS_LIST_FIRST_CALL_IDX    RECENT_CALLS_LIST_HEADER_IDX + 1
#define RECENT_CALLS_LIST_LAST_CALL_IDX     RECENT_CALLS_LIST_FOOTER_IDX - 1

/* List delimiter */
#define FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT     0x01
#define FRAME_RECENT_CALLS_LIST_DELIMITER_TOKEN         "|"
#define FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS           12
#define FRAME_RECENT_CALLS_INITIAL_SEND_START_1         0
#define FRAME_RECENT_CALLS_INITIAL_SEND_ELEMENTS_1      7
#define FRAME_RECENT_CALLS_INITIAL_SEND_START_2         FRAME_RECENT_CALLS_INITIAL_SEND_ELEMENTS_1
#define FRAME_RECENT_CALLS_INITIAL_SEND_ELEMENTS_2      5
#define FRAME_RECENT_CALLS_MOVE_TO_BOTTOM_START_1       7
#define FRAME_RECENT_CALLS_MOVE_TO_BOTTOM_ELEMENTS_1    5
#define FRAME_RECENT_CALLS_MOVE_TO_BOTTOM_START_2       1
#define FRAME_RECENT_CALLS_MOVE_TO_BOTTOM_ELEMENTS_2    6
#define FRAME_RECENT_CALLS_MIN_DISTANCE_TO_TOP          3
#define FRAME_RECENT_CALLS_LIST_            

/* Type of calls supported in recent call list*/
#define RECENT_CALLS_TYPE_UNKNOWN       0
#define RECENT_CALLS_TYPE_INCOMING      1
#define RECENT_CALLS_TYPE_OUTGOING      2
#define RECENT_CALLS_TYPE_MISSED        3   
#define RECENT_CALLS_NUM_TYPES          4

/* Call type icon byte code in UTF-8 */
#define RECENT_CALLS_TYPE_ICON_SIZE     4 
#define RECENT_CALLS_TYPE_ICON_MISSED   { 0xEF, 0xB0, 0x96, 0x20 }
#define RECENT_CALLS_TYPE_ICON_INCOMING { 0xEF, 0xB0, 0x97, 0x20 }
#define RECENT_CALLS_TYPE_ICON_OUTGOING { 0xEF, 0xB0, 0x98, 0x20 }

#define RECENT_CALLS_SELECTED_CONTACT_INVALID   0xFF

/* Call status frame (Frame-Id 0x03) macros*/

// Max number of call option list elements (obtained from shared_data sobumodule)
#define CALL_STATUS_OPTIONS_LIST_ELEMENTS   CALL_OPTIONS_LIST_NUM_MAX_ELEMENTS
// Number of fixed call info elements in call status data frame (Call contact name and Call status message)
#define CALL_STATUS_INFO_ELEMENTS           2
// Max number of call status frame data elements including call options list and call info messages
#define CALL_STATUS_LIST_ELEMENTS           CALL_STATUS_OPTIONS_LIST_ELEMENTS + CALL_STATUS_INFO_ELEMENTS
// Call options list delimiter token
#define FRAME_CALL_STATUS_OPTIONS_LIST_DELIMITER_TOKEN         "|"
// Min number of call option list elements
#define CALL_STATUS_OPTIONS_LIST_NUM_MIN_ELEMENTS       1
// Cal frame data index of the first option list element if there is one
#define CALL_STATUS_OPTIONS_LIST_INITIAL_TOP_ELEMENT    2
// Number of call options displayed in the cluster at a given position
#define CALL_STATUS_OPTIONS_LIST_DISPLAYED_ELEMENTS             CLUSTER_NUM_ROWS - CALL_STATUS_INFO_ELEMENTS
// Number of call options attributes to update when only the selected element is moved (the displayed elements remains)
#define CALL_STATUS_OPTIONS_LIST_UPDATE_SELECT_NUM_ELEMENTS     CALL_STATUS_OPTIONS_LIST_DISPLAYED_ELEMENTS
// Number of call options attributes to update when the displayed list is updated (the displayed elements + the next/prev not displayed elements)
#define CALL_STATUS_OPTIONS_LIST_UPDATE_LIST_NUM_ELEMENTS       CALL_STATUS_OPTIONS_LIST_DISPLAYED_ELEMENTS + 1
// Index of the first element in the call status frame
#define CALL_STATUS_FRAME_INITIAL_INDEX         0

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*------------------------ BAP UHV LSG Data types ---------------------- */

/* ASG_Capabilities (0x10) data types */

typedef enum DisplaySizeClass_Tag
{
    DisplaySizeClass_Small      = 0x00,
    DisplaySizeClass_Medium     = 0x01,
    DisplaySizeClass_Large      = 0x02,
    DisplaySizeClass_Reserved   = 0x03
}DisplaySizeClass_T;

typedef struct __attribute__ ((__packed__)) ASG_Capabilities_Tag
{
    DisplaySizeClass_T  displaySizeClass;
    uint8_t             numVisibleListElements;
}ASG_Capabilities_T;

/* ASG_Config (0x11) data types */

typedef struct __attribute__ ((__packed__)) ASG_Config_Tag
{
    uint8_t  vMajor;
    uint8_t  vMinor;
}ASG_Config_T;

/* MFL Block Definition (0x12) data types */

typedef struct __attribute__ ((__packed__)) MFL_Block_Definition_Tag
{
    uint8_t  keyBlock_0;
    uint8_t  keyBlock_1;
    uint8_t  keyBlock_2;
    uint8_t  keyBlock_3;
    uint8_t  keyBlock_4;
    uint8_t  keyBlock_5;
    uint8_t  keyBlock_6;
    uint8_t  keyBlock_7;
}MFL_Block_Definition_T;

/* FrameStatus (0x13) data types */

typedef struct __attribute__ ((__packed__)) MFL_Assigned_Tag
{
    uint8_t  focusedFrameId;
    uint8_t  MFL_Blocks;
}MFL_Assigned_T;

typedef enum ASG_Response_Tag
{
    ASG_Response_SetVisOFF          = 0x00,
    ASG_Response_SetVisON           = 0x01,
    ASG_Response_QueuedUp           = 0x02,
    ASG_Response_ASGReqVisON        = 0x03,
    ASG_Response_FirstReserved      = 0x04,
    ASG_Response_LastReserved       = 0xFE,
    ASG_Response_NoResponse         = 0xFF,
}ASG_Response_T;

typedef enum FSG_Request_Tag
{
    FSG_Request_ReqVisOFF                   = 0x00,
    FSG_Request_ReqVisON                    = 0x01,
    FSG_Request_AcceptASGReq                = 0x02,
    FSG_Request_RefuseASGReq                = 0x03,
    FSG_Request_ReqVisOFF_MenueQuit_Short   = 0x04,
    FSG_Request_ReqVisOFF_MenueQuit_Long    = 0x05,
    FSG_Request_FirstReserved               = 0x06,
    FSG_Request_LastReserved                = 0xFE,
    FSG_Request_NoRequest                   = 0xFF,
}FSG_Request_T;

typedef struct __attribute__ ((__packed__)) FrameStatus_Tag
{
    uint8_t         frameId;
    uint8_t         relativePriority;
    MFL_Assigned_T  MFL_Assigned;
    ASG_Response_T  ASG_Response;
    FSG_Request_T   FSG_Request;
}FrameStatus_T;

/* FrameData (0x14) data types */

typedef enum ListOperation_Tag
{
    ListOperation_Unknown               = 0x00,
    ListOperation_ListUp                = 0x01,
    ListOperation_ListDown              = 0x02,
    ListOperation_PageFlipUp            = 0x03,
    ListOperation_PageFlipDown          = 0x04,
    ListOperation_FastScrollingUp       = 0x05,
    ListOperation_FastScrollingDown     = 0x06,
    ListOperation_FastPageFlipUp        = 0x07,
    ListOperation_FastPageFlipDown      = 0x08,
    ListOperation_MovinToTopOfList      = 0x09,
    ListOperation_MovinToBottomOfList   = 0x0A,
    ListOperation_MenuChange            = 0x0B,
    ListOperation_EnteringMenu          = 0x0C,
    ListOperation_LeavingMenu           = 0x0D,
    ListOperation_LaunchingPopUp        = 0x0E,
}ListOperation_T;

typedef enum FrameData_SingleEntry_Type_Tag
{
    FrameData_SingleEntry_Type_Unknown      = 0x00,
    FrameData_SingleEntry_Type_Directory    = 0x01,
    FrameData_SingleEntry_Type_Filename     = 0x02,
    FrameData_SingleEntry_Type_PhoneNumber  = 0x03,
    FrameData_SingleEntry_Type_MenuItem     = 0x04,
    FrameData_SingleEntry_Type_CheckBox     = 0x05,
    FrameData_SingleEntry_Type_RadioButton  = 0x06,
    FrameData_SingleEntry_Type_Speller      = 0x07,
}FrameData_SingleEntry_Type_T;

typedef struct __attribute__ ((__packed__)) FrameData_SingleEntry_Tag
{
    uint8_t                             pos;
    FrameData_SingleEntry_Type_T        type;
    uint8_t                             attributes;
    char                                name[FRAME_DATA_MAX_STRING_SIZE];
}FrameData_SingleEntry_T;

typedef struct __attribute__ ((__packed__)) FrameData_Array_Tag
{
    FrameData_SingleEntry_T   entry[FRAME_DATA_MAX_ARRAY_ELEMENTS];
}FrameData_Array_T;

typedef struct __attribute__ ((__packed__)) FrameData_GetArray_Tag
{
    uint8_t         frameId;
    ArrayHeader_T   arrayHeader;
}FrameData_GetArray_T;

typedef struct __attribute__ ((__packed__)) FrameData_StatusArray_Tag
{
    uint8_t             frameId;
    uint8_t             listElementOnTop;
    ListOperation_T     listOperation;
    ArrayHeader_T       arrayHeader;
    FrameData_Array_T   arrayData;
}FrameData_StatusArray_T;

/* Scrollbar (0x16) data types */

typedef struct __attribute__ ((__packed__)) Scrollbar_Tag
{
    uint8_t             frameId;
    uint8_t             attributes;
    uint8_t             sliderLength;
    uint8_t             sliderPosition;
}Scrollbar_T;

/*-------------- BAP Telephony Frame data types ----------------------- */

/* Frame display state*/
typedef enum FrameState_Tag
{
    FrameState_OFF          = 0x00,
    FrameState_ReqON        = 0x01,
    FrameState_GoingToON    = 0x02,
    FrameState_ON           = 0x03,
    FrameState_ReqOFF       = 0x04,
    FrameState_GoingToOFF   = 0x05,
    FrameState_Wait         = 0x06,
    FrameState_NumStates,
}FrameState_T;

/* Frame parameters */
typedef enum Frame_Prms_Tag
{
    Frame_ConnectionSts,
    Frame_ConnectionStsMsg,
    Frame_MissedCalls,
    Frame_RecentCallsHeader,
    Frame_RecentCallsList,
    Frame_RecentCallsFooter,
    Frame_CallSts,
    Frame_CallContactMsg,
    Frame_CallStsMsg,
    Frame_CallOptionsList,
    Frame_NumPrms,
}FramePrms_T;

/* Connection status Network Strength */
typedef enum ConnectionStatus_NetworkStrength_Tag
{
    ConnectionStatus_NetworkStrength_0,
    ConnectionStatus_NetworkStrength_1,
    ConnectionStatus_NetworkStrength_2,
    ConnectionStatus_NetworkStrength_3,
    ConnectionStatus_NetworkStrength_4,
    ConnectionStatus_NetworkStrengthsLevels
}ConnectionStatus_NetworkStrength_T;

/* Connection status Battery levels */
typedef enum ConnectionStatus_BatteryLevel_Tag
{
    ConnectionStatus_BatteryLevel_0,
    ConnectionStatus_BatteryLevel_1,
    ConnectionStatus_BatteryLevel_2,
    ConnectionStatus_BatteryLevel_3,
    ConnectionStatus_BatteryLevel_4,
    ConnectionStatus_BatteryLevel_5,
    ConnectionStatus_BatteryLevels
}ConnectionStatus_BatteryLevel_T;

/* Connection status (Frame-Id 0x01) parameter datatype*/

typedef struct __attribute__ ((__packed__)) ConnectionStatus_Tag
{
    ConnectionStatus_BatteryLevel_T batteryLevels;
    char connectionStatusMsg[FRAME_ID_DEVICE_INFO_NUM_ROWS][FRAME_DATA_MAX_STRING_SIZE];
    uint8_t missedCalls;
}ConnectionStatus_T;


/* Recent calls (Frame-Id 0x02) parameter datatype*/

typedef struct __attribute__ ((__packed__)) RecentCalls_SendBuffer_Tag
{
    uint8_t listElementsIdx[FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS];
    uint8_t listElementsAttributes[FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS];
    uint8_t topElementIdx;
    uint8_t selectedElementIdx;
    uint8_t numElements;
}RecentCalls_Buffer_T;

/* Recent calls list update commands */
typedef enum RecentCalls_Update_Command_Tag
{
    RecentCalls_NoCommand,
    RecentCalls_InitialSend,
    RecentCalls_InitialSend_Complete,
    RecentCalls_ListDown,
    RecentCalls_ListUp,
    RecentCalls_MoveToBottom,
    RecentCalls_MoveToBottom_Complete,
    RecentCalls_UpdateListUp,
    RecentCalls_UpdateListDown,
    RecentCalls_UpdateDisplayedData,
    RecentCalls_NumCmds,
}RecentCalls_UpdateCmd_T;

typedef struct __attribute__ ((__packed__)) RecentCalls_Tag
{
    uint8_t numElements;
    RecentCalls_Buffer_T buffer;
    char recentCallsList[RECENT_CALLS_LIST_ELEMENTS][FRAME_DATA_MAX_STRING_SIZE];
    RecentCalls_UpdateCmd_T currentCmd;
}RecentCalls_T;

/* Call status (Frame-Id 0x01) parameter datatype*/

/* Option list update commands */
typedef enum CallStatus_Update_Command_Tag
{
    CallStatus_NoCommand,
    CallStatus_InitialSend,
    CallStatus_ListDown,
    CallStatus_ListUp,
    CallStatus_NumCmds,
}CallStatus_Update_Cmd_T;

typedef struct __attribute__ ((__packed__)) CallOption_Tag
{
    char    optionName[FRAME_DATA_MAX_STRING_SIZE];
    uint8_t optionId;
}CallOption_T;

typedef struct __attribute__ ((__packed__)) CallStatus_Tag
{
    bool_t callSts;                                                         // Active call
    uint8_t numOptions;                                                     // Number of options displayed in call
    uint8_t topElementIdx;                                                  // Top element
    uint8_t selectedElementIdx;                                             // Selected element from list
    CallStatus_Update_Cmd_T currentCmd;                                    // Current cmd
    char callContactMsg[FRAME_DATA_MAX_STRING_SIZE];                        
    char callStatusMsg[FRAME_DATA_MAX_STRING_SIZE];
    CallOption_T callOptionsList[CALL_STATUS_OPTIONS_LIST_ELEMENTS];
    uint8_t listElementsIdx[CALL_STATUS_LIST_ELEMENTS];
    uint8_t listElementsAttributes[CALL_STATUS_LIST_ELEMENTS];
}CallStatus_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*------------------------ BAP UHV LSG X-Macros ---------------------- */

/* LSG Tables */

#define BAP_TELEPHONY_TABLE(LSG)                                                     \
    LSG( TELEPHONY,       0x2B)                                                      \

/* FCT Tables */

#define BAP_TELEPHONY_CACHE_TABLE(FCT)                                                                                                  \
    /*   LSG           FCT Name                 Fct-Class                Fct-Id     Opcode Table                            */          \
    FCT( TELEPHONY,        GET_ALL,             FctClass_Cache,          0x01,      BAP_TELEPHONY_GET_ALL_TABLE                 )       \

#define BAP_TELEPHONY_COMMON_PROPERTY_TABLE(FCT)                                                                                        \
    /*   LSG           FCT Name                 Fct-Class                Fct-Id     Opcode Table                                */      \
    FCT( TELEPHONY,        BAP_CONFIG,          FctClass_Property,       0x02,      BAP_TELEPHONY_BAP_CONFIG_TABLE              )       \
    FCT( TELEPHONY,        FUNCTION_LIST,       FctClass_Property,       0x03,      BAP_TELEPHONY_FUNCTION_LIST_TABLE           )       \
    FCT( TELEPHONY,        HEARTBEAT,           FctClass_Property,       0x04,      BAP_TELEPHONY_HEARTBEAT_TABLE               )       \

#define BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE(FCT)                                                                                      \
    /*   LSG           FCT Name                 Fct-Class                Fct-Id     Opcode Table                                */      \
    FCT( TELEPHONY,    FSG_OPERATION_STATE,     FctClass_Property,       0x0F,      BAP_TELEPHONY_FSG_OPERATION_STATE_TABLE     )       \
    FCT( TELEPHONY,    ASG_CAPABILITIES,        FctClass_Property,       0x10,      BAP_TELEPHONY_ASG_CAPABILITIES_TABLE        )       \
    FCT( TELEPHONY,    ASG_CONFIG,              FctClass_Property,       0x11,      BAP_TELEPHONY_ASG_CONFIG_TABLE              )       \
    FCT( TELEPHONY,    MFL_BLOCK_DEFINITION,    FctClass_Property,       0x12,      BAP_TELEPHONY_MFL_BLOCK_DEFINITION_TABLE    )       \
    FCT( TELEPHONY,    FRAME_STATUS,            FctClass_Property,       0x13,      BAP_TELEPHONY_FRAME_STATUS_TABLE            )       \
    FCT( TELEPHONY,    FRAME_DATA_ACK,          FctClass_Property,       0x15,      BAP_TELEPHONY_FRAME_DATA_ACK_TABLE          )       \
    FCT( TELEPHONY,    SCROLLBAR,               FctClass_Property,       0x16,      BAP_TELEPHONY_SCROLLBAR_TABLE               )       \
    FCT( TELEPHONY,    LSG_STATUS,              FctClass_Property,       0x17,      BAP_TELEPHONY_LSG_STATUS_TABLE              )       \

#define BAP_TELEPHONY_ARRAY_TABLE(FCT)                                                                                                  \
    /*   LSG           FCT Name                 Fct-Class                Fct-Id     Opcode Table                                */      \
    FCT( TELEPHONY,    FRAME_DATA,              FctClass_Array,          0x14,      BAP_TELEPHONY_FRAME_DATA_TABLE              )       \

#define BAP_TELEPHONY_PROPERTY_TABLE(FCT)                                               \
    BAP_TELEPHONY_COMMON_PROPERTY_TABLE(FCT)                                            \
    BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE(FCT)                                          \

#define BAP_TELEPHONY_FUNCTION_TABLE(FCT)                                               \
    BAP_TELEPHONY_CACHE_TABLE(FCT)                                                      \
    BAP_TELEPHONY_PROPERTY_TABLE(FCT)                                                   \
    BAP_TELEPHONY_ARRAY_TABLE(FCT)                                                      \

/* FCT/Opcode Tables */

#define BAP_TELEPHONY_GET_ALL_TABLE(OPCODE)                                                                                                             \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  GET_ALL,                    Opcode_GetAll,              Type_Void,               0,              uint8_t                                )   \
   OPCODE(  GET_ALL,                    Opcode_StatusAll,           Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  GET_ALL,                    Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_BAP_CONFIG_TABLE(OPCODE)                                                                                                          \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                             */  \
   OPCODE(  BAP_CONFIG,                 Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  BAP_CONFIG,                 Opcode_Status,              Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  BAP_CONFIG,                 Opcode_HeartbeatStatus,     Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  BAP_CONFIG,                 Opcode_Reset,               Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  BAP_CONFIG,                 Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_FUNCTION_LIST_TABLE(OPCODE)                                                                                                       \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  FUNCTION_LIST,              Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  FUNCTION_LIST,              Opcode_Status,              Type_Int8,               0,              uint8_t                                )   \
   OPCODE(  FUNCTION_LIST,              Opcode_HeartbeatStatus,     Type_Int8,               0,              uint8_t                                )   \
   OPCODE(  FUNCTION_LIST,              Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_HEARTBEAT_TABLE(OPCODE)                                                                                                           \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  HEARTBEAT,                  Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  HEARTBEAT,                  Opcode_Status,              Type_Int8,               0,              uint8_t                                )   \
   OPCODE(  HEARTBEAT,                  Opcode_HeartbeatStatus,     Type_Int8,               0,              uint8_t                                )   \
   OPCODE(  HEARTBEAT,                  Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_FSG_OPERATION_STATE_TABLE(OPCODE)                                                                                                 \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  FSG_OPERATION_STATE,        Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  FSG_OPERATION_STATE,        Opcode_Status,              Type_Int8,               1,              FSGOperationState_T                    )   \
   OPCODE(  FSG_OPERATION_STATE,        Opcode_HeartbeatStatus,     Type_Int8,               1,              FSGOperationState_T                    )   \
   OPCODE(  FSG_OPERATION_STATE,        Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_ASG_CAPABILITIES_TABLE(OPCODE)                                                                                                    \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  ASG_CAPABILITIES,           Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  ASG_CAPABILITIES,           Opcode_SetGet,              Type_FixedByteSequence,  2,              ASG_Capabilities_T                     )   \
   OPCODE(  ASG_CAPABILITIES,           Opcode_Status,              Type_FixedByteSequence,  2,              ASG_Capabilities_T                     )   \
   OPCODE(  ASG_CAPABILITIES,           Opcode_HeartbeatStatus,     Type_FixedByteSequence,  2,              ASG_Capabilities_T                     )   \
   OPCODE(  ASG_CAPABILITIES,           Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_ASG_CONFIG_TABLE(OPCODE)                                                                                                          \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  ASG_CONFIG,                 Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  ASG_CONFIG,                 Opcode_SetGet,              Type_FixedByteSequence,  2,              ASG_Config_T                           )   \
   OPCODE(  ASG_CONFIG,                 Opcode_Status,              Type_FixedByteSequence,  2,              ASG_Config_T                           )   \
   OPCODE(  ASG_CONFIG,                 Opcode_HeartbeatStatus,     Type_FixedByteSequence,  2,              ASG_Config_T                           )   \
   OPCODE(  ASG_CONFIG,                 Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_MFL_BLOCK_DEFINITION_TABLE(OPCODE)                                                                                                          \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  MFL_BLOCK_DEFINITION,       Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  MFL_BLOCK_DEFINITION,       Opcode_SetGet,              Type_FixedByteSequence,  8,              MFL_Block_Definition_T                 )   \
   OPCODE(  MFL_BLOCK_DEFINITION,       Opcode_Status,              Type_FixedByteSequence,  8,              MFL_Block_Definition_T                 )   \
   OPCODE(  MFL_BLOCK_DEFINITION,       Opcode_HeartbeatStatus,     Type_FixedByteSequence,  8,              MFL_Block_Definition_T                 )   \
   OPCODE(  MFL_BLOCK_DEFINITION,       Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_FRAME_STATUS_TABLE(OPCODE)                                                                                                        \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  FRAME_STATUS,               Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  FRAME_STATUS,               Opcode_SetGet,              Type_FixedByteSequence,  6,              FrameStatus_T                          )   \
   OPCODE(  FRAME_STATUS,               Opcode_Status,              Type_FixedByteSequence,  6,              FrameStatus_T                          )   \
   OPCODE(  FRAME_STATUS,               Opcode_HeartbeatStatus,     Type_FixedByteSequence,  6,              FrameStatus_T                          )   \
   OPCODE(  FRAME_STATUS,               Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

/* 
 * frameId Size = 1 bytes
 * ListOperation = 1, ListElementOnTop = 1
 * ArrayHeader Size = Mode (1 byte) + Start (1 byte) + Elements (1 byte) = 3 bytes
 * SIngleEntry Size = Pos  (1 bytes) + Type (1 byte) + Attributes (1 byte) + Name (MAX_STRING_SIZE (94)) = 97 bytes
 *
 * GetArray Size = FrameID (1 byte) + ArrayHeader (3 bytes) = 4 bytes
 * StatusArray Size = FrameID (1 bytes) + ListElementOnTop (1 byte) + ListOpearation (1 byte) + ArrayHeader (3 bytes) + SIZE_ARRAY*(SingleEntrySize (97 bytes))
 *
 * SIZE_ARRAY <= (Nmax = 7)
 *
 * StatusArraySizeMin = 6 bytes
 * StatusArraySize = 6 + N*97 bytes
 * StatusArraySizeMax = 6 + (97*7) bytes (Nmax = 7)
 *
 * 8 < StatusArraySize < 685 bytes
 *
 * */

#define BAP_TELEPHONY_FRAME_DATA_TABLE(OPCODE)                                                                                                          \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  FRAME_DATA,                 Opcode_GetArray,            Type_FixedByteSequence,  4,              FrameData_GetArray_T                   )   \
   OPCODE(  FRAME_DATA,                 Opcode_StatusArray,         Type_ByteSequence,       687,            FrameData_StatusArray_T                )   \
   OPCODE(  FRAME_DATA,                 Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_FRAME_DATA_ACK_TABLE(OPCODE)                                                                                                      \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  FRAME_DATA_ACK,             Opcode_Set,                 Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  FRAME_DATA_ACK,             Opcode_Status,              Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  FRAME_DATA_ACK,             Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_SCROLLBAR_TABLE(OPCODE)                                                                                                           \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  SCROLLBAR,                  Opcode_Get,                 Type_Void,               0,              uint8_t                                )   \
   OPCODE(  SCROLLBAR,                  Opcode_Status,              Type_FixedByteSequence,  4,              Scrollbar_T                            )   \
   OPCODE(  SCROLLBAR,                  Opcode_HeartbeatStatus,     Type_FixedByteSequence,  4,              Scrollbar_T                            )   \
   OPCODE(  SCROLLBAR,                  Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

#define BAP_TELEPHONY_LSG_STATUS_TABLE(OPCODE)                                                                                                          \
   /*       FCT                         Opcode Name                 Opcode Type              Opcode Size     Parameters                            */   \
   OPCODE(  LSG_STATUS,                 Opcode_Set,                 Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  LSG_STATUS,                 Opcode_Status,              Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  LSG_STATUS,                 Opcode_HeartbeatStatus,     Type_Int8,               1,              uint8_t                                )   \
   OPCODE(  LSG_STATUS,                 Opcode_Error,               Type_Int8,               1,              Error_T                                )   \

/*------------------------ BAP Telephony frame X-Macros ---------------------- */

#define BAP_TELEPHONY_FRAME_TABLE(FRAME)                                                        \
    /*       Frame Name                  Frame-Id                    Frame-Data            */   \
    FRAME(   NO_FRAME,                   0x00,                       uint8_t                )   \
    FRAME(   CONNECTION_STATUS,          0x01,                       ConnectionStatus_T     )   \
    FRAME(   RECENT_CALLS,               0x02,                       RecentCalls_T          )   \
    FRAME(   CALL_STATUS,                0x03,                       CallStatus_T           )   \
    FRAME(   RELEASE_ALL_FRAMES,         0xFF,                       uint8_t                )   \

#endif /* SOURCE_USER_APP_BAP_APPL_BAP_TELEPHONY_BAP_TELEPHONY_ACFG_H_ */
