/*===========================================================================*/
/**
 * @file bap_audio_appl.c
 *
 * BAP FSG Application for TELEPHONY
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2022 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <bap_telephony_appl.h>
#include <bap_audio_utils.h>
#include <project_def.h>
#include <console.h>
#include <bit_utils.h>
#include <shadow_storage.h>
#include <aswc.h>

#include <bap.h>
#include <bap_appl.h>
#include <bap_defines.h>
#include <bap_types.h>
#include <xdc/runtime/Error.h>
#include <string.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <can_appl.h>
#include <can_appl_volkswagen.h>

#include <inttypes.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*------------------------ BAP UHV LSG Local macros ---------------------- */

/*
 *
 * Declaration of parameters of a specific opcode
 *
 * To be used by:
 *
 * - DECLARE_FCT_PARAMS
 *
 */
#define DECLARE_OPCODE_PARAMS(FCT, OPTYPE, TYPE,SIZE, PARAMETER)    static PARAMETER BAP_TELEPHONY_##FCT##_##OPTYPE##_Data = (PARAMETER){0};

/*
 *
 * Declaration of parameters of all opcodes supported by function
 *
 * To be used by:
 *
 * - BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE
 *
 */
#define DECLARE_FCT_PARAMS(LSG,FCT,CLS,ID, OPCODES) OPCODES(DECLARE_OPCODE_PARAMS)

/*
 *
 * Declaration of callback for a specific opcode
 *
 * To be used by:
 *
 * - DECLARE_FCT_CALLBACKS
 *
 */
#define DECLARE_OPCODE_CALLBACKS(FCT, OPTYPE, TYPE, SIZE, PARAMETER) static void BAP_TELEPHONY_##FCT##_##OPTYPE##_Cbk(uint8_t *, uint16_t);

/*
 *
 * Declaration of callbacks for all opcodes supported by a given function
 *
 * To be used by:
 *
 * - BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE
 *
 */
#define DECLARE_FCT_CALLBACKS(LSG,FCT,CLS,ID,OPCODES) OPCODES(DECLARE_OPCODE_CALLBACKS)

/*
 *
 * Declaration of element in function pointer array. This function pointer array element
 * points to a correspondent opcode callback
 *
 * To be used by:
 *
 * - DEFINE_OPCODE_CBK_VECTOR
 *
 */
#define DEFINE_OPCODE_CBK_ELEMENT(FCT, OPTYPE, TYPE, SIZE, PARAMETER)  [OPTYPE] =                                   \
                                                                    {                                               \
                                                                        &BAP_TELEPHONY_##FCT##_##OPTYPE##_Cbk       \
                                                                    },                                              \

/*
 *
 * Declaration of function pointer array of function. This array contains callbacks
 * for all opcodes supported by function
 *
 * To be used by:
 *
 * - BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE
 *
 */
#define DEFINE_OPCODE_CBK_VECTOR(LSG,FCT,CLS,ID,OPCODES)    static BAP_TELEPHONY_Opcode_CbkPtr BAP_##LSG##_##FCT##_Cbks[] =     \
                                                            {                                                                   \
                                                                 OPCODES(DEFINE_OPCODE_CBK_ELEMENT)                             \
                                                            };

/*
 *
 * Declaration of element in msg array. This elemnt has data for a given opcode
 *
 * To be used by:
 *
 * - DEFINE_FCT_VECTOR
 *
 */
#define DEFINE_OPCODE_ELEMENT(FCT, OPTYPE, TYPE, SIZE, PARAMETER)   [OPTYPE] =                                                  \
                                                                    {                                                           \
                                                                        TYPE,                                                   \
                                                                        SIZE,                                                   \
                                                                        (uint8_t *) &BAP_TELEPHONY_##FCT##_##OPTYPE##_Data      \
                                                                    },                                                          \

/*
 *
 * Declaration of msg array of function. Each element of this array
 * contains data about supportes opcodes
 *
 * To be used by:
 *
 * - BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE
 *
 */
#define DEFINE_FCT_VECTOR(LSG,FCT,CLS,ID,OPCODES)  static FctMessage_T BAP_##LSG##_##FCT##_Msgs[] =         \
                                                   {                                                        \
                                                        OPCODES(DEFINE_OPCODE_ELEMENT)                      \
                                                   };                                                       \



/*
 *
 * Declaration of array containing data of property functions
 *
 * To be used by:
 *
 * - BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE
 *
 */
#define DEFINE_PROPERTY_HANDLE_ELEMENT(LSG,FCT,CLS,ID,OPCODES)  [BAP_##LSG##_Property_##FCT##_Idx] =        \
                                                                {                                           \
                                                                    BapFct_##LSG##_##FCT##_Id,              \
                                                                    &(BAP_##LSG##_##FCT##_Msgs[0]),         \
                                                                    &(BAP_##LSG##_##FCT##_Cbks[0]),         \
                                                                },                                          \

/*
 *
 * Declaration of array containing data of array functions
 *
 * To be used by:
 *
 * - BAP_TELEPHONY_ARRAY_TABLE
 *
 */
#define DEFINE_ARRAY_HANDLE_ELEMENT(LSG,FCT,CLS,ID,OPCODES)     [BAP_##LSG##_Array_##FCT##_Idx] =           \
                                                                {                                           \
                                                                    BapFct_##LSG##_##FCT##_Id,              \
                                                                    0,                                      \
                                                                    0,                                      \
                                                                    {0},                                    \
                                                                    &(BAP_##LSG##_##FCT##_Cbks[0]),         \
                                                                    &(BAP_##LSG##_##FCT##_Msgs[0]),         \
                                                                },

/*------------------------ BAP Telephony Frame Local macros ---------------------- */

/*
 *
 * Declaration of parameters of a specific frame
 *
 * To be used by:
 *
 * - DECLARE_FCT_PARAMS
 *
 */
#define DEFINE_FRAME_DATA(NAME,ID,DATA)    static DATA BAP_TELEPHONY_FRAME_##NAME##_Data = (DATA){0};


/*
 *
 * Declaration of parameters of a specific frame
 *
 * To be used by:
 *
 * - DECLARE_FCT_PARAMS
 *
 */
#define MAP_FRAME_ID_TO_FRAME_IDX(NAME,ID,DATA) [BAP_TELEPHONY_FRAME_##NAME##_Id] = {BAP_TELEPHONY_FRAME_##NAME##_Idx},

/*
 *
 * Declaration of parameters of a specific frame
 *
 * To be used by:
 *
 * - DECLARE_FCT_PARAMS
 *
 */
#define DEFINE_FRAME_ELEMENT(NAME,ID,DATA)                      [BAP_TELEPHONY_FRAME_##NAME##_Idx] =                                                        \
                                                                {                                                                                           \
                                                                    {BAP_TELEPHONY_FRAME_##NAME##_Id,0,0,0,ASG_Response_NoResponse,FSG_Request_NoRequest},  \
                                                                    {BAP_TELEPHONY_FRAME_##NAME##_Id,0,0,0},                                                \
                                                                    {BAP_TELEPHONY_FRAME_##NAME##_Id,0,0,{0,0,0},{0,0,0,0}},                                \
                                                                    FrameState_OFF,                                                                         \
                                                                    (uint8_t *)&(BAP_TELEPHONY_FRAME_##NAME##_Data),                                        \
                                                                },       

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*------------------------ BAP UHV LSG Local types ---------------------- */

/* Struct used to hold OpCode information */
typedef struct FctMessage_t
{
    Type_T          opType;
    uint16_t        opSize;
    uint8_t*        opPrms;
}FctMessage_T;

/* Function pointer to OpCode callback */
typedef void (*BAP_TELEPHONY_Opcode_CbkPtr)(uint8_t *, uint16_t);

/* Struct used to handle property function data */
typedef struct BapLsg_TELEPHONY_FctProperty_Handle_t
{
    fctId_t                         fctId;
    FctMessage_T*                   fctMsgs;
    BAP_TELEPHONY_Opcode_CbkPtr*    fctCbks;
}TELEPHONY_FctProperty_Handle_t;

#define MAX_REQ_INDEX   4

/* Struct used to handle array function data */
typedef struct BapLsg_TELEPHONY_FctArray_Handle_t
{
    fctId_t                         fctId;
    uint8_t                         getArrayRequested;
    uint8_t                         reqIndexIdx;
    uint8_t                         reqIndex[MAX_REQ_INDEX+1];
    BAP_TELEPHONY_Opcode_CbkPtr*    fctCbks;
    FctMessage_T*                   fctMsgs;
}TELEPHONY_FctArray_Handle_t;

/*------------------------ BAP Telephony Frame Local types ---------------------- */

/* Struct used to store Frame information */
typedef struct Frame_Tag
{
    FrameStatus_T           frameStatus;
    Scrollbar_T             scrollBar;
    FrameData_StatusArray_T frameData;
    FrameState_T            frameState;
    uint8_t*                pFrameData;
}Frame_T;



/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*------------------------ BAP UHV LSG Local objects ---------------------- */

/* Declare objects related to property functions */

BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE(DECLARE_FCT_PARAMS)

BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE(DECLARE_FCT_CALLBACKS)

BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE(DEFINE_FCT_VECTOR)

BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE(DEFINE_OPCODE_CBK_VECTOR)

static TELEPHONY_FctProperty_Handle_t telephonyFctPropertyData[BAP_TELEPHONY_Property_NumFcts] = {
  BAP_TELEPHONY_SPECIFIC_PROPERTY_TABLE(DEFINE_PROPERTY_HANDLE_ELEMENT)
};

/* Declare objects related to array functions */

BAP_TELEPHONY_ARRAY_TABLE(DECLARE_FCT_PARAMS)

BAP_TELEPHONY_ARRAY_TABLE(DECLARE_FCT_CALLBACKS)

BAP_TELEPHONY_ARRAY_TABLE(DEFINE_FCT_VECTOR)

BAP_TELEPHONY_ARRAY_TABLE(DEFINE_OPCODE_CBK_VECTOR)

static TELEPHONY_FctArray_Handle_t telephonyFctArrayData[BAP_TELEPHONY_Array_NumFcts] = {
  BAP_TELEPHONY_ARRAY_TABLE(DEFINE_ARRAY_HANDLE_ELEMENT)
};

/* 64 bit field used to flag pending status request of property functions */
static uint64_t statusFlags = 0;

/* 64 bit field used to flag pending statusArray request of array functions */
static uint64_t statusArrayFlags = 0;

/* Global flag for locking and unlocking array content sending */
static bool_t gbLockArrayData = BAP_FALSE;

/* Mask used to set and clear flags
 * This is used because the bit fields are of
 * 64 bit. So, doing, for example:
 *
 * statusFlags = 0
 * statusFlags |= 1 << 40;
 *
 * (1 << 40)will be interpreted like 0
 *
 */
static uint64_t mask = 1;

/* Timer used to count time to send delayed status message for LsgStatus function*/
uint16_t LSG_STATUS_Opcode_Status_Timer = 0;

/*------------------------ BAP Telephony Frame objects ---------------------- */

/* Declare frame related objects*/

BAP_TELEPHONY_FRAME_TABLE(DEFINE_FRAME_DATA)
                                                                              
static Frame_T frameArray[BAP_TELEPHONY_NumFrames] = {
  BAP_TELEPHONY_FRAME_TABLE(DEFINE_FRAME_ELEMENT)
};

TELEPHONY_Frame_Id_T MapFrameIdToFrameIdx[] = {
    BAP_TELEPHONY_FRAME_TABLE(MAP_FRAME_ID_TO_FRAME_IDX)    
    [FRAME_STATUS_FRAME_ID_DETERMINED_BY_FSG] = {BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx},
};

/* 64 bit field used to indicate the Idx of the frame that is being update */
static uint64_t frameUpdateFlags = 0;

/* 64 bit field used to indicate the idx of the frame that must update his data */
static uint64_t frameUpdateDataFlags = 0;

/* 64 bit field used to indicate the Idx of the frame that is enqueued (will be updated after the current one)*/
static uint64_t frameQueuedFlags = 0;

/* 64 bit field used to indicate the Idx of the frame that is currently enabled*/
static uint64_t frameEnabledFlags = 0;

/* Global variable indicating last enabled frame */
static TELEPHONY_Frame_Id_T lastEnabledFrame =  BAP_TELEPHONY_FRAME_NO_FRAME_Id;

/* GLobal boolean variable indicating that a call was made from another TAB */
static bool_t callMadeFromAnotherTab = false;

/* Global semaphore for locking and unlocking access to call status frame data */
static Semaphore_Handle CallStatusDataSem = NULL;

//static Semaphore_Handle frameDataSem[BAP_TELEPHONY_NumFrames] = {NULL};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*------------------------ BAP UHV LSG Local functions ---------------------- */


/* Function-like macros to access data from property function */

/* Obtain function-Id of property function */
#define bap_telephony_appl_getFctId(fct)                telephonyFctPropertyData[fct].fctId
/* Check if the property has a given Function-Id */
#define bap_telephony_appl_isFctId(fct, fctId)          (bap_telephony_appl_getFctId(fct) == fctId)
/* Invoke Opcode callback from a given method function */
#define bap_telephony_appl_getOpCbk(fct, opcode, data, length)   (telephonyFctPropertyData[fct].fctCbks[opcode])(data,length);
/* Get Opcode data type from a given property function */
#define bap_telephony_appl_getOpType(fct, opcode)       ((telephonyFctPropertyData[fct].fctMsgs)[opcode]).opType
/* Get Opcode data size from a given property function */
#define bap_telephony_appl_getOpSize(fct, opcode)        ((telephonyFctPropertyData[fct].fctMsgs)[opcode]).opSize
/* Get Opcode parameters from a given property function */
#define bap_telephony_appl_getParams(fct, opcode)        ((telephonyFctPropertyData[fct].fctMsgs)[opcode]).opPrms
/* Get pending status requests for property function */
#define bap_telephony_appl_getPendingStatusFlags()       (statusFlags)
/* Check if there are pending status requests for property function */
#define bap_telephony_appl_isPendingStatusFlags()        (bap_telephony_appl_getPendingStatusFlags() != 0)
/* Get idx of first property that has a pending status request */
#define bap_telephony_appl_getNextStatusFlag()           (BitUtils_CountTrailingZeros64(bap_telephony_appl_getPendingStatusFlags()))
/* Query status request for property function */
#define bap_telephony_appl_setStatusFlag(idx)           {                           \
                                                            mask    = 1;            \
                                                            mask  <<= idx;          \
                                                            statusFlags |= mask;    \
                                                        }
/* Clear pending status request for property function */
#define bap_telephony_appl_clrStatusFlag(idx)           {                           \
                                                            mask    = 1;            \
                                                            mask  <<= idx;          \
                                                            statusFlags &= ~mask;   \
                                                        }


/*Function-like macros to access data from array function */

/* Obtain function-Id of array function */
#define bap_telephony_appl_array_getFctId(fct)                          telephonyFctArrayData[fct].fctId
/* Check if the method has a given Function-Id */
#define bap_telephony_appl_array_isFctId(fct, fctId)                    (bap_telephony_appl_array_getFctId(fct) == fctId)
/* Invoke Opcode callback from a given array function */
#define bap_telephony_appl_array_getOpCbk(fct, opcode, data, length)    (telephonyFctArrayData[fct].fctCbks[opcode])(data,length);
/* Get Opcode data type from a given array function */
#define bap_telephony_appl_array_getOpType(fct, opcode)                 ((telephonyFctArrayData[fct].fctMsgs)[opcode]).opType
/* Get Opcode data size from a given array function */
#define bap_telephony_appl_array_getOpSize(fct, opcode)                 ((telephonyFctArrayData[fct].fctMsgs)[opcode]).opSize
/* Get Opcode parameters from a given array function */
#define bap_telephony_appl_array_getParams(fct, opcode)                 ((telephonyFctArrayData[fct].fctMsgs)[opcode]).opPrms

/* Get pending statusArray requests for array function */
#define bap_telephony_appl_array_getPendingStatusArrayFlags()           (statusArrayFlags)
/* Is pending statusArray requests for array function */
#define bap_telephony_appl_array_isPendingStatusArrayFlags()            (bap_telephony_appl_array_getPendingStatusArrayFlags() != 0)

/* Is pending statusArray requests for array function (generic variable) */
#define bap_telephony_appl_array_isPendingVarStatusArrayFlags(var)      (var != 0)

/* Get idx of first array that has a pending statusArray request */
#define bap_telephony_appl_array_getNextStatusArrayFlag()               (BitUtils_CountTrailingZeros64(bap_telephony_appl_array_getPendingStatusArrayFlags()))

/* Get idx of first array that has a pending statusArray request (generic var) */
#define bap_telephony_appl_array_getNextVarStatusArrayFlag(var)         (BitUtils_CountTrailingZeros64(var))

/* Query statusArray request for array function */
#define bap_telephony_appl_array_setStatusArrayFlag(idx)                {                                       \
                                                                            mask    = 1;                        \
                                                                            mask  <<= idx;                      \
                                                                            statusArrayFlags |= mask;           \
                                                                        }

/* Clear pending statusArray request for array function */
#define bap_telephony_appl_array_clrStatusArrayFlag(idx)                {                                       \
                                                                            mask    = 1;                        \
                                                                            mask  <<= idx;                      \
                                                                            statusArrayFlags &= ~mask;          \
                                                                        }

/* Clear pending statusArray request for array function (generic variable) */
#define bap_telephony_appl_array_clrVarStatusArrayFlag(var,idx)         {                                       \
                                                                            mask    = 1;                        \
                                                                            mask  <<= idx;                      \
                                                                            var &= ~mask;                       \
                                                                        }


/* Obtain IdxSize parameter from ArrayHeader.Mode */
#define bap_telephony_appl_arrayHeader_getIdxSize(header)   ((header->mode) & (FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_MASK)) >> FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_SHIFT
/* Obtain Unknown parameter from ArrayHeader.Mode */
#define bap_telephony_appl_arrayHeader_getUnknownParam(header)  ((header->mode) & (FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_MASK)) >> FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_SHIFT
/* Obtain PosTransmit parameter from ArrayHeader.Mode */
#define bap_telephony_appl_arrayHeader_getPosTransmit(header)   ((header->mode) & (FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_MASK)) >> FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_SHIFT
/* Obtain ArrayDirection parameter from ArrayHeader.Mode */
#define bap_telephony_appl_arrayHeader_getArrayDir(header)   ((header->mode) & (FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_MASK)) >> FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_SHIFT
/* Obtain RecordAdress parameter from ArrayHeader.Mode */
#define bap_telephony_appl_arrayHeader_getRecorAddress(header)   ((header->mode) & (FRAME_DATA_ARRAYHEADER_MODE_RECORDADRESS_MASK))

/* Init send routines for property function */
BapError_et BAP_TELEPHONY_Property_InitSend(TELEPHONY_Fct_Property_Idx_t idx);

/* Set initial value for a property function */
void BAP_TELEPHONY_Property_SetInitialValue(TELEPHONY_Fct_Property_Idx_t idx);

/* Send routines for property functions */
BapError_et BAP_TELEPHONY_Property_Send(TELEPHONY_Fct_Property_Idx_t idx);

/* Send routine for array functions */
BapError_et BAP_TELEPHONY_Array_Send(TELEPHONY_Fct_Array_Idx_t idx, OpCode_T op);

/* Custom function to serialize variable parameters for ByteSequence type Functions*/
void BAP_TELEPHONY_SerializeByteSequence(uint8_t idx, uint8_t *pVar, uint16_t * pLength, OpCode_T op);

/* Task to execute when the LSG Status timer consumes*/
void BAP_TELEPHONY_LSG_STATUS_Timer_Task(void);

/*------------------------ BAP Telephony local functions  ---------------------- */

/*Function-like macros to access data from frames */

/* Get update flags for frames */
#define bap_telephony_appl_frame_getUpdateFlags()           (frameUpdateFlags)
/* Check if there are frames being updated */
#define bap_telephony_appl_frame_isUpdateFlag()             (bap_telephony_appl_frame_getUpdateFlags()   != 0)
/* Get idx of the frame that is being updated */
#define bap_telephony_appl_frame_getUpdateFlag()            (BitUtils_CountTrailingZeros64(bap_telephony_appl_frame_getUpdateFlags()))
/* Set update flag for a given frame */
#define bap_telephony_appl_frame_setUpdateFlag(idx)         do{                                                         \
                                                                mask    = 1;                                            \
                                                                mask  <<= idx;                                          \
                                                                bap_telephony_appl_frame_getUpdateFlags() |= mask;      \
                                                            }while(0)

/* Clear update flag for a given frame */
#define bap_telephony_appl_frame_clrUpdateFlag(idx)         do{                                                         \
                                                                mask    = 1;                                            \
                                                                mask  <<= idx;                                          \
                                                                bap_telephony_appl_frame_getUpdateFlags() &= ~mask;     \
                                                            }while(0)

/* Get queued flags for frames */
#define bap_telephony_appl_frame_getQueuedFlags()           (frameQueuedFlags)
/* Check if there are frames queued */
#define bap_telephony_appl_frame_isQueuedFlag()             (bap_telephony_appl_frame_getQueuedFlags()  != 0)
/* Get idx of the frame that is being queued */
#define bap_telephony_appl_frame_getQueuedFlag()            (BitUtils_CountTrailingZeros64(bap_telephony_appl_frame_getQueuedFlags()))
/* Set queued flag for a given frame */
#define bap_telephony_appl_frame_setQueuedFlag(idx)         do{                                                         \
                                                                mask    = 1;                                            \
                                                                mask  <<= idx;                                          \
                                                                bap_telephony_appl_frame_getQueuedFlags() |= mask;      \
                                                            }while(0)

/* Clear queued flag for a given frame */
#define bap_telephony_appl_frame_clrQueuedFlag(idx)         do{                                                         \
                                                                mask    = 1;                                            \
                                                                mask  <<= idx;                                          \
                                                                bap_telephony_appl_frame_getQueuedFlags() &= ~mask;     \
                                                            }while(0)

/* Get enabled flags */
#define bap_telephony_appl_frame_getEnabledFlags()          (frameEnabledFlags)
/* Check if there are frames enabled */
#define bap_telephony_appl_frame_isEnabledFlag()            (bap_telephony_appl_frame_getEnabledFlags()  != 0)
/* Get idx of the frame that is enabled */
#define bap_telephony_appl_frame_getEnabledFlag()           (BitUtils_CountTrailingZeros64(bap_telephony_appl_frame_getEnabledFlags()))
/* Set enabled flag for a given frame */
#define bap_telephony_appl_frame_setEnabledFlag(idx)        do{                                                         \
                                                                mask    = 1;                                            \
                                                                mask  <<= idx;                                          \
                                                                bap_telephony_appl_frame_getEnabledFlags() |= mask;     \
                                                            }while(0)

/* Clear enabled flag for a given frame */
#define bap_telephony_appl_frame_clrEnabledFlag(idx)        do{                                                         \
                                                                mask    = 1;                                            \
                                                                mask  <<= idx;                                          \
                                                                bap_telephony_appl_frame_getEnabledFlags() &= ~mask;    \
                                                            }while(0)

/* Clear enabled flag*/
#define  bap_telephony_appl_frame_clrCurrentEnabledFlag()   bap_telephony_appl_frame_clrEnabledFlag(bap_telephony_appl_frame_getEnabledFlag())


/* Get updated data flags of frames */
#define bap_telephony_appl_frame_getUpdateDataFlags()       (frameUpdateDataFlags)
/* Check if there are frames updating their data */
#define bap_telephony_appl_frame_isUpdateDataFlag()         (bap_telephony_appl_frame_getUpdateDataFlags() != 0)
/* Get idx of the frame whose data is being updated */
#define bap_telephony_appl_frame_getUpdateDataFlag()        (BitUtils_CountTrailingZeros64(bap_telephony_appl_frame_getUpdateDataFlags()))
/* Set update data flag for a given frame */
#define bap_telephony_appl_frame_setUpdateDataFlag(idx)     do{                                                         \
                                                                mask    = 1;                                            \
                                                                mask  <<= idx;                                          \
                                                                bap_telephony_appl_frame_getUpdateDataFlags() |= mask;  \
                                                            }while(0)

/* Clear update data flag for a given frame */
#define bap_telephony_appl_frame_clrUpdateDataFlag(idx)     do{                                                         \
                                                                mask    = 1;                                            \
                                                                mask  <<= idx;                                          \
                                                                bap_telephony_appl_frame_getUpdateDataFlags() &= ~mask; \
                                                            }while(0)
/* Get status from current frame*/
#define bap_telephony_appl_frame_getStatus(idx)             (frameArray[idx].frameStatus)
/* Set status to a given frame */
#define bap_telephony_appl_frame_setStatus(idx,status)      (frameArray[idx].frameStatus = status)
/* Get Id for a given frame*/
#define bap_telephony_appl_frame_getId(idx)                 (bap_telephony_appl_frame_getStatus(idx).frameId)
/* Get ASG response */
#define bap_telephony_appl_frame_getASGResponse(idx)        (bap_telephony_appl_frame_getStatus(idx).ASG_Response)
/* Set ASG response */
#define bap_telephony_appl_frame_setASGResponse(idx,asg)    (bap_telephony_appl_frame_getStatus(idx).ASG_Response = asg)
/* Get FSG request*/
#define bap_telephony_appl_frame_getFSGRequest(idx)         (bap_telephony_appl_frame_getStatus(idx).FSG_Request)
/* Set FSG request*/
#define bap_telephony_appl_frame_setFSGRequest(idx,fsg)     (bap_telephony_appl_frame_getStatus(idx).FSG_Request = fsg)
/* Set focussed frame-Id*/
#define bap_telephony_appl_frame_setFocusedFrameId(idx,id)  (bap_telephony_appl_frame_getStatus(idx).MFL_Assigned.focusedFrameId = id)
/* Set MFL blocks*/
#define bap_telephony_appl_frame_setMFLBlocks(idx,blocks)   (bap_telephony_appl_frame_getStatus(idx).MFL_Assigned.MFL_Blocks = blocks)
/* Get state from current frame*/
#define bap_telephony_appl_frame_getState(idx)              (frameArray[idx].frameState)
/* Set state to frame*/
#define bap_telephony_appl_frame_setState(idx,state)        (frameArray[idx].frameState = state)
/* Get frame data pointer */
#define bap_telephony_appl_frame_getData(idx)               (frameArray[idx].pFrameData)
/* Get frame scrollbar */
#define bap_telephony_appl_frame_getScrollbar(idx)          (frameArray[idx].scrollBar)
/* Get frame statusArray */
#define bap_telephony_appl_frame_getStatusArray(idx)        (frameArray[idx].frameData)


/* Process key event for a frame */
void BAP_TELEPHONY_FRAME_ProcessKeyEvent(TELEPHONY_Frame_Idx_T idx, MFL_Tasten_Id_T key);
/* Start ON request for a given frame */
bool_t BAP_TELEPHONY_ReqFrameON(TELEPHONY_Frame_Idx_T newIdx, FrameStatus_T frameStatus);
/* Start OFF request for a given frame */
void BAP_TELEPHONY_ReqFrameOFF(TELEPHONY_Frame_Idx_T idx);
/* Set ON state to given frame */
bool_t BAP_TELEPHONY_SetFrameON(TELEPHONY_Frame_Idx_T idx, FrameStatus_T frameStatus);
/* Set OFF state to given frame */
void BAP_TELEPHONY_SetFrameOFF(TELEPHONY_Frame_Idx_T idx, FrameStatus_T frameStatus);

/* Release all frames*/
void BAP_TELEPHONY_FRAME_Release(void);

/* Send current FrameData for Connection Status frame*/
void BAP_TELEPHONY_FRAME_ConnectionStatus_SendData(void);
/* Set visible status for Connection Status frame */
void BAP_TELEPHONY_FRAME_ConnectionStatus_SendStatus(void);
/* Send current FrameData for Call Status frame*/
void BAP_TELEPHONY_FRAME_CallStatus_SendData(void);
/* Set visible status for Call Status frame */
void BAP_TELEPHONY_FRAME_CallStatus_SendStatus(void);

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*----------------------- BAP UHV LSG Function Definitions ----------------- */
/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Sem_Init
 *
 * @brief      Initialize semaphores
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_Sem_Init(void)
{
    CallStatusDataSem = Semaphore_create(1, NULL, NULL);
}



/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Task
 *
 * @brief      Cyclical TELEPHONY Task
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
BapError_et BAP_TELEPHONY_Task(void)
{
    BapError_et eErr = BapErr_OK;

    /* Frame task*/
    BAP_TELEPHONY_Frame_Task();

    /* Timer function to trigger timed events*/
    BAP_TELEPHONY_Timer_Task();

    /* Property functions task */
    BAP_TELEPHONY_Property_Task();

    /* Array function task */
    BAP_TELEPHONY_Array_Task();

    return eErr;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Frame_Task
 *
 * @brief      Periodical TELEPHONY task to process Frame updates
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_Frame_Task(void)
{
    TELEPHONY_Frame_Idx_T   idx;
    FrameStatus_T           frameStatus;
    FrameData_StatusArray_T frameStatusArray;
    Scrollbar_T             scrollbar;

    /* Check if there is a frame that needs to update his data*/
    if(bap_telephony_appl_frame_isUpdateDataFlag())
    {        
        /* Get idx of the frame whose data must be updated */
        idx = bap_telephony_appl_frame_getUpdateDataFlag();

        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Frame_Task > UpdateData: flags = %lu, idx = %x, frameId = %x\r\n",(unsigned long)frameUpdateDataFlags,idx,bap_telephony_appl_frame_getId(idx));

        /* Get scrollbar of the frame being updated*/
        scrollbar = bap_telephony_appl_frame_getScrollbar(idx);


        if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_CALL_STATUS_Id)
        {
            /* Attempt to get access to call status frame data */
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Frame_Task > Get Call Status semaphore \r\n");
            Semaphore_pend(CallStatusDataSem,BIOS_WAIT_FOREVER);
        }

        /* Get status array of the frame being updated*/
        frameStatusArray = bap_telephony_appl_frame_getStatusArray(idx);

        /* Load and trigger BAP-level status message for Scrollbar (Fct-Id 0x16) */
        BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_SCROLLBAR_Idx, Opcode_Status, (uint8_t *) &scrollbar, sizeof(scrollbar));

        /* Load and trigger BAP-level status message for FrameData (Fct-Id 0x14) */
        BAP_TELEPHONY_Array_Opcode_Cbk(BAP_TELEPHONY_Array_FRAME_DATA_Idx, Opcode_StatusArray, (uint8_t *) &frameStatusArray,sizeof(frameStatusArray));

        bap_telephony_appl_frame_clrUpdateDataFlag(idx);

        if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_CALL_STATUS_Id)
        {
            /* Attempt to get access to call status frame data */
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Frame_Task > Release Call Status semaphore \r\n");
            Semaphore_post(CallStatusDataSem);
        }

    }
    else if(gbLockArrayData == FALSE)
    {
        /* Check if there is currently a frame that is being updated */
        if(bap_telephony_appl_frame_isUpdateFlag())
        {
            /* Get idx of the frame that is being updated */
            idx = bap_telephony_appl_frame_getUpdateFlag();

            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Frame_Task > Update status: flags = %lu, idx = %x, frameId = %x\r\n",(unsigned long)frameUpdateFlags,idx,bap_telephony_appl_frame_getId(idx));

            /* Get status of the frame being updated */
            frameStatus = bap_telephony_appl_frame_getStatus(idx);

            /* Load and trigger BAP-level status message for FrameStatus (Fct-Id 0x13) */
            BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_FRAME_STATUS_Idx, Opcode_Status, (uint8_t *) &(frameStatus), sizeof(frameStatus));
        }
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Property_Init
 *
 * @brief      Init value for all TELEPHONY Property Fcts
 *
 * @param [in] void
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_TELEPHONY_Property_Init(void)
{
    BapError_et eErr = BapErr_OK;
    TELEPHONY_Fct_Property_Idx_t fctPropertyIdx;

    for(fctPropertyIdx = BAP_TELEPHONY_Property_FSG_OPERATION_STATE_Idx; fctPropertyIdx < BAP_TELEPHONY_Property_NumFcts;fctPropertyIdx++)
    {
        eErr = BAP_TELEPHONY_Property_InitSend(fctPropertyIdx);

        if(BapErr_OK != eErr)
        {
            return eErr;
        }
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Property_InitValues
 *
 * @brief      Init value for all TELEPHONY Property Fcts
 *
 * @param [in] void
 *
 * @return     BapError_et
 *
 ******************************************************************************/
void BAP_TELEPHONY_Property_InitValues(void)
{
    TELEPHONY_Fct_Property_Idx_t fctPropertyIdx;

    for(fctPropertyIdx = BAP_TELEPHONY_Property_FSG_OPERATION_STATE_Idx; fctPropertyIdx < BAP_TELEPHONY_Property_NumFcts;fctPropertyIdx++)
    {
        BAP_TELEPHONY_Property_SetInitialValue(fctPropertyIdx);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Property_Task
 *
 * @brief      Periodical TELEPHONY task to process Property functions
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_Property_Task(void)
{
    TELEPHONY_Fct_Property_Idx_t fctPropertyIdx;

    /* While there are pending status requests */
    while(bap_telephony_appl_isPendingStatusFlags())
    {
        /* Get the first pending request */
        fctPropertyIdx = (TELEPHONY_Fct_Property_Idx_t)bap_telephony_appl_getNextStatusFlag();

        /* Process pending request */
        BAP_TELEPHONY_Property_Send(fctPropertyIdx);

        /* Clear pending request */
        bap_telephony_appl_clrStatusFlag(fctPropertyIdx);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Array_Task
 *
 * @brief      Periodical TELEPHONY task to process Array functions
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_Array_Task(void)
{
    TELEPHONY_Fct_Array_Idx_t fctArrayIdx;
    uint64_t tempStatusArrayFlags;

    tempStatusArrayFlags = bap_telephony_appl_array_getPendingStatusArrayFlags();

    /* While there are pending statusArray requests */
    while(bap_telephony_appl_array_isPendingVarStatusArrayFlags(tempStatusArrayFlags))
    {
        /* Get the first pending request */
        fctArrayIdx = (TELEPHONY_Fct_Array_Idx_t)bap_telephony_appl_array_getNextVarStatusArrayFlag(tempStatusArrayFlags);

        if(gbLockArrayData == BAP_FALSE)
        {
            /* Lock array data */
            gbLockArrayData = BAP_TRUE;

            /* Send status array */
            BAP_TELEPHONY_Array_Send(fctArrayIdx, Opcode_StatusArray);
        
            /* Clear pending request */
            bap_telephony_appl_array_clrStatusArrayFlag(fctArrayIdx);
        }
        else
        {
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Array_Task > Ommiting Array send \r\n");
        }

        /* Clear pending request */
        bap_telephony_appl_array_clrVarStatusArrayFlag(tempStatusArrayFlags,fctArrayIdx);
    }

} 

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Acknowledge
 *
 * @brief      Is called when an Acknowledge is generated in BAP
 *             for TELEPHONY LSG
 *
 * @param [in] void
 *
 * @return     void
 *Void
 ******************************************************************************/
void BAP_TELEPHONY_Acknowledge(fctId_t aFctId, BapAcknowledge_et aeAcknowledge)
{
    TELEPHONY_Frame_Idx_T idx;
    FrameState_T frameState;
    RecentCalls_UpdateCmd_T prevCmd;
    CallStatus_Update_Cmd_T prevCallCmd;

    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Acknowledge > fctId = %x, aeAcknowledge = %x \r\n", aFctId, aeAcknowledge);

    if((aFctId == BapFct_TELEPHONY_FRAME_DATA_Id) && (aeAcknowledge == BapAck_Array_Data))
    {
        /* Status Array message was acknowledge by BAP, unlock the transmission of other messages */
        gbLockArrayData = BAP_FALSE;

        /* Get idx of the current enabled frame*/
        idx = bap_telephony_appl_frame_getEnabledFlag();

        /* Check if the recent calls frame is active */
        if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_RECENT_CALLS_Id)
        {
            /* Get command executed in the list before this message */
            prevCmd = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_CurrentCmd();

            /* If there was an active command*/
            if(prevCmd != RecentCalls_NoCommand)
            {
                /* Clear the prevous command*/
                BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(RecentCalls_NoCommand);


                /* If there was a down command in the list */
                if((prevCmd == RecentCalls_ListDown))
                {
                    /* Check if the list must be updated*/
                    BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_UpdateListDown);
                }

                /* If there was an up command in the list */
                if((prevCmd == RecentCalls_ListUp))
                {
                    /* Check if the list must be updated*/
                    BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_UpdateListUp);
                }

                if(prevCmd == RecentCalls_InitialSend)
                {
                    BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_InitialSend_Complete);
                }

                if(prevCmd == RecentCalls_MoveToBottom)
                {
                    BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_MoveToBottom_Complete);    
                }

            }
        }

        /* Attempt to get access to call status frame data */
        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Acknowledge > Get Call Status semaphore \r\n");
        Semaphore_pend(CallStatusDataSem,BIOS_WAIT_FOREVER);

        /* Get command executed in the list before this message */
        prevCallCmd = BAP_TELEPHONY_FRAME_CallStatus_List_Get_CurrentCmd();    

        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Acknowledge > Call status > cmd = %d \r\n",prevCallCmd);

        /* If there was an active command*/
        if(prevCallCmd != CallStatus_NoCommand)
        {
            /* Clear the prevous command*/
            BAP_TELEPHONY_FRAME_CallStatus_List_Set_CurrentCmd(CallStatus_NoCommand);
        }

        /* Release access to call status frame data*/
        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Acknowledge > Release Call Status semaphore \r\n");
        Semaphore_post(CallStatusDataSem);

    }

    if((aFctId == BapFct_TELEPHONY_FRAME_STATUS_Id))
    {
        if(bap_telephony_appl_frame_getUpdateFlags())
        {
            /* Get idx of the frame that was updated by the previous message*/
            idx = bap_telephony_appl_frame_getUpdateFlag();

            /* Get frame state of that message to analyze what to do */
            frameState = bap_telephony_appl_frame_getState(idx);
            
            /* Clear update flag so the frame status is no longer updated*/
            bap_telephony_appl_frame_clrUpdateFlag(idx);

            if(frameState == FrameState_GoingToON)
            {
                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Acknowledge > frameId %x enabled \r\n",bap_telephony_appl_frame_getId(idx));

                if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_RECENT_CALLS_Id)
                {
                    BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_InitialSend_Complete);
                }
                else
                {
                    lastEnabledFrame = bap_telephony_appl_frame_getId(idx);
                }

                bap_telephony_appl_frame_setState(idx,FrameState_ON);
                bap_telephony_appl_frame_setEnabledFlag(idx);
            }

            if(frameState == FrameState_GoingToOFF)
            {
                if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_RELEASE_ALL_FRAMES_Id)
                {
                    /* Must disable the current frame that is showing*/                    
                    if(bap_telephony_appl_frame_isEnabledFlag())
                    {
                        idx = bap_telephony_appl_frame_getEnabledFlag();
                        bap_telephony_appl_frame_setState(idx,FrameState_OFF);
                        bap_telephony_appl_frame_clrEnabledFlag(idx);
                    }
                }
                else
                {
                    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_Acknowledge > frameId %x disabled \r\n",bap_telephony_appl_frame_getId(idx));
                    /* Updated frame must be indicated as disabled */
                    bap_telephony_appl_frame_setState(idx,FrameState_OFF);
                    bap_telephony_appl_frame_clrEnabledFlag(idx);

                    /* Check if there is a pending frame update*/
                    if(bap_telephony_appl_frame_isQueuedFlag())
                    {
                        idx = bap_telephony_appl_frame_getQueuedFlag();
                        bap_telephony_appl_frame_setUpdateFlag(idx);
                        bap_telephony_appl_frame_clrQueuedFlag(idx);
                    }
                }
            }
        }
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_IndicationVoid
 *
 * @brief      Is called when an Void indication arrives
 *             for TELEPHONY
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_IndicationVoid(fctId_t aFctId, BapIndication_et aeIndication)
{
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_IndicationInt8
 *
 * @brief      Is called when an Int8 indication arrives
 *             for TELEPHONY
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_IndicationInt8(fctId_t aFctId,
                              BapIndication_et aeIndication,
                              uint8_t au8Value)
{
    OpCode_T opCode;

    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_IndicationInt8 > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_IndicationInt8 > aeIndication = %x  \n",aeIndication);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_IndicationInt8 > au8Value = %x  \n",au8Value);

    if((aFctId == BapFct_TELEPHONY_LSG_STATUS_Id) && (aeIndication == BapInd_DataSet))
    {
            opCode = BAP_TELEPHONY_Map_Ind_to_Opcode[aeIndication];

            BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_LSG_STATUS_Idx,
                                        opCode, &au8Value,sizeof(uint8_t));
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_IndicationByteSequence
 *
 * @brief      Is called when an Void indication arrives
 *             for OPS
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_IndicationByteSequence(fctId_t aFctId
                                    , BapIndication_et aeIndication
                                    , const volatile_ptr_t apValue
                                    , uint16_t au16Length)
{
    OpCode_T opCode;

    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_IndicationByteSequence > aFctId = %x  \n",aFctId);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_IndicationByteSequence > aeIndication = %x  \n",aeIndication);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_IndicationByteSequence > au16Length = %x  \n",au16Length);

    switch(aFctId)
    {
        case BapFct_TELEPHONY_ASG_CAPABILITIES_Id:

            if((aeIndication == BapInd_DataSet) || (aeIndication == BapInd_DataSetGet))
            {
                opCode = BAP_TELEPHONY_Map_Ind_to_Opcode[aeIndication];

                BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_ASG_CAPABILITIES_Idx,
                                           opCode, (uint8_t *)apValue,au16Length);
            }

        break;

        case BapFct_TELEPHONY_ASG_CONFIG_Id:

            if((aeIndication == BapInd_DataSet) || (aeIndication == BapInd_DataSetGet))
            {
                opCode = BAP_TELEPHONY_Map_Ind_to_Opcode[aeIndication];

                BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_ASG_CONFIG_Idx,
                                           opCode, (uint8_t *)apValue,au16Length);
            }

        break;

        case BapFct_TELEPHONY_MFL_BLOCK_DEFINITION_Id:

            if((aeIndication == BapInd_DataSet) || (aeIndication == BapInd_DataSetGet))
            {
                opCode = BAP_TELEPHONY_Map_Ind_to_Opcode[aeIndication];

                BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_MFL_BLOCK_DEFINITION_Idx,
                                           opCode, (uint8_t *)apValue,au16Length);
            }        

        break;

        case BapFct_TELEPHONY_FRAME_STATUS_Id:

            if((aeIndication == BapInd_DataSet) || (aeIndication == BapInd_DataSetGet))
            {
                opCode = BAP_TELEPHONY_Map_Ind_to_Opcode[aeIndication];

                BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_FRAME_STATUS_Idx,
                                           opCode, (uint8_t *)apValue,au16Length);
            }                

        break;

        case BapFct_TELEPHONY_FRAME_DATA_Id:

            if(aeIndication == BapInd_DataGet)
            {
                opCode = BAP_TELEPHONY_Map_Ind_to_Opcode[aeIndication];

                BAP_TELEPHONY_Array_Opcode_Cbk(BAP_TELEPHONY_Array_FRAME_DATA_Idx,
                                           Opcode_GetArray, (uint8_t *)apValue,au16Length);
            }                        

        break;

        case BapFct_TELEPHONY_FRAME_DATA_ACK_Id:

            if(aeIndication == BapInd_DataSet)
            {
                opCode = BAP_TELEPHONY_Map_Ind_to_Opcode[aeIndication];

                BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_FRAME_DATA_ACK_Idx,
                                           opCode, (uint8_t *)apValue,au16Length);
            }                        

        break;

        default:

        break;
    }


}

/***************************************************************************//**
 *
 * @fn         BAP_OPS_IndicationError
 *
 * @brief      Is called when an Error indication arrives
 *             for OPS
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_IndicationError(fctId_t aFctId
                             , BapError_et aeErrorCode)
{
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Property_InitSend
 *
 * @brief      Initial send of a property class function
 *
 * @param [in] TELEPHONY_Fct_Property_Idx_t
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_TELEPHONY_Property_InitSend(TELEPHONY_Fct_Property_Idx_t idx)
{
    BapError_et eErr = BapErr_OK;
    uint8_t pVar[MAX_LEN];
    uint16_t aLength = 0;

    switch(bap_telephony_appl_getOpType(idx,Opcode_Status))
    {
        case Type_Int8:
            eErr = BAP_InitSendInt8(BapLsg_TELEPHONY_Id,
                                    bap_telephony_appl_getFctId(idx),
                                    bap_telephony_appl_getParams(idx,Opcode_Status));
            break;

        case Type_Int16:
            eErr = BAP_InitSendInt16(BapLsg_TELEPHONY_Id,
                                     bap_telephony_appl_getFctId(idx),
                                     bap_telephony_appl_getParams(idx,Opcode_Status));
            break;

        case Type_Int32:
            eErr = BAP_InitSendInt32(BapLsg_TELEPHONY_Id,
                                     bap_telephony_appl_getFctId(idx),
                                     bap_telephony_appl_getParams(idx,Opcode_Status));
            break;

        case Type_FixedByteSequence:
            eErr = BAP_InitSendByteSequence(BapLsg_TELEPHONY_Id,
                                            bap_telephony_appl_getFctId(idx),
                                            bap_telephony_appl_getParams(idx,Opcode_Status),
                                            bap_telephony_appl_getOpSize(idx,Opcode_Status));
            break;

        case Type_ByteSequence:
            eErr = BAP_InitSendByteSequence(BapLsg_TELEPHONY_Id,
                                            bap_telephony_appl_getFctId(idx),
                                            pVar,
                                            aLength);
            break;
    }

    if(eErr != BapErr_OK)
    {
        LOG_PRINT(DEBUG_BAP, "BAP LSG: TELEPHONY (%x) FCT: (%x) InitSend -> eErr = %x \n",
                  BapLsg_TELEPHONY_Id, bap_telephony_appl_getFctId(idx), eErr);
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Property_SetInitialValue
 *
 * @brief      Set initial value for a property class funciton
 *
 * @param [in] TELEPHONY_Fct_Property_Idx_t
 *
 * @return     void
 *
  ******************************************************************************/
void BAP_TELEPHONY_Property_SetInitialValue(TELEPHONY_Fct_Property_Idx_t idx)
{
    memset(bap_telephony_appl_getParams(idx,Opcode_Status), 0x00, bap_telephony_appl_getOpSize(idx,Opcode_Status));

    switch(idx)
    {
        case BAP_TELEPHONY_Property_ASG_CAPABILITIES_Idx:

            BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Data.displaySizeClass = DisplaySizeClass_Small;
            BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Data.numVisibleListElements = ASG_CAPABILITIES_NUM_LIST_ELEMENTS_DEFAULT_VALUE;

            break;

        case BAP_TELEPHONY_Property_ASG_CONFIG_Idx:

            BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Data.vMajor = ASG_CONFIG_VERSION_MAJOR;
            BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Data.vMinor = ASG_CONFIG_VERSION_MINOR;

            break;

        case BAP_TELEPHONY_Property_FRAME_STATUS_Idx:

            BAP_TELEPHONY_FRAME_STATUS_Opcode_Status_Data.ASG_Response = ASG_Response_NoResponse;
            BAP_TELEPHONY_FRAME_STATUS_Opcode_Status_Data.FSG_Request = FSG_Request_NoRequest;

            break; 

        case BAP_TELEPHONY_Property_FRAME_DATA_ACK_Idx:

            BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Status_Data = FRAME_STATUS_FRAME_ID_DEVICE_INFO;

            break;

        case BAP_TELEPHONY_Property_SCROLLBAR_Idx:

            BAP_TELEPHONY_SCROLLBAR_Opcode_Status_Data.frameId = FRAME_STATUS_FRAME_ID_DEVICE_INFO;
            BAP_TELEPHONY_SCROLLBAR_Opcode_Status_Data.sliderLength = SCROLLBAR_SLIDER_LENGTH_DEFAULT_VALUE;

            break;

        case BAP_TELEPHONY_Property_LSG_STATUS_Idx:

            BAP_TELEPHONY_LSG_STATUS_Opcode_Status_Data = LSG_STATUS_ALIVE;

            break;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Property_Send
 *
 * @brief      Request status of a property class function
 *
 * @param [in] TELEPHONY_Fct_Property_Idx_t
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_TELEPHONY_Property_Send(TELEPHONY_Fct_Property_Idx_t idx)
{
    BapError_et eErr = BapErr_OK;
    uint8_t pVar[MAX_LEN];
    uint16_t aLength = 0;

    LOG_PRINT(DEBUG_BAP,"Sending property = %d \n",idx);

    switch(bap_telephony_appl_getOpType(idx,Opcode_Status))
    {
        case Type_Int8:
            eErr = BAP_SendInt8(BapLsg_TELEPHONY_Id,
                                bap_telephony_appl_getFctId(idx),
                                BAP_TELEPHONY_Map_OpCode_to_Req[Opcode_Status],
                                bap_telephony_appl_getParams(idx,Opcode_Status));
            break;

        case Type_Int16:
            eErr = BAP_SendInt16(BapLsg_TELEPHONY_Id,
                                 bap_telephony_appl_getFctId(idx),
                                 BAP_TELEPHONY_Map_OpCode_to_Req[Opcode_Status],
                                 bap_telephony_appl_getParams(idx,Opcode_Status));
            break;

        case Type_Int32:
            eErr = BAP_SendInt32(BapLsg_TELEPHONY_Id,
                                 bap_telephony_appl_getFctId(idx),
                                 BAP_TELEPHONY_Map_OpCode_to_Req[Opcode_Status],
                                 bap_telephony_appl_getParams(idx,Opcode_Status));
            break;

        case Type_FixedByteSequence:
            eErr = BAP_SendByteSequence(BapLsg_TELEPHONY_Id,
                                        bap_telephony_appl_getFctId(idx),
                                        BAP_TELEPHONY_Map_OpCode_to_Req[Opcode_Status],
                                        bap_telephony_appl_getParams(idx,Opcode_Status),
                                        bap_telephony_appl_getOpSize(idx,Opcode_Status));
            break;

        case Type_ByteSequence:
            eErr = BAP_SendByteSequence(BapLsg_TELEPHONY_Id,
                                        bap_telephony_appl_getFctId(idx),
                                        BAP_TELEPHONY_Map_OpCode_to_Req[Opcode_Status],
                                        pVar,
                                        aLength);
            break;
    }

    if(eErr != BapErr_OK)
    {
        LOG_PRINT(DEBUG_BAP, "BAP LSG: TELEPHONY (%x) FCT: (%x) InitSend -> eErr = %x \n",
                  BapLsg_TELEPHONY_Id, bap_telephony_appl_getFctId(idx), eErr);
    }

    return eErr;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Array_Send
 *
 * @brief      Request opcode send of an array class function
 *
 * @param [in] TELEPHONY_Fct_Array_Idx_t
 *             OpCode_T
 *
 * @return     BapError_et
 *
 ******************************************************************************/
BapError_et BAP_TELEPHONY_Array_Send(TELEPHONY_Fct_Array_Idx_t idx, OpCode_T op)
{
    BapError_et eErr = BapErr_OK;
    uint8_t pVar[MAX_LEN];
    uint16_t aLength;

    switch(bap_telephony_appl_array_getOpType(idx,op))
    {
        case Type_Int8:
            eErr = BAP_SendInt8(BapLsg_TELEPHONY_Id,
                                bap_telephony_appl_array_getFctId(idx),
                                BAP_TELEPHONY_Map_OpCode_to_Req[op],
                                bap_telephony_appl_array_getParams(idx,op));
            break;

        case Type_Int16:
            eErr = BAP_SendInt16(BapLsg_TELEPHONY_Id,
                                 bap_telephony_appl_array_getFctId(idx),
                                 BAP_TELEPHONY_Map_OpCode_to_Req[op],
                                 bap_telephony_appl_array_getParams(idx,op));
            break;

        case Type_Int32:
            eErr = BAP_SendInt32(BapLsg_TELEPHONY_Id,
                                 bap_telephony_appl_array_getFctId(idx),
                                 BAP_TELEPHONY_Map_OpCode_to_Req[op],
                                 bap_telephony_appl_array_getParams(idx,op));
            break;

        case Type_FixedByteSequence:
            eErr = BAP_SendByteSequence(BapLsg_TELEPHONY_Id,
                                        bap_telephony_appl_array_getFctId(idx),
                                        BAP_TELEPHONY_Map_OpCode_to_Req[op],
                                        bap_telephony_appl_array_getParams(idx,op),
                                        bap_telephony_appl_array_getOpSize(idx,op));
            break;

        case Type_ByteSequence:

            BAP_TELEPHONY_SerializeByteSequence((uint8_t)idx,pVar,&aLength,op);

            eErr = BAP_SendByteSequence(BapLsg_TELEPHONY_Id,
                                        bap_telephony_appl_array_getFctId(idx),
                                        BAP_TELEPHONY_Map_OpCode_to_Req[op],
                                        pVar,
                                        aLength);

            break;
    }

    return eErr;
}

void BAP_TELEPHONY_SerializeByteSequence(uint8_t idx, uint8_t *pVar, uint16_t * pLength, OpCode_T op)
{
    switch(idx)
    {
        case BAP_TELEPHONY_Array_FRAME_DATA_Idx:

            if(op == Opcode_StatusArray)
            {
                BAP_FRAME_DATA_Serialize_StatusArray_Data(pVar,pLength);
            }

            break;


    }
}


/***************************************************************************//**
 *
 * @fn         BAP_SerializeByteSequence
 *
 * @brief      Serialize paraeters of a variable ByteSequence function.
 *             This function is "ugly" but handle two special cases of
 *             functions with variable length parameters ("strings")
 *
 * @param [in] AUDIO_Fct_Property_Idx_t
 *             uint8_t *
 *             uint8_t *
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Serialize_StatusArray_Data(uint8_t * pVar, uint16_t* pLength)
{
    uint16_t nBytes = 0;

    /* Serialize FrameId */
    memcpy(&(pVar[nBytes]),&(BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Data.frameId),sizeof(uint8_t));
    nBytes+=1;

    /* Serialize list element on top*/
    memcpy(&(pVar[nBytes]),&(BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Data.listElementOnTop),sizeof(uint8_t));
    nBytes+=1;    

    /* Serialize list operation*/
    memcpy(&(pVar[nBytes]),&(BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Data.listOperation),sizeof(uint8_t));
    nBytes+=1;    

    /* Serialize array header */
    nBytes += BAP_FRAME_DATA_Serialize_ArrayHeader(&(pVar[nBytes]), &(BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Data.arrayHeader));

    /* Serialize array data */
    nBytes += BAP_FRAME_DATA_Serialize_ArrayData(&pVar[nBytes], &(BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Data.arrayHeader),
                                           &(BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Data.arrayData));

    /* Return the total number of serialized bytes */
    *pLength = nBytes;
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Serialize_ArrayHeader
 *
 * @brief      Serialize BAP Info List ArrayHeader parameter in a
 *             uint8_t array
 *
 * @param [out] uint8_t*         - Serialized data
 * @param [in]  ArrayHeader_T*   - Array header to be serialized
 *
 * @return     uint16_t - Serialized length
 *
 ******************************************************************************/
uint16_t BAP_FRAME_DATA_Serialize_ArrayHeader(uint8_t * pVar, ArrayHeader_T * header)
{
    uint16_t i;
    uint16_t u16Length;
    ArrayIndexSize_T idxSize;

    i = 0;

    // Serialize ArrayHeader.Mode parameter
    memcpy(&pVar[i],&(header->mode),sizeof(header->mode));
    i+=sizeof(header->mode);

    // Serialize ArrayHeader.Start parameter
    // IdxSize bit from ArrayHeader.Mode must be analyzed
    idxSize = BAP_FRAME_DATA_Get_Array_Header_IdxSize(header);
    if(idxSize == ArrayIndexSize_16Bits)
    {
        // If ArrayHeader.Mode.IdxSize is 16 bit
        // The two bytes of Start goes in the message
        memcpy(&pVar[i],&(header->start),sizeof(header->start));
        i+=sizeof(header->start);

        // If ArrayHeader.Mode.IdxSize is 16 bit
        // The two bytes of Elements goes in the message
        memcpy(&pVar[i],&(header->elements),sizeof(header->elements));
        i+=sizeof(header->elements);
    }
    else
    {
        // If ArrayHeader.Mode.IdxSize is 8 bit
        // Only the LSB of ArrayHeader.Start
        // goes on the message
        pVar[i] = (uint8_t)(header->start & 0x00FF);
        i+=1;

        // If ArrayHeader.Mode.IdxSize is 8 bit
        // Only the LSB of ArrayHeader.Elements
        // goes on the message
        pVar[i] = (uint8_t)(header->elements & 0x00FF);
        i+=1;
    }

    u16Length = i;

    return u16Length;
}

uint16_t BAP_FRAME_DATA_Serialize_ArrayData(uint8_t* pVar, ArrayHeader_T* header, FrameData_Array_T* data)
{
    uint16_t nBytes;
    uint16_t entryNameBytes;
    uint16_t elements;
    uint16_t i;
    ArrayRecordAddress_T recordAddress;
    bool_t posTransmit;
    ArrayIndexSize_T idxSize;

    /* Serialize ArrayData parameter */

    // ArrayHeader.Elements is needed to loop through the data
    elements = BAP_FRAME_DATA_Get_Array_Header_Elements(header);
    // ArrayHeader.Mode.RecordAddress must be analyzed
    recordAddress = BAP_FRAME_DATA_Get_Array_Header_RecordAddress(header);
    // ArrayHeader.Mode.PosTransmit must be analyzed
    posTransmit = BAP_FRAME_DATA_Get_Array_Header_PosTransmit(header);
    // IdxSize bit from ArrayHeader.Mode must be analyzed
    idxSize = BAP_FRAME_DATA_Get_Array_Header_IdxSize(header);

    // Initialize byte counter
    nBytes = 0;

    // Loop through all the data entry
    for(i = 0; i < elements; i++)
    {
        // Serialize Data.Entry[i].Pos parameter if:
        //
        //  - Header.Mode.posTransmit is TRUE
        //  - Array idx size is 8 bit
        //
        if((posTransmit == true))
        {
            if(idxSize == ArrayIndexSize_8Bits)
            {
                // If ArrayHeader.Mode.IdxSize is 8 bit
                pVar[nBytes] = (uint8_t)(data->entry[i].pos);
                nBytes+=1;
            }
        }

        // Serialize Data.Entry[i].type parameter if:
        //
        //  - Header.Mode.recordAddress.Type is set
        //
        if((recordAddress & ArrayRecordAdress_TypeAndAttributes))
        {   
            memcpy(&pVar[nBytes],&(data->entry[i].type),sizeof(data->entry[i].type));
            nBytes+=sizeof(data->entry[i].type);
        }

        // Serialize Data.Entry[i].attributes parameter if:
        //
        //  - Header.Mode.recordAddress.Attributes is set
        //
        if((recordAddress & ArrayRecordAdress_AttributesOnly))
        {
            memcpy(&pVar[nBytes],&(data->entry[i].attributes),sizeof(data->entry[i].attributes));
            nBytes+=sizeof(data->entry[i].attributes);
        }

        // Serialize Data.Entry[i].name parameter if:
        //
        //  - Header.Mode.recordAddress.Name
        //
        if(recordAddress & ArrayRecordAdress_NameOnly)
        {
            entryNameBytes = data->entry[i].name[0] + 1;
            memcpy(&(pVar[nBytes]),&(data->entry[i].name[0]),entryNameBytes);
            nBytes += entryNameBytes;
        }
    }

    return nBytes;    
}


ArrayIndexSize_T BAP_FRAME_DATA_Get_Array_Header_IdxSize(ArrayHeader_T* header)
{
    uint8_t idxSize;

    idxSize = bap_telephony_appl_arrayHeader_getIdxSize(header);
    if(idxSize == FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_16BITS)
    {
        return ArrayIndexSize_16Bits;
    }
    else
    {
        return ArrayIndexSize_8Bits;
    }
}

uint16_t BAP_FRAME_DATA_Get_Array_Header_Elements(ArrayHeader_T* header)
{
    return (header->elements);
}

uint16_t BAP_FRAME_DATA_Get_Array_Header_Start(ArrayHeader_T* header)
{
    return (header->start);
}

ArrayRecordAddress_T BAP_FRAME_DATA_Get_Array_Header_RecordAddress(ArrayHeader_T* header)
{
    return (ArrayRecordAddress_T)(bap_telephony_appl_arrayHeader_getRecorAddress(header));
}

bool_t BAP_FRAME_DATA_Get_Array_Header_PosTransmit(ArrayHeader_T* header)
{
    uint8_t posTransmit;

    posTransmit = bap_telephony_appl_arrayHeader_getPosTransmit(header);
    if(posTransmit == FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_TRANSMITTED)
    {
        return true;
    }

    return false;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Property_Opcode_Cbk
 *
 * @brief      Invoke opcode callback supported by property function
 *
 * @param [in] AUDIO_Fct_Property_Idx_t - Property function index
 *             OpCode_T - Opcode
 *             uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_Property_Opcode_Cbk(TELEPHONY_Fct_Property_Idx_t idx, OpCode_T op, uint8_t * data, uint16_t length)
{
    LOG_PRINT(DEBUG_BAP,"BAP TELEPHONY Fct Idx = %x, Opcode Cbk = %x Length = %x \n",
              idx,op,length);
    bap_telephony_appl_getOpCbk(idx, op, data,length)
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Array_Opcode_Cbk
 *
 * @brief      Invoke opcode callback supported by array function
 *
 * @param [in] TELEPHONY_Fct_Property_Idx_t - Property function index
 *             OpCode_T - Opcode
 *             uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_Array_Opcode_Cbk(TELEPHONY_Fct_Array_Idx_t idx, OpCode_T op, uint8_t * data, uint16_t length)
{
    LOG_PRINT(DEBUG_BAP,"BAP TELEPHONY Fct Idx = %x, Opcode Cbk = %x Length = %x \n",
              idx,op,length);
    bap_telephony_appl_array_getOpCbk(idx, op, data,length)    
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_Get_Cbk
 *
 * @brief      Invoke opcode "Get" callback for "FSG-OperationState"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_Get_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_Get_Cbk
 *
 * @brief      Invoke opcode "Status" callback for "FSG-OperationState"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_Status_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_HeartbeatStatus_Cbk
 *
 * @brief      Invoke opcode "HeartbeatStatus" callback for "FSG-OperationState"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_HeartbeatStatus_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "FSG-OperationState"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FSG_OPERATION_STATE_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Get_Cbk
 *
 * @brief      Invoke opcode "Get" callback for "ASG_Capabilities"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Get_Cbk(uint8_t* data, uint16_t length)
{
    /* Generate status message*/
    BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_ASG_CAPABILITIES_Idx, Opcode_Status, data, length);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_SetGet_Cbk
 *
 * @brief      Invoke opcode "SetGet" callback for "ASG_Capabilities"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_SetGet_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_SetGet_Size)
    {
        /* Get display size class*/
        BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_SetGet_Data.displaySizeClass = (DisplaySizeClass_T) data[ASG_CAPABILITIES_DISPLAY_SIZE_CLASS_IDX];

        /* Get number of list elements */
        BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_SetGet_Data.numVisibleListElements = data[ASG_CAPABILITIES_NUM_LIST_ELEMENTS_IDX];

        /* Generate status message*/
        BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_ASG_CAPABILITIES_Idx, Opcode_Status, data, length);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Cbk
 *
 * @brief      Invoke opcode "Status" callback for "ASG_Capabilities"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Size)
    {
        /* Get display size class*/
        BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Data.displaySizeClass = (DisplaySizeClass_T) data[ASG_CAPABILITIES_DISPLAY_SIZE_CLASS_IDX];

        /* Get number of list elements */
        BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Status_Data.numVisibleListElements = data[ASG_CAPABILITIES_NUM_LIST_ELEMENTS_IDX];
    }

    /* Trigger status message*/
    bap_telephony_appl_setStatusFlag(BAP_TELEPHONY_Property_ASG_CAPABILITIES_Idx);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_HeartbeatStatus_Cbk
 *
 * @brief      Invoke opcode "HeartbeatStatus" callback for "ASG_Capabilities"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_HeartbeatStatus_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "ASG_Capabilities"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CAPABILITIES_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CONFIG_Opcode_Get_Cbk
 *
 * @brief      Invoke opcode "Get" callback for "ASG_Config"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CONFIG_Opcode_Get_Cbk(uint8_t* data, uint16_t length)
{
    /* Generate status message*/
    BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_ASG_CONFIG_Idx, Opcode_Status, data, length);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CONFIG_Opcode_SetGet_Cbk
 *
 * @brief      Invoke opcode "SetGet" callback for "ASG_Config"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CONFIG_Opcode_SetGet_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_ASG_CONFIG_Opcode_SetGet_Size)
    {    
        /* Get Version Major parameter*/
        BAP_TELEPHONY_ASG_CONFIG_Opcode_SetGet_Data.vMajor = data[ASG_CONFIG_VERSION_MAJOR_IDX];

        /* Get Version Minor parameter */
        BAP_TELEPHONY_ASG_CONFIG_Opcode_SetGet_Data.vMinor = data[ASG_CONFIG_VERSION_MINOR_IDX];

        /* Generate status message*/
        BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_ASG_CONFIG_Idx, Opcode_Status, data, length);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Cbk
 *
 * @brief      Invoke opcode "Status" callback for "ASG_Config"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Size)
    {
        /* Get Version Major parameter*/
        BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Data.vMajor = data[ASG_CONFIG_VERSION_MAJOR_IDX];

        /* Get Version Minor parameter */
        BAP_TELEPHONY_ASG_CONFIG_Opcode_Status_Data.vMinor = data[ASG_CONFIG_VERSION_MINOR_IDX];
    }

    /* Trigger status message*/
    bap_telephony_appl_setStatusFlag(BAP_TELEPHONY_Property_ASG_CONFIG_Idx);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CONFIG_Opcode_HeartbeatStatus_Cbk
 *
 * @brief      Invoke opcode "HeartbeatStatus" callback for "ASG_Config"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CONFIG_Opcode_HeartbeatStatus_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_CONFIG_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "ASG_Config"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_CONFIG_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Get_Cbk
 *
 * @brief      Invoke opcode "Get" callback for "MFL_Block_Definition"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Get_Cbk(uint8_t* data, uint16_t length)
{
    /* Generate status message*/
    BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_MFL_BLOCK_DEFINITION_Idx, Opcode_Status, data, length);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Cbk
 *
 * @brief      Invoke opcode "SetGet" callback for "MFL_Block_Definition"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Size)
    {
        /* Get parameters*/
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Data.keyBlock_0 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_0_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Data.keyBlock_1 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_1_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Data.keyBlock_2 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_2_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Data.keyBlock_3 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_3_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Data.keyBlock_4 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_4_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Data.keyBlock_5 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_5_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Data.keyBlock_6 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_6_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_SetGet_Data.keyBlock_7 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_7_IDX];

        /* Generate status message*/
        BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_MFL_BLOCK_DEFINITION_Idx, Opcode_Status, data, length);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Cbk
 *
 * @brief      Invoke opcode "Status" callback for "MFL Block Definition"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Size)
    {
        /* Get parameters*/
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Data.keyBlock_0 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_0_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Data.keyBlock_1 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_1_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Data.keyBlock_2 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_2_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Data.keyBlock_3 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_3_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Data.keyBlock_4 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_4_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Data.keyBlock_5 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_5_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Data.keyBlock_6 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_6_IDX];
        BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Status_Data.keyBlock_7 = data[MFL_BLOCK_DEFINITION_KEY_BLOCK_7_IDX];        
    }

    /* Trigger status message*/
    bap_telephony_appl_setStatusFlag(BAP_TELEPHONY_Property_MFL_BLOCK_DEFINITION_Idx);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_HeartbeatStatus_Cbk
 *
 * @brief      Invoke opcode "HeartbeatStatus" callback for "MFL_BlockDefinition"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_HeartbeatStatus_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "MFL_Block_Definition"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_MFL_BLOCK_DEFINITION_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_STATUS_Opcode_Get_Cbk
 *
 * @brief      Invoke opcode "Get" callback for "FrameStatus"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_STATUS_Opcode_Get_Cbk(uint8_t* data, uint16_t length)
{
    /* Generate status message*/
    BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_FRAME_STATUS_Idx, Opcode_Status, data, length);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_STATUS_Opcode_SetGet_Cbk
 *
 * @brief      Invoke opcode "SetGet" callback for "FrameStatus"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_STATUS_Opcode_SetGet_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_FRAME_STATUS_Opcode_SetGet_Size)
    {    
        /* Get frameStatus parameters from SetGet message */
        memcpy(&BAP_TELEPHONY_FRAME_STATUS_Opcode_SetGet_Data,data,length);

        /* Analyze ASG Response*/
        BAP_TELEPHONY_ASG_Response(BAP_TELEPHONY_FRAME_STATUS_Opcode_SetGet_Data);

    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ProcessKeyEvent
 *
 * @brief      Process key event in BAP TELEPHONY
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ProcessKeyEvent(uint8_t key)
{
    TELEPHONY_Frame_Idx_T idx;

    if(bap_telephony_appl_frame_isEnabledFlag())
    {
        idx = bap_telephony_appl_frame_getEnabledFlag();

        BAP_TELEPHONY_FRAME_ProcessKeyEvent(idx, key);
    }
    else
    {
        BAP_TELEPHONY_FRAME_ProcessKeyEvent(BAP_TELEPHONY_FRAME_NO_FRAME_Idx, key);
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_ProcessKeyEvent
 *
 * @brief      Process key event for a FRAME in BAP TELEPHONY
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_ProcessKeyEvent(TELEPHONY_Frame_Idx_T idx, MFL_Tasten_Id_T key)
{
    uint8_t currentNumListElements;
    uint8_t selectedListElementIdx;
    uint8_t selectedElementIdx; 
    bool_t connectionSts = false;

    if(idx == BAP_TELEPHONY_FRAME_NO_FRAME_Idx)
    {    
        if((key == MFL_Tasten_Flash_Id))
        {
            /* Send Frame data (Scrollbar and Displayed data)*/
            BAP_TELEPHONY_FRAME_ConnectionStatus_SendData();
            /* Send new status */
            BAP_TELEPHONY_FRAME_ConnectionStatus_SendStatus();
        }        
    }

    if(idx == BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx)
    {
        if((key == MFL_Tasten_Flash_Id) || (key == MFL_Tasten_FolderUp_Id) || (key == MFL_Tasten_FolderDown_Id))
        {
            /* Get connection sts */
            Shadow_Client_Storage_Get(SHADOW_PhoneRepetition_ConnectionStatus,(uint8_t *)&connectionSts);

            // Get current number of elements in list
            currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

            // Attempt initial send of the recent call list
            if(connectionSts == true && currentNumListElements >= 3)
            {
                BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_InitialSend);
                BAP_TELEPHONY_FRAME_RecentCalls_ClearSelectedContact();
                BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallCounter(CONNECTION_STATUS_MIN_MISSED_CALLS);
                BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallIcon();
            }
        }
    }

    if(idx ==  BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx)
    {
        if(key == MFL_Tasten_FolderDown_Id)
        {
            // Attempt to do a list down
            if(BAP_TELEPHONY_FRAME_RecentCalls_List_Get_CurrentCmd() == RecentCalls_NoCommand)
            {
                BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_ListDown);
            }
        }

        if(key == MFL_Tasten_FolderUp_Id)
        {
            // Attempt to do a list up
            if(BAP_TELEPHONY_FRAME_RecentCalls_List_Get_CurrentCmd() == RecentCalls_NoCommand)
            {
                BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_ListUp);
            }
        }

        if((key == MFL_Tasten_Ok_Id) || (key == MFL_Tasten_Flash_Id))
        {
            // Call the selected contact
            BAP_TELEPHONY_FRAME_RecentCalls_CallSelectedContact();
        }

    }

    if(idx == BAP_TELEPHONY_FRAME_CALL_STATUS_Idx)
    {
        if(key == MFL_Tasten_FolderDown_Id)
        {
            // Attempt to get access to call status frame data
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_ProcessKeyEvent > Get Call Status semaphore \r\n");
            Semaphore_pend(CallStatusDataSem,BIOS_WAIT_FOREVER);

            // Attempt to do a list down
            if(BAP_TELEPHONY_FRAME_CallStatus_List_Get_CurrentCmd() == CallStatus_NoCommand)
            {
                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_ProcessKeyEvent > Selecting down \r\n");

                BAP_TELEPHONY_FRAME_Process_CallStatus_Event(CallStatus_ListDown);
            }

            // Release access to call status data frame
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_ProcessKeyEvent > Release Call Status semaphore \r\n");
            Semaphore_post(CallStatusDataSem);
        }

        if(key == MFL_Tasten_FolderUp_Id)
        {
            // Attempt to get access to call status frame data
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_ProcessKeyEvent > Get Call Status semaphore \r\n");
            Semaphore_pend(CallStatusDataSem,BIOS_WAIT_FOREVER);

            // Attempt to do a list up
            if(BAP_TELEPHONY_FRAME_CallStatus_List_Get_CurrentCmd() == CallStatus_NoCommand)
            {
                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_ProcessKeyEvent > Selecting Up \r\n");

                BAP_TELEPHONY_FRAME_Process_CallStatus_Event(CallStatus_ListUp);
            }

            // Release access to call status data frame
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_ProcessKeyEvent > Release Call Status semaphore \r\n");
            Semaphore_post(CallStatusDataSem);
        } 

        if((key == MFL_Tasten_Ok_Id))
        {
            // Attempt to get access to call status frame data
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_ProcessKeyEvent > Get Call Status semaphore \r\n");
            Semaphore_pend(CallStatusDataSem,BIOS_WAIT_FOREVER);

            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_ProcessKeyEvent > Selecting OK \r\n");

            // Call the selected contact
            BAP_TELEPHONY_FRAME_CallStatus_SelectCallOption();
            
            // Release access to call status data
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_ProcessKeyEvent > Release Call Status semaphore \r\n");
            Semaphore_post(CallStatusDataSem);
        }
    }

}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_Release
 *
 * @brief      Release frames
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_Release(void)
{
    FrameStatus_T           frameStatus;

    /* Set FrameStatus */
    frameStatus.frameId = BAP_TELEPHONY_FRAME_RELEASE_ALL_FRAMES_Id;  
    frameStatus.MFL_Assigned.MFL_Blocks = 0x07;
    frameStatus.FSG_Request = FSG_Request_ReqVisOFF;
    frameStatus.ASG_Response = ASG_Response_NoResponse;
    // Set FrameStatus parameter for frame
    BAP_TELEPHONY_ASG_Response(frameStatus);

}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_ConnectionStatus_SendStatus
 *
 * @brief      Send connection status data
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void   BAP_TELEPHONY_FRAME_ConnectionStatus_SendData(void)
{
    ListOperation_T         listOperation;    
    uint8_t                 listElementOnTop;
    ArrayHeaderPrms_T       headerPrms;
    Scrollbar_T             scrollbar;

    /* Set scrollbar*/
    scrollbar.frameId = BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Id;
    scrollbar.attributes = SCROLLBAR_ATTRIBUTES_NOTHING;
    scrollbar.sliderLength = SCROLLBAR_SLIDER_LENGTH_DEFAULT_VALUE;
    scrollbar.sliderPosition = SCROLLBAR_SLIDER_POSITION_TOP_OF_LIST;
    BAP_TELEPHONY_FRAME_UpdateScrollbar(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx, scrollbar);

    /* Send required frame data */
    listElementOnTop = FRAME_DATA_LIST_ELEMENT_ON_TOP_DEFAULT_VALUE;
    listOperation = ListOperation_Unknown;
    headerPrms = BAP_TELEPHONY_FRAME_GetArrayHeaderPrms(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx);
    BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx, listOperation, 
                                        listElementOnTop, headerPrms);

    bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_ConnectionStatus_SendStatus
 *
 * @brief      Start connection status frame request
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_ConnectionStatus_SendStatus(void)
{
    FrameStatus_T           frameStatus;

    /* Set FrameStatus */
    frameStatus.frameId = BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Id;  
    frameStatus.MFL_Assigned.MFL_Blocks = 0x00;
    frameStatus.FSG_Request = FSG_Request_ReqVisON;
    frameStatus.ASG_Response = ASG_Response_NoResponse;
    // Set FrameStatus parameter for frame
    BAP_TELEPHONY_ASG_Response(frameStatus);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_Process_RecentCalls_Event
 *
 * @brief      Process update command for the recent calls list
 *
 * @param [in] RecentCalls_UpdateCmd_T
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_UpdateCmd_T cmd)
{
    Scrollbar_T scrollbar;
    uint8_t listElementOnTop;
    ListOperation_T listOperation;
    ArrayHeaderPrms_T headerPrms;
    FrameStatus_T frameStatus;
    RecentCalls_UpdateCmd_T prevCmd;
    uint8_t numListElements;
    uint8_t topElementIdx;
    uint8_t nextElementIdx;
    uint8_t prevElementIdx;
    uint8_t prevElementListIdx;
    uint8_t nextElementListIdx;
    uint8_t topElementListIdx;


    prevCmd = cmd;

    if((cmd == RecentCalls_ListDown) && (BAP_TELEPHONY_FRAME_RecentCalls_List_Last_Element_Selected() == true))
    {
        cmd = RecentCalls_InitialSend;
    }

    if((cmd == RecentCalls_ListUp) && (BAP_TELEPHONY_FRAME_RecentCalls_List_First_Element_Selected() == true))
    {
        cmd = RecentCalls_MoveToBottom;
    }  

    if(cmd == RecentCalls_UpdateDisplayedData)
    {
        cmd = RecentCalls_InitialSend;
    }

    if(cmd == RecentCalls_InitialSend)
    {
        /* Set Scrollbar*/

        // Get scrollbar parameters
        scrollbar.frameId = BAP_TELEPHONY_FRAME_RECENT_CALLS_Id;
        scrollbar.attributes = SCROLLBAR_ATTRIBUTES_VERTICAL_SCROLLBAR_AND_NAVIGATION_ARROWS_MASK;
        scrollbar.sliderLength = SCROLLBAR_SLIDER_LENGTH_DEFAULT_VALUE;
        scrollbar.sliderPosition = SCROLLBAR_SLIDER_POSITION_TOP_OF_LIST;
        
        // Set scrollbar parameters
        BAP_TELEPHONY_FRAME_UpdateScrollbar(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, scrollbar);  

        /* Set FrameData*/ 

        // Initialize recent calls buffer
        BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Clear();
        BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Init(); 

        // Get FrameData parameters

        // // Get FrameData.listElementOnTop
        listElementOnTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();
        // // Get FrameData.listOperation
        listOperation = BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation(cmd); 
        // // Get FrameData.arrayHeader
        headerPrms = BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms(cmd);

        // Set FrameData parameters
        BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, listOperation, listElementOnTop,headerPrms);

        /* Set update data flag */
        bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx);

        /* Set FrameStatus */
        if(prevCmd == RecentCalls_InitialSend)
        {
            frameStatus.frameId = BAP_TELEPHONY_FRAME_RECENT_CALLS_Id;  
            frameStatus.MFL_Assigned.MFL_Blocks = 0x00;
            frameStatus.FSG_Request = FSG_Request_ReqVisON;
            frameStatus.ASG_Response = ASG_Response_NoResponse;
            BAP_TELEPHONY_ASG_Response(frameStatus);
        }

        BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(cmd);
    }

    if(cmd == RecentCalls_InitialSend_Complete)
    {
        /* Set FrameData */
        
        // Get FrameData parameters

        // // Get FrameData.listElementOnTop
        listElementOnTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();
        // // Get FrameData.listOperation
        listOperation = BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation(cmd);
        // // Get FrameData.arrayHeader 
        headerPrms = BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms(cmd);

        // Set FrameData parameters
        BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, listOperation, listElementOnTop,headerPrms);        
    
        /* Set update data flag */
        bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx);

        BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(cmd);     
    }

    if(cmd == RecentCalls_MoveToBottom)
    {
        /* Set FrameData*/ 

        // Initialize recent calls buffer to the bottom of the list
        BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Clear();
        BAP_TELEPHONY_FRAME_RecentCalls_Buffer_InitToBottom(); 

        BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(cmd);

        // Get FrameData parameters

        // // Get FrameData.listElementOnTop
        listElementOnTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();
        // // Get FrameData.listOperation
        listOperation = BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation(cmd); 
        // // Get FrameData.arrayHeader
        headerPrms = BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms(cmd);

        // Set FrameData parameters
        BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, listOperation, listElementOnTop,headerPrms);

        /* Set update data flag */
        bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx);
    }

    if(cmd == RecentCalls_MoveToBottom_Complete)
    {
        /* Set FrameData */
        
        // Get FrameData parameters

        BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(cmd);  

        // // Get FrameData.listElementOnTop
        listElementOnTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();
        // // Get FrameData.listOperation
        listOperation = BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation(cmd);
        // // Get FrameData.arrayHeader 
        headerPrms = BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms(cmd);

        // Set FrameData parameters
        BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, listOperation, listElementOnTop,headerPrms);        
    
        /* Set update data flag */
        bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx);

    }

    if((cmd == RecentCalls_ListDown) || (cmd == RecentCalls_ListUp))
    {
        /* Set Scrollbar */

        // Get Scrollbar parameters
        scrollbar.frameId = BAP_TELEPHONY_FRAME_RECENT_CALLS_Id;
        scrollbar.attributes = SCROLLBAR_ATTRIBUTES_VERTICAL_SCROLLBAR_AND_NAVIGATION_ARROWS_MASK;
        scrollbar.sliderLength = SCROLLBAR_SLIDER_LENGTH_DEFAULT_VALUE;
        scrollbar.sliderPosition = scrollbar.sliderPosition++;
        
        // Set Scrollbar parameters
        BAP_TELEPHONY_FRAME_UpdateScrollbar(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, scrollbar);  

        /* Set FrameData*/ 

        // Set FrameData parameters

        BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(cmd);

        // Get FrameData parameters

        // // Get FrameData.listElementOnTOp
        listElementOnTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();
        // // Get FrameData.listOperation
        listOperation = BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation(cmd); 
        // // Get FrameData.arrayHeader
        headerPrms = BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms(cmd);
        
        // Update Attributes       
        BAP_TELEPHONY_FRAME_RecentCalls_UpdateAttributes(cmd);

        // // Get FrameData.listElementOnTOp
        listElementOnTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();

        // Set FrameData parameters

        BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, listOperation, listElementOnTop,headerPrms);        
    
        /* Set Update data flag */
        bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx);

    }

    if(cmd == RecentCalls_UpdateListDown)
    {
        if(BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop() == true)
        {
            // Get num elements in list
            numListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

            // Get top element index for buffer
            topElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();

            // Get next element index to top element in buffer (this could be the new index of top)
            nextElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(topElementIdx);

            // Get prev element index to top element in buffer (we need to obtain the reference of this index to list)
            prevElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(topElementIdx);

            // Get list index (content) of previous element to top in buffer  
            prevElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(prevElementIdx);

            // If the list index of the previous element to top is the last we don't have to update anything
            if(prevElementListIdx != numListElements)
            {
                // Get next element in list to that element
                nextElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NextElementIdx(prevElementListIdx);

                // Set the next list index in the top position
                BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx(topElementIdx,nextElementListIdx);
                // Update top position to next element in buffer
                BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_TopElementIdx(nextElementIdx);

                /* Set FrameData*/ 

                // Get FrameData parameters
                // // Get FrameData.listElementOnTOp
                listElementOnTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();
                // // Get FrameData.listOperation
                listOperation = BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation(cmd);
                // // Get FrameData.arrayHeader
                headerPrms = BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms(cmd);

                // Set FrameData parameters

                BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, listOperation, listElementOnTop,headerPrms);        

                /* Set Update data flag */
                bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx);

                BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(cmd);
            }
        
        }
    }

    if(cmd == RecentCalls_UpdateListUp)
    {        

        if(BAP_TELEPHONY_FRAME_RecentCalls_UpdateBottom() == true)
        {
            // Get num elements in list
            numListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

            // Get top element index for buffer
            topElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();

            // Get prev element index for top element in buffer
            prevElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(topElementIdx);

            // Get list index (content) of the top element index in buffer
            topElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(topElementIdx);

            if(topElementListIdx != FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT)
            {
                // Get prev element in list to that element
                prevElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_PrevElementIdx(topElementListIdx);

                BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx(prevElementIdx,prevElementListIdx);
                BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_TopElementIdx(prevElementIdx);

                /* Set FrameData*/ 

                // Get FrameData parameters
                // // Get FrameData.listElementOnTOp
                listElementOnTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();
                // // Get FrameData.listOperation
                listOperation = BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation(cmd);
                // // Get FrameData.arrayHeader
                headerPrms = BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms(cmd);

                // Set FrameData parameters
                BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, listOperation, listElementOnTop,headerPrms);        
            
                /* Set Update data flag */
                bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx);

                BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(cmd);
            }
        }
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_Process_CallStatus_Event
 *
 * @brief      Process update command for the call options list
 *
 * @param [in] RecentCalls_UpdateCmd_T
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_Process_CallStatus_Event(CallStatus_Update_Cmd_T cmd)
{
    uint8_t i;
    uint8_t listIdx;
    uint8_t numOptions;
    uint8_t topElementIdx;
    uint8_t selectedElementIdx;
    ListOperation_T listOperation; 
    uint8_t listElementOnTop;
    ArrayHeaderPrms_T headerPrms;
    Scrollbar_T scrollbar;

    if(cmd == CallStatus_InitialSend)
    {
        /* Set Scrollbar */
        scrollbar.frameId = BAP_TELEPHONY_FRAME_CALL_STATUS_Id;
        scrollbar.attributes = SCROLLBAR_ATTRIBUTES_NOTHING;
        scrollbar.sliderLength = SCROLLBAR_SLIDER_LENGTH_DEFAULT_VALUE;
        scrollbar.sliderPosition = SCROLLBAR_SLIDER_POSITION_TOP_OF_LIST;
        BAP_TELEPHONY_FRAME_UpdateScrollbar(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx, scrollbar);

        /* Set FrameData */

        // Initialize buffer attributes
        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Clear();
        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Init();

        // Get FrameData parameters
        // // Get FrameData.listElementOnTop
        listElementOnTop = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_TopElementIdx();
        // // Get FrameData.listOperation
        listOperation = BAP_TELEPHONY_FRAME_CallStatus_Get_ListOperation(cmd); 
        // // Get FrameData.arrayHeader
        headerPrms = BAP_TELEPHONY_FRAME_CallStatus_Get_ArrayHeaderPrms(cmd);

        // Set FrameData parameters
        BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx, listOperation, listElementOnTop,headerPrms);

        // Set update data flasg
        bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx);
        
        /* Set FrameStatus */
        BAP_TELEPHONY_FRAME_CallStatus_SendStatus();

        /* Set current cmd*/
        BAP_TELEPHONY_FRAME_CallStatus_List_Set_CurrentCmd(cmd);
    }

    if((cmd == CallStatus_ListDown) || (cmd == CallStatus_ListUp))
    {
        if((cmd == CallStatus_ListDown) && (BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected() == false)
            || ((cmd == CallStatus_ListUp) && (BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected() == false)))
        {
            /* Set Scrollbar */
            scrollbar.frameId = BAP_TELEPHONY_FRAME_CALL_STATUS_Id;
            scrollbar.attributes = SCROLLBAR_ATTRIBUTES_NOTHING;
            scrollbar.sliderLength = SCROLLBAR_SLIDER_LENGTH_DEFAULT_VALUE;
            scrollbar.sliderPosition = scrollbar.sliderPosition++;
            BAP_TELEPHONY_FRAME_UpdateScrollbar(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx, scrollbar);   

            /* Set FrameData */

            BAP_TELEPHONY_FRAME_CallStatus_List_Set_CurrentCmd(cmd);

            // Get FrameData parameters

            // // Get FrameData.listElementOnTOp (in this command, top element is the initial index row of the frame)
            listElementOnTop = CALL_STATUS_FRAME_INITIAL_INDEX;
            // // Get FrameData.listOperation
            listOperation = BAP_TELEPHONY_FRAME_CallStatus_Get_ListOperation(cmd); 
            // // Get FrameData.arrayHeader
            headerPrms = BAP_TELEPHONY_FRAME_CallStatus_Get_ArrayHeaderPrms(cmd);
            
            // Update Attributes       
            BAP_TELEPHONY_FRAME_CallStatus_UpdateAttributes(cmd);
            
            // Set FrameData parameters
            BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx, listOperation, listElementOnTop,headerPrms);

            // Set update data flasg
            bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx);
        }                      
    }

}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation
 *
 * @brief      Get list operation for recent calls list command
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
ListOperation_T BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation(RecentCalls_UpdateCmd_T cmd)
{
    ListOperation_T listOperation;

    switch(cmd)
    {
        case RecentCalls_InitialSend:
        case RecentCalls_InitialSend_Complete:
        case RecentCalls_MoveToBottom_Complete:
        case RecentCalls_UpdateListUp:
        case RecentCalls_UpdateListDown:

            listOperation = ListOperation_Unknown;
        
        break;

        case RecentCalls_ListDown:

            listOperation = ListOperation_ListDown;

        break;

        case RecentCalls_ListUp:
        case RecentCalls_MoveToBottom:
        
            listOperation = ListOperation_ListUp;
        
        break;

        default:
        
            listOperation = ListOperation_Unknown;
        
        break;
    }

    return listOperation;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Get_ListOperation
 *
 * @brief      Get list operation for call status list command
 * 
 * @param [in]  CallStatus_Update_Cmd_T
 *
 * @return      void
 *
 ******************************************************************************/
ListOperation_T BAP_TELEPHONY_FRAME_CallStatus_Get_ListOperation(CallStatus_Update_Cmd_T cmd)
{
    ListOperation_T listOperation;

    switch(cmd)
    {
        case CallStatus_InitialSend:

            listOperation = ListOperation_Unknown;
        
        break;

        case CallStatus_ListDown:

            listOperation = ListOperation_ListDown;

        break;

        case CallStatus_ListUp:

            listOperation = ListOperation_ListUp;

        break;

        default:
        
            listOperation = ListOperation_Unknown;
        
        break;
    }

    return listOperation;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms
 *
 * @brief      Get array header parameter for the given command in recent calls
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
ArrayHeaderPrms_T BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms(RecentCalls_UpdateCmd_T cmd)
{
    ArrayHeaderPrms_T headerPrms;
    
    /* Get common parameters for array header in recent calls data */
    headerPrms = BAP_TELEPHONY_FRAME_GetArrayHeaderPrms(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx);

    /* Record adress parameter of the array header is determined by the update command */
    headerPrms.recordAddress = BAP_TELEPHONY_FRAME_RecentCalls_Get_RecordAdress(cmd);

    /* Start parameter of array header is determined by the update command */
    headerPrms.start = BAP_TELEPHONY_FRAME_RecentCalls_Get_Start(cmd);

    /* Element parameter of array header is determined by the update command */
    headerPrms.elements = BAP_TELEPHONY_FRAME_RecentCalls_Get_Elements(cmd);

    return headerPrms;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Get_ArrayHeaderPrms
 *
 * @brief      Get array header parameter for the given command in call list
 * 
 * @param [in]  CallStatus_Update_Cmd_T
 *
 * @return      void
 *
 ******************************************************************************/
ArrayHeaderPrms_T BAP_TELEPHONY_FRAME_CallStatus_Get_ArrayHeaderPrms(CallStatus_Update_Cmd_T cmd)
{
    ArrayHeaderPrms_T headerPrms;
    
    /* Get common parameters for array header in recent calls data */
    headerPrms = BAP_TELEPHONY_FRAME_GetArrayHeaderPrms(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx);

    /* Record adress parameter of the array header is determined by the update command */
    headerPrms.recordAddress = BAP_TELEPHONY_FRAME_CallStatus_Get_RecordAdress(cmd);

    /* Start parameter of array header is determined by the update command */
    headerPrms.start = BAP_TELEPHONY_FRAME_CallStatus_Get_Start(cmd);

    /* Element parameter of array header is determined by the update command */
    headerPrms.elements = BAP_TELEPHONY_FRAME_CallStatus_Get_Elements(cmd);

    return headerPrms;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Get_RecordAdress
 *
 * @brief      Get record adress for header parameter in recent calls list command
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
ArrayRecordAddress_T BAP_TELEPHONY_FRAME_RecentCalls_Get_RecordAdress(RecentCalls_UpdateCmd_T cmd)
{
    ArrayRecordAddress_T recordAdress = ArrayRecordAdress_TypeAndAttributesAndName;

    switch(cmd)
    {
        case RecentCalls_InitialSend:
        case RecentCalls_InitialSend_Complete:
        case RecentCalls_MoveToBottom:
        case RecentCalls_MoveToBottom_Complete:
            
            recordAdress = ArrayRecordAdress_TypeAndAttributesAndName;
        
        break;

        case RecentCalls_ListDown:

            recordAdress = ArrayRecordAdress_AttributesOnly;

        break;
        case RecentCalls_ListUp:

            recordAdress = ArrayRecordAdress_AttributesOnly;

        break;

        case RecentCalls_UpdateListDown:
        case RecentCalls_UpdateListUp:

            recordAdress = ArrayRecordAdress_NameOnly;
        
        break;

        default:

        break;
    }

    return recordAdress;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Get_RecordAdress
 *
 * @brief      Get record adress for header parameter in recent calls list command
 * 
 * @param [in]  CallStatus_Update_Cmd_T
 *
 * @return      void
 *
 ******************************************************************************/
ArrayRecordAddress_T BAP_TELEPHONY_FRAME_CallStatus_Get_RecordAdress(CallStatus_Update_Cmd_T cmd)
{
    ArrayRecordAddress_T recordAdress = ArrayRecordAdress_TypeAndAttributesAndName;

    switch(cmd)
    {
        case CallStatus_InitialSend:
            
            recordAdress = ArrayRecordAdress_TypeAndAttributesAndName;
    
        break;

        case CallStatus_ListDown:
        case CallStatus_ListUp:

            recordAdress = ArrayRecordAdress_AttributesOnly;

        break;

        default:
            recordAdress = ArrayRecordAdress_TypeAndAttributesAndName;
        break;
    }

    return recordAdress;  
}



/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Get_Start
 *
 * @brief      Get start header parameter for recent calls list command
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
uint16_t BAP_TELEPHONY_FRAME_RecentCalls_Get_Start(RecentCalls_UpdateCmd_T cmd)
{
    uint16_t start = 0;
    uint8_t selectedElementIdx;
    uint8_t selectedListElementIdx;
    uint8_t nextElementListIdx;
    uint8_t prevElementListIdx;
    uint8_t currentNumListElements;
    uint8_t topElementIdx;
    uint8_t prevElementIdx;
    uint8_t nextElementIdx;

    switch(cmd)
    {
        case RecentCalls_InitialSend:
            start = FRAME_RECENT_CALLS_INITIAL_SEND_START_1;
        break;

        case RecentCalls_InitialSend_Complete:
            start = FRAME_RECENT_CALLS_INITIAL_SEND_START_2;
        break;

        case RecentCalls_MoveToBottom:
            start = FRAME_RECENT_CALLS_MOVE_TO_BOTTOM_START_1;
        break;

        case RecentCalls_MoveToBottom_Complete:
            start = FRAME_RECENT_CALLS_MOVE_TO_BOTTOM_START_2;
        break;

        case RecentCalls_ListDown:

            /* Get current num of elements in the list (including footer) */
            currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

            /* Get index of the selected element in the buffer */
            selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();
            
            /* Get index of the selected element in the list */
            selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx();
            
            /* Get index of the next element in the list */
            nextElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NextElementIdx(selectedListElementIdx);

            if((selectedListElementIdx == FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT) || (nextElementListIdx == currentNumListElements))
            {
                start = selectedElementIdx;
            }
            else
            {
                /* Get previous element to the selected element in buffer*/
                prevElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(selectedElementIdx);
                start = prevElementIdx;
            }      

        break;

        case RecentCalls_ListUp:

            /* Get current num of elements in the list */
            currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

            /* Get index of the selected element in the buffer */
            selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();
            
            /* Get index of the selected element in the list */
            selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx();
            
            /* Get index of the previous element in the list */
            prevElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_PrevElementIdx(selectedListElementIdx);

            if((prevElementListIdx == FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT) || (selectedListElementIdx == currentNumListElements))
            {
                start = selectedElementIdx;
            }
            else
            {
                /* Get next element to the selected element in buffer*/
                nextElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(selectedElementIdx);
                start = nextElementIdx;
            }      

        break;

        case RecentCalls_UpdateListDown:

            // Get top element index for buffer
            topElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();

            // Get prev element index to top element in buffer
            prevElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(topElementIdx);

            start = prevElementIdx;

        break;

        case RecentCalls_UpdateListUp:

            // Get top element index for buffer
            topElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();

            start = topElementIdx;

        break;

        default:

        break;
    }

    return start;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Get_Start
 *
 * @brief      Get start header parameter for recent calls list command
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
uint16_t BAP_TELEPHONY_FRAME_CallStatus_Get_Start(CallStatus_Update_Cmd_T cmd)
{
    uint16_t start = 0;
    uint8_t selectedElementIdx;
    uint8_t currentNumListElements;
    uint8_t prevElementIdx;
    uint8_t nextElementIdx;

    switch(cmd)
    {
        case CallStatus_InitialSend:
            start = CALL_STATUS_FRAME_INITIAL_INDEX;
        break; 

        case CallStatus_ListDown:

            if(BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected() == false)
            {
                /* Get current num of elements in the frame (option elements + call info elements) */
                currentNumListElements = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements() + CALL_STATUS_INFO_ELEMENTS;
                
                /* Get index of the selected element in the list */
                selectedElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx();  

                /* Get index of the next element in the list */
                nextElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx(selectedElementIdx);

                if(BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected() == true)
                {
                    // The start is the previous element to the selected element
                    start = selectedElementIdx - 1;
                }
                else
                {
                    if(BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes(nextElementIdx) == FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK)
                    {  
                        prevElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_PrevElementIdx(selectedElementIdx);
                        // The start is the previous element to the previous one
                        start = prevElementIdx - 1;
                    }
                    else
                    {
                        // The start is the previous element to the selected element
                        start = selectedElementIdx - 1;
                    }
                }  

            }

        break;

        case CallStatus_ListUp:

            if(BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected() == false)
            {
                /* Get current num of elements in the list (including footer) */
                currentNumListElements = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements() + CALL_STATUS_INFO_ELEMENTS;
                
                /* Get index of the selected element in the list */
                selectedElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx();  

                /* Get index of the next element in the list */
                prevElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_PrevElementIdx(selectedElementIdx);

                if(BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected() == true)
                {
                    // The start is the previous element to the previous one
                    start = prevElementIdx - 1;
                }
                else
                {
                    if(BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes(prevElementIdx) == FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK)
                    {
                        // The start is the previous element to the previous one
                        start = prevElementIdx - 1;
                    }
                    else
                    {
                        // The start is the previous element to the previous one
                        start = prevElementIdx - 1;
                    }
                }
            }    

        break;       
    }

    return start;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Get_Elements
 *
 * @brief      Get elements header parameter for recent calls list command
 * 
 * @param [in]  RecentCalls_UpdateCmd_T - Recent calls list update command
 *
 * @return      uint16_t - header.elements parameter
 *
 ******************************************************************************/
uint16_t BAP_TELEPHONY_FRAME_RecentCalls_Get_Elements(RecentCalls_UpdateCmd_T cmd)
{
    uint16_t elements = 0;
    uint8_t selectedElementIdx;
    uint8_t selectedListElementIdx;
    uint8_t nextElementListIdx;
    uint8_t prevElementListIdx;
    uint8_t currentNumListElements;

    switch(cmd)
    {
        case RecentCalls_InitialSend:
            elements = FRAME_RECENT_CALLS_INITIAL_SEND_ELEMENTS_1;
        break;

        case RecentCalls_InitialSend_Complete:
            elements = FRAME_RECENT_CALLS_INITIAL_SEND_ELEMENTS_2;
        break;

        case RecentCalls_MoveToBottom:
            elements = FRAME_RECENT_CALLS_MOVE_TO_BOTTOM_ELEMENTS_1;
        break;

        case RecentCalls_MoveToBottom_Complete:
            elements = FRAME_RECENT_CALLS_MOVE_TO_BOTTOM_ELEMENTS_2;
        break;

        case RecentCalls_ListDown:

            /* Get current num of elements in the list */
            currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

            /* Get index of the selected element in the buffer */
            selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();
            
            /* Get index of the selected element in the list */
            selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx();
            
            /* Get index of the next element in the list */
            nextElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NextElementIdx(selectedListElementIdx);

            if((selectedListElementIdx == FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT) || (nextElementListIdx == currentNumListElements))
            {
                elements = 2; 
            }
            else
            {
                elements = 4;                 
            } 

        break;

        case RecentCalls_ListUp:

            /* Get current num of elements in the list */
            currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

            /* Get index of the selected element in the buffer */
            selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();
            
            /* Get index of the selected element in the list */
            selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx();
            
            /* Get index of the previous element in the list */
            prevElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_PrevElementIdx(selectedListElementIdx);

            if((prevElementListIdx == FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT) || (selectedListElementIdx == currentNumListElements))
            {
                elements = 2; 
            }
            else
            {
                elements = 4;                 
            }  

        break;

        case RecentCalls_UpdateListDown:
        case RecentCalls_UpdateListUp:
            elements = 1;
        break;

        default:

        break;
    }

    return elements;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Get_Elements
 *
 * @brief      Get elements header parameter for call status list command
 * 
 * @param [in]  CallStatus_Update_Cmd_T - Call status list update command
 *
 * @return      uint16_t - header.elements parameter
 *
 ******************************************************************************/
uint16_t BAP_TELEPHONY_FRAME_CallStatus_Get_Elements(CallStatus_Update_Cmd_T cmd)
{
    uint16_t elements = 0;
    uint8_t selectedElementIdx;
    uint8_t nextElementIdx;
    uint8_t prevElementIdx;
    uint8_t currentNumListElements;

    switch(cmd)
    {
        case CallStatus_InitialSend:
            elements = CALL_STATUS_LIST_ELEMENTS;
        break;

        case CallStatus_ListDown:

            if(BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected() == false)
            {

                /* Get current num of elements in the list */
                currentNumListElements = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements() + CALL_STATUS_INFO_ELEMENTS;
                
                /* Get index of the selected element in the list */
                selectedElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx();

                /* Get index of the next element in the list */
                nextElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx(selectedElementIdx);

                if(BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected() == true)
                {
                    elements = CALL_STATUS_OPTIONS_LIST_UPDATE_SELECT_NUM_ELEMENTS;
                }
                else
                {
                    if(BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes(nextElementIdx) == FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK)
                    {                    
                        elements = CALL_STATUS_OPTIONS_LIST_UPDATE_LIST_NUM_ELEMENTS;
                    }
                    else
                    {
                        elements = CALL_STATUS_OPTIONS_LIST_UPDATE_SELECT_NUM_ELEMENTS;
                    }
                }
            }

        break;

        case CallStatus_ListUp:

            if(BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected() == false)
            {
                /* Get current num of elements in the list */
                currentNumListElements = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements() + CALL_STATUS_INFO_ELEMENTS;
                
                /* Get index of the selected element in the list */
                selectedElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx();

                /* Get index of the prev element in the list */
                prevElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx(selectedElementIdx);

                if(BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected() == true)
                {
                    elements = CALL_STATUS_OPTIONS_LIST_UPDATE_SELECT_NUM_ELEMENTS;
                }
                else
                {
                    if(BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes(prevElementIdx) == FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK)
                    {                    
                        elements = CALL_STATUS_OPTIONS_LIST_UPDATE_LIST_NUM_ELEMENTS;
                    }
                    else
                    {
                        elements = CALL_STATUS_OPTIONS_LIST_UPDATE_SELECT_NUM_ELEMENTS;
                    }                    
                }                
            }

        break;
    }

    return elements;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_UpdateAttributes
 *
 * @brief      Update visibility attributes for recent calls list command
 * 
 * @param [in]  RecentCalls_UpdateCmd_T - Recent calls list update command
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_UpdateAttributes(RecentCalls_UpdateCmd_T cmd)
{
    uint8_t selectedElementIdx;
    uint8_t selectedListElementIdx;
    uint8_t nextElementIdx;
    uint8_t nextElementListIdx;
    uint8_t prevElementIdx;
    uint8_t prevElementListIdx;
    uint8_t currentNumListElements;  
    uint8_t nextNextElementIdx;
    uint8_t prevPrevElementIdx;

    switch(cmd)
    {
        case RecentCalls_ListDown:

            if(BAP_TELEPHONY_FRAME_RecentCalls_List_Last_Element_Selected() == false)
            {
                /* Get current num of elements in the list */
                currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

                /* Get index of the selected element in the buffer */
                selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();
                
                /* Get index of the selected element in the list */
                selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx();
            
                /* Get index of the next element in the list */
                nextElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NextElementIdx(selectedListElementIdx);

                if((selectedListElementIdx == FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT) || (nextElementListIdx == currentNumListElements))
                {
                    nextElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(selectedElementIdx);

                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(nextElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);
                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_SelectedElementIdx(nextElementIdx);
                }
                else
                {
                    prevElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(selectedElementIdx);
                    nextElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(selectedElementIdx);
                    nextNextElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(nextElementIdx);

                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(prevElementIdx ,FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK);
                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(nextElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);
                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(nextNextElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);

                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_SelectedElementIdx(nextElementIdx);
                }
            }

        break;

        case RecentCalls_ListUp:

            if(BAP_TELEPHONY_FRAME_RecentCalls_List_First_Element_Selected() == false)
            {
                /* Get current num of elements in the list */
                currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

                /* Get index of the selected element in the buffer */
                selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();
                
                /* Get index of the selected element in the list */
                selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx();
                
                /* Get index of the previous element in the list */
                prevElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_PrevElementIdx(selectedListElementIdx);

                if((prevElementListIdx == FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT) || (selectedListElementIdx == currentNumListElements))
                {
                    prevElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(selectedElementIdx);

                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(prevElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);

                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_SelectedElementIdx(prevElementIdx);
                }
                else
                {
                    prevElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(selectedElementIdx);
                    nextElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(selectedElementIdx);
                    prevPrevElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(prevElementIdx);

                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(nextElementIdx ,FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK);
                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(prevElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);
                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(prevPrevElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);

                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_SelectedElementIdx(prevElementIdx);
                }

            }

        break;

        default:

        break;
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_UpdateAttributes
 *
 * @brief      Update visibility attributes for recent calls list command
 * 
 * @param [in]  CallStatus_UpdateCmd_T - Recent calls list update command
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_UpdateAttributes(CallStatus_Update_Cmd_T cmd)
{
    uint8_t selectedElementIdx;
    uint8_t nextElementIdx;
    uint8_t prevElementIdx;
    uint8_t currentNumListElements;  

    switch(cmd)
    {
        case CallStatus_ListDown:

            if(BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected() == false)
            {
                /* Get current num of elements in the list */
                currentNumListElements = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements() + CALL_STATUS_INFO_ELEMENTS;

                /* Get index of the selected element in the buffer */
                selectedElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx();

                /* Get next index of the selected element */
                nextElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx(selectedElementIdx);

                if(BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected() == true)
                {
                    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(nextElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);
                    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx(nextElementIdx);
                }
                else
                {
                    if(BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes(nextElementIdx) == FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK)
                    {
                        /* Get next index of the selected element*/
                        prevElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_PrevElementIdx(selectedElementIdx);

                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(prevElementIdx ,FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK);
                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                    |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(nextElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                    |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);

                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx(nextElementIdx);
                    }
                    else
                    {
                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                    |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(nextElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                    |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);

                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx(nextElementIdx);
                    }

                }
            }

        break;

        case CallStatus_ListUp:

            if(BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected() == false)
            {
                /* Get current num of elements in the list */
                currentNumListElements = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements() + CALL_STATUS_INFO_ELEMENTS;

                /* Get index of the selected element in the buffer */
                selectedElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx();

                /* Get prev index of the selected element */
                prevElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_PrevElementIdx(selectedElementIdx);

                if(BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected() == true)
                {
                    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(prevElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);

                    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx(prevElementIdx);
                }
                else
                {
                    if(BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes(prevElementIdx) == FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK)
                    {
                        /* Get next index of the selected element*/
                        nextElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx(selectedElementIdx);

                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(nextElementIdx ,FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK);
                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                    |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(prevElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                    |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);

                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx(prevElementIdx);
                    }
                    else
                    {
                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(selectedElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                    |   FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(prevElementIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK 
                                                                                    |   FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);

                        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx(prevElementIdx);
                    }
                }
            }

        break;

        default:

        break;        
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop
 *
 * @brief      Check if is necessary to update the top element
 * 
 * @param [in]  void
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop(void)
{
    uint8_t selectedElementIdx;
    uint8_t topElementIdx;
    uint8_t distanceSelectedToTop;
    uint8_t numListElements;
    uint8_t numElements;
    bool_t ret = false;

    /* Get the current number of elements in the list */
    numListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

    /* Get the current number of element in the buffer */
    numElements = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NumElements();

    /* Check if there are more list elements than buffer elements */
    if(numListElements > numElements)
    {
        /* Get the buffer index of the current selected element */
        selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();

        /* Get the buffer index of the current top element */
        topElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();

        if(selectedElementIdx != topElementIdx)
        {
            /* Calculate the clock distance between the selected and top element */
            distanceSelectedToTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_ClockDistance(selectedElementIdx, topElementIdx, numElements);

            if(distanceSelectedToTop <= FRAME_RECENT_CALLS_MIN_DISTANCE_TO_TOP)
            {
                ret = true;
            }

        }
    }    

    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > selectedElementIdx = %x \r\n", selectedElementIdx);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > topElement = %x \r\n", topElementIdx);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > numElements = %x \r\n",numElements);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > numListElements = %x \r\n",numListElements);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > distanceSelectedToTop = %x \r\n",distanceSelectedToTop);

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_UpdateBottom
 *
 * @brief      Check if is necessary to update the bottom element
 * 
 * @param [in]  void
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_UpdateBottom(void)
{
    uint8_t selectedElementIdx;
    uint8_t topElementIdx;
    uint8_t distanceSelectedToTop;
    uint8_t numListElements;
    uint8_t numElements;
    bool_t ret = false;

    /* Get the current number of elements in the list */
    numListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

    /* Get the current number of element in the buffer */
    numElements = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NumElements();

    /* Check if there are more list elements than buffer elements */
    if(numListElements > numElements)
    {
        /* Get the buffer index of the current selected element */
        selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();

        /* Get the buffer index of the current top element */
        topElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();

        if(selectedElementIdx != topElementIdx)
        {
            /* Calculate the clock distance between the selected and top element */
            distanceSelectedToTop = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_AntiClockDistance(selectedElementIdx, topElementIdx, numElements);

            if(distanceSelectedToTop <= FRAME_RECENT_CALLS_MIN_DISTANCE_TO_TOP)
            {
                ret = true;
            }

        }
    }    

    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > selectedElementIdx = %x \r\n", selectedElementIdx);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > topElement = %x \r\n", topElementIdx);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > numElements = %x \r\n",numElements);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > numListElements = %x \r\n",numListElements);
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop > distanceSelectedToTop = %x \r\n",distanceSelectedToTop);

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Clear
 *
 * @brief      Clear buffer parameters
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Clear(void)
{
    memset(BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.listElementsIdx,0xff,FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS);
    memset(BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.listElementsAttributes,0x00,FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS);
    BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.selectedElementIdx = 0;
    BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.topElementIdx = 0;
    BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.numElements = 0;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Clear
 *
 * @brief      Clear buffer parameters
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_Buffer_Clear(void)
{
    memset(BAP_TELEPHONY_FRAME_CALL_STATUS_Data.listElementsIdx,0xff,CALL_STATUS_LIST_ELEMENTS);
    memset(BAP_TELEPHONY_FRAME_CALL_STATUS_Data.listElementsAttributes,0x00,CALL_STATUS_LIST_ELEMENTS);
    BAP_TELEPHONY_FRAME_CALL_STATUS_Data.selectedElementIdx = 0;
    BAP_TELEPHONY_FRAME_CALL_STATUS_Data.topElementIdx = 0;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_InitBuffer
 *
 * @brief      Init buffer with initial N elements from list
 * 
 * @param [in]  void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Init(void)
{
    uint8_t i;
    uint8_t listIdx;
    uint8_t numListElements;
    uint8_t numElements;
    uint8_t topElementIdx;
    uint8_t selectedElementIdx;

    /* Init the buffer setting the header element */
    listIdx = 0;
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(listIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK);
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx(listIdx,listIdx);
    listIdx++;

    /* Now get the number of elements in the list */
    numListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

    /* Calculate the number of elements that will be put in the buffer */
    /* The buffer only has (FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS - 1) elements to store because of the header */
    numElements = (numListElements > (FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS - 1)) ? (FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS - 1) : numListElements;
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_NumElements(numElements);

    /* Add the elements*/
    for(i = 0; i < numElements; i++)
    {   
        BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx(listIdx,listIdx);
        BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(listIdx,FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK);
        listIdx++;
    }

    /* Set top element index of the buffer*/
    topElementIdx = FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT;
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_TopElementIdx(FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT);

    /* Set selected element index to be the same as top element*/
    selectedElementIdx = topElementIdx;
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_SelectedElementIdx(FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT);

    /* Set attributes to display */
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(selectedElementIdx, 
                FRAME_DATA_ATTRIBUTES_VISIBLE_MASK | FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);            
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(selectedElementIdx + 1, 
                FRAME_DATA_ATTRIBUTES_VISIBLE_MASK | FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);            
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(selectedElementIdx + 2, 
                FRAME_DATA_ATTRIBUTES_VISIBLE_MASK | FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK); 

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Init
 *
 * @brief      Init buffer with initial N elements from list
 * 
 * @param [in]  void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_Buffer_Init(void)
{
    uint8_t i;
    uint8_t listIdx;
    uint8_t numOptions;
    uint8_t topElementIdx;
    uint8_t selectedElementIdx;
    uint8_t nextElementIdx;

    /* Set attributes for first element (CallContactMsg) */
    listIdx = CALL_STATUS_FRAME_INITIAL_INDEX;
    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(listIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK);
    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementIdx(listIdx,listIdx);
    listIdx++;

    /* Set attributes for second element (CallStsMsg)*/
    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(listIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK);
    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementIdx(listIdx,listIdx);
    listIdx++;

    /* Init all other elements as not visible */
    for(i = CALL_STATUS_FRAME_INITIAL_INDEX; i < CALL_STATUS_OPTIONS_LIST_ELEMENTS; i++)
    {   
        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(listIdx, FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK);
        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementIdx(listIdx,listIdx);
        listIdx++;
    }

    /* Now get the number of option elements in list */
    numOptions = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements();

    /* If there are available call options */
    if(numOptions)
    {
        /* Set top element index of the buffer*/
        topElementIdx = CALL_STATUS_OPTIONS_LIST_INITIAL_TOP_ELEMENT;
        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_TopElementIdx(topElementIdx);

        /* Set selected element index to be the same as top element*/
        selectedElementIdx = topElementIdx;
        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx(selectedElementIdx);

        /* Set attributes to display */
        BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(selectedElementIdx,FRAME_DATA_ATTRIBUTES_VISIBLE_MASK | FRAME_DATA_ATTRIBUTES_FOCUSED_MASK);

        if(numOptions > CALL_STATUS_OPTIONS_LIST_NUM_MIN_ELEMENTS)
        {
            nextElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx(selectedElementIdx);
            BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(nextElementIdx,FRAME_DATA_ATTRIBUTES_VISIBLE_MASK | FRAME_DATA_ATTRIBUTES_SELECTABLE_MASK);
        }
    }
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_InitToBottom
 *
 * @brief      Init buffer with last N elements from list
 * 
 * @param [in]  void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_Buffer_InitToBottom(void)
{
    uint8_t i;
    uint8_t listIdx;
    uint8_t numElements;
    uint8_t numListElements;
    uint8_t topElementIdx;
    uint8_t nextElementIdx;
    uint8_t prevElementIdx;
    uint8_t selectedElementIdx;    
    uint8_t prevElementListIdx;
    uint8_t nextElementListIdx;

    /* Init the buffer setting the header element */
    listIdx = 0;
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(listIdx, FRAME_DATA_ATTRIBUTES_VISIBLE_MASK);
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx(listIdx,listIdx);
    listIdx++;

    /* Now get the number of elements in the list (including the footer) */
    numListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

    /* Calculate the number of elements that will be put in the buffer */
    /* The buffer only has (FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS - 1) elements to store because of the header */
    numElements = (numListElements > (FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS - 1)) ? (FRAME_RECENT_CALLS_DISPLAYED_ELEMENTS - 1) : numListElements;
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_NumElements(numElements);

    /* Add the first "numElements" elements from the list to the buffer */
    for(i = 0; i < numElements; i++)
    {   
        BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx(listIdx,listIdx);
        BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(listIdx,FRAME_DATA_ATTRIBUTES_NOT_VISIBLE_MASK);
        listIdx++;
    }

    /* Set top element index of the buffer*/
    topElementIdx = FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT;
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_TopElementIdx(FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT);

    /* Set selected element index to be the same as top element*/
    selectedElementIdx = topElementIdx;
    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_SelectedElementIdx(FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT);

    /* Now, move the selected element until the bottom of the list */
    for(i = 0; i < numListElements; i++)
    {
        BAP_TELEPHONY_FRAME_RecentCalls_UpdateAttributes(RecentCalls_ListDown);

        if(BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop() == true)
        {
            // Get top element index for buffer
            topElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();

            // Get next element index to top element in buffer (this could be the new index of top)
            nextElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(topElementIdx);

            // Get prev element index to top element in buffer (we need to obtain the reference of this index to list)
            prevElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(topElementIdx);

            // Get list index (content) of previous element to top in buffer  
            prevElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(prevElementIdx);

            // If the list index of the previous element to top is the last we don't have to update anything
            if(prevElementListIdx != numListElements)
            {
                // Get next element in list to that element
                nextElementListIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NextElementIdx(prevElementListIdx);

                // Set the next list index in the top position
                BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx(topElementIdx,nextElementListIdx);
                // Update top position to next element in buffer
                BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_TopElementIdx(nextElementIdx);           
            }
        }
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Print
 *
 * @brief      Print buffer starting from top element
 * 
 * @param [in]  void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Print(void)
{
    uint8_t i;
    uint8_t numElements;
    uint8_t bufferElementIdx;

    /* Log number of elements in buffer */
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Print > numElements = %x \r\n",
                                            BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NumElements());
    /* Log selected element in buffer */
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Print > selectedElementIdx = %x \r\n",
                                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx());
    /* Log top element in buffer */
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Print > topElementIdx = %x \r\n",
                                    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx());

    /* Log list element indexes (starting from top)*/

    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Print > listElementIdx = { ");
    LOG_PRINT(DEBUG_BAP,"[%x] = %x, ",0,BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(0));

    bufferElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();
    numElements = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NumElements();
    for(i = 0; i < numElements; i++)
    {
        LOG_PRINT(DEBUG_BAP,"[%x] = %x, ",bufferElementIdx,BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(bufferElementIdx));
        bufferElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(bufferElementIdx);
    }
    LOG_PRINT(DEBUG_BAP,"} \r\n");

    /* Los list element attributes (starting from top )*/

    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Print > listElementsAttr = { ");
    LOG_PRINT(DEBUG_BAP,"[%x] = %x, ",0,BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementAttributes(0));
    
    bufferElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();
    for(i = 0; i < numElements; i++)
    {
        LOG_PRINT(DEBUG_BAP,"[%x] = %x, ",bufferElementIdx,BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementAttributes(bufferElementIdx));
        bufferElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(bufferElementIdx);
    }
    LOG_PRINT(DEBUG_BAP,"} \r\n");
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx
 *
 * @brief      Get index of the buffer that represents the selected element
 * 
 * @param [in]  void
 *
 * @return      uint8_t - selected element index
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx(void)
{
    return BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.selectedElementIdx;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx
 *
 * @brief      Get index of the buffer that represents the selected element
 * 
 * @param [in]  void
 *
 * @return      uint8_t - selected element index
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx(void)
{
    return BAP_TELEPHONY_FRAME_CALL_STATUS_Data.selectedElementIdx;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_SelectedElementIdx
 *
 * @brief      Set the index of the buffer that will represent the selected
 *             element
 * 
 * @param [in]  uint8_t - buffer_sel_idx - Buffer index to set as selected
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_SelectedElementIdx(uint8_t buffer_sel_idx)
{

    BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.selectedElementIdx = buffer_sel_idx;

    return true;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx
 *
 * @brief      Set the index of the buffer that will represent the selected
 *             element
 * 
 * @param [in]  uint8_t - buffer_sel_idx - Buffer index to set as selected
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx(uint8_t buffer_sel_idx)
{
    BAP_TELEPHONY_FRAME_CALL_STATUS_Data.selectedElementIdx = buffer_sel_idx;

    return true;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx
 *
 * @brief      Get index of the buffer that represents the top element
 * 
 * @param [in]  void
 *
 * @return      uint8_t
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx(void)
{
    return BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.topElementIdx;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_TopElementIdx
 *
 * @brief      Get index of the buffer that represents the top element
 * 
 * @param [in]  void
 *
 * @return      uint8_t
 *
 ******************************************************************************/
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_TopElementIdx(void)
{
    return BAP_TELEPHONY_FRAME_CALL_STATUS_Data.topElementIdx;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_TopElementIdx
 *
 * @brief      Set the index of the buffer that will represent the top
 *             element
 * 
 * @param [in]  uint8_t - Top element index
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_TopElementIdx(uint8_t buffer_top_idx)
{
    BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.topElementIdx = buffer_top_idx;

    return true;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_TopElementIdx
 *
 * @brief      Set the index of the buffer that will represent the top
 *             element
 * 
 * @param [in]  uint8_t - Top element index
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_TopElementIdx(uint8_t buffer_top_idx)
{
    BAP_TELEPHONY_FRAME_CALL_STATUS_Data.topElementIdx = buffer_top_idx;

    return true;   
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NumElements
 *
 * @brief      Get number of elements in the buffer
 * 
 * @param [in]  void
 *
 * @return      uint8_t 
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NumElements(void)
{
    return BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.numElements;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements
 *
 * @brief      Get number of elements in the buffer
 * 
 * @param [in]  void
 *
 * @return      uint8_t 
 *
 ******************************************************************************/
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements(void)
{
    return BAP_TELEPHONY_FRAME_CALL_STATUS_Data.numOptions;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_NumElements
 *
 * @brief      Set number of elements in the buffer
 * 
 * @param [in]  uint8_t - Num elements in buffer
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_NumElements(uint8_t num_elements)
{
    BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.numElements = num_elements;

    return true;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_NumElements
 *
 * @brief      Set number of elements in the buffer
 * 
 * @param [in]  uint8_t - Num elements in buffer
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_NumElements(uint8_t num_elements)
{
    BAP_TELEPHONY_FRAME_CALL_STATUS_Data.numOptions = num_elements;

    return true;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx
 *
 * @brief      Get list element index from buffer. The listElementIdx array
 *             contains indexes from the recents calls list that build the
 *             current displayed part of the list
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *
 * @return      uint8_t - list index
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(uint8_t buffer_idx)
{
    return BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.listElementsIdx[buffer_idx];
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementIdx
 *
 * @brief      Get list element index from buffer. The listElementIdx array
 *             contains indexes from the recents calls list that build the
 *             current displayed part of the list
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *
 * @return      uint8_t - list index
 *
 ******************************************************************************/
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementIdx(uint8_t buffer_idx)
{
    return BAP_TELEPHONY_FRAME_CALL_STATUS_Data.listElementsIdx[buffer_idx];
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx
 *
 * @brief      Set list element index in buffer array
 * 
 * @param [in]   uint8_t - buffer_idx - Buffer index 
 * @param [out]  uint8_t - list_idx   - List index 
 *
 *
 * @return      bool_t - Operation result
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx(uint8_t buffer_idx, uint8_t list_idx)
{
    BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.listElementsIdx[buffer_idx] = list_idx;

    return true;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementIdx
 *
 * @brief      Set list element index in buffer array
 * 
 * @param [in]   uint8_t - buffer_idx - Buffer index 
 * @param [out]  uint8_t - list_idx   - List index 
 *
 *
 * @return      bool_t - Operation result
 *
 ******************************************************************************/
bool_t    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementIdx(uint8_t buffer_idx, uint8_t list_idx)
{
    BAP_TELEPHONY_FRAME_CALL_STATUS_Data.listElementsIdx[buffer_idx] = list_idx;

    return true;    
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementAttributes
 *
 * @brief      Get list element attributes from buffer. The listElementAttributes array
 *             contains attributes for the elements of listElementsIdx
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *
 * @return      uint8_t - attributes
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementAttributes(uint8_t buffer_idx)
{
    return BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.listElementsAttributes[buffer_idx];
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes
 *
 * @brief      Get list element attributes from buffer. The listElementAttributes array
 *             contains attributes for the elements of listElementsIdx
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *
 * @return      uint8_t - attributes
 *
 ******************************************************************************/
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes(uint8_t buffer_idx)
{
    return BAP_TELEPHONY_FRAME_CALL_STATUS_Data.listElementsAttributes[buffer_idx];
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes
 *
 * @brief      Set list element attributes in buffer. The listElementAttributes array
 *             contains attributes for the elements of listElementsIdx
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *              uint8_t - attributes - Attributes
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(uint8_t buffer_idx, uint8_t attr)
{
    BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.buffer.listElementsAttributes[buffer_idx] = attr;

    return true;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes
 *
 * @brief      Set list element attributes in buffer. The listElementAttributes array
 *             contains attributes for the elements of listElementsIdx
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *              uint8_t - attributes - Attributes
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(uint8_t buffer_idx, uint8_t attr)
{
    BAP_TELEPHONY_FRAME_CALL_STATUS_Data.listElementsAttributes[buffer_idx] = attr;

    return true;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx
 *
 * @brief      Calculate next element in buffer (circular) (not counting 0)
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *
 * @return      uint8_t - Next index
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(uint8_t buffer_idx)
{
    uint8_t nextElement;
    uint8_t numElements;

    /* Get total number of elements in buffer (counting the footer (+1) but not the header) */
    numElements = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NumElements();

    /* Get previous element  index in the buffer*/
    if(buffer_idx > (numElements))
    {
        nextElement = 0;
    }
    else
    {
        if(buffer_idx == 0)
        {
            nextElement = FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT;
        }
        else
        {
            nextElement = buffer_idx + 1;
            nextElement = (nextElement > (numElements)) ? FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT : nextElement;    
        }
    }

    return nextElement;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx
 *
 * @brief      Calculate next element in buffer (circular) (not counting 0)
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *
 * @return      uint8_t - Next index
 *
 ******************************************************************************/
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx(uint8_t buffer_idx)
{
    uint8_t nextElement;
    uint8_t numOptions;
    uint8_t numElements;

    /* Get available number of options elements */
    numOptions = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements();
    /* Calculate total number of call status elements in frame */
    numElements = numOptions + CALL_STATUS_INFO_ELEMENTS;

    if(numOptions < CALL_STATUS_OPTIONS_LIST_NUM_MIN_ELEMENTS)
    {
        /* If there are no option list elements, next is set to initial index */
        nextElement = CALL_STATUS_FRAME_INITIAL_INDEX;
    }
    else if ((buffer_idx > (numElements - 1)) || (buffer_idx < CALL_STATUS_OPTIONS_LIST_INITIAL_TOP_ELEMENT))
    {
        /* Check for invalid values, if selected option is greater than number of elements or is less than the
        index of the first option, next is set to initial index */
        nextElement = CALL_STATUS_FRAME_INITIAL_INDEX;
    }
    else
    {
        if(buffer_idx == (numElements - 1))
        {
            /* If the selected option is the last one, return the same element, no next is available */
            nextElement = buffer_idx;
        }
        else
        {
            /* If option is valid and not the last one, return the next index */
            nextElement = buffer_idx + 1;
        } 
    }

    return nextElement;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx
 *
 * @brief      Calculate next element in buffer (circular) (not counting 0)
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *
 * @return      uint8_t - Next index
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(uint8_t buffer_idx)
{
    uint8_t prevElement;
    uint8_t numElements;

    /* Get total number of elements in buffer */
    numElements = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NumElements();

    /* Get previous element  index in the buffer*/
    if(buffer_idx > (numElements))
    {
        prevElement = 0;
    }
    else
    {
        if(buffer_idx == 0)
        {
            prevElement = 0;
        }
        else
        {
            prevElement = buffer_idx - 1;
            prevElement = (prevElement == 0) ? (numElements)  : prevElement;
        }
    }

    return prevElement;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_PrevElementIdx
 *
 * @brief      Calculate next element in buffer (circular) (not counting 0)
 * 
 * @param [in]  uint8_t - buffer_idx - Buffer index 
 *
 * @return      uint8_t - Next index
 *
 ******************************************************************************/
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_PrevElementIdx(uint8_t buffer_idx)
{
    uint8_t prevElement;
    uint8_t numOptions;
    uint8_t numElements;

    /* Get available number of elements (including headers) */
    numOptions = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements();
    /* Calculate total number of call status elements in frame */
    numElements = numOptions + CALL_STATUS_INFO_ELEMENTS;

    /* Get next element  index in the buffer*/
    if(numOptions < CALL_STATUS_OPTIONS_LIST_NUM_MIN_ELEMENTS)
    {
        /* If there are no option list elements, prev is set to initial index */
        prevElement = CALL_STATUS_FRAME_INITIAL_INDEX;
    }
    else if ((buffer_idx > (numElements - 1)) || (buffer_idx < CALL_STATUS_OPTIONS_LIST_INITIAL_TOP_ELEMENT))
    {
        /* Check for invalid values, if selected option is greater than number of elements or is less than the
        index of the first option, prev is set to initial index */
        prevElement = CALL_STATUS_FRAME_INITIAL_INDEX;
    }
    else
    {
        /* If the selected option is the first one, return the same element, no prev option is available */
        if(buffer_idx == CALL_STATUS_OPTIONS_LIST_INITIAL_TOP_ELEMENT)
        {
            prevElement = buffer_idx;
        }
        else
        {
            /* If option is valid and not the first one, return the prev index */
            prevElement = buffer_idx - 1;
        }
    }

    return prevElement;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_ClockDistance
 *
 * @brief      Calculate the anti clock distance between two indexes in buffer
 * 
 * @param [in]  uint8_t - fromIdx
 *              uint8_t - toIdx
 *              uint8_t - len
 *
 * @return      uint8_t
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_ClockDistance(uint8_t fromIdx, uint8_t toIdx, uint8_t len)
{
    return (((toIdx - fromIdx) + len) % len) -1;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_Buffer_AntiClockDistance
 *
 * @brief      Calculate the anti clock distance between two indexes in buffer
 * 
 * @param [in]  uint8_t - fromIdx
 *              uint8_t - toIdx
 *              uint8_t - len
 *
 * @return      uint8_t
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_Buffer_AntiClockDistance(uint8_t fromIdx, uint8_t toIdx, uint8_t len)
{
    return (((fromIdx - toIdx) + len) % len) -1;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements
 *
 * @brief      Get number of elements from list
 * 
 * @param [in]  void
 *
 * @return      uint8_t
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements(void)
{
    return BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.numElements;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_Set_NumElements
 *
 * @brief      Set number of elements from list
 * 
 * @param [in]  uint8_t - Number of elements
 *
 * @return      bool_t 
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_List_Set_NumElements(uint8_t num_elements)
{
    BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.numElements = num_elements;

    return true;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_Get_CurrentCmd
 *
 * @brief      Get current command in recent calls list
 * 
 * @param [in]  void
 *
 * @return      RecentCalls_UpdateCmd_T 
 *
 ******************************************************************************/
RecentCalls_UpdateCmd_T BAP_TELEPHONY_FRAME_RecentCalls_List_Get_CurrentCmd(void)
{
    return BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.currentCmd;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_List_Get_CurrentCmd
 *
 * @brief      Get current command in call status list
 * 
 * @param [in]  void
 *
 * @return      CallStatus_Update_Cmd_T 
 *
 ******************************************************************************/
CallStatus_Update_Cmd_T BAP_TELEPHONY_FRAME_CallStatus_List_Get_CurrentCmd(void)
{
    return BAP_TELEPHONY_FRAME_CALL_STATUS_Data.currentCmd;
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd
 *
 * @brief      Set current command in recent calls list
 * 
 * @param [in]  RecentCalls_UpdateCmd_T - Recent calls command
 *
 * @return      void 
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(RecentCalls_UpdateCmd_T cmd)
{
    if(cmd < RecentCalls_NumCmds)
    {
        BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.currentCmd = cmd;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_List_Set_CurrentCmd
 *
 * @brief      Set current command in recent calls list
 * 
 * @param [in]  CallStatus_Update_Cmd_T - Recent calls command
 *
 * @return      void 
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_List_Set_CurrentCmd(CallStatus_Update_Cmd_T cmd)
{
    if(cmd < CallStatus_NumCmds)
    {
        BAP_TELEPHONY_FRAME_CALL_STATUS_Data.currentCmd = cmd;
    }    
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx
 *
 * @brief      Get list index of the selected element in buffer 
 * 
 * @param [in]  void
 *
 * @return      uint8_t - Selected list element index
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx(void)
{
    uint8_t selectedElementIdx;
    uint8_t selectedListElementIdx;

    /* Get the index of the selected element in buffer */
    selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();
    /* Get list element index from the selected index in buffer */
    selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(selectedElementIdx);

    return selectedListElementIdx;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_Get_TopElementIdx
 *
 * @brief      Get list index of the top element in buffer 
 * 
 * @param [in]  void
 *
 * @return      uint8_t - Top list element index
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_TopElementIdx(void)
{
    uint8_t topElementIdx;
    uint8_t topListElementIdx;

    /* Get the index of the selected element in buffer */
    topElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx();    
    /* Get list element index from the top index in buffer */
    topListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(topElementIdx);

    return topListElementIdx;
}



/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_GetNextElement
 *
 * @brief      Calculate next element in list (circular) (not counting 0)
 * 
 * @param [in]  uint8_t - list element index
 *
 * @return      uint8_t - Next list elements index
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NextElementIdx(uint8_t listElementIdx)
{
    uint8_t nextListElementIdx;
    uint8_t numListElements;

    /* Get total number of elements in list (counting the footer (+1) but not the header) */
    numListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

    /* Get next index in the list*/
    if(listElementIdx > (numListElements))
    {
        nextListElementIdx = 0;
    }
    else
    {
        if(listElementIdx == 0)
        {
            nextListElementIdx = 0;
        }
        else
        {
            nextListElementIdx = (listElementIdx + 1);
            nextListElementIdx = (nextListElementIdx > (numListElements)) ? FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT : nextListElementIdx;    
        }
    }

    return nextListElementIdx;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_Get_PrevElementIdx
 *
 * @brief      Calculate prev element in list (circular) (not counting 0)
 * 
 * @param [in]  uint8_t list element idx
 *
 * @return      uint8_t - Prev list elements index
 *
 ******************************************************************************/
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_PrevElementIdx(uint8_t listElementIdx)
{
    uint8_t prevListElementIdx;
    uint8_t numListElements;

    /* Get total number of elements in list (counting the footer (+1) but not the header) */
    numListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

    /* Get previous element  index in the buffer*/
    if(listElementIdx > numListElements)
    {
        prevListElementIdx = 0;
    }
    else
    {
        if(listElementIdx == 0)
        {
            prevListElementIdx = 0;
        }
        else
        {
            prevListElementIdx = listElementIdx - 1;
            prevListElementIdx = (prevListElementIdx == 0) ? (numListElements)  : prevListElementIdx;    
        }
    }

    return prevListElementIdx;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_First_Element_Selected
 *
 * @brief      Check if the first element from the list is selected
 * 
 * @param [in]  void
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_List_First_Element_Selected(void)
{
    uint8_t currentNumListElements;
    uint8_t selectedElementIdx;
    uint8_t selectedListElementIdx;
    bool_t ret = false;

    /* Get current num of elements in the list (including footer) */
    currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

    /* Get index of the selected element in the buffer */
    selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();

    /* Get index of the selected element in the list */
    selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx();

    /* Check if the selected element in the buffer refers to the first element of list */
    if (selectedListElementIdx == FRAME_RECENT_CALLS_LIST_INITIAL_TOP_ELEMENT)
    {
        ret = true;
    }

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected
 *
 * @brief      Check if the first element from the list is selected
 * 
 * @param [in]  void
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected(void)
{
    uint8_t currentNumListElements;
    uint8_t selectedElementIdx;
    bool_t ret = false;

    /* Get current num of elements in the list (including headers) */
    currentNumListElements = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements() + CALL_STATUS_INFO_ELEMENTS;

    if(currentNumListElements > CALL_STATUS_INFO_ELEMENTS)
    {
        /* Get index of the selected element in the buffer */
        selectedElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx();

        /* Check if the selected element in the buffer refers to the first element of list */
        if (selectedElementIdx == CALL_STATUS_OPTIONS_LIST_INITIAL_TOP_ELEMENT)
        {
            ret = true;
        }
    }

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_List_Last_Element_Selected
 *
 * @brief      Check if the last element from the list is selected
 * 
 * @param [in]  void
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_List_Last_Element_Selected(void)
{
    uint8_t currentNumListElements;
    uint8_t selectedElementIdx;
    uint8_t selectedListElementIdx;
    uint8_t nextElementListIdx;
    bool_t ret = false;

    /* Get current num of elements in the list (including footer) */
    currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

    /* Get index of the selected element in the buffer */
    selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();

    /* Get index of the selected element in the list */
    selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx();

    /* Check if the selected element in the buffer refers to the last element of list */
    if (selectedListElementIdx == currentNumListElements)
    {
        ret = true;
    }

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected
 *
 * @brief      Check if the last element from the list is selected
 * 
 * @param [in]  void
 *
 * @return      bool_t
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected(void)
{
    uint8_t currentNumListElements;
    uint8_t selectedElementIdx;
    bool_t ret = false;

    /* Get current num of elements in the list (including headers) */
    currentNumListElements = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements() + CALL_STATUS_INFO_ELEMENTS;

    if(currentNumListElements > CALL_STATUS_INFO_ELEMENTS)
    {
        /* Get index of the selected element in the buffer */
        selectedElementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx();

        /* Check if the selected element in the buffer refers to the first element of list */
        if (selectedElementIdx == (currentNumListElements-1))
        {
            ret = true;
        }
    }

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_CallSelectedContact
 *
 * @brief      Call the selected contact from the list
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_CallSelectedContact(void)
{
    uint8_t currentNumListElements;
    uint8_t selectedElementIdx;
    uint8_t selectedListElementIdx;

    // Get Current num of list elements (including footer)
    currentNumListElements = BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements() + 1;

    // Get Selected element buffer index
    selectedElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx();

    // Get selected element list index
    selectedListElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(selectedElementIdx);

    // Check if the selected element is the footer
    if(selectedListElementIdx == currentNumListElements)
    {
        // In this case, must go back to connection status frame
        /* Send Frame data (Scrollbar and Displayed data)*/
        BAP_TELEPHONY_FRAME_ConnectionStatus_SendData();
        /* Send new status */
        BAP_TELEPHONY_FRAME_ConnectionStatus_SendStatus();                
    }
    else
    {
        // Send the selected contact index to phone repetition to make a call
        Shadow_Server_Storage_Set(SHADOW_PhoneRepetition_SelectedContact, &selectedListElementIdx);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_SelectCallOption
 *
 * @brief      Select call option from list
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_SelectCallOption(void)
{
    uint8_t selectedOptionId;
    uint8_t selectedOptionIdx;
    uint8_t numOptionElements;

    // Get the number of elements in the option list
    numOptionElements = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements();

    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_SelectCallOption > numOptions = %d \r\n", numOptionElements);

    if(numOptionElements)
    {
        // Get the index of the selected element in the list
        selectedOptionIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx() - CALL_STATUS_INFO_ELEMENTS;

        // Get the selected option Id
        selectedOptionId = (BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callOptionsList[selectedOptionIdx]).optionId;

        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_SelectCallOption > selectedOptionIdx = %d \r\n", selectedOptionIdx);
        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_SelectCallOption > selectedOptionId = %d \r\n", selectedOptionId);

        // Send the selected option Id to phone repetition to make a call
        Shadow_Server_Storage_Set(SHADOW_PhoneRepetition_SelectedOption, &selectedOptionId);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_ClearSelectedContact
 *
 * @brief      Update selected contact to an invalid value in order to be availa
 *             ble to make a call to the previous index 
 * 
 * @param [in]  void
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_ClearSelectedContact(void)
{
    uint8_t selectedListElementIdx;

    // Use this predefined value to update the shadow signal
    selectedListElementIdx = RECENT_CALLS_SELECTED_CONTACT_INVALID;

    // Set this signal to an invalid contact index in order to update the next selected contact
    Shadow_Server_Storage_Set(SHADOW_PhoneRepetition_SelectedContact, (uint8_t *)&selectedListElementIdx);    
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_UpdateScrollbar
 *
 * @brief      Generate Scrollbar for selected frame
 *
 * @param [in]  TELEPHONY_Frame_Idx_T - Selected frame 
 *              Scrollbar_T           - Scrollbar parameters
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_UpdateScrollbar(TELEPHONY_Frame_Idx_T idx, Scrollbar_T scrollbar)
{
    if(idx < BAP_TELEPHONY_NumFrames)
    {
        switch(bap_telephony_appl_frame_getId(idx))
        {
            case BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Id:            
                /* Trigger scrollbar update */
                memcpy(&(bap_telephony_appl_frame_getScrollbar(idx)),&scrollbar,sizeof(scrollbar));

            break;

            case BAP_TELEPHONY_FRAME_RECENT_CALLS_Id:

                /* Set scrollbar*/
                scrollbar.frameId = BAP_TELEPHONY_FRAME_RECENT_CALLS_Id;
                scrollbar.attributes = SCROLLBAR_ATTRIBUTES_VERTICAL_SCROLLBAR_AND_NAVIGATION_ARROWS_MASK;
                scrollbar.sliderLength = SCROLLBAR_SLIDER_LENGTH_DEFAULT_VALUE;
                scrollbar.sliderPosition = SCROLLBAR_SLIDER_POSITION_TOP_OF_LIST;

                /* Trigger scrollbar update */
                memcpy(&(bap_telephony_appl_frame_getScrollbar(idx)),&scrollbar,sizeof(scrollbar));

            break;

            case BAP_TELEPHONY_FRAME_CALL_STATUS_Id:

                /* Trigger scrollbar update */
                memcpy(&(bap_telephony_appl_frame_getScrollbar(idx)),&scrollbar,sizeof(scrollbar));

            break;

        }
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_GetArrayHeaderPrms
 *
 * @brief      Get array header parameters for a frame
 *
 * @param [in]  TELEPHONY_Frame_Idx_T - Selected frame 
 *
 * @return     ArrayHeaderPrms_T
 *
 ******************************************************************************/
ArrayHeaderPrms_T BAP_TELEPHONY_FRAME_GetArrayHeaderPrms(TELEPHONY_Frame_Idx_T idx)
{
    ArrayHeaderPrms_T headerPrms;

    switch(bap_telephony_appl_frame_getId(idx))
    {
        case BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Id:

            // Set Idx size to 8 bits
            headerPrms.idxSize = ArrayIndexSize_8Bits;
            // // Set to Transmit element position
            headerPrms.posTransmit = true;
            // // Set Array direction to forward
            headerPrms.arrayDirection = ArrayDirection_Forward;
            // // Set unknknown parameter (bit4) 
            headerPrms.unknownParam = false;
            // // Set record Adress: Transmit all elements
            headerPrms.recordAddress = ArrayRecordAdress_TypeAndAttributesAndName;
            // // Set ArrayHeader.Start
            headerPrms.start = FRAME_DATA_ARRAY_HEADER_START_DEFAULT_VALUE;
            // // Set ArrayHeader.Elements
            headerPrms.elements = FRAME_DATA_ARRAY_HEADER_ELEMENTS_DEFAULT_VALUE;

        break;

        case BAP_TELEPHONY_FRAME_RECENT_CALLS_Id:

            // // Set idx size to 8 bits
            headerPrms.idxSize = ArrayIndexSize_8Bits;
            // // Set to Transmit element position
            headerPrms.posTransmit = true;
            // // Set Array direction to forward
            headerPrms.arrayDirection = ArrayDirection_Forward;
            // // Set unknknown parameter (bit4) 
            headerPrms.unknownParam = false;

        break;

        case BAP_TELEPHONY_FRAME_CALL_STATUS_Id:

            // // Set idx size to 8 bits
            headerPrms.idxSize = ArrayIndexSize_8Bits;
            // // Set to Transmit element position
            headerPrms.posTransmit = true;
            // // Set Array direction to forward
            headerPrms.arrayDirection = ArrayDirection_Forward;
            // // Set unknknown parameter (bit4) 
            headerPrms.unknownParam = false;

        break;

    }

    return headerPrms;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_UpdateStatusData
 *
 * @brief      Generate FrameData for selected frame
 *
 * @param [in]  TELEPHONY_Frame_Idx_T - Selected frame 
 *              ListOperation_T       - List operation 
 *              uint8_t               - Top element
 *              ArrayHeaderPrms_T     - Header parameters
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_UpdateStatusData(TELEPHONY_Frame_Idx_T idx, ListOperation_T listOperation, uint8_t listElementOnTop, ArrayHeaderPrms_T headerPrms)
{
    FrameData_StatusArray_T statusArray;

    if(idx < BAP_TELEPHONY_NumFrames)
    {
        switch(bap_telephony_appl_frame_getId(idx))
        {
            case BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Id:
                
                /* Set StatusArray*/
                // Set StatusArray.frameId
                statusArray.frameId = BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Id;
                // Set StatusArray.ListElementOnTop
                statusArray.listElementOnTop = listElementOnTop;
                // Set StatusArray.ListOperation
                statusArray.listOperation = listOperation;
                // Set StatusArray.Header
                BAP_FRAME_DATA_Set_Array_Header_Prms(&(statusArray.arrayHeader), &headerPrms);
                // Set StatusArray.Data
                BAP_FRAME_DATA_Set_Array_Data(&headerPrms,&(statusArray));
            
                /* Trigger statusArray update */
                memcpy(&(frameArray[idx].frameData),&statusArray,sizeof(statusArray));
            break;

            case BAP_TELEPHONY_FRAME_RECENT_CALLS_Id:

                /* Set StatusArray*/
                // Set StatusArray.frameId
                statusArray.frameId = BAP_TELEPHONY_FRAME_RECENT_CALLS_Id;
                // Set StatusArray.ListElementOnTop
                statusArray.listElementOnTop = listElementOnTop;
                // Set StatusArray.ListOperation
                statusArray.listOperation = listOperation;
                // Set StatusArray.Header
                BAP_FRAME_DATA_Set_Array_Header_Prms(&(statusArray.arrayHeader), &headerPrms);
                // Set StatusArray.Data
                BAP_FRAME_DATA_Set_Array_Data(&headerPrms,&(statusArray));

                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_UpdateStatusData > frameId = %x, top = %x, op = %x \r\n",
                                                            statusArray.frameId, statusArray.listElementOnTop, statusArray.listOperation);
                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_UpdateStatusData > start = %x, elements = %x, mode = %x \r\n",
                                                            statusArray.arrayHeader.start, statusArray.arrayHeader.elements, statusArray.arrayHeader.mode);
                /* Trigger statusArray update */
                memcpy(&(frameArray[idx].frameData),&statusArray,sizeof(statusArray));
                
            break;

            case BAP_TELEPHONY_FRAME_CALL_STATUS_Id:
                
                /* Set StatusArray*/
                // Set StatusArray.frameId
                statusArray.frameId = BAP_TELEPHONY_FRAME_CALL_STATUS_Id;
                // Set StatusArray.ListElementOnTop
                statusArray.listElementOnTop = listElementOnTop;
                // Set StatusArray.ListOperation
                statusArray.listOperation = listOperation;
                // Set StatusArray.Header
                BAP_FRAME_DATA_Set_Array_Header_Prms(&(statusArray.arrayHeader), &headerPrms);
                // Set StatusArray.Data
                BAP_FRAME_DATA_Set_Array_Data(&headerPrms,&(statusArray));
            
                /* Trigger scrollbar update */
                memcpy(&(frameArray[idx].frameData),&statusArray,sizeof(statusArray));

            break;

        }
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ASG_Response
 *
 * @brief      Process key event in BAP TELEPHONY
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ASG_Response(FrameStatus_T rcvFrameStatus)
{
    uint8_t id = rcvFrameStatus.frameId;
    TELEPHONY_Frame_Idx_T idx = MapFrameIdToFrameIdx[id];

    if(idx < BAP_TELEPHONY_NumFrames)
    {

        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ASG_Response > frameId = %x\r\n",bap_telephony_appl_frame_getId(idx));

        switch(rcvFrameStatus.ASG_Response)
        {
            case ASG_Response_NoResponse:
            case ASG_Response_ASGReqVisON:
            case ASG_Response_QueuedUp:

                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ASG_Response > ASG_Response_NoResponse\r\n");

                if(id == FRAME_STATUS_FRAME_ID_RELEASE_ALL_FRAMES)
                {
                    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ASG_Response > Release all frames \r\n");

                    idx = MapFrameIdToFrameIdx[id];
                    BAP_TELEPHONY_ReqFrameOFF(idx);                    
                }
                else
                {
                    if(id == FRAME_STATUS_FRAME_ID_DETERMINED_BY_FSG)
                    {
                        if(lastEnabledFrame == FRAME_STATUS_FRAME_ID_NO_FRAME)
                        {
                            idx = MapFrameIdToFrameIdx[id];        
                        }
                        else
                        {
                            idx = MapFrameIdToFrameIdx[lastEnabledFrame];
                        }

                        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ASG_Response > Determined id by FSG: frameId = %x\r\n",bap_telephony_appl_frame_getId(idx));

                    }
                
                    BAP_TELEPHONY_ReqFrameON(idx,rcvFrameStatus);

                }

            break;

            case ASG_Response_SetVisON:     

                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ASG_Response > ASG_Response_SetVisON\r\n");

                BAP_TELEPHONY_SetFrameON(idx, rcvFrameStatus);

            break;

            case ASG_Response_SetVisOFF:

                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ASG_Response > ASG_Response_SetVisOFF\r\n");

                BAP_TELEPHONY_SetFrameOFF(idx, rcvFrameStatus);

            break;

            default:

            break;

        }
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ReqFrameON
 *
 * @brief      Attempt to trigger an ON request for idx frame
 *
 * @param [in] TELEPHONY_Frame_Idx_T newIdx - Idx of the frame
 *             FrameStatus_T frameStatus    - Request parameters
 *
 * @return     void
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_ReqFrameON(TELEPHONY_Frame_Idx_T newIdx, FrameStatus_T frameStatus)
{
    TELEPHONY_Frame_Idx_T currentIdx;
    bool_t ret = false;

    /* Set received ASGResponse to selected frame*/
    bap_telephony_appl_frame_setASGResponse(newIdx, frameStatus.ASG_Response);
    /* Set received MFL blocks to selected frame*/
    bap_telephony_appl_frame_setMFLBlocks(newIdx, frameStatus.MFL_Assigned.MFL_Blocks);
    /* Set focussed frame Id to 0x00 (no frame yet)*/
    bap_telephony_appl_frame_setFocusedFrameId(newIdx, 0x00);

    /* Set FSG Request analyzing the ASG_Response */
    if(bap_telephony_appl_frame_getASGResponse(newIdx) == ASG_Response_NoResponse)
    {
        bap_telephony_appl_frame_setFSGRequest(newIdx,FSG_Request_ReqVisON);
    }
    else
    {
        bap_telephony_appl_frame_setFSGRequest(newIdx,FSG_Request_AcceptASGReq);        
    }

    /* Check if there is a current enabled frame */
    if(bap_telephony_appl_frame_isEnabledFlag())
    {
        /* Get the idx of the current frame that is showing */
        currentIdx = bap_telephony_appl_frame_getEnabledFlag();

        if(currentIdx != newIdx)
        {
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ReqFrameON > Frame-Id %x currently ON, start OFF request \r\n",bap_telephony_appl_frame_getId(currentIdx));
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ReqFrameON > Queue Frame-Id %x  \r\n",bap_telephony_appl_frame_getId(newIdx));

            /* Start OFF request for current showing frame */
            BAP_TELEPHONY_ReqFrameOFF(currentIdx);

            /* Queue ON request for the new frame */

            /* Check if there is already a queued flag*/
            if(bap_telephony_appl_frame_getQueuedFlags())
            {
                /* If there is an already queued flag, invalidate it*/
                bap_telephony_appl_frame_clrQueuedFlag(bap_telephony_appl_frame_getQueuedFlag());
            }
            bap_telephony_appl_frame_setQueuedFlag(newIdx);

            /* Set state of new frame to ReqON */
            bap_telephony_appl_frame_setState(newIdx,FrameState_ReqON);
        }
    }
    else
    {
        /* In case the frame is call status, check if the call was made from another tab */
        if(bap_telephony_appl_frame_getId(newIdx) == BAP_TELEPHONY_FRAME_CALL_STATUS_Id)
        {
            callMadeFromAnotherTab = true;
        }

        /* If there is no enabled frame, start ON request for new frame */
        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ReqFrameON > No Frame-Id currently ON, start ON request for frame-Id = %x  \r\n",bap_telephony_appl_frame_getId(newIdx));
        bap_telephony_appl_frame_setUpdateFlag(newIdx);

        /* Set state of new frame to ReqON */
        bap_telephony_appl_frame_setState(newIdx,FrameState_ReqON);

    }

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_SetFrameON
 *
 * @brief      Trigger an ON set for idx frame
 *
 * @param [in] TELEPHONY_Frame_Idx_T newIdx - Idx of the frame
 *             FrameStatus_T frameStatus    - Set parameters
 *
 * @return     void
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_SetFrameON(TELEPHONY_Frame_Idx_T idx, FrameStatus_T frameStatus)
{
    bool_t ret = false;

    /* Check if there is no a current frame enabled */
    if(!bap_telephony_appl_frame_isEnabledFlag())
    {
        /* Set ON set parameters*/
        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_SetFrameON >  There is no Frame-Id ON, set Frame-Id %x to ON \r\n",bap_telephony_appl_frame_getId(idx));
        bap_telephony_appl_frame_setFocusedFrameId(idx, bap_telephony_appl_frame_getId(idx));
        bap_telephony_appl_frame_setMFLBlocks(idx, frameStatus.MFL_Assigned.MFL_Blocks);
        bap_telephony_appl_frame_setASGResponse(idx,frameStatus.ASG_Response);
        bap_telephony_appl_frame_setFSGRequest(idx,FSG_Request_ReqVisON);
        
        /* Set state of new frame to GoingToON*/
        bap_telephony_appl_frame_setState(idx,FrameState_GoingToON);
        
        /* Start ON set for new frame */
        bap_telephony_appl_frame_setUpdateFlag(idx);
    }

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_ReqFrameOFF
 *
 * @brief      Attempt to trigger an OFF request for idx frame
 *
 * @param [in] TELEPHONY_Frame_Idx_T newIdx - Idx of the frame
 *             FrameStatus_T frameStatus    - Request parameters
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_ReqFrameOFF(TELEPHONY_Frame_Idx_T idx)
{   
    /* Check if the current frame is enabled*/
    if((idx == bap_telephony_appl_frame_getEnabledFlag()) || (idx == BAP_TELEPHONY_FRAME_RELEASE_ALL_FRAMES_Idx))
    {
        /* Set OFF request parameters*/
        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_ReqFrameOFF > Frame-Id %x currently ON, start OFF request \r\n",bap_telephony_appl_frame_getId(idx));
        bap_telephony_appl_frame_setFSGRequest(idx,FSG_Request_ReqVisOFF);
        bap_telephony_appl_frame_setASGResponse(idx,ASG_Response_NoResponse);
        
        /* Set frame state */
        bap_telephony_appl_frame_setState(idx,FrameState_ReqOFF);
        
        /* Start OFF request*/
        bap_telephony_appl_frame_setUpdateFlag(idx);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_SetFrameOFF
 *
 * @brief      Trigger an OFF set for idx frame
 *
 * @param [in] TELEPHONY_Frame_Idx_T newIdx - Idx of the frame
 *             FrameStatus_T frameStatus    - Set parameters
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_SetFrameOFF(TELEPHONY_Frame_Idx_T idx, FrameStatus_T frameStatus)
{
    /* Check if the Frame-Id is "Release-All" Id*/
    if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_RELEASE_ALL_FRAMES_Id)
    {
        /* Start off request */
        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_SetFrameOFF > Frame-Id %x currently ON, set OFF \r\n",bap_telephony_appl_frame_getId(idx));
        bap_telephony_appl_frame_setASGResponse(idx,frameStatus.ASG_Response);
        bap_telephony_appl_frame_setFSGRequest(idx,FSG_Request_ReqVisOFF);
        bap_telephony_appl_frame_setState(idx,FrameState_GoingToOFF);
        bap_telephony_appl_frame_setUpdateFlag(idx); 
    }
    else if (bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_NO_FRAME_Id)
    {
        /* Set OFF parameters*/
        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_SetFrameOFF > Frame-Id %x set OFF \r\n",bap_telephony_appl_frame_getId(idx));
        bap_telephony_appl_frame_setFocusedFrameId(idx,frameStatus.MFL_Assigned.focusedFrameId);
        bap_telephony_appl_frame_setMFLBlocks(idx, frameStatus.MFL_Assigned.MFL_Blocks);
        bap_telephony_appl_frame_setASGResponse(idx,frameStatus.ASG_Response);
        bap_telephony_appl_frame_setFSGRequest(idx,FSG_Request_ReqVisOFF);
        
        /* Update frame state and start Request */
        bap_telephony_appl_frame_setState(idx,FrameState_GoingToOFF);
        bap_telephony_appl_frame_setUpdateFlag(idx);     
    }
    else
    {
        /* Check if the current frame is enabled */
        if(idx == bap_telephony_appl_frame_getEnabledFlag())
        {
            /* Set OFF parameters*/
            LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_SetFrameOFF > Frame-Id %x currently ON, set OFF \r\n",bap_telephony_appl_frame_getId(idx));
            bap_telephony_appl_frame_setFocusedFrameId(idx,frameStatus.MFL_Assigned.focusedFrameId);
            bap_telephony_appl_frame_setMFLBlocks(idx, frameStatus.MFL_Assigned.MFL_Blocks);
            bap_telephony_appl_frame_setASGResponse(idx,frameStatus.ASG_Response);
            bap_telephony_appl_frame_setFSGRequest(idx,FSG_Request_ReqVisOFF);
            
            /* Update frame state and start request */
            bap_telephony_appl_frame_setState(idx,FrameState_GoingToOFF);
            bap_telephony_appl_frame_setUpdateFlag(idx);
        }
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_UpdatePrm
 *
 * @brief      Update parameter for the selected frame
 *
 * @param [in]  TELEPHONY_Frame_Idx_T   - selected frame
 *              FramePrms_T             - frame parameter
 *              uint8_t*                - Data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_UpdatePrm(TELEPHONY_Frame_Idx_T idx,FramePrms_T framePrm, uint8_t* data)
{
    /* Update data for Frame-Id 0x01 (Connection Status)*/
    if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Id)
    {
        /* Update Connection status frame parameter*/
        BAP_TELEPHONY_FRAME_ConnectionStatus_UpdatePrm(framePrm,data);
    }

    /* Update data for Frame-Id 0x02 (Recent call list) */
    if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_RECENT_CALLS_Id)
    {
        /* Update frame data */
        BAP_TELEPHONY_FRAME_RecentCalls_UpdatePrm(framePrm,data);    
    }

    /* Update data for Frame-Id 0x03 (Call status) */
    if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_CALL_STATUS_Id)
    {
        /* Update frame data */
        BAP_TELEPHONY_FRAME_CallStatus_UpdatePrm(framePrm,data);    
    }

}

/***************************************************************************//**
 * 
 * @fn          BAP_TELEPHONY_FRAME_ConnectionStatus_SetNetworkStrengthIcon
 * 
 * @brief       Updates the network strength icon in the telephony frame
 *              connection status.
 *
 * @param [in] networkStrength      - The network strength level.
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_ConnectionStatus_SetNetworkStrengthIcon(uint8_t networkStrength)
{
    size_t i;
    size_t entryCount;

    LOG_PRINT(DEBUG_BAP, "BAP_TELEPHONY_FRAME_ConnectionStatus_SetNetworkStrengthIcon > Network Strength Level: %d \r\n", networkStrength);

    /* Reset Network Strength Icon */
    for (i = 0, entryCount = 0; i < ConnectionStatus_NetworkStrengthsLevels; i++)
    {
        memcpy(&(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_NETWORK_STRENGTH_ROW][entryCount]),BAP_TELEPHONY_FRAME_Connection_Status_Network_Strength_Empty_Icon[i],sizeof(BAP_TELEPHONY_FRAME_Connection_Status_Network_Strength_Empty_Icon[i]));
        entryCount += sizeof(BAP_TELEPHONY_FRAME_Connection_Status_Network_Strength_Empty_Icon[i]);
    }

    BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_NETWORK_STRENGTH_ROW][entryCount] = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_LAST_ITEM;

    /* Set Network Strength Icon */
    for (i = 0, entryCount = 0; i < networkStrength; i++)
    {
        memcpy(&(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_NETWORK_STRENGTH_ROW][entryCount]),BAP_TELEPHONY_FRAME_Connection_Status_Network_Strength_Fully_Icon[i],sizeof(BAP_TELEPHONY_FRAME_Connection_Status_Network_Strength_Fully_Icon[i]));
        entryCount += sizeof(BAP_TELEPHONY_FRAME_Connection_Status_Network_Strength_Fully_Icon[i]);
    }
}

/***************************************************************************//**
 * 
 * @fn          BAP_TELEPHONY_FRAME_ConnectionStatus_SetBatteryLevelIcon
 * 
 * @brief       Updates the battery level icon in the telephony frame
 *              connection status.
 *
 * @param [in] networkStrength      - The battery level.
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_ConnectionStatus_SetBatteryLevelIcon(uint8_t batteryLevelValue)
{
    LOG_PRINT(DEBUG_BAP, "BAP_TELEPHONY_FRAME_ConnectionStatus_SetBatteryLevelIcon > Battery Level: %d \r\n", batteryLevelValue);

    memcpy(&(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_ICONS_ROW][FRAME_ID_DEVICE_INFO_BATTERY_ICON_POSITION]),BAP_TELEPHONY_FRAME_Connection_Status_Battery_Level_Icon[batteryLevelValue],sizeof(BAP_TELEPHONY_FRAME_Connection_Status_Battery_Level_Icon[batteryLevelValue]));
}

/***************************************************************************//**
 * 
 * @fn          BAP_TELEPHONY_FRAME_ConnectionStatus_SetBluetoothIcon
 * 
 * @brief       Set the bluetooth icon in the telephony frame connection 
 *              status.
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_ConnectionStatus_SetBluetoothIcon(void)
{
    memcpy(&(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_ICONS_ROW][FRAME_ID_DEVICE_INFO_BLUETOOTH_ICON_POSITION]),BAP_TELEPHONY_FRAME_Connection_Status_Bluetooth_Icon,sizeof(BAP_TELEPHONY_FRAME_Connection_Status_Bluetooth_Icon));
}

/***************************************************************************//**
 * 
 * @fn          BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallIcon
 * 
 * @brief       Set the missed call icon in the telephony frame connection 
 *              status.
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallIcon(void)
{
    char missedCalls;

    /* Only set missed call icon if there are missed calls */
    if((BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.missedCalls > CONNECTION_STATUS_MIN_MISSED_CALLS) 
    && (BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.missedCalls <= CONNECTION_STATUS_MAX_MISSED_CALLS))
    {
        /* Convert missed calls number to char */        
        missedCalls = BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.missedCalls + '0';

        memcpy(&(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_ICONS_ROW][FRAME_ID_DEVICE_INFO_MISSED_CALL_ICON_POSITION]),BAP_TELEPHONY_FRAME_Connection_Status_Missed_Call_Icon, sizeof(BAP_TELEPHONY_FRAME_Connection_Status_Missed_Call_Icon));
        memcpy(&(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_ICONS_ROW][FRAME_ID_DEVICE_INFO_MISSED_CALL_CNT_POSITION]),&(missedCalls),sizeof(missedCalls));
    }
    else if(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.missedCalls == CONNECTION_STATUS_MIN_MISSED_CALLS)
    {
        memset(&(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_ICONS_ROW][FRAME_ID_DEVICE_INFO_MISSED_CALL_ICON_POSITION]),0x00, sizeof(BAP_TELEPHONY_FRAME_Connection_Status_Missed_Call_Icon));
        memset(&(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_ICONS_ROW][FRAME_ID_DEVICE_INFO_MISSED_CALL_CNT_POSITION]),0x00,sizeof(missedCalls));        
    }
}

/***************************************************************************//**
 * 
 * @fn          BAP_TELEPHONY_FRAME_ConnectionStatus_SetBluetoothIcon
 * 
 * @brief       Increase missed call counter that will be displayed in the cluster
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_ConnectionStatus_AddMissedCallCounter(uint8_t missedCallCounter)
{
    BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.missedCalls += missedCallCounter;

    if(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.missedCalls > CONNECTION_STATUS_MAX_MISSED_CALLS)
    {
        BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.missedCalls = CONNECTION_STATUS_MAX_MISSED_CALLS;
    }
}

/***************************************************************************//**
 * 
 * @fn          BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallCounter
 * 
 * @brief       Increase missed call counter that will be displayed in the cluster
 *
 * @return      void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallCounter(uint8_t missedCallCounter)
{
    if(missedCallCounter > CONNECTION_STATUS_MAX_MISSED_CALLS)
    {
        BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.missedCalls = CONNECTION_STATUS_MAX_MISSED_CALLS;
    }
    else
    {
        BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.missedCalls = missedCallCounter;
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_ConnectionStatus_UpdatePrm
 *
 * @brief      Update connection status data
 *
 * @param [in]  FramePrms_T - frame parameter
 *              uint8_t*    - Data
 *
 * @return     void
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_ConnectionStatus_UpdatePrm(FramePrms_T framePrm, uint8_t *data)
{
    bool_t                  connectionSts = false;
    uint8_t                 missedCalls;
    uint8_t                 rowCount = 0;
    char*                   msgRow;
    char                    missedCallChar;
    bool_t                  ret = false;

    if(framePrm < Frame_NumPrms)
    {
        switch (framePrm)
        {
            case Frame_ConnectionSts:
                /* Get connection sts */
                Shadow_Client_Storage_Get(SHADOW_PhoneRepetition_ConnectionStatus, (uint8_t *)&connectionSts);

                /* Reset missed calls counter */
                if (connectionSts)
                {
                    BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallCounter(CONNECTION_STATUS_MIN_MISSED_CALLS);
                    BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallIcon();
                }

                if(bap_telephony_appl_frame_isEnabledFlag())
                {
                    if (bap_telephony_appl_frame_getEnabledFlag() != BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx)
                    {
                        /* Put ConnectionStatus in foreground */
                        BAP_TELEPHONY_FRAME_ConnectionStatus_SendData();
                        BAP_TELEPHONY_FRAME_ConnectionStatus_SendStatus();
                    }
                }
                break;

            case Frame_ConnectionStsMsg:
                /* Get connection sts */
                Shadow_Client_Storage_Get(SHADOW_PhoneRepetition_ConnectionStatus, (uint8_t *)&connectionSts);

                // Clean frame data
                for (rowCount = 0; rowCount < FRAME_ID_DEVICE_INFO_NUM_ROWS; rowCount++)
                {
                    strcpy(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[rowCount], FRAME_ID_DEVICE_INFO_EMPTY_ROW);
                }

                // Set initial index
                rowCount = 0;

                // Extract the first row
                msgRow = strtok((char *)data, FRAME_ID_DEVICE_INFO_DELIMITER_TOKEN);

                // Loop through the string to extract all other tokens
                while (msgRow != NULL && (rowCount < FRAME_ID_DEVICE_INFO_NUM_ROWS))
                {
                    // Copy the row
                    strcpy(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[rowCount], msgRow);

                    // Count the obtained element
                    rowCount++;

                    // Extract the next row
                    msgRow = strtok(NULL, FRAME_ID_DEVICE_INFO_DELIMITER_TOKEN);
                }

                if (connectionSts)
                {
                    if(strcmp(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[0], FRAME_ID_DEVICE_INFO_SRC_CARPLAY) &&
                            strcmp(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[0], FRAME_ID_DEVICE_INFO_SRC_ANDROIDAUTO))
                    {
                        uint8_t networkStrength = atoi(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_NETWORK_STRENGTH_ROW]);
                        if (networkStrength >= ConnectionStatus_NetworkStrength_0 && networkStrength <= ConnectionStatus_NetworkStrengthsLevels)
                        {
                            BAP_TELEPHONY_FRAME_ConnectionStatus_SetNetworkStrengthIcon(networkStrength);
                        }

                        uint8_t batteryLevel = atoi(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[FRAME_ID_DEVICE_INFO_CONNECTED_ICONS_ROW]);
                        if (batteryLevel >= ConnectionStatus_BatteryLevel_0 && batteryLevel <= ConnectionStatus_BatteryLevel_5)
                        {
                            BAP_TELEPHONY_FRAME_ConnectionStatus_SetBatteryLevelIcon(batteryLevel);
                        }

                        BAP_TELEPHONY_FRAME_ConnectionStatus_SetBluetoothIcon();

                        BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallIcon();
                    }
                }

                BAP_TELEPHONY_FRAME_ConnectionStatus_SendData();
                ret = true;
                break;

            case Frame_MissedCalls:

                /* Get connection sts */
                Shadow_Client_Storage_Get(SHADOW_PhoneRepetition_ConnectionStatus, (uint8_t *)&connectionSts);

                if(connectionSts)
                {
                    /* Get connection sts */
                    Shadow_Client_Storage_Get(SHADOW_PhoneRepetition_MissedCalls, (uint8_t *)&missedCalls);

                    /* Increment missed calls to counter*/
                    BAP_TELEPHONY_FRAME_ConnectionStatus_AddMissedCallCounter(missedCalls);

                    /* Set missed call icon */
                    BAP_TELEPHONY_FRAME_ConnectionStatus_SetMissedCallIcon();

                    /* Senc connection status data */
                    BAP_TELEPHONY_FRAME_ConnectionStatus_SendData();

                }

                ret = true;

                break;

            default:
                LOG_PRINT(DEBUG_BAP, "BAP_TELEPHONY_FRAME_ConnectionStatus_UpdatePrm > Connection sts frame does not support this parameter: %d \r\n", framePrm);
                break;
        }
    }

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_UpdatePrm
 *
 * @brief      Update selected recent calls frame parameter
 *
 * @param [in]  FramePrms_T - frame parameter
 *              uint8_t*    - Data
 *
 * @return     void
 *
 ******************************************************************************/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_UpdatePrm(FramePrms_T framePrm, uint8_t* data)
{
    bool_t ret = false;

    if(framePrm < Frame_NumPrms)
    {
        switch(framePrm)
        {
            case Frame_RecentCallsFooter:
                // Set footer
                BAP_TELEPHONY_FRAME_RecentCalls_UpdateFooter(data);
                ret = true;
            break;

            case Frame_RecentCallsHeader:
                // Set header
                BAP_TELEPHONY_FRAME_RecentCalls_UpdateHeader(data);
                ret = true;
            break;

            case Frame_RecentCallsList:
                // Set list
                BAP_TELEPHONY_FRAME_RecentCalls_UpdateList(data);
                ret = true;
            break;

            default:
                // Unsupported parameter
                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdatePrm > Recent calls frame does not support this parameter: %d \r\n", framePrm);
            break;
        }
    }

    return ret;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_UpdatePrm
 *
 * @brief      Update selected call status frame parameter
 *
 * @param [in]  FramePrms_T - frame parameter
 *              uint8_t*    - Data
 *              
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_UpdatePrm(FramePrms_T framePrm, uint8_t* data)
{
    if(framePrm < Frame_NumPrms)
    {
        LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdatePrm > framePrm = %d \r\n",framePrm);

        switch(framePrm)
        {
            case Frame_CallSts:
                // Update call status
                BAP_TELEPHONY_FRAME_CallStatus_UpdateCallSts(data[0]);
            break;

            case Frame_CallContactMsg:
                // Set call contact message
                BAP_TELEPHONY_FRAME_CallStatus_UpdateCallContactMsg(data);
            break;

            case Frame_CallStsMsg:
                // Set call status message
                BAP_TELEPHONY_FRAME_CallStatus_UpdateCallStsMsg(data);
            break;

            case Frame_CallOptionsList:
                // Set call options list
                BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList(data);
            break;

            default:
                // Unsupported parameter
                LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdatePrm > Call status frame does not support this parameter: %d \r\n", framePrm);
            break;
        }
    }

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_UpdateCallSts
 *
 * @brief      Update call status from received data
 *
 * @param [in] uint8_t* - Data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_UpdateCallSts(uint8_t data)
{
    bool_t newSts = (bool_t)data;
    bool_t oldSts;

    // Attempt to get access to CallStatus data
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList > Get Call Status semaphore \r\n");
    Semaphore_pend(CallStatusDataSem, BIOS_WAIT_FOREVER);

    oldSts = BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callSts;

    if(newSts != oldSts)
    {
        if(newSts == true)
        {
            /* Send FrameData for CallStatus frame*/
            BAP_TELEPHONY_FRAME_Process_CallStatus_Event(CallStatus_InitialSend);
        }
        else
        {
            /* Check if the cluster was in another tab when the call was done */
            if(callMadeFromAnotherTab)
            {
                callMadeFromAnotherTab = false;
                lastEnabledFrame = BAP_TELEPHONY_FRAME_NO_FRAME_Id;
                /* Send frame status update to return to previous TAB*/
                BAP_TELEPHONY_FRAME_Release();
            }
            else
            {
                /* Send FrameStatus to start displaying Connection Status frame */
                BAP_TELEPHONY_FRAME_ConnectionStatus_SendStatus(); 
            }
        
        }

        BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callSts = newSts;
    }

    // Release access to call status data
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList > Release Call Status semaphore \r\n");
    Semaphore_post(CallStatusDataSem);

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_SendData
 *
 * @brief      Send call status data
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void   BAP_TELEPHONY_FRAME_CallStatus_SendData(void)
{
    ListOperation_T         listOperation;    
    uint8_t                 listElementOnTop;
    ArrayHeaderPrms_T       headerPrms;
    Scrollbar_T             scrollbar;


    /* Set scrollbar*/
    scrollbar.frameId = BAP_TELEPHONY_FRAME_CALL_STATUS_Id;
    scrollbar.attributes = SCROLLBAR_ATTRIBUTES_NOTHING;
    scrollbar.sliderLength = SCROLLBAR_SLIDER_LENGTH_DEFAULT_VALUE;
    scrollbar.sliderPosition = SCROLLBAR_SLIDER_POSITION_TOP_OF_LIST;
    BAP_TELEPHONY_FRAME_UpdateScrollbar(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx, scrollbar);

    /* Send required frame data */
    listElementOnTop = FRAME_DATA_LIST_ELEMENT_ON_TOP_DEFAULT_VALUE;
    listOperation = ListOperation_Unknown; 
    headerPrms = BAP_TELEPHONY_FRAME_GetArrayHeaderPrms(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx);
    BAP_TELEPHONY_FRAME_UpdateStatusData(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx,listOperation,listElementOnTop,headerPrms);
    
    bap_telephony_appl_frame_setUpdateDataFlag(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx);
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_SendStatus
 *
 * @brief      Start call status frame request
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_SendStatus(void)
{
    FrameStatus_T           frameStatus;

    /* Set FrameStatus */
    frameStatus.frameId = BAP_TELEPHONY_FRAME_CALL_STATUS_Id;  
    frameStatus.MFL_Assigned.MFL_Blocks = 0x00;
    frameStatus.FSG_Request = FSG_Request_ReqVisON;
    frameStatus.ASG_Response = ASG_Response_NoResponse;
    // Set FrameStatus parameter for frame
    BAP_TELEPHONY_ASG_Response(frameStatus);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_UpdateCallContactMsg
 *
 * @brief      Update call contact message from received data
 *
 * @param [in] uint8_t* - Data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_UpdateCallContactMsg(uint8_t * data)
{
    Scrollbar_T scrollbar;
    uint8_t listElementOnTop;
    ListOperation_T listOperation; 
    ArrayHeaderPrms_T headerPrms;

    // Attempt to get access to CallStatus data
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList > Get Call Status semaphore \r\n");
    Semaphore_pend(CallStatusDataSem, BIOS_WAIT_FOREVER);

    strcpy((BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callContactMsg),(char *)data);   

    BAP_TELEPHONY_FRAME_Process_CallStatus_Event(CallStatus_InitialSend);

    // Release access to call status data
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList > Release Call Status semaphore \r\n");
    Semaphore_post(CallStatusDataSem);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_UpdateCallContactMsg
 *
 * @brief      Update call status message from received data
 *
 * @param [in] uint8_t* - Data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_UpdateCallStsMsg(uint8_t * data)
{
    Scrollbar_T scrollbar;
    uint8_t listElementOnTop;
    ListOperation_T listOperation; 
    ArrayHeaderPrms_T headerPrms;

    // Attempt to get access to CallStatus data
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList > Get Call Status semaphore \r\n");
    Semaphore_pend(CallStatusDataSem, BIOS_WAIT_FOREVER);

    strcpy(BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callStatusMsg,(char *)data);   

    BAP_TELEPHONY_FRAME_Process_CallStatus_Event(CallStatus_InitialSend);

    // Release access to call status data
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList > Release Call Status semaphore \r\n");
    Semaphore_post(CallStatusDataSem);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_CallStatus_UpdateCallOptionsList
 *
 * @brief      Update call options list from received data
 *
 * @param [in] uint8_t* - Data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList(uint8_t *data)
{
    uint8_t                 i;    
    uint8_t                 rowCount;
    uint8_t                 entryCount;
    char*                   element;
    uint8_t                 optionId;
    uint8_t                 currentNumListElements;
    TELEPHONY_Frame_Idx_T   idx;


    // Attempt to get access to CallStatus data
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList > Get Call Status semaphore \r\n");
    Semaphore_pend(CallStatusDataSem, BIOS_WAIT_FOREVER);

    // Get current number of elements in options list
    currentNumListElements = BAP_TELEPHONY_FRAME_CALL_STATUS_Data.numOptions;

    // Attempt to extract the first element
    element = strtok((char *)data,FRAME_CALL_STATUS_OPTIONS_LIST_DELIMITER_TOKEN);
    rowCount = 0;
    i = 0;

    // Loop through the string to extract all other elements
    while((rowCount < CALL_OPTIONS_LIST_NUM_MAX_ELEMENTS) && (element != NULL))
    {
        // First byte of the extracted element indicates the option id
        optionId = element[0] - '0';            
        element +=1;

        // Copy the option Id
        BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callOptionsList[i].optionId = optionId;

        // Copy the option Name
        strcpy(&(((BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callOptionsList)[i]).optionName),element);

        // Count the obtained element
        rowCount++;
        i++;
        // Extract the next row
        element = strtok(NULL, FRAME_RECENT_CALLS_LIST_DELIMITER_TOKEN);
    }

    // If number of elements changed
    if(rowCount != currentNumListElements)
    {
        // Update the number of elements
        BAP_TELEPHONY_FRAME_CALL_STATUS_Data.numOptions = rowCount;
    }

    BAP_TELEPHONY_FRAME_Process_CallStatus_Event(CallStatus_InitialSend);

    // Release access to call status data
    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList > Release Call Status semaphore \r\n");
    Semaphore_post(CallStatusDataSem);
}


/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_UpdateFooter
 *
 * @brief      Update recent calls footer from received data
 *
 * @param [in] uint8_t* - Data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_UpdateFooter(uint8_t * data)
{
    uint8_t currentNumListElements = BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.numElements;

    // Set footer after the last call element in list
    strcpy(BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[currentNumListElements + 1],(char *)data);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_UpdateHeader
 *
 * @brief      Update recent calls header from received data
 *
 * @param [in] uint8_t* - Data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_UpdateHeader(uint8_t * data)
{
    strcpy((BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[RECENT_CALLS_LIST_HEADER_IDX]),(char *)data);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_RecentCalls_UpdateList
 *
 * @brief      Update recent calls list from received data
 *
 * @param [in] uint8_t* - Data
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_RecentCalls_UpdateList(uint8_t *data)
{
    uint8_t                 rowCount;
    uint8_t                 entryCount;
    char*                   element;
    char                    type[2];
    uint32_t                callType;  
    uint8_t                 i;
    char                    currentFooter[FRAME_DATA_MAX_STRING_SIZE];
    uint8_t                 currentNumListElements;
    TELEPHONY_Frame_Idx_T   idx;

    // Get current number of elements (call elements not including the header and the footer)
    currentNumListElements = BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.numElements;

    // With the current number of elements, get the footer from the designated idx in case
    // we need to update it. The footer position is the next after the last call element
    strcpy(currentFooter,BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[currentNumListElements + 1]);

    // Attempt to extract the first element
    element = strtok((char *)data,FRAME_RECENT_CALLS_LIST_DELIMITER_TOKEN);
    rowCount = 0;
    i = RECENT_CALLS_LIST_FIRST_CALL_IDX;

    // Loop through the string to extract all other elements
    while((rowCount < RECENT_CALLS_LIST_NUM_MAX_ELEMENTS) && (element != NULL))
    {
        // First byte of the extracted element indicates the call type
        memcpy(type,element,1);            
        type[1] = '\0';
        element +=1;

        if(BAP_AUDIO_Utils_StringToInt(&callType, type) == STR_TO_INT_SUCCESS)
        {
            entryCount = 0;
            if(callType < RECENT_CALLS_NUM_TYPES)
            {
                memcpy(&(BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[i][entryCount]),BAP_TELEPHONY_FRAME_Recent_Calls_Type_Icon[callType],sizeof(BAP_TELEPHONY_FRAME_Recent_Calls_Type_Icon[callType]));
                entryCount += sizeof(BAP_TELEPHONY_FRAME_Recent_Calls_Type_Icon[callType]);
            }

            // Copy the row
            strcpy(&(BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[i][entryCount]),element);

            // Count the obtained element
            rowCount++;
            i++;
            // Extract the next row
            element = strtok(NULL, FRAME_RECENT_CALLS_LIST_DELIMITER_TOKEN);
        }
    }

    // If number of elements changed
    if(rowCount != currentNumListElements)
    {
        // Update the number of elements
        BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.numElements = rowCount;
        // Update the same footer but in his new position
        BAP_TELEPHONY_FRAME_RecentCalls_UpdateFooter((uint8_t * )currentFooter);
    }

    /* Get idx of the current enabled frame*/
    idx = bap_telephony_appl_frame_getEnabledFlag();

    /* Check if the recent calls frame is active */
    if(bap_telephony_appl_frame_getId(idx) == BAP_TELEPHONY_FRAME_RECENT_CALLS_Id)
    {
        BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_UpdateDisplayedData);
    }

    LOG_PRINT(DEBUG_BAP,"BAP_TELEPHONY_FRAME_RecentCalls_UpdateList > List updated, numElements = %x \r\n",rowCount);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_STATUS_Opcode_Status_Cbk
 *
 * @brief      Invoke opcode "Status" callback for "FrameStatus"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_STATUS_Opcode_Status_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_FRAME_STATUS_Opcode_Status_Size)
    {
        /* Get parameters*/
        memcpy(&BAP_TELEPHONY_FRAME_STATUS_Opcode_Status_Data,data,length);      
    }

    /* Trigger status message*/
    bap_telephony_appl_setStatusFlag(BAP_TELEPHONY_Property_FRAME_STATUS_Idx);
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_STATUS_Opcode_HeartbeatStatus_Cbk
 *
 * @brief      Invoke opcode "HeartbeatStatus" callback for "FrameStatus"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_STATUS_Opcode_HeartbeatStatus_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_STATIS_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "FrameStatus"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_STATUS_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_DATA_Opcode_GetArray_Cbk
 *
 * @brief      Invoke opcode "GetArray" callback for "FrameData"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_DATA_Opcode_GetArray_Cbk(uint8_t* data, uint16_t length)
{
    uint8_t i = 0;
    TELEPHONY_Frame_Id_T frameId = (TELEPHONY_Frame_Id_T) data[0];

    if(frameId == BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Id)
    {    
        /* Send Frame data (Scrollbar and Displayed data) */
        BAP_TELEPHONY_FRAME_ConnectionStatus_SendData();      
    }
    else if(frameId == BAP_TELEPHONY_FRAME_CALL_STATUS_Id)
    {
        /* Send Frame data (Scrollbar and displayed data) */
        BAP_TELEPHONY_FRAME_Process_CallStatus_Event(CallStatus_InitialSend);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Cbk
 *
 * @brief      Invoke opcode "StatusArray" callback for "FrameData"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Cbk(uint8_t* data, uint16_t length)
{
    if(length <= BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Size)
    {
        /* Get parameters*/
        memcpy(&BAP_TELEPHONY_FRAME_DATA_Opcode_StatusArray_Data,data,length);  

        /* Trigger statusArray message*/
        bap_telephony_appl_array_setStatusArrayFlag(BAP_TELEPHONY_Array_FRAME_DATA_Idx);    
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Set_Array_Data
 *
 * @brief      Set BAP Array data from list as specified in Header
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Set_Array_Data(ArrayHeaderPrms_T * headerPrms, FrameData_StatusArray_T * array)
{
    uint16_t i;
    uint16_t j;
    uint16_t listElementIdx;
    uint8_t elementIdx;
    uint8_t arrElementSize;
    uint8_t listElementAttributes;
    FrameData_SingleEntry_T aux;

    if(array->frameId == BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Id)
    {
        for(i = 0; i < headerPrms->elements; i++)
        {
            /* Set Pos for element */
            array->arrayData.entry[i].pos = i;

            /* Set attributes for element*/
            array->arrayData.entry[i].attributes = 0x80; //visible

            /* Set Type for element */
            array->arrayData.entry[i].type = FrameData_SingleEntry_Type_Unknown;

            /* Set name for element*/
            arrElementSize = strlen(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[i]);
            arrElementSize = (arrElementSize < (FRAME_DATA_MAX_STRING_SIZE)) ? arrElementSize : (FRAME_DATA_MAX_STRING_SIZE);
            array->arrayData.entry[i].name[0] = arrElementSize;
            memcpy((array->arrayData.entry[i].name + 1),BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Data.connectionStatusMsg[i],arrElementSize);
        }
    }

    if(array->frameId == BAP_TELEPHONY_FRAME_RECENT_CALLS_Id)
    {
        if(array->listOperation == ListOperation_Unknown)
        {
            elementIdx = headerPrms->start;

            for(i = 0; i < (headerPrms->elements); i++)
            {
                // Get idx of the recent call list

                listElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(elementIdx);
                listElementAttributes = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementAttributes(elementIdx);

                LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > entry     = %x \r\n",elementIdx);
                LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > j     = %x \r\n",listElementIdx);
                LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > attr  = %x \r\n",listElementAttributes);
                LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > x     = %s \r\n",BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[listElementIdx]);

                /* Set Pos for element */
                array->arrayData.entry[i].pos = elementIdx;

                /* Set attributes for element*/
                array->arrayData.entry[i].attributes = listElementAttributes;

                /* Set Type for element */
                array->arrayData.entry[i].type = FrameData_SingleEntry_Type_Unknown;

                /* Set name for element*/
                arrElementSize = strlen(BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[listElementIdx]);
                arrElementSize = (arrElementSize < (FRAME_DATA_MAX_STRING_SIZE)) ? arrElementSize : (FRAME_DATA_MAX_STRING_SIZE);
                array->arrayData.entry[i].name[0] = arrElementSize;
                memcpy((array->arrayData.entry[i].name + 1),BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[listElementIdx],arrElementSize);
            
                elementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(elementIdx);   
            }
        }
        if((array->listOperation == ListOperation_ListDown) || (array->listOperation == ListOperation_ListUp))
        {
            elementIdx = headerPrms->start;

            LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > start     = %x \r\n",headerPrms->start);
            LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > elements  = %x \r\n",headerPrms->elements);

            for(i = 0; i < (headerPrms->elements);i++)
            {
                /* Get attributes for this element */
                listElementAttributes = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementAttributes(elementIdx);
                
                LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > entry     = %x \r\n",elementIdx);
                LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > attr  = %x \r\n",listElementAttributes);
                
                /* Set Pos for element */
                array->arrayData.entry[i].pos = elementIdx;

                /* Set attributes for element*/
                array->arrayData.entry[i].attributes = listElementAttributes;

                /* Set Type for element */
                array->arrayData.entry[i].type = FrameData_SingleEntry_Type_Unknown;

                if(array->listOperation == ListOperation_ListDown)
                {
                    elementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(elementIdx);            
                }
                else
                {
                    if(BAP_TELEPHONY_FRAME_RecentCalls_List_Get_CurrentCmd() == RecentCalls_MoveToBottom)
                    {
                        listElementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(elementIdx);

                        LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > j     = %x \r\n",listElementIdx);
                        LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > x     = %s \r\n",BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[listElementIdx]);


                        /* Set name for element*/
                        arrElementSize = strlen(BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[listElementIdx]);
                        arrElementSize = (arrElementSize < (FRAME_DATA_MAX_STRING_SIZE)) ? arrElementSize : (FRAME_DATA_MAX_STRING_SIZE);
                        array->arrayData.entry[i].name[0] = arrElementSize;
                        memcpy((array->arrayData.entry[i].name + 1),BAP_TELEPHONY_FRAME_RECENT_CALLS_Data.recentCallsList[listElementIdx],arrElementSize);
                    
                        elementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(elementIdx);   
                    }
                    else
                    {
                        elementIdx = BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(elementIdx);
                                        /* Set Type for element */ 
                    }
                }
            }    

            for(i = 0; i < (headerPrms->elements);i++)
            {
                for(j=i+1; j < (headerPrms->elements);j++)
                {
                    if(array->arrayData.entry[i].pos > array->arrayData.entry[j].pos)
                    {
                        memcpy(&aux,&(array->arrayData.entry[i]),sizeof(FrameData_SingleEntry_T));
                        memcpy(&(array->arrayData.entry[i]),&(array->arrayData.entry[j]),sizeof(FrameData_SingleEntry_T));
                        memcpy(&(array->arrayData.entry[j]),&aux,sizeof(FrameData_SingleEntry_T));
                    }
                }
            }

            array->arrayHeader.start = array->arrayData.entry[0].pos;

        }
    }

    if(array->frameId == BAP_TELEPHONY_FRAME_CALL_STATUS_Id)
    {
        if(array->listOperation == ListOperation_Unknown)
        {
            elementIdx = headerPrms->start;

            // Call contact message

            /* Set Pos for element */
            array->arrayData.entry[elementIdx].pos = elementIdx;

            /* Set Attributes for element */
            array->arrayData.entry[elementIdx].attributes = BAP_TELEPHONY_FRAME_CALL_STATUS_Data.listElementsAttributes[elementIdx];

            /* Set Type for element */
            array->arrayData.entry[elementIdx].type = FrameData_SingleEntry_Type_Unknown;

            /* Set name for element*/
            arrElementSize = strlen(BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callContactMsg);
            arrElementSize = (arrElementSize < (FRAME_DATA_MAX_STRING_SIZE)) ? arrElementSize : (FRAME_DATA_MAX_STRING_SIZE);
            // When setting a BAP array, the first byte is used to indicate the array length in bytes
            array->arrayData.entry[elementIdx].name[FRAME_DATA_ARRAY_NAME_SIZE_INDEX] = arrElementSize;
            // The next bytes are used to set the byte array
            memcpy((array->arrayData.entry[elementIdx].name + FRAME_DATA_ARRAY_NAME_DATA_INITIAL_INDEX),BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callContactMsg,arrElementSize);

            elementIdx++;

            // Call status message

            /* Set Pos for element */
            array->arrayData.entry[elementIdx].pos = elementIdx;

            /* Set Attributes for element */
            array->arrayData.entry[elementIdx].attributes = BAP_TELEPHONY_FRAME_CALL_STATUS_Data.listElementsAttributes[elementIdx];

            /* Set Type for element */
            array->arrayData.entry[elementIdx].type = FrameData_SingleEntry_Type_Unknown;

            /* Set name for element*/
            arrElementSize = strlen(BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callStatusMsg);
            arrElementSize = (arrElementSize < (FRAME_DATA_MAX_STRING_SIZE)) ? arrElementSize : (FRAME_DATA_MAX_STRING_SIZE);
            // When setting a BAP array, the first byte is used to indicate the array length in bytes
            array->arrayData.entry[elementIdx].name[FRAME_DATA_ARRAY_NAME_SIZE_INDEX] = arrElementSize;
            // The next bytes are used to set the byte array
            memcpy((array->arrayData.entry[elementIdx].name + FRAME_DATA_ARRAY_NAME_DATA_INITIAL_INDEX),BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callStatusMsg,arrElementSize);

            elementIdx++;

            // Call options

            for(i = 0; i < CALL_STATUS_OPTIONS_LIST_ELEMENTS; i++)
            {
                /* Set Pos for element */
                array->arrayData.entry[elementIdx].pos = elementIdx;

                /* Set attributes for element*/
                array->arrayData.entry[elementIdx].attributes = BAP_TELEPHONY_FRAME_CALL_STATUS_Data.listElementsAttributes[elementIdx];

                /* Set Type for element */
                array->arrayData.entry[elementIdx].type = FrameData_SingleEntry_Type_Unknown;
            
                /* Set name for element */
                arrElementSize = strlen(BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callOptionsList[i].optionName);
                arrElementSize = (arrElementSize < (FRAME_DATA_MAX_STRING_SIZE)) ? arrElementSize : (FRAME_DATA_MAX_STRING_SIZE);
                array->arrayData.entry[elementIdx].name[FRAME_DATA_ARRAY_NAME_SIZE_INDEX] = arrElementSize;
                memcpy((array->arrayData.entry[elementIdx].name + FRAME_DATA_ARRAY_NAME_DATA_INITIAL_INDEX),BAP_TELEPHONY_FRAME_CALL_STATUS_Data.callOptionsList[i].optionName,arrElementSize);

                elementIdx++;
            }

        }

        if((array->listOperation == ListOperation_ListDown) || (array->listOperation == ListOperation_ListUp))
        {

            elementIdx = headerPrms->start + 1;

            LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > start     = %x \r\n",headerPrms->start);
            LOG_PRINT(DEBUG_BAP,"BAP_FRAME_DATA_Set_Array_Data > elements  = %x \r\n",headerPrms->elements);

            for(i = 0; i < (headerPrms->elements);i++)
            {
                /* Get attributes for this element */
                listElementAttributes = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes(elementIdx);
                                
                /* Set Pos for element */
                array->arrayData.entry[i].pos = elementIdx;

                /* Set attributes for element*/
                array->arrayData.entry[i].attributes = listElementAttributes;

                /* Set Type for element */
                array->arrayData.entry[i].type = FrameData_SingleEntry_Type_Unknown;

                elementIdx = BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx(elementIdx);            
            }    

        }
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Set_Array_Header_Prms
 *
 * @brief      Set all parameters from Array Header
 *
 * @param [in]  ArrayHeader_T*   header - Array header
 * @param [out] ArrayHeaderPrms* headerPrms - Array header parameters
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Set_Array_Header_Prms(ArrayHeader_T* header, ArrayHeaderPrms_T* headerPrms)
{
    /* Set internal parameters to array header */
    BAP_FRAME_DATA_Set_Array_Header_Direction(header,headerPrms->arrayDirection);
    BAP_FRAME_DATA_Set_Array_Header_IdxSize(header,headerPrms->idxSize);
    BAP_FRAME_DATA_Set_Array_Header_UnknownParam(header, headerPrms->unknownParam);
    BAP_FRAME_DATA_Set_Array_Header_PosTransmit(header,headerPrms->posTransmit);
    BAP_FRAME_DATA_Set_Array_Header_Start(header,headerPrms->start);
    BAP_FRAME_DATA_Set_Array_Header_Elements(header,headerPrms->elements );
    BAP_FRAME_DATA_Set_Array_Header_RecordAddress(header,headerPrms->recordAddress);
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Set_Array_Header_Direction
 *
 * @brief      Set ArrayDirection parameter in Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] ArrayDirection_T - Array header direction
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Set_Array_Header_Direction(ArrayHeader_T* header, ArrayDirection_T direction)
{
    /* Set 'Array Direction' parameter to Array Header */
    header->mode &= ~(FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_MASK);
    if(direction == ArrayDirection_Forward)
    {
        header->mode |= (FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_FW << FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_SHIFT);
    }
    else
    {
        header->mode |= (FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_BW << FRAME_DATA_ARRAYHEADER_MODE_ARRAYDIRECTION_SHIFT);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Set_Array_Header_IdxSize
 *
 * @brief      Set Array Idx size parameter in Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] ArrayIndexSize_T - Array idx size
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Set_Array_Header_IdxSize(ArrayHeader_T* header, ArrayIndexSize_T idxSize)
{
    header->mode &= ~(FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_MASK);
    if(idxSize == ArrayIndexSize_16Bits)
    {
        header->mode |= (FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_16BITS << FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_SHIFT);
    }
    else
    {
        header->mode |= (FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_8BITS << FRAME_DATA_ARRAYHEADER_MODE_INDEXSIZE_SHIFT);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Set_Array_Header_UnknownParam
 *
 * @brief      Set Unknown parameter from Array Header. The BAP AUDIO documenta
 *             tion refers the definition of this parameter to another documenta
 *             tion that we don't posess but we know by reverse engineerin that
 *             we need to take this but into account
 *
 * @param [in] ArrayHeader_T* - Array header
 *
 * @return     ArrayIndexSize_T - Array index size
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Set_Array_Header_UnknownParam(ArrayHeader_T* header, bool_t unknownPrm)
{
    header->mode &= ~(FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_MASK);

    if(unknownPrm == true)
    {
        header->mode |= (FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_ENABLE << FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_SHIFT);
    }
    else
    {
        header->mode |= (FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_DISABLE << FRAME_DATA_ARRAYHEADER_MODE_UNKNOWN_PARAM_SHIFT);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Set_Array_Header_PosTransmit
 *
 * @brief      Set PosTransmit parameter from Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] bool_t         - Transmit position with array
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Set_Array_Header_PosTransmit(ArrayHeader_T* header, bool_t posTransmit)
{
    header->mode &= ~(FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_MASK);

    if(posTransmit == true)
    {
        header->mode |= (FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_TRANSMITTED << FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_SHIFT);
    }
    else
    {
        header->mode |= (FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_NOTTRANSMITTED << FRAME_DATA_ARRAYHEADER_MODE_ARRAYPOSITION_SHIFT);
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Set_Array_Header_Start
 *
 * @brief      Set Start parameter to Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] uint16_t       - Start index of array
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Set_Array_Header_Start(ArrayHeader_T* header, uint16_t start)
{
    header->start = start;
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Set_Array_Header_Elements
 *
 * @brief      Set Elements parameter to Array Header
 *
 * @param [in] ArrayHeader_T* - Array header
 * @param [in] uint16_t       - Elements from array
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Set_Array_Header_Elements(ArrayHeader_T* header, uint16_t elements)
{
    header->elements = elements;
}

/***************************************************************************//**
 *
 * @fn         BAP_FRAME_DATA_Set_Array_Header_RecordAdress
 *
 * @brief      Set RecordAdress parameter to Array Header
 *
 * @param [in] ArrayHeader_T*       - Array header
 * @param [in] ArrayRecordAddress_T - RecordAddress
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_FRAME_DATA_Set_Array_Header_RecordAddress(ArrayHeader_T* header, ArrayRecordAddress_T recordAddress)
{
    header->mode &= ~(FRAME_DATA_ARRAYHEADER_MODE_RECORDADRESS_MASK);
    header->mode |= recordAddress;
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_DATA_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "FrameData"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_DATA_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Set_Cbk
 *
 * @brief      Invoke opcode "Set" callback for "FrameDataAck"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Set_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Status_Cbk
 *
 * @brief      Invoke opcode "Status" callback for "FrameDataAck"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Status_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Status" callback for "FrameDataAck"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_FRAME_DATA_ACK_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_SCROLLBAR_Opcode_Get_Cbk
 *
 * @brief      Invoke opcode "Set" callback for "Scrollbar"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_SCROLLBAR_Opcode_Get_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_SCROLLBAR_Opcode_Status_Cbk
 *
 * @brief      Invoke opcode "Status" callback for "Scrollbar"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_SCROLLBAR_Opcode_Status_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_SCROLLBAR_Opcode_Status_Size)
    {
        /* Get parameters*/
        memcpy(&BAP_TELEPHONY_SCROLLBAR_Opcode_Status_Data,data,length);  

        /* Trigger status message*/
        bap_telephony_appl_setStatusFlag(BAP_TELEPHONY_Property_SCROLLBAR_Idx);  
    }
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_SCROLLBAR_Opcode_HeartbeatStatus_Cbk
 *
 * @brief      Invoke opcode "HeartbeatStatus" callback for "Scrollbar"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_SCROLLBAR_Opcode_HeartbeatStatus_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_SCROLLBAR_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "Scrollbar"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_SCROLLBAR_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_LSG_STATUS_Opcode_Set_Cbk
 *
 * @brief      Invoke opcode "Set" callback for "Lsg Status"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_LSG_STATUS_Opcode_Set_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_LSG_STATUS_Opcode_Set_Size)
    {
        /* Set data*/
        BAP_TELEPHONY_LSG_STATUS_Opcode_Set_Data = data[0];

        /* If the cluster is indicating that is alive, set the status message timer*/
        if(data[0] == LSG_STATUS_ALIVE)
        {
            /* Set lsgStatus message timer*/
            LSG_STATUS_Opcode_Status_Timer = LSG_STATUS_OPCODE_STATUS_DELAYED_TIME;
        }
    }     
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_LSG_STATUS_Opcode_Status_Cbk
 *
 * @brief      Invoke opcode "Status" callback for "LsgStatus"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_LSG_STATUS_Opcode_Status_Cbk(uint8_t* data, uint16_t length)
{
    if(length == BAP_TELEPHONY_LSG_STATUS_Opcode_Status_Size)
    {
        /* Set data*/
        BAP_TELEPHONY_LSG_STATUS_Opcode_Status_Data = data[0];

        /* Trigger status message */
        bap_telephony_appl_setStatusFlag(BAP_TELEPHONY_Property_LSG_STATUS_Idx);
    }   
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_LSG_STATUS_Opcode_HeartbeatStatus_Cbk
 *
 * @brief      Invoke opcode "HeartbeatStatus" callback for "LsgStatus"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_LSG_STATUS_Opcode_HeartbeatStatus_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_LSG_STATUS_Opcode_Error_Cbk
 *
 * @brief      Invoke opcode "Error" callback for "LsgStatus"
 *             function
 *
 * @param [in] uint8_t* - Data
 *             uint16_t - Data length
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_LSG_STATUS_Opcode_Error_Cbk(uint8_t* data, uint16_t length)
{

}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_Timer_Task
 *
 * @brief      Timer task to process timed events in BAP TELEPHONY
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_Timer_Task(void)
{
    /* Trigger delayed status message for LsgStatus function*/
    BAP_TELEPHONY_LSG_STATUS_Timer_Task();    
}

/***************************************************************************//**
 *
 * @fn         BAP_TELEPHONY_LSG_STATUS_Timer_Task
 *
 * @brief      Timer task to send delayed status message to the cluster
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void BAP_TELEPHONY_LSG_STATUS_Timer_Task(void)
{
    if(LSG_STATUS_Opcode_Status_Timer > 0)
    {
        LSG_STATUS_Opcode_Status_Timer--;
        if(LSG_STATUS_Opcode_Status_Timer == 0)
        {
            BAP_TELEPHONY_Property_Opcode_Cbk(BAP_TELEPHONY_Property_LSG_STATUS_Idx, Opcode_Status,
                                            &BAP_TELEPHONY_LSG_STATUS_Opcode_Set_Data,
                                            sizeof(BAP_TELEPHONY_LSG_STATUS_Opcode_Set_Data));
        }
    }
}
