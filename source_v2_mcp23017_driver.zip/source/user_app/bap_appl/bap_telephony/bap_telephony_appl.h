/*
 * bap_audio_appl.h
 *
 *  Created on: 20 jul. 2022
 *      Author: lrobles
 */

#ifndef SOURCE_USER_APP_BAP_APPL_BAP_TELEPHONY_BAP_TELEPHONY_APPL_H_
#define SOURCE_USER_APP_BAP_APPL_BAP_TELEPHONY_BAP_TELEPHONY_APPL_H_
/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include <project_def.h>
#include <console.h>
#include <common_definitions.h>

#include <bap.h>
#include <bap_appl.h>
#include <bap_defines.h>
#include <bap_types.h>
#include <bap_telephony_acfg.h>
#include <bap_telephony_defines.h>

#include <xdc/runtime/Error.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*------------------------ BAP UHV LSG exported objects ---------------------- */


static BapRequest_et BAP_TELEPHONY_Map_OpCode_to_Req[NUM_OPCODES] =
{
     /* Opcodes from Property class functions */
     [Opcode_Status]     = {BapReq_Data},

     /* Opcodes from Method class functions */
     [Opcode_Processing] = {BapReq_Processing},
     [Opcode_Result]     = {BapReq_Result},
     [Opcode_Abort]      = {BapReq_Abort},

     /* Opcodes from Array class functions */
     [Opcode_StatusArray]   = {BapReq_Data},
     [Opcode_ChangedArray]  = {BapReq_Changed},
};

static OpCode_T BAP_TELEPHONY_Map_Ind_to_Opcode[] =
{
     [BapInd_Start]          = {Opcode_Start},
     [BapInd_StartResult]    = {Opcode_StartResult},
     [BapInd_Abort]          = {Opcode_Abort},
     [BapInd_Processing_CNF] = {Opcode_Processing},
     [BapInd_DataSet]        = {Opcode_Set},
     [BapInd_DataGet]        = {Opcode_Get},
     [BapInd_DataSetGet]     = {Opcode_SetGet},     
};

/*------------------------ BAP Telephony Exported objects ---------------------- */

/* Network Strength to corresponding icon byte code in UTF-8 */
static uint8_t BAP_TELEPHONY_FRAME_Connection_Status_Network_Strength_Empty_Icon[ConnectionStatus_NetworkStrengthsLevels][CONNECTION_STATUS_ICON_NETWORK_STRENGTH_SIZE] =
{
    [ConnectionStatus_NetworkStrength_0]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_0,
    [ConnectionStatus_NetworkStrength_1]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_1,
    [ConnectionStatus_NetworkStrength_2]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_2,
    [ConnectionStatus_NetworkStrength_3]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_3,
    [ConnectionStatus_NetworkStrength_4]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_EMPTY_LEVEL_4,
};

/* Network Strength to corresponding icon byte code in UTF-8 */
static uint8_t BAP_TELEPHONY_FRAME_Connection_Status_Network_Strength_Fully_Icon[ConnectionStatus_NetworkStrengthsLevels][CONNECTION_STATUS_ICON_NETWORK_STRENGTH_SIZE] =
{
    [ConnectionStatus_NetworkStrength_0]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_0,
    [ConnectionStatus_NetworkStrength_1]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_1,
    [ConnectionStatus_NetworkStrength_2]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_2,
    [ConnectionStatus_NetworkStrength_3]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_3,
    [ConnectionStatus_NetworkStrength_4]   = CONNECTION_STATUS_ICON_NETWORK_STRENGTH_FULLY_LEVEL_4,
};

/* Battery level to corresponding icon byte code in UTF-8 */
static uint8_t BAP_TELEPHONY_FRAME_Connection_Status_Battery_Level_Icon[ConnectionStatus_BatteryLevels][CONNECTION_STATUS_ICON_BATTERY_SIZE] =
{
    [ConnectionStatus_BatteryLevel_0]   = CONNECTION_STATUS_ICON_BATTERY_LEVEL_0,
    [ConnectionStatus_BatteryLevel_1]   = CONNECTION_STATUS_ICON_BATTERY_LEVEL_1,
    [ConnectionStatus_BatteryLevel_2]   = CONNECTION_STATUS_ICON_BATTERY_LEVEL_2,
    [ConnectionStatus_BatteryLevel_3]   = CONNECTION_STATUS_ICON_BATTERY_LEVEL_3,
    [ConnectionStatus_BatteryLevel_4]   = CONNECTION_STATUS_ICON_BATTERY_LEVEL_4,
    [ConnectionStatus_BatteryLevel_5]   = CONNECTION_STATUS_ICON_BATTERY_LEVEL_5,
};

static uint8_t BAP_TELEPHONY_FRAME_Connection_Status_Bluetooth_Icon[CONNECTION_STATUS_ICON_BLUETOOTH_SIZE] = CONNECTION_STATUS_ICON_BLUETOOTH;

static uint8_t BAP_TELEPHONY_FRAME_Connection_Status_Missed_Call_Icon[CONNECTION_STATUS_ICON_MISSED_CALL_SIZE] = CONNECTION_STATUS_ICON_MISSED_CALL;

/* Map call type to the corrspondent icon byte code in UTF-8*/
static uint8_t BAP_TELEPHONY_FRAME_Recent_Calls_Type_Icon[RECENT_CALLS_NUM_TYPES][RECENT_CALLS_TYPE_ICON_SIZE] =
{
    [RECENT_CALLS_TYPE_MISSED]      = RECENT_CALLS_TYPE_ICON_MISSED,
    [RECENT_CALLS_TYPE_INCOMING]    = RECENT_CALLS_TYPE_ICON_INCOMING,
    [RECENT_CALLS_TYPE_OUTGOING]    = RECENT_CALLS_TYPE_ICON_OUTGOING,
};


/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*------------------------ BAP UHV LSG exported function prototypes ---------------------- */

/* BAP TELEPHONY Task functions */
void        BAP_TELEPHONY_Sem_Init                (void);
BapError_et BAP_TELEPHONY_Task                    (void);
BapError_et BAP_TELEPHONY_Property_Init           (void);
void        BAP_TELEPHONY_Property_InitValues     (void);
void        BAP_TELEPHONY_Property_Task           (void);
void        BAP_TELEPHONY_Array_Task              (void);
void        BAP_TELEPHONY_Timer_Task              (void);

/* BAP TELEPHONY Acknowledge function */
void BAP_TELEPHONY_Acknowledge            (fctId_t aFctId, BapAcknowledge_et aeAcknowledge);


/* BAP TELEPHONY Indication functions */
void BAP_TELEPHONY_IndicationVoid         (fctId_t aFctId, BapIndication_et aeIndication);
void BAP_TELEPHONY_IndicationInt8         (fctId_t aFctId, BapIndication_et aeIndication, uint8_t au8Value);
void BAP_TELEPHONY_IndicationByteSequence (fctId_t aFctId, BapIndication_et aeIndication, const volatile_ptr_t apValue, uint16_t au16Length);
void BAP_TELEPHONY_IndicationError        (fctId_t aFctId, BapError_et aeErrorCode);

/* Generic opcode cbk for property functions */
void BAP_TELEPHONY_Property_Opcode_Cbk(TELEPHONY_Fct_Property_Idx_t idx, OpCode_T op, uint8_t * data, uint16_t length);

/* Generic opcode cbk for array functions */
void BAP_TELEPHONY_Array_Opcode_Cbk(TELEPHONY_Fct_Array_Idx_t idx, OpCode_T op, uint8_t * data, uint16_t length);

void    BAP_FRAME_DATA_Set_Array_Header_Prms(ArrayHeader_T* header, ArrayHeaderPrms_T* headerPrms);
void    BAP_FRAME_DATA_Set_Array_Header_Direction(ArrayHeader_T* header, ArrayDirection_T direction);
void    BAP_FRAME_DATA_Set_Array_Header_IdxSize(ArrayHeader_T* header, ArrayIndexSize_T idxSize);
void    BAP_FRAME_DATA_Set_Array_Header_UnknownParam(ArrayHeader_T* header, bool_t unknownParam);
void    BAP_FRAME_DATA_Set_Array_Header_PosTransmit(ArrayHeader_T* header, bool_t posTransmit);
void    BAP_FRAME_DATA_Set_Array_Header_Start(ArrayHeader_T* header, uint16_t start);
void    BAP_FRAME_DATA_Set_Array_Header_Elements(ArrayHeader_T* header, uint16_t elements);
void    BAP_FRAME_DATA_Set_Array_Header_RecordAddress(ArrayHeader_T* header, ArrayRecordAddress_T recordAdress);

ArrayIndexSize_T     BAP_FRAME_DATA_Get_Array_Header_IdxSize(ArrayHeader_T* header);
void                 BAP_FRAME_DATA_Get_Array_Header_Prms(ArrayHeader_T* header, ArrayHeaderPrms_T* headerPrms);
ArrayDirection_T     BAP_FRAME_DATA_Get_Array_Header_Direction(ArrayHeader_T* header);
ArrayIndexSize_T     BAP_FRAME_DATA_Get_Array_Header_IdxSize(ArrayHeader_T* header);
bool_t               BAP_FRAME_DATA_Get_Array_Header_UnknownParam(ArrayHeader_T* header);
bool_t               BAP_FRAME_DATA_Get_Array_Header_PosTransmit(ArrayHeader_T* header);
uint16_t             BAP_FRAME_DATA_Get_Array_Header_Start(ArrayHeader_T* header);
uint16_t             BAP_FRAME_DATA_Get_Array_Header_Elements(ArrayHeader_T* header);
ArrayRecordAddress_T BAP_FRAME_DATA_Get_Array_Header_RecordAddress(ArrayHeader_T* header);

void BAP_FRAME_DATA_Set_Array_Data(ArrayHeaderPrms_T * headerPrms, FrameData_StatusArray_T * array);
void BAP_FRAME_DATA_Serialize_StatusArray_Data(uint8_t * pVar, uint16_t* pLength);
uint16_t BAP_FRAME_DATA_Serialize_ArrayHeader(uint8_t* pVar, ArrayHeader_T* header);
uint16_t BAP_FRAME_DATA_Serialize_ArrayData(uint8_t* pVar, ArrayHeader_T* header, FrameData_Array_T* data);

/*------------------------ BAP Telephony Exported function prototypes ---------------------- */

/* BAP TELEPHONY Frame Task function */
void BAP_TELEPHONY_Frame_Task(void);

/* BAP TELEPHONY Update Frame Status function */
void BAP_TELEPHONY_ASG_Response(FrameStatus_T rcvFrameStatus);

/* BAP TELEPHONY Update Scrollbar function */
void BAP_TELEPHONY_FRAME_UpdateScrollbar(TELEPHONY_Frame_Idx_T idx, Scrollbar_T scrollbar);

/* BAP TELEPHONY Update FrameData functions*/
ArrayHeaderPrms_T BAP_TELEPHONY_FRAME_GetArrayHeaderPrms(TELEPHONY_Frame_Idx_T idx);
void      BAP_TELEPHONY_FRAME_UpdateStatusData(TELEPHONY_Frame_Idx_T idx, ListOperation_T listOperation, 
                                                  uint8_t listElementOnTop, ArrayHeaderPrms_T headerPrms);

/* BAP TELEPHONY Process key event for current frame */
void      BAP_TELEPHONY_ProcessKeyEvent(uint8_t key);

/* BAP TELEPHONY Update frame parameters functions */
void      BAP_TELEPHONY_FRAME_UpdatePrm(TELEPHONY_Frame_Idx_T idx,FramePrms_T framePrm, uint8_t* data);
bool_t    BAP_TELEPHONY_FRAME_ConnectionStatus_UpdatePrm(FramePrms_T framePrm, uint8_t *data);
void      BAP_TELEPHONY_FRAME_ConnectionStatus_SetNetworkStrengthIcon(uint8_t networkStrength);
void      BAP_TELEPHONY_FRAME_ConnectionStatus_SetBatteryLevelIcon(uint8_t batteryLevelValue);
void      BAP_TELEPHONY_FRAME_ConnectionStatus_SetBluetoothIcon();
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_UpdatePrm(FramePrms_T framePrm, uint8_t* data);
void      BAP_TELEPHONY_FRAME_CallStatus_UpdatePrm(FramePrms_T framePrm, uint8_t* data);
void      BAP_TELEPHONY_FRAME_RecentCalls_UpdateFooter(uint8_t * data);
void      BAP_TELEPHONY_FRAME_RecentCalls_UpdateHeader(uint8_t * data);
void      BAP_TELEPHONY_FRAME_RecentCalls_UpdateList(uint8_t *data);
void      BAP_TELEPHONY_FRAME_CallStatus_UpdateCallSts(uint8_t data);
void      BAP_TELEPHONY_FRAME_CallStatus_UpdateCallContactMsg(uint8_t * data);
void      BAP_TELEPHONY_FRAME_CallStatus_UpdateCallStsMsg(uint8_t * data);
void      BAP_TELEPHONY_FRAME_CallStatus_UpdateOptionsList(uint8_t * data);

/* BAP TELEPHONY Process update command for recent calls list */
void      BAP_TELEPHONY_FRAME_Process_RecentCalls_Event(RecentCalls_UpdateCmd_T cmd);

/* ----------------- BAP TELEPHONY Recent calls list helper functions ---------------------------- */

/* BAP TELEPHONY Get FrameData parameters for Recent calls list update command */
ListOperation_T BAP_TELEPHONY_FRAME_RecentCalls_Get_ListOperation(RecentCalls_UpdateCmd_T cmd);
ArrayHeaderPrms_T BAP_TELEPHONY_FRAME_RecentCalls_Get_ArrayHeaderPrms(RecentCalls_UpdateCmd_T cmd);
ArrayRecordAddress_T BAP_TELEPHONY_FRAME_RecentCalls_Get_RecordAdress(RecentCalls_UpdateCmd_T cmd);
uint16_t BAP_TELEPHONY_FRAME_RecentCalls_Get_Start(RecentCalls_UpdateCmd_T cmd);
uint16_t BAP_TELEPHONY_FRAME_RecentCalls_Get_Elements(RecentCalls_UpdateCmd_T cmd);

/* BAP_TELEPHONY Function used to update buffer attributes for the given command*/
void BAP_TELEPHONY_FRAME_RecentCalls_UpdateAttributes(RecentCalls_UpdateCmd_T cmd);

/* BAP TELEPHONY Function used to make a call from an elements */
void BAP_TELEPHONY_FRAME_RecentCalls_CallSelectedContact(void);

/* BAP TELEPHONY Function used to check if needs to update Top element*/
bool_t BAP_TELEPHONY_FRAME_RecentCalls_UpdateTop(void);
bool_t BAP_TELEPHONY_FRAME_RecentCalls_UpdateBottom(void);


/* BAP TELEPHONY Functions used to handle Recent calls buffer data */
void      BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Clear(void);
void      BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Init(void);
void      BAP_TELEPHONY_FRAME_RecentCalls_Buffer_InitToBottom(void);
void      BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Print(void);
uint8_t   BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_SelectedElementIdx(void);
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_SelectedElementIdx(uint8_t buffer_sel_idx);
uint8_t   BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_TopElementIdx(void);
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_TopElementIdx(uint8_t buffer_top_idx);
uint8_t   BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NumElements(void);
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_NumElements(uint8_t num_elements);
uint8_t   BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementIdx(uint8_t buffer_idx);
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementIdx(uint8_t buffer_idx, uint8_t list_idx);
uint8_t   BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_ListElementAttributes(uint8_t buffer_idx);
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Set_ListElementAttributes(uint8_t buffer_idx, uint8_t attr);
uint8_t   BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_NextElementIdx(uint8_t buffer_idx);
uint8_t   BAP_TELEPHONY_FRAME_RecentCalls_Buffer_Get_PrevElementIdx(uint8_t buffer_idx);
uint8_t   BAP_TELEPHONY_FRAME_RecentCalls_Buffer_ClockDistance(uint8_t fromIdx, uint8_t toIdx, uint8_t len);
uint8_t   BAP_TELEPHONY_FRAME_RecentCalls_Buffer_AntiClockDistance(uint8_t fromIdx, uint8_t toIdx, uint8_t len);

/* BAP TELEPHONY Functions used to handle Recent calls list data */
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NumElements(void);
bool_t BAP_TELEPHONY_FRAME_RecentCalls_List_Set_NumElements(uint8_t num_elements);
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_SelectedElementIdx(void);
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_TopElementIdx(void);
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_NextElementIdx(uint8_t listElementIdx);
uint8_t BAP_TELEPHONY_FRAME_RecentCalls_List_Get_PrevElementIdx(uint8_t listElementIdx);
RecentCalls_UpdateCmd_T BAP_TELEPHONY_FRAME_RecentCalls_List_Get_CurrentCmd(void);
void BAP_TELEPHONY_FRAME_RecentCalls_List_Set_CurrentCmd(RecentCalls_UpdateCmd_T cmd);
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_List_First_Element_Selected(void);
bool_t    BAP_TELEPHONY_FRAME_RecentCalls_List_Last_Element_Selected(void);

/* ----------------- BAP TELEPHONY Call Status list helper functions ---------------------------- */

/* BAP TELEPHONY Get FrameData parameters for Call status list update command */
ListOperation_T BAP_TELEPHONY_FRAME_CallStatus_Get_ListOperation(CallStatus_Update_Cmd_T cmd);
ArrayHeaderPrms_T BAP_TELEPHONY_FRAME_CallStatus_Get_ArrayHeaderPrms(CallStatus_Update_Cmd_T cmd);
ArrayRecordAddress_T BAP_TELEPHONY_FRAME_CallStatus_Get_RecordAdress(CallStatus_Update_Cmd_T cmd);
uint16_t BAP_TELEPHONY_FRAME_CallStatus_Get_Start(CallStatus_Update_Cmd_T cmd);
uint16_t BAP_TELEPHONY_FRAME_CallStatus_Get_Elements(CallStatus_Update_Cmd_T cmd);

/* BAP TELEPHONY Functions used to handle CallStatus buffer data */
void      BAP_TELEPHONY_FRAME_CallStatus_Buffer_Clear(void);
void      BAP_TELEPHONY_FRAME_CallStatus_Buffer_Init(void);
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_SelectedElementIdx(void);
bool_t    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_SelectedElementIdx(uint8_t buffer_sel_idx);
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_TopElementIdx(void);
bool_t    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_TopElementIdx(uint8_t buffer_top_idx);
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NumElements(void);
bool_t    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_NumElements(uint8_t num_elements);
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementIdx(uint8_t buffer_idx);
bool_t    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementIdx(uint8_t buffer_idx, uint8_t list_idx);
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_ListElementAttributes(uint8_t buffer_idx);
bool_t    BAP_TELEPHONY_FRAME_CallStatus_Buffer_Set_ListElementAttributes(uint8_t buffer_idx, uint8_t attr);
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_NextElementIdx(uint8_t buffer_idx);
uint8_t   BAP_TELEPHONY_FRAME_CallStatus_Buffer_Get_PrevElementIdx(uint8_t buffer_idx);

CallStatus_Update_Cmd_T BAP_TELEPHONY_FRAME_CallStatus_List_Get_CurrentCmd(void);
void BAP_TELEPHONY_FRAME_CallStatus_List_Set_CurrentCmd(CallStatus_Update_Cmd_T cmd);

bool_t    BAP_TELEPHONY_FRAME_CallStatus_List_First_Element_Selected(void);
bool_t    BAP_TELEPHONY_FRAME_CallStatus_List_Last_Element_Selected(void);

void BAP_TELEPHONY_FRAME_CallStatus_SelectCallOption(void);

#endif /* SOURCE_USER_APP_BAP_APPL_BAP_TELEPHONY_BAP_TELEPHONY_APPL_H_ */
