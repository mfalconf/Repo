/*===========================================================================*/
/**
 * @file bap_telephony_defines.h
 *
 * BAP Telephony constant definition 
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2023 Mirgor Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
#ifndef SOURCE_USER_APP_BAP_APPL_BAP_TELEPHONY_BAP_TELEPHONY_DEFINES_H_
#define SOURCE_USER_APP_BAP_APPL_BAP_TELEPHONY_BAP_TELEPHONY_DEFINES_H_

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include <bap_telephony/bap_telephony_acfg.h>
#include <bap_defines.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*------------------------ BAP UHV LSG Exported types ---------------------- */

/*
 *
 * Define all opcodes size in a function table
 *
 * To be used by:
 *
 * - DEFINE_OPCODES_SIZE_FOR_ALL_FCT
 *
 */
#undef DEFINE_OPCODES_SIZE_FOR_EACH_FCT
#define DEFINE_OPCODES_SIZE_FOR_EACH_FCT(FCT, OPTYPE, TYPE, SIZE, PARAMETER) BAP_TELEPHONY_##FCT##_##OPTYPE##_Size = SIZE,

/*
 *
 * Define opcodes size for all function in LSG table
 *
 * To be used by:
 *
 * - BAP_TELEPHONY_FUNCTION_TABLE
 *
 */
#define DEFINE_OPCODES_SIZE_FOR_ALL_FCT(LSG,FCT,CLS,ID,OPCODES) OPCODES(DEFINE_OPCODES_SIZE_FOR_EACH_FCT)

typedef enum BAP_TELEPHONY_Opcode_Size_t
{
    BAP_TELEPHONY_FUNCTION_TABLE(DEFINE_OPCODES_SIZE_FOR_ALL_FCT)
}BAP_TELEPHONY_Opcode_Size_T;

/**
 * Named index for ALL the functions in TELEPHONY control device
 */
#define ENUMERATE_TELEPHONY_FUNCTIONS(LSG,FCT,CLS,ID,OPCODES)    BAP_##LSG##_##FCT##_Idx,
typedef enum BAP_TELEPHONY_Fct_Idx_t
{
   BAP_TELEPHONY_FUNCTION_TABLE(ENUMERATE_TELEPHONY_FUNCTIONS)
   BAP_TELEPHONY_NumFcts,
}TELEPHONY_Fct_Idx_T;

/**
 * Named index for PROPERTY functions in TELEPHONY control device
 */
#define ENUMERATE_TELEPHONY_SPECIFIC_PROPERTY_FUNCTIONS(LSG,FCT,CLS,ID, OPCODES)    BAP_##LSG##_Property_##FCT##_Idx,
typedef enum BAP_TELEPHONY_Fct_Property_Idx_t
{
    BAP_TELEPHONY_PROPERTY_TABLE(ENUMERATE_TELEPHONY_SPECIFIC_PROPERTY_FUNCTIONS)
    BAP_TELEPHONY_Property_NumFcts,
}TELEPHONY_Fct_Property_Idx_t;

/**
 * Named index for ARRAY function in TELEPHONY control device
 */
#define ENUMERATE_TELEPHONY_ARRAY_FUNCTIONS(LSG,FCT,CLS,ID,OPCODES) BAP_##LSG##_Array_##FCT##_Idx,
typedef enum BAP_TELEPHONY_Fct_Array_Idx_t
{
   BAP_TELEPHONY_ARRAY_TABLE(ENUMERATE_TELEPHONY_ARRAY_FUNCTIONS)
   BAP_TELEPHONY_Array_NumFcts,
}TELEPHONY_Fct_Array_Idx_t;

/*------------------------ BAP Telephony Exported types ---------------------- */

/**
 * Named index for ALL the frames
 * 
 * To be used by: 
 * - BAP_TELEPHONY_FRAME_TABLE
 * 
 */
#define DEFINE_FRAME_INDEX_TYPE(NAME,ID,DATA)    BAP_TELEPHONY_FRAME_##NAME##_Idx,
typedef enum BAP_TELEPHONY_Frame_Idx_Tag
{
   BAP_TELEPHONY_FRAME_TABLE(DEFINE_FRAME_INDEX_TYPE)
   BAP_TELEPHONY_NumFrames,
}TELEPHONY_Frame_Idx_T;

/**
 * Named id for ALL the frames
 * 
 * To be used by:
 * - BAP_TELEPHONY_FRAME_TABLE
 * 
 */
#define DEFINE_FRAME_ID_TYPE(NAME,ID,DATA)   BAP_TELEPHONY_FRAME_##NAME##_Id = ID,
typedef enum BAP_TELEPHONY_Frame_Id_Tag
{
   BAP_TELEPHONY_FRAME_TABLE(DEFINE_FRAME_ID_TYPE)
}TELEPHONY_Frame_Id_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

#endif /* SOURCE_USER_APP_BAP_APPL_BAP_TELEPHONY_BAP_TELEPHONY_DEFINES_H_ */
