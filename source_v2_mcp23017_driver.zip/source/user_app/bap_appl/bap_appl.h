#ifndef BAP_APPL_H_
#define BAP_APPL_H_
/*===========================================================================*/
/**
 * @file bap_appl.c
 *
 * Function definitions of the BAP Application
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/
/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include <bap_audio/bap_audio_appl.h>
#include <bap_telephony/bap_telephony_appl.h>

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/* Maximum length for string data type */
#define MAX_LEN 512

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern void         Bap_Task_Init(void);
extern BapError_et  Bap_Appl_Init(void);
extern BapError_et  Bap_Appl_Task(void);
extern BapError_et  Bap_Appl_Shutdown(void);

BapError_et BAP_Init_LSG(lsgId_t aLsgId);
BapError_et BAP_Start_LSG(lsgId_t aLsgId);
void BAP_Property_InitValues(lsgId_t aLsgId);
BapError_et BAP_Property_Init(lsgId_t aLsgId);
BapError_et Bap_Shutdown_LSG(lsgId_t aLsgId);



/* Init send routines */
BapError_et BAP_InitSendInt8(lsgId_t aLsgId, fctId_t aFctId,uint8_t *pVar);
BapError_et BAP_InitSendInt16(lsgId_t aLsgId, fctId_t aFctId,uint8_t *pVar);
BapError_et BAP_InitSendInt32(lsgId_t aLsgId, fctId_t aFctId,uint8_t *pVar);
BapError_et BAP_InitSendByteSequence(lsgId_t aLsgId, fctId_t aFctId,uint8_t *pvar,uint8_t length);

/* General send routines for different data types */
BapError_et BAP_SendInt8(lsgId_t aLsgId, fctId_t aFctId, BapRequest_et aeRequest, uint8_t *pVar);
BapError_et BAP_SendInt16(lsgId_t aLsgId, fctId_t aFctId, BapRequest_et aeRequest, uint8_t *pVar);
BapError_et BAP_SendInt32(lsgId_t aLsgId, fctId_t aFctId, BapRequest_et aeRequest, uint8_t *pVar);
BapError_et BAP_SendByteSequence(lsgId_t aLsgId, fctId_t aFctId, BapRequest_et aeRequest, uint8_t *pvar,uint8_t length);

#endif /* BAP_APPL_H_ */

