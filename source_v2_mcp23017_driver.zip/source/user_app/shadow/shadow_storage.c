/*===========================================================================*/
/**
 * @file shadow_storage.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:shadow_storage.c~8:csrc:kok_basa#1 %
 * @version %version:8 %
 * @author  %derived_by:qzvjgd %
 * @date    %date_modified:Wed Sep 17 14:59:23 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2014 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <shadow_storage.h>
#include <shadow_storage_callouts.h>
#include <shadow_storage_cfg.h>
#include <sharedbus_msg_ids.h>
#include <stdbool.h>
#include <console.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <timedate.h>
#include <aswc.h>
#include <external_signals.h>

#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Task.h>


/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/* Size of shadow storage   */
#define SHADOW_SERVER_STORAGE_TOTAL_SIZE        (SHADOW_SERVER_STORAGE_LENGTH_PLUS_1 - 1)
#define SHADOW_CLIENT_STORAGE_TOTAL_SIZE        (SHADOW_CLIENT_STORAGE_LENGTH_PLUS_1 - 1)

/* offset limit of shadow storage   */
#define SHADOW_SERVER_STORAGE_OFFSET_MIN        0
#define SHADOW_SERVER_STORAGE_OFFSET_MAX        (SHADOW_SERVER_STORAGE_TOTAL_SIZE - 1)

#define SHADOW_CLIENT_STORAGE_OFFSET_MIN        0
#define SHADOW_CLIENT_STORAGE_OFFSET_MAX        (SHADOW_CLIENT_STORAGE_TOTAL_SIZE - 1)

#define SHADOW_SERVER_STORAGE_EVENTS_BUFFER_SIZE   2
#define SHADOW_SERVER_STORAGE_EVENTS_NONE_VALUE    0

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
/* Enumeration of NAME_VAR_XXXX necessary for calculate VAR_XXXX_OFFSETT  */
#undef X
#define X(a,b)     aux_NAME_##a, NAME_##a = (aux_NAME_##a-1)+b,
typedef enum aux_shadow_server_storage_Tag
{
   INITIAL_SERVER_VALUE = 0,
   SHADOW_SERVER_STORAGE
   SHADOW_SERVER_STORAGE_LENGTH_PLUS_1
}aux_shadow_server_storage_T;

typedef enum aux_shadow_client_storage_Tag
{
    INITIAL_CLIENT_VALUE = 0,
    SHADOW_CLIENT_STORAGE
    SHADOW_CLIENT_STORAGE_LENGTH_PLUS_1
}aux_shadow_client_storage_T;

/* Enumeration of VAR_XXXX_OFFSET  */
#undef X
#define X(a,b)     a##_OFFSET = NAME_##a-b,
typedef enum shadow_server_storage_offset_Tag
{
   SHADOW_SERVER_STORAGE
}shadow_server_storage_offset_T;

typedef enum shadow_client_storage_offset_Tag
{
   SHADOW_CLIENT_STORAGE
}shadow_client_storage_offset_T;

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
/* Struct for handling the shadow storage  */
typedef struct shadow_storage_Tag
{
   uint16_t offset;
   uint16_t length;
}shadow_storage_T;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/* Offset and length shadow storage  */
#undef X
#define X(a,b)     {a##_OFFSET, b},
static const shadow_storage_T shadow_server_storage_offset[NUM_VAR_SHADOW_SERVER_STORAGE]={SHADOW_SERVER_STORAGE};

static const shadow_storage_T shadow_client_storage_offset[NUM_VAR_SHADOW_CLIENT_STORAGE]={SHADOW_CLIENT_STORAGE};
/* Data shadow storage   */
static uint8_t shadow_server_storage_data[SHADOW_SERVER_STORAGE_TOTAL_SIZE];

static uint8_t shadow_client_storage_data[SHADOW_CLIENT_STORAGE_TOTAL_SIZE];

static uint8_t shadow_client_storage_data_copy[SHADOW_CLIENT_STORAGE_TOTAL_SIZE];

#if(0)
/* Data shadow storage desip   */
static uint8_t    shadow_storage_data_desip[SHADOW_STORAGE_TOTAL_SIZE];
static uint16_t   shadow_storage_length_data_desip = 0;
static uint8_t    shadow_storage_pack_number_desip = 1;
#endif

/* Data shadow storage buffer   */
static uint8_t    shadow_client_storage_data_buf[SHADOW_CLIENT_STORAGE_TOTAL_SIZE];
static uint16_t   shadow_client_storage_length_data_buf = 0;
static uint8_t    shadow_client_storage_pack_number_buf = 1;

/* Flag what indicate if the shadow variables have been changed */
static bool_t  shadow_server_storage_flag_changed = false;

/* Indicates that the shadow storage has at least once received valid data */
static bool_t shadow_server_storage_has_valid_data = false;

static bool_t shadow_client_storage_has_valid_data = false;

/* Array indicating the id of shadow server signals that represent events */
static shadow_server_storage_id_T shadow_server_storage_event_id[] = {SHADOW_PhoneRepetition_SelectedOption};
/* Array indicating the id of event signals that were updated*/
static shadow_server_storage_id_T shadow_server_storage_event_changed[SHADOW_SERVER_STORAGE_EVENTS_BUFFER_SIZE];
/* Idx indicating the events that were updated*/
static uint8_t event_changed_idx = 0;

static Semaphore_Handle shadow_server_sem = NULL;

static Semaphore_Handle shadow_client_sem = NULL;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void shadow_server_storage_set_flag_changed(void);
static void shadow_server_storage_clear_flag_changed(void);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Initialize_Sem
 *
 * @brief      Shadow storage initialize_Sem
 *
 * @details    Initialize the internal semaphore of the module
 *
 * @return     void
 *
 ******************************************************************************/
void Shadow_Server_Storage_Initialize_Sem(void)
{
   shadow_server_sem = Semaphore_create(1, NULL, NULL);
}

/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Initialize
 *
 * @brief      Shadow storage initialize
 *
 * @details
 *
 * @param [in] none
 *
 * @return     void
 *
 ******************************************************************************/
void Shadow_Server_Storage_Initialize(void)
{
   /* Force Update  */
   LOG_PRINT(DEBUG_SHADOW, "Force first shadow update to VIP\r\n");
   Shadow_Server_Storage_Request_Update();
   shadow_server_storage_clear_flag_changed();
}

void Shadow_Client_Storage_Initialize(void)
{
   shadow_client_sem = Semaphore_create(1, NULL, NULL);
   Shadow_Client_Storage_Clear_ALL_Data();
}

/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Clear_ALL_Data
 *
 * @brief      Clear ALL values of a variable that has shadow.
 *
 * @details
 *
 * @param [in] uint8_t var_id
 *             uint8_t *data
 *
 * @return     void
 *
 ******************************************************************************/
void Shadow_Server_Storage_Clear_ALL_Data(void)
{
    /* Get access to resouce */
    Semaphore_pend(shadow_server_sem, BIOS_WAIT_FOREVER);

    memset(&shadow_server_storage_data[0],0x00,sizeof(shadow_server_storage_data));

    /* Release access to resource */
    Semaphore_post(shadow_server_sem);
}

void Shadow_Client_Storage_Clear_ALL_Data(void)
{
    /* Get access to resouce */
    Semaphore_pend(shadow_client_sem, BIOS_WAIT_FOREVER);

    memset(&shadow_client_storage_data[0],0x00,sizeof(shadow_client_storage_data));
    memset(&shadow_client_storage_data_copy[0],0x00,sizeof(shadow_client_storage_data_copy));

    /* Release access to resource */
    Semaphore_post(shadow_client_sem);
}

/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Set
 *
 * @brief      Set value of a variable that has shadow.
 *
 * @details
 *
 * @param [in] uint8_t var_id
 *             uint8_t *data
 *
 * @return     void
 *
 ******************************************************************************/
bool_t Shadow_Server_Storage_Set(uint16_t server_var_id, uint8_t *data)
{
   bool_t successful_set = false;
   uint8_t i = 0;

   if( shadow_server_storage_offset[server_var_id].offset <= SHADOW_SERVER_STORAGE_OFFSET_MAX )
   {
      /* Get access to resouce */
      Semaphore_pend(shadow_server_sem, BIOS_WAIT_FOREVER);

      memcpy(&shadow_server_storage_data[shadow_server_storage_offset[server_var_id].offset],data,shadow_server_storage_offset[server_var_id].length);

      if(data[0] != SHADOW_SERVER_STORAGE_EVENTS_NONE_VALUE)
      {
         for(i = 0; i < sizeof(shadow_server_storage_event_id);i++)
         {
            if(shadow_server_storage_event_id[i] == server_var_id)
            {
               if(event_changed_idx < SHADOW_SERVER_STORAGE_EVENTS_BUFFER_SIZE)
               {
                  shadow_server_storage_event_changed[event_changed_idx] = server_var_id;
                  event_changed_idx++; 
               }
               else
               {
                  LOG_PRINT(DEBUG_SHADOW,"Error with event change. Increase buffer \r\n");
               }
            }
         }
      }

      shadow_server_storage_set_flag_changed();

      successful_set = true;

      /* Release access to resource */
      Semaphore_post(shadow_server_sem);
   }

   return(successful_set);
}

bool_t Shadow_Server_Storage_Get(uint16_t server_var_id, uint8_t *data)
{
   bool_t successful_get = false;

   if( shadow_server_storage_offset[server_var_id].offset <= SHADOW_SERVER_STORAGE_OFFSET_MAX )
   {
      /* Get access to resouce */
      Semaphore_pend(shadow_server_sem, BIOS_WAIT_FOREVER);

      memcpy(data,&shadow_server_storage_data[shadow_server_storage_offset[server_var_id].offset],shadow_server_storage_offset[server_var_id].length);

      successful_get = true;

      /* Release access to resource */
      Semaphore_post(shadow_server_sem);
   }

   return(successful_get);
}


bool_t Shadow_Client_Storage_Get(uint16_t client_var_id, uint8_t *data)
{
   bool_t successful_get = false;

   if( (client_var_id < NUM_VAR_SHADOW_CLIENT_STORAGE))
   {
      /* Get access to resouce */
      Semaphore_pend(shadow_client_sem, BIOS_WAIT_FOREVER);

      memcpy(data,&shadow_client_storage_data[shadow_client_storage_offset[client_var_id].offset],shadow_client_storage_offset[client_var_id].length);

      successful_get = true;

      /* Release access to resource */
      Semaphore_post(shadow_client_sem);
   }

   return(successful_get);
}

void Shadow_Client_Storage_Update_Signals(void)
{
    uint8_t value[SHADOW_CLIENT_STORAGE_TOTAL_SIZE];
    uint16_t i;

    for(i = 0; i < NUM_VAR_SHADOW_CLIENT_STORAGE; i++)
    {
        if(Shadow_Client_Storage_Get(i,&value[0]) == true)
        {
            if(memcmp(&value[0],&shadow_client_storage_data_copy[shadow_client_storage_offset[i].offset],shadow_client_storage_offset[i].length) != 0)
            {
                memcpy(&shadow_client_storage_data_copy[shadow_client_storage_offset[i].offset],&value[0],shadow_client_storage_offset[i].length);
                Shadow_Client_Storage_Callback(i, &value[0]);
            }
        }
    }
}

#if(0)
/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Get
 *
 * @brief      Get value of a variable that has shadow.
 *
 * @details
 *
 * @param [in] uint8_t var_id
 *             uint8_t *data
 *
 * @return     void
 *
 ******************************************************************************/
bool_t Shadow_Storage_Get(uint16_t var_id, uint8_t *data)
{
   bool_t successful_get = false;

   if( (var_id < NUM_VAR_SHADOW_STORAGE) && (true == shadow_storage_has_valid_data) )
   {
      /* Get access to resouce */
      Semaphore_pend(shadow_sem, BIOS_WAIT_FOREVER);

      memcpy(data,&shadow_storage_data[shadow_storage_offset[var_id].offset],shadow_storage_offset[var_id].length);

      successful_get = true;

      /* Release access to resource */
      Semaphore_post(shadow_sem);
   }

   return(successful_get);
}

/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Get_address
 *
 * @brief      Get address of a variable that has shadow.
 *
 * @details
 *
 * @param [in] uint8_t var_id
 *
 * @return     uint32_t
 *
 ******************************************************************************/
void * Shadow_Storage_Get_address(uint16_t var_id)
{
   return((void *)&shadow_storage_data[shadow_storage_offset[var_id].offset]);
}

/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Set_DESIP_to_Buffer
 *
 * @brief      Update shadow_storage vector via DESIP
 *             This function is called when receive the event EVG_UPDATE_SHADOW_STORAGE_AP_VIP
 *
 * @details
 *
 * @param [in] const SAL_Message_T *msg
 *
 * @return     void
 *
 ******************************************************************************/
bool_t Shadow_Storage_Set_DESIP_to_Buffer(const uint8_t * data)
{
   SIP_shadow_storage_T aux_shadow_storage;
   bool_t rx_msg_ok = false;

   /* Load desip data in struct  */
   memcpy(&aux_shadow_storage, data, sizeof(SIP_shadow_storage_T));

   /* Load data in shadow_storage_data_desip */
   memcpy(&shadow_storage_data_desip[shadow_storage_length_data_desip], &aux_shadow_storage.data[0], aux_shadow_storage.length_data);
   shadow_storage_length_data_desip += aux_shadow_storage.length_data;

   if(   (  aux_shadow_storage.total_pack_number == aux_shadow_storage.pack_number ) &&
         (  shadow_storage_pack_number_desip == aux_shadow_storage.pack_number) )
   {
      /* packtization Complete!! */

      if( SHADOW_STORAGE_DESIP_TO_BUFF_SIZE == shadow_storage_length_data_desip )
      {
         /* Copy all data of buffer shadow_storage_data_desip to buffer shadow_storage_data   */
          LOG_PRINT(DEBUG_SHADOW, "Shadow storage from VIP completed!");

         /* Get access to resouce */
         Semaphore_pend(shadow_sem, BIOS_WAIT_FOREVER);

         memcpy(&shadow_storage_data[SHADOW_STORAGE_DESIP_TO_BUFF_OFFSET_MIN], &shadow_storage_data_desip[0], shadow_storage_length_data_desip);

         /* Release access to resource */
         Semaphore_post(shadow_sem);

         rx_msg_ok = true;
		 shadow_storage_has_valid_data = true;
      }
      else
      {
          LOG_PRINT(DEBUG_SHADOW, "Shadow storage from VIP received completed, but size error prevented it to be copied to the AP shadow");
      }

      /* prepare variables for prox message desip */
      shadow_storage_length_data_desip = 0;
      shadow_storage_pack_number_desip = 1;
   }
   else
   {
      if( shadow_storage_pack_number_desip == aux_shadow_storage.pack_number )
      {
         /* partial packetization ok! */
         LOG_PRINT(DEBUG_SHADOW, "Shadow storage from VIP received package %d from %d", shadow_storage_pack_number_desip, aux_shadow_storage.total_pack_number);
         shadow_storage_pack_number_desip++;
      }
      else
      {
         /* packetization fail, all the messages this packetization will be lost */
         LOG_PRINT(DEBUG_SHADOW, "Error receiving shadow storage from VIP");
         shadow_storage_length_data_desip = 0;
         shadow_storage_pack_number_desip = 1;
      }
   }

   return(rx_msg_ok);
}
#endif

/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Receive_Buffer
 *
 * @brief      Update buffer of shadow_storage with data received.
 *
 * @details
 *
 * @param [in] const uint8_t * data
 *
 * @return     bool_t
 *
 ******************************************************************************/
bool_t Shadow_Client_Storage_Receive_Buffer(const uint8_t * data)
{
   SIP_shadow_storage_T aux_shadow_client_storage;
   bool_t rx_msg_ok = false;

   /* Get access to resouce */
   //Semaphore_pend(shadow_sem_a15, BIOS_WAIT_FOREVER);

   /* Load desip data in struct  */
   memcpy(&aux_shadow_client_storage, data, sizeof(SIP_shadow_storage_T));

   LOG_PRINT_SVER(DEBUG_SHADOW,"total_pack_number = %u \n",aux_shadow_client_storage.total_pack_number);
   LOG_PRINT_SVER(DEBUG_SHADOW,"pack_number = %u \n",aux_shadow_client_storage.pack_number);
   LOG_PRINT_SVER(DEBUG_SHADOW,"length_data = %u \n",aux_shadow_client_storage.length_data);


   /* Load data in shadow_storage_data_buf */
   memcpy(&shadow_client_storage_data_buf[shadow_client_storage_length_data_buf], &aux_shadow_client_storage.data[0], aux_shadow_client_storage.length_data);
   shadow_client_storage_length_data_buf += aux_shadow_client_storage.length_data;

   if(   (  aux_shadow_client_storage.total_pack_number == aux_shadow_client_storage.pack_number ) &&
         (  shadow_client_storage_pack_number_buf == aux_shadow_client_storage.pack_number) )
   {
      /* packtization Complete!! */

      if( SHADOW_CLIENT_STORAGE_TOTAL_SIZE == shadow_client_storage_length_data_buf )
      {
         /* Copy all data of buffer shadow_storage_data_buf to buffer shadow_storage_data   */

         memcpy(&shadow_client_storage_data[SHADOW_CLIENT_STORAGE_OFFSET_MIN], &shadow_client_storage_data_buf[0], shadow_client_storage_length_data_buf);

         rx_msg_ok = true;
         shadow_client_storage_has_valid_data = true;
      }

      /* prepare variables for prox message desip */
      shadow_client_storage_length_data_buf = 0;
      shadow_client_storage_pack_number_buf = 1;
   }
   else
   {
      if( shadow_client_storage_pack_number_buf == aux_shadow_client_storage.pack_number )
      {
         /* partial packetization ok! */
         shadow_client_storage_pack_number_buf++;
      }
      else
      {
         /* packetization fail, all the messages this packetization will be lost */
         shadow_client_storage_length_data_buf = 0;
         shadow_client_storage_pack_number_buf = 1;
      }
   }

   /* Release access to resource */
   //Semaphore_post(shadow_sem_a15);

   return(rx_msg_ok);
}

/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Send_Buffer
 *
 * @brief      Send shadow_storage_data vector via DESIP
 *
 * @details
 *
 * @param [in] const SAL_Message_T *msg
 *
 * @return     void
 *
 ******************************************************************************/
void Shadow_Server_Storage_Send_Buffer(void)
{
   SIP_shadow_storage_T aux_shadow_server_storage;

   uint8_t total_pack_num;
   uint8_t pack_num = 1;

   uint16_t length = SHADOW_SERVER_STORAGE_OFFSET_MIN;

   /* Calculate total_pack_num   */
   if( ( SHADOW_SERVER_STORAGE_TOTAL_SIZE % SPI_MAX_SHADOW_STORAGE_DATA_SIZE ) == 0 )
   {
      total_pack_num = SHADOW_SERVER_STORAGE_TOTAL_SIZE / SPI_MAX_SHADOW_STORAGE_DATA_SIZE;
   }
   else
   {
      total_pack_num = ( SHADOW_SERVER_STORAGE_TOTAL_SIZE / SPI_MAX_SHADOW_STORAGE_DATA_SIZE ) + 1;
   }

   /* Get access to resouce */
   Semaphore_pend(shadow_server_sem, BIOS_WAIT_FOREVER);

   /* Send via DESIP the data of shadow_storage_data[]  */
   for( pack_num = 1 ; pack_num <= total_pack_num; pack_num++)
   {
      aux_shadow_server_storage.pack_number        = pack_num;
      aux_shadow_server_storage.total_pack_number  = total_pack_num;
      if( pack_num == total_pack_num )
      {
         aux_shadow_server_storage.length_data        = SHADOW_SERVER_STORAGE_TOTAL_SIZE - ( (total_pack_num - 1)*SPI_MAX_SHADOW_STORAGE_DATA_SIZE );
      }
      else
      {
         aux_shadow_server_storage.length_data        = SPI_MAX_SHADOW_STORAGE_DATA_SIZE;
      }

      memcpy(&aux_shadow_server_storage.data[0], &shadow_server_storage_data[length], sizeof(aux_shadow_server_storage.data));

      //LOG_PRINT(DEBUG_SHADOW, "SHADOW_SERVER_STORAGE_TOTAL_SIZE: %d    pack_num/total_pack:%d/%d\n",SHADOW_SERVER_STORAGE_TOTAL_SIZE,pack_num,total_pack_num);
      //LOG_PRINT(DEBUG_SHADOW, "desip length:%d          partial length:%d\n",aux_shadow_server_storage.length_data,length);

      Shadow_Server_Storage_Send_to_Client(&aux_shadow_server_storage,(aux_shadow_server_storage.length_data + 3));

      length += aux_shadow_server_storage.length_data;
   }

   /* Release access to resource */
   Semaphore_post(shadow_server_sem);

}

/***************************************************************************//**
 *
 * @fn         Shadow_Server_Storage_Send_to_Client
 *
 * @brief      Send shwd_strg via DESIP
 *
 * @param [in] SIP_shadow_storage_T *shwd_strg
 * @param [in] uint8_t length_data
 *
 * @return     none
 *
 ******************************************************************************/
void Shadow_Server_Storage_Send_to_Client( SIP_shadow_storage_T *shwd_server_strg, uint8_t length_data )
{
    SB_Tx_S2C_UPDATE_SHADOW_SERVER_MEMORY(NULL,(uint8_t *)shwd_server_strg,length_data);
}


/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Enable_Update_Is
 *
 * @brief      Return if update buffer shadow_storage_data is enable.
 *
 * @param [in] none
 *
 * @return     bool_t
 *
 ******************************************************************************/
bool_t Shadow_Server_Storage_Enable_Update_Is(void)
{
   return(Shadow_Server_Storage_Flag_Changed_Is());
}

/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Request_Update
 *
 * @brief      Send message via DESIP for request update shadow_storage_data.
 *
 * @param [in] none
 *
 * @return     bool_t
 *
 ******************************************************************************/
void Shadow_Server_Storage_Request_Update(void)
{
   Shadow_Server_Storage_Send_Buffer();
}


/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Update
 *
 * @brief      Update buffer shadow_storage_data only if is enable it.
 *
 * @details
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
void Shadow_Server_Storage_Update(void)
{
   uint8_t i = 0;
   uint8_t reset_value = SHADOW_SERVER_STORAGE_EVENTS_NONE_VALUE;

   if( Shadow_Server_Storage_Enable_Update_Is() )
   {
      shadow_server_storage_clear_flag_changed();
      Shadow_Server_Storage_Request_Update();

      if(event_changed_idx>0)
      {
         Task_sleep(100000 / Clock_tickPeriod); // 100 ms
         for(i = 0; i < event_changed_idx; i++)
         {
            Shadow_Server_Storage_Set(shadow_server_storage_event_changed[i],&reset_value);
         }
         
         shadow_server_storage_clear_flag_changed();
         Shadow_Server_Storage_Request_Update();

         /* Get access to resouce */
         Semaphore_pend(shadow_server_sem, BIOS_WAIT_FOREVER);
         event_changed_idx=0;
         /* Release access to resouce */
         Semaphore_post(shadow_server_sem);
      }
   }
}

/***************************************************************************//**
 *
 * @fn         shadow_storage_Changed_Is
 *
 * @brief      return flag if the shadow variables have been changed
 *
 * @details
 *
 * @param [in] void
 *
 * @return     bool_t
 *
 ******************************************************************************/
bool_t Shadow_Server_Storage_Flag_Changed_Is(void)
{
   return(shadow_server_storage_flag_changed);
}

/***************************************************************************//**
 *
 * @fn         shadow_storage_set_changed
 *
 * @brief      Set flag if the shadow variables have been changed
 *
 * @details
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void shadow_server_storage_set_flag_changed(void)
{
   shadow_server_storage_flag_changed = true;
}

/***************************************************************************//**
 *
 * @fn         shadow_storage_clear_changed
 *
 * @brief      Clear flag if the shadow variables have been changed
 *
 * @details
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
static void shadow_server_storage_clear_flag_changed(void)
{
   shadow_server_storage_flag_changed = false;
}

/***************************************************************************//**
 *
 * @fn         Shadow_Storage_Valid_Data_Is
 *
 * @brief      return flag if the shadow variables have valid data
 *
 * @details
 *
 * @param [in] void
 *
 * @return     bool_t
 *
 ******************************************************************************/
bool_t Shadow_Server_Storage_Valid_Data_Is(void)
{
   return(shadow_server_storage_has_valid_data);
}

bool_t Shadow_Client_Storage_Valid_Data_Is(void)
{
   return(shadow_client_storage_has_valid_data);
}


/*===========================================================================*/
/*!
 * @file shadow_storage.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * Rev 08  17 Sep 2014	  qzvjgd (Gabriel Gavinowich)
 * kok_basa#192730: VIP_RDO: FIBSSW-300: Moved shadow_storage indexes from uint8_t to uint16_t
 *
 * Rev 07 08-Sep-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#192027: VIP_RDO: FIBSSW-488: Change length of offset to uin16_t
 *
 * Rev 06 02-Sep-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#191521: VIP_RDO: FIBSSW-424: Implement valid data in shadow storage
 *
 * Rev 05  29 Aug 2014	  qzvjgd (Gabriel Gavinowich)
 * kok_basa#191328: VIP_RDO: FIBSSW-380: Implement shadow buffer management on coldstart
 *
 * Rev 04 22-Aug-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#190664: VIP_RDO: FIBSSW-392: Add initialization of shadow storage
 *
 * Rev 03 13-Aug-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#189802: VIP_RDO: FIBSSW-384: Improve the shadow storage dual (VIP <-> AP)
 *
 * Rev 2 5-Aug-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#189219: VIP_RDO: FIBSSW-342: Implementation the shadows storage dual (VIP <-> AP).
 *
 * Rev 1 04-Jul-2014  fzdbm3 (Pablo Daniel Folino)
 *   - Created initial file.
 */
/*===========================================================================*/
