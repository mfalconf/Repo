#ifndef SHADOW_STORAGE_H
#   define SHADOW_STORAGE_H
/*===========================================================================*/
/**
 * @file shadow_storage.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:shadow_storage.h~8:incl:kok_basa#1 %
 * @version %version:8 %
 * @author  %derived_by:fzdbm3 %
 * @date    %date_modified:Thu Nov  5 14:16:34 2015 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2014 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup shadow_storage Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <string.h>
#include <xdc/runtime/System.h>

#include "types.h"
#include "source/shared_data/shadow_signals/shadow_storage_acfg.h"
#include "shadow_storage_cfg.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
/* Enumeration of the var Id */
#undef X
#define X(a,b)     a,
typedef enum shadow_server_storage_id_Tag
{
   SHADOW_SERVER_STORAGE
   NUM_VAR_SHADOW_SERVER_STORAGE
}shadow_server_storage_id_T;

typedef enum shadow_client_storage_id_Tag
{
   SHADOW_CLIENT_STORAGE
   NUM_VAR_SHADOW_CLIENT_STORAGE
}shadow_client_storage_id_T;

typedef int8_t (*sig_subscribe_fptr) (uint8_t *value);

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/* Maximum length of data bytes shadow storage  */
#define SPI_MAX_SHADOW_STORAGE_DATA_SIZE     100

/* Update Shadow Storage   */
typedef struct SIP_shadow_storage_Tag
{
   uint8_t  pack_number;                              /* packetization number:         1 - 255 */
   uint8_t  total_pack_number;                        /* total packetization number:   1 - 255 */
   uint8_t  length_data;                              /* length_data each desip message, maximum limit: SPI_MAX_SHADOW_STORAGE_DATA_SIZE  */
   uint8_t  data[SPI_MAX_SHADOW_STORAGE_DATA_SIZE];   /* data[]   */
}SIP_shadow_storage_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern void       Shadow_Server_Storage_Initialize_Sem(void);
extern void       Shadow_Server_Storage_Initialize(void);
extern void       Shadow_Client_Storage_Initialize(void);
extern void       Shadow_Server_Storage_Clear_ALL_Data(void);
extern void       Shadow_Client_Storage_Clear_ALL_Data(void);
extern bool_t     Shadow_Server_Storage_Set(uint16_t server_var_id, uint8_t *data);
extern bool_t     Shadow_Server_Storage_Get(uint16_t client_var_id, uint8_t *data);
extern bool_t     Shadow_Client_Storage_Get(uint16_t client_var_id, uint8_t *data);

#if(0)
extern bool_t     Shadow_Storage_Get(uint16_t var_id, uint8_t *data);
extern void *     Shadow_Storage_Get_address(uint16_t var_id);
extern bool_t     Shadow_Storage_Set_DESIP_to_Buffer(const uint8_t * data);
#endif

extern void       Shadow_Server_Storage_Update(void);
extern bool_t     Shadow_Server_Storage_Enable_Update_Is(void);
extern bool_t     Shadow_Server_Storage_Flag_Changed_Is(void);
extern void       Shadow_Server_Storage_Request_Update(void);
extern void       Shadow_Server_Storage_Send_Buffer(void);
extern void       Shadow_Server_Storage_Send_to_Client( SIP_shadow_storage_T *shwd_server_strg, uint8_t length_data );
extern bool_t     Shadow_Server_Storage_Valid_Data_Is(void);
extern bool_t     Shadow_Client_Storage_Receive_Buffer(const uint8_t * data);
extern void       Shadow_Client_Storage_Update_Signals(void);
extern bool_t     Shadow_Client_Storage_Valid_Data_Is(void);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file shadow_storage.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * Rev 08 05-Nov-2015  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#227317: VIP_RDO: FILBSW-95: $22 $2905 Read - Bluetooth last pairing status
 *
 * Rev 07 26-Oct-2015  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#226235: VIP_RDO: FIXHSW-134: $22 $201E Read - Wake up reasons recording
 *
 * Rev 06  17 Sep 2014	  qzvjgd (Gabriel Gavinowich)
 * kok_basa#192730: VIP_RDO: FIBSSW-300: Moved shadow_storage indexes from uint8_t to uint16_t
 *
 * Rev 05 08-Sep-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#192031: VIP_RDO: FIBSSW-51: Implement Read DTC Snapshot Record ( 19 04 )
 *
 * Rev 04 02-Sep-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#191521: VIP_RDO: FIBSSW-424: Implement valid data in shadow storage
 *
 * Rev 03 22-Aug-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#190664: VIP_RDO: FIBSSW-392: Add initialization of shadow storage
 *
 * Rev 02 13-Aug-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#189802: VIP_RDO: FIBSSW-384: Improve the shadow storage dual (VIP <-> AP)
 *
 * Rev 1 04-Jul-2014  fzdbm3 (Pablo Daniel Folino)
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* SHADOW_STORAGE_H */
