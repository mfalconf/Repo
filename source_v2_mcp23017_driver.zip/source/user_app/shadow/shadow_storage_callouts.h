#ifndef SHADOW_STORAGE_CALLOUTS_H
#   define SHADOW_STORAGE_CALLOUTS_H
/*===========================================================================*/
/**
 * @file shadow_storage_cbk.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:shadow_storage_cbk.h~2:incl:kok_basa#1 %
 * @version %version:2 %
 * @author  %derived_by:fzdbm3 %
 * @date    %date_modified:Fri Aug 22 08:29:08 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2014 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <shadow_storage_cfg.h>
#include <shadow_storage.h>

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/
extern int8_t Shadow_Client_Storage_Callback(uint16_t client_var_id,uint8_t *data);
/* Prototype Signal_xxxxx_Callback */
#undef X
#define X(a,b) extern int8_t _##a##_Callback(uint8_t *data);
SHADOW_CLIENT_STORAGE

/*===========================================================================*/
/*!
 * @file shadow_storage_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * Rev 02 22-Aug-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#190664: VIP_RDO: FIBSSW-392: Add initialization of shadow storage
 *
 * Rev 1 04-Jul-2014  fzdbm3 (Pablo Daniel Folino)
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* SHADOW_STORAGE_CALLOUTS_H */
