#include <standard.h>

#include <shadow_manager.h>
#include <shadow_storage.h>
#include <console.h>

#include <xdc/runtime/Error.h>

#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>


/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static uint8_t stack[0x1000];

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void Shadow_Task_Thread(UArg arg0, UArg arg1);


/*===========================================================================*
 * Function Definitions
 *===========================================================================*/


void Shadow_Task_Init(void)
{
    Error_Block eb;
    Task_Params taskParams;
    Task_Handle task_h;

    LOG_PRINT_INFO(DEBUG_SHADOW, "Shadow task initialization...\n");

    Error_init(&eb);

    Shadow_Server_Storage_Initialize_Sem();

    /* create main thread (interrupts not enabled in main on BIOS) */
    Task_Params_init(&taskParams);
    taskParams.instance->name = "shadow_task";
    taskParams.arg0 = NULL;
    taskParams.arg1 = NULL;
    taskParams.stack = stack;
    taskParams.stackSize = 0x1000;
    taskParams.affinity = APP_CORE_NUM;
    task_h = Task_create(Shadow_Task_Thread, &taskParams, &eb);
    if (NULL == task_h)
    {
       LOG_PRINT_INFO(DEBUG_SHADOW,"Couldn't create Shadow task\n");
    }
    else
    {
       LOG_PRINT_INFO(DEBUG_SHADOW,"Shadow thread created successfully\n");
    }
}


/*
static void Can_Task_Theard_Shutdown(void)
{

}
*/

static void Shadow_Task_Thread(UArg arg0, UArg arg1)
{
    bool_t running = true;

    LOG_PRINT_INFO(DEBUG_SHADOW,"Shadow_Task_Thread entry\n");

    // Init Shadow
    Shadow_Server_Storage_Initialize();

    while(running)
    {
        Task_sleep(100000 / Clock_tickPeriod); // 100 ms

        Shadow_Server_Storage_Update();

        /* TODO: Check why we can't send all threads to sleep. The ipu1 crashes if we try it
         * We should call 
         * running = MN_Keep_Running();
         */
    }

    //Shadow_Task_Theard_Shutdown();
}

