/*===========================================================================*/
/**
 * @file shadow_storage_callouts.c
 *
 * @todo Callouts of micbias module.
 *
 * %full_filespec:shadow_storage_callouts.c~4:csrc:kok_basa#1 %
 * @version %version:4 %
 * @author  %derived_by:fzdbm3 %
 * @date    %date_modified:Fri Aug 22 08:29:20 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Callouts of analog module.
 * 	     This file has the applications specific code for analog.
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <shadow_storage_callouts.h>
#include <stdbool.h>
#include <console.h>

#include <timedate.h>
#include <aswc.h>
#include <external_signals.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <bap_appl.h>
#include <antpwr.h>
#include <micbias.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/* Pointer to function Signal_XXXXX_Callback */
#undef X
#define X(a,b)     &_##a##_Callback,
static sig_subscribe_fptr ClientSignalCallback[NUM_VAR_SHADOW_CLIENT_STORAGE] = {SHADOW_CLIENT_STORAGE};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
 *
 * @fn         Shadow_Client_Storage_Signal_Callback
 *
 * @brief      Call to client signal callback
 *
 * @param [in] uint16_t client_var_id - Client signal ID
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t Shadow_Client_Storage_Callback(uint16_t client_var_id, uint8_t *data)
{
    return (ClientSignalCallback[client_var_id](data));
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_Selected_TimeDate_Callback
 *
 * @brief      Selected_TimeDate signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_Selected_TimeDate_Callback(uint8_t *data){
    TD_TimeDate_T timedate;

    LOG_PRINT(DEBUG_SHADOW,"_Shadow_Desired_TimeDate \n");

    timedate.rtc_year       = data[0];
    timedate.rtc_month      = data[1];
    timedate.rtc_day        = data[2];
    timedate.rtc_hour       = data[3];
    timedate.rtc_minute     = data[4];
    timedate.rtc_sec        = data[5];
    timedate.rtc_hr_mode    = (TD_Hr_Mode_T)data[6];

    LOG_PRINT_INFO(DEBUG_SHADOW,"%d/%d/%d %d:%d:%d   (%d) \n",data[0],data[1],data[2],data[3],data[4],data[5],data[6]);

    TD_SetTimeDatebyHU( &timedate );

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_SWC_Mode_Callback
 *
 * @brief      SWC_Mode signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_SWC_Mode_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_SWC_Mode_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"SWC_Mode = %d \n",data[0]);
    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_SWC_KeyCfg_Callback
 *
 * @brief      SWC_KeyCfg signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_SWC_KeyCfg_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_SWC_KeyCfg_Callback \n");
    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_SWC_KeyCfg_Ch2_Callback
 *
 * @brief      SWC_KeyCfg_Ch2 signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_SWC_KeyCfg_Ch2_Callback(uint8_t *data){
    LOG_PRINT_INFO(DEBUG_SHADOW,"_SHADOW_SWC_KeyCfg_Ch2_Callback \n");
    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_ASWC_Cfg_Rx_Callback
 *
 * @brief      ASWC_Cfg_Rx signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_ASWC_Cfg_Rx_Callback(uint8_t *data){
    LOG_PRINT_INFO(DEBUG_SHADOW,"_SHADOW_ASWC_Cfg_Rx_Callback \n");
    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_ASWC_Cfg_Ch2_Rx_Callback
 *
 * @brief      ASWC_Cfg_Ch2_Rx signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_ASWC_Cfg_Ch2_Rx_Callback(uint8_t *data){
    LOG_PRINT_INFO(DEBUG_SHADOW,"_SHADOW_ASWC_Cfg_Ch2_Rx_Callback \n");
    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_Dimming_Callback
 *
 * @brief      Dimming signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_Dimming_Callback(uint8_t *data){
    LOG_PRINT_INFO(DEBUG_SHADOW, "_SHADOW_Dimming_Callback \n");

    ES_DimmingSetDetectionMode((dimming_mode_t) data[0]);
    ES_DimmingSetNewDuty(data[1]);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_RobertitoSyncStatus_Callback
 *
 * @brief      Robertito Sync Status signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_RobertitoSyncStatus_Callback(uint8_t *data){
    
    LOG_PRINT_INFO(DEBUG_SHADOW, "_SHADOW_Robertito_Callback: %d \n", *data);
    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_CurrentSource_Callback
 *
 * @brief      AudioRepetition_CurrentSource signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_CurrentSource_Callback(uint8_t *data){

    LOG_PRINT(DEBUG_BAP,"_SHADOW_AudioRepetition_CurrentSource_Callback \n");

    BAP_AUDIO_ACTIVE_SOURCE_Update();

    if(data[0] < HU_NUM_SRC)
    {
        LOG_PRINT(DEBUG_BAP,"CurrentSource = %d \n",data[0]);
        BAP_AUDIO_ACTIVE_SOURCE_NAME_Update(data[0]);
        BAP_AUDIO_CURRENT_STATION_INFO_Update();
    }

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_UpdatingMetaData_Callback
 *
 * @brief      AudioRepetition_UpdatingMetaData signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_UpdatingMetaData_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_UpdatingMetaData_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"UpdatingMetaData = %d \n",data[0]);
    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_PlayState_Callback
 *
 * @brief      AudioRepetition_PlayState signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_PlayState_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_AudioPlayState_Callback \n");

    if(data[0] < HU_NUM_PLAY_STATE)
    {
        LOG_PRINT(DEBUG_SHADOW,"PlayState = %d \n",data[0]);
        BAP_AUDIO_MUTE_Update();
    }

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_TunedFrequency_Callback
 *
 * @brief      AudioRepetition_TunedFrequency
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_TunedFrequency_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW__AudioRepetition_TunedFrequency_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"TunedFrequency = %s \n",(char *)data);

    BAP_AUDIO_ACTIVE_SOURCE_Update();
    BAP_AUDIO_CURRENT_STATION_INFO_Update();

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_PresetList_Callback
 *
 * @brief      AudioRepetition_PresetList signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_PresetList_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_PresetList_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"PresetList = %s \n",(char *)data);

    BAP_INFO_LIST_Decode_PresetList(data);
    BAP_AUDIO_ACTIVE_SOURCE_Update();
    BAP_AUDIO_CURRENT_STATION_INFO_Update();

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_PSN_Callback
 *
 * @brief      AudioRepetition_PSN signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_PSN_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_PSN_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"PSN = %s \n",(char *)data);

    BAP_AUDIO_CURRENT_STATION_INFO_Update();

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_RadioText_Callback
 *
 * @brief      AudioRepetition_RadioText signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_RadioText_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_RadioText_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"RadioText = %s \n",(char *)data);

    BAP_AUDIO_CURRENT_STATION_INFO_Update();

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_SongName_Callback
 *
 * @brief      AudioRepetition_SongName signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_SongName_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_SongName_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"SongName = %s \n",(char *)data);

    BAP_AUDIO_CURRENT_STATION_INFO_Update();

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_ArtistName_Callback
 *
 * @brief      AudioRepetition_ArtistName signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_ArtistName_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_ArtistName_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"ArtistName = %s \n",(char *)data);

    BAP_AUDIO_CURRENT_STATION_INFO_Update();

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_AlbumName_Callback
 *
 * @brief      AudioRepetition_AlbumName signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_AlbumName_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_AlbumName_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"AlbumName = %s \n",(char *)data);

    BAP_AUDIO_CURRENT_STATION_INFO_Update();

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_RepeatSts_Callback
 *
 * @brief      AudioRepetition_RepeatSts signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_RepeatSts_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_RepeatSts_Callback \n");

    if(data[0] < HU_NUM_REPEAT_STS)
    {
        LOG_PRINT(DEBUG_SHADOW,"RepeatSts = %d \n",data[0]);
        BAP_AUDIO_SOURCE_STATE_Update();
    }

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_ShuffleSts_Callback
 *
 * @brief      AudioRepetition_ShuffleSts signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_ShuffleSts_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_ShuffleSts_Callback \n");

    if(data[0] < HU_NUM_SHUFFLE_STS)
    {
        LOG_PRINT(DEBUG_SHADOW,"RepeatSts = %d \n",data[0]);
        BAP_AUDIO_SOURCE_STATE_Update();
    }


    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_ConnectionStatus_Callback
 *
 * @brief      PhoneRepetition_ConnectionStatus signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_PhoneRepetition_ConnectionStatus_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_PhoneRepetition_ConnectionStatus_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"ConnectionStatus = %d \n",data[0]);

    BAP_TELEPHONY_FRAME_UpdatePrm(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx, Frame_ConnectionSts, data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_ConnectionStatusMessage_Callback
 *
 * @brief      PhoneRepetition_ConnectionStatusMessage signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_PhoneRepetition_ConnectionStatusMessage_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_PhoneRepetition_ConnectionStatusMessage_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"ConnectionStatusMessage = %s \n",(char *)data);

    BAP_TELEPHONY_FRAME_UpdatePrm(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx, Frame_ConnectionStsMsg, data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_MissedCalls_Callback
 *
 * @brief      PhoneRepetition_MissedCalls signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_PhoneRepetition_MissedCalls_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_PhoneRepetition_MissedCalls_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"MissedCalls = %d \n",data[0]);

    BAP_TELEPHONY_FRAME_UpdatePrm(BAP_TELEPHONY_FRAME_CONNECTION_STATUS_Idx, Frame_MissedCalls, data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_RecentCallsListFooter_Callback
 *
 * @brief      PhoneRepetition_RecentCallsListFooter signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t  _SHADOW_PhoneRepetition_RecentCallsListFooter_Callback(uint8_t *data)
{
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_PhoneRepetition_RecentCallsListFooter_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"RecentsCallsListFooter = %s \n",(char *)data);

    BAP_TELEPHONY_FRAME_UpdatePrm(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, Frame_RecentCallsFooter, data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_RecentCallsList_Callback
 *
 * @brief      PhoneRepetition_RecentCallsList signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t  _SHADOW_PhoneRepetition_RecentCallsList_Callback(uint8_t *data)
{
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_PhoneRepetition_RecentCallsList_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"RecentsCallsList = %s \n",(char *)data);

    BAP_TELEPHONY_FRAME_UpdatePrm(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, Frame_RecentCallsList, data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_RecentCallsListHeader_Callback
 *
 * @brief      PhoneRepetition_RecentCallsListHeader signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t  _SHADOW_PhoneRepetition_RecentCallsListHeader_Callback(uint8_t *data)
{
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_PhoneRepetition_RecentCallsListHeader_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"RecentsCallsListHeader = %s \n",(char *)data);

    BAP_TELEPHONY_FRAME_UpdatePrm(BAP_TELEPHONY_FRAME_RECENT_CALLS_Idx, Frame_RecentCallsHeader, data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_CallSts_Callback
 *
 * @brief      PhoneRepetition_CallSts_ signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_PhoneRepetition_CallSts_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_PhoneRepetition_CallSts_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"CallSts = %d \n",data[0]);

    BAP_TELEPHONY_FRAME_UpdatePrm(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx, Frame_CallSts, data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_CallContactMessage_Callback
 *
 * @brief      PhoneRepetition_CallContactMessage signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_PhoneRepetition_CallContactMessage_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_PhoneRepetition_CallContactMessage_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"CallContactMessage = %s \n",data);
    BAP_TELEPHONY_FRAME_UpdatePrm(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx, Frame_CallContactMsg, data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_CallStsMessage_Callback
 *
 * @brief      PhoneRepetition_CallStsMessage signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_PhoneRepetition_CallStsMessage_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_PhoneRepetition_CallStsMessage_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"CallStsMessage = %s \n",data);

    BAP_TELEPHONY_FRAME_UpdatePrm(BAP_TELEPHONY_FRAME_CALL_STATUS_Idx, Frame_CallStsMsg, data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_PrivacyModeSts_Callback
 *
 * @brief      AudioRepetition_PrivacyModeSts signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_PrivacyModeSts_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_PrivacyModeSts_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"PrivacyModeSts = %d \n",data[0]);
    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_MaxVolume_Callback
 *
 * @brief      AudioRepetition_MaxVolume signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_MaxVolume_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_MaxVolume_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"MaxVolume = %d \n",data[0]);

    BAP_AUDIO_FSG_SETUP_Update(data[0]);

    return 0;
}


/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_CurrentVolume_Callback
 *
 * @brief      AudioRepetition_CurrentVolume signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_CurrentVolume_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_CurrentVolume_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"CurrentVolume = %d \n",data[0]);
    LOG_PRINT(DEBUG_SHADOW,"Changing volume = %d \n",data[1]);

    BAP_AUDIO_CURRENT_VOLUME_Update(data);

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AudioRepetition_MuteSts_Callback
 *
 * @brief      AudioRepetition_MuteSts signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AudioRepetition_MuteSts_Callback(uint8_t *data){
    LOG_PRINT(DEBUG_SHADOW,"_SHADOW_AudioRepetition_MuteSts_Callback \n");
    LOG_PRINT(DEBUG_SHADOW,"MuteSts = %d \n",data[0]);

    BAP_AUDIO_MUTE_Update();

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_AntMicTestStart_Callback
 *
 * @brief      Antennas and mic test signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_AntMicTestStart_Callback(uint8_t *data) {
    LOG_PRINT_INFO(DEBUG_SHADOW, "_SHADOW_AntMicTestStart_Callback \n");

    //reset state machines of mic and antennas
    AntPwr_Run_Test();
    MicBias_Run_Test();

    return 0;
}

/***************************************************************************//**
 *
 * @fn         _SHADOW_PhoneRepetition_CallOptions_Callback
 *
 * @brief      PhoneRepetition CallOptions signal callback
 *
 * @param [in] uint8_t *data -  Client signal data
 *
 * @return     int8_t
 *
 ******************************************************************************/
int8_t _SHADOW_PhoneRepetition_CallOptions_Callback(uint8_t *data) {
    LOG_PRINT(DEBUG_SHADOW, "_SHADOW_PhoneRepetition_CallOptions_Callback \n");
    LOG_PRINT(DEBUG_SHADOW, "%s \n",(char *)data);

    BAP_TELEPHONY_FRAME_CallStatus_UpdatePrm(Frame_CallOptionsList,(char *)data);

    return 0;
}

/*===========================================================================*/
/*!
 * @file shadow_storage_callouts.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * Rev 04 22-Aug-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#190664: VIP_RDO: FIBSSW-392: Add initialization of shadow storage
 *
 * Rev 03 13-Aug-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#189802: VIP_RDO: FIBSSW-384: Improve the shadow storage dual (VIP <-> AP)
 *
 * Rev 2 5-Aug-2014  fzdbm3 (Pablo Daniel Folino)
 * kok_basa#189219: VIP_RDO: FIBSSW-342: Implementation the shadows storage dual (VIP <-> AP).
 *
 * Rev 1 07-Jul-2014  fzdbm3 (Pablo Daniel Folino)
 *   - Created initial file.
 *
 *
 */
/*===========================================================================*/
