#ifndef MICBIAS_H_
#define MICBIAS_H_
/*===========================================================================*/
/**
 * @file MICBIAS.h
 *
 * Function definitions for the Microphone diagnostic module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <stdint.h>

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
typedef enum MicBias_Ctrl_Tag
{
   MIC_BIAS_OFF,
   MIC_BIAS_ON,
}MicBias_Ctrl_T;

typedef enum MicBias_Status_Tag
{
   MIC_OK,
   MIC_OPEN_CIRCUIT,       /* Open                                                     */
   MIC_PLUS_SHORT_TO_MINUS,/* MIC+ short to MIC-, also known as RESISTANCE condition   */
   MIC_PLUS_SHORT_TO_BAT,  /* MIC+ short to BAT                                        */
   MIC_PLUS_SHORT_TO_GND,  /* MIC+ short to GND, also known as Short_To_GND condition  */
   MIC_MINUS_SHORT_TO_BAT, /* MIC- short to BAT                                        */
   MIC_MINUS_SHORT_TO_GND, /* MIC- short to GND, also known as AMPLITUD condition      */
   MIC_NOT_INIT
}MicBias_Status_T;

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
void MicBias_Init (void);
void MicBias_Update (void);
void MicBias_Run_Test (void);
MicBias_Status_T MicBias_Get_Status (void);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file MICBIAS.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 05-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* MICBIAS_H_ */
