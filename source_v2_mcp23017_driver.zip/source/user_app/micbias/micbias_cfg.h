#ifndef MICBIAS_CFG_H
#   define MICBIAS_CFG_H
/*===========================================================================*/
/**
 * @file micbias_cfg.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:micbias_cfg.h~2:incl:kok_basa#1 %
 * @version %version:2 %
 * @author  %derived_by:fzdbm3 %
 * @date    %date_modified:Fri Nov 29 15:26:54 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2013 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * #define Constants
 *===========================================================================*/
#define MAX_VOLTAGE           3300
#define AD_CHANNEL_MIC_P_DIAG    7
#define AD_CHANNEL_MIC_N_DIAG    6

#define MICBIAS_DIAG_ERR_CNT_MAX 3

/*===========================================================================*
 * #define MACROS
 *===========================================================================*/
/*---------------------------------------------------------------------*\
 * Set up mic_diag voltage table
\*---------------------------------------------------------------------*/
/* define under a) MIC+ v_min                            */
/* define under b) MIC+ v_max                            */
/* define under c) MIC- v_min                            */
/* define under d) MIC- v_max                            */
/* define under e) mic_status (MicBias_Status_T)         */

/*    a      b     c     d     e                         */
/* Quint
#define MIC_DIAG_V_TABLE \
    X( 650    ,2199  ,50    ,2600    ,MIC_OK                    )\
    X( 1200   ,1300  ,0     ,49     ,MIC_OPEN_CIRCUIT          )\
    X( 550    ,649   ,550   ,800    ,MIC_PLUS_SHORT_TO_MINUS   )\
    X( 2200   ,2250  ,0     ,49     ,MIC_PLUS_SHORT_TO_BAT     )\
    X( 0      ,49    ,0     ,49     ,MIC_PLUS_SHORT_TO_GND     )\
    X( 2200   ,2250  ,2150  ,2250   ,MIC_MINUS_SHORT_TO_BAT    )\
    X( 1200   ,1300  ,0     ,49     ,MIC_MINUS_SHORT_TO_GND    )\
*/
/* Volkswagen*/
#define MIC_DIAG_V_TABLE \
    X( 801    ,1199  ,100   ,549    ,MIC_OK                    )\
    X( 1200   ,1599  ,0     ,99     ,MIC_OPEN_CIRCUIT          )\
    X( 550    ,800   ,550   ,800    ,MIC_PLUS_SHORT_TO_MINUS   )\
    X( 1600   ,3300  ,0     ,3300   ,MIC_PLUS_SHORT_TO_BAT     )\
    X( 0      ,99    ,0     ,3300   ,MIC_PLUS_SHORT_TO_GND     )\
    X( 0      ,3300  ,1600  ,3300   ,MIC_MINUS_SHORT_TO_BAT    )\
    X( 0      ,3300  ,0     ,99     ,MIC_MINUS_SHORT_TO_GND    )\

/*===========================================================================*
 * Custom Type Declarations
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file micbias_cfg.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 07-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* MICBIAS_CFG_H */
