/*===========================================================================*/
/**
 * @file micbias.c
 *
 * MicBias control interface
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <micbias.h>
#include <micbias_cfg.h>
#include <drv/board/board.h>
#include <comm_protocol.h>
#include <console.h>
#include <conversions.h>
#include <shadow_storage.h>

#include <ti/csl/soc.h>
#include <ti/csl/csl_gpio.h>
#include <ti/csl/hw_types.h>
#include <xdc/runtime/System.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/BIOS.h>
#include <antpwr.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define MIN_AD_COUNTS         0x0
#define MAX_AD_COUNTS         0x03FF

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef enum cs_micbias_tag
{
    CS_MICBIAS_INIT,
    CS_MICBIAS_CHECK_DIAG,
    CS_MICBIAS_ERROR
}cs_micbias_t;

typedef struct MIC_Diag_Tag
{
   uint16_t mic_plus_v_min;
   uint16_t mic_plus_v_max;
   uint16_t mic_minus_v_min;
   uint16_t mic_minus_v_max;
   MicBias_Status_T mic_status;
}MicBias_Diag_T;

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
uint8_t micbias_diag_err_cnt;
cs_micbias_t cs_micbias_diag;
MicBias_Status_T mic_status;
static Semaphore_Handle mic_sem = NULL;

#undef X
#define X(a,b,c,d,e) {a,b,c,d,e},
static MicBias_Diag_T mic_diag[] = {MIC_DIAG_V_TABLE};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
*
* @fn         MicBias_Init
*
* @brief      Initialization function
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void MicBias_Init (void)
{
    GPIOModuleEnable(MICBIAS_CTRL_GPIO_ADDR);

    /* Set pins as output */
    GPIODirModeSet(MICBIAS_CTRL_GPIO_ADDR, MICBIAS_CTRL_GPIO_PIN, GPIO_DIR_OUTPUT);

    /* Put to low so they all start off */
    GPIOPinWrite(MICBIAS_CTRL_GPIO_ADDR, MICBIAS_CTRL_GPIO_PIN, GPIO_PIN_LOW);

    cs_micbias_diag = CS_MICBIAS_INIT;
    mic_status = MIC_NOT_INIT;

    mic_sem = Semaphore_create(1, NULL, NULL);
}

/***************************************************************************//**
*
* @fn         MicBias_Ctrl
*
* @brief      Power up the FMAM antenna
*
* @param [in] enable
*
* @return     None
*
******************************************************************************/
void MicBias_Ctrl (MicBias_Ctrl_T enable)
{
    if(MIC_BIAS_ON == enable)
    {
        GPIOPinWrite(MICBIAS_CTRL_GPIO_ADDR, MICBIAS_CTRL_GPIO_PIN, GPIO_PIN_HIGH);
    }
    else
    {
        GPIOPinWrite(MICBIAS_CTRL_GPIO_ADDR, MICBIAS_CTRL_GPIO_PIN, GPIO_PIN_LOW);
    }
}

/***************************************************************************//**
*
* @fn         MicBias_Update
*
* @brief      Update the antenna diag state
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void MicBias_Update (void)
{
    int i;
    uint32_t value;
    uint32_t mic_plus_diag_voltage;
    uint32_t mic_minus_diag_voltage;
    MicBias_Status_T mic_status_temp;

    Semaphore_pend(mic_sem, BIOS_WAIT_FOREVER);
    switch(cs_micbias_diag)
    {
        case CS_MICBIAS_INIT:
            micbias_diag_err_cnt = 0;
            MicBias_Ctrl(MIC_BIAS_ON);
            cs_micbias_diag = CS_MICBIAS_CHECK_DIAG;
            break;

        case CS_MICBIAS_CHECK_DIAG:
#ifdef IGNORE_MIC_DIAGNOSTIC
            mic_status_temp = MIC_OK;
#else
             value = COMM_Protocol_GetADStatus(AD_CHANNEL_MIC_P_DIAG);
             mic_plus_diag_voltage = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);
             LOG_PRINT_INFO(DEBUG_MICBIAS, "Mic+ value = %d\r\n", value);
             LOG_PRINT_INFO(DEBUG_MICBIAS, "Mic+ voltage = %d\r\n", mic_plus_diag_voltage);

             value = COMM_Protocol_GetADStatus(AD_CHANNEL_MIC_N_DIAG);
             mic_minus_diag_voltage = Scale(value, MIN_AD_COUNTS, MAX_AD_COUNTS, 0, MAX_VOLTAGE);
             LOG_PRINT_INFO(DEBUG_MICBIAS, "Mic- value = %d\r\n", value);
             LOG_PRINT_INFO(DEBUG_MICBIAS, "Mic- voltage = %d\r\n", mic_minus_diag_voltage);

             /* Look for the current mic status */
             for(i=0; i<Num_Elems(mic_diag); i++)
             {
                 if( (mic_plus_diag_voltage  >= mic_diag[i].mic_plus_v_min)  &&
                     (mic_plus_diag_voltage  <= mic_diag[i].mic_plus_v_max)  &&
                     (mic_minus_diag_voltage >= mic_diag[i].mic_minus_v_min) &&
                     (mic_minus_diag_voltage <= mic_diag[i].mic_minus_v_max) )
                 {
                     /* voltage error condition founded */
                     mic_status_temp = mic_diag[i].mic_status;
                     break;
                 }
             }

             if(mic_status_temp != MIC_OK)
             {
                 micbias_diag_err_cnt++;
                 if (micbias_diag_err_cnt >= MICBIAS_DIAG_ERR_CNT_MAX)
                 {
                     MicBias_Ctrl(MIC_BIAS_OFF);
                     cs_micbias_diag = CS_MICBIAS_ERROR;
                     LOG_PRINT_INFO(DEBUG_MICBIAS, "MicBias Error = %d\r\n", mic_status_temp);
                 }
                 else
                 {
                    mic_status_temp = mic_status;
                 }
             }
             else
             {
                 micbias_diag_err_cnt = 0;
             }
#endif

            //if there is a change set the update shadow storage
            if (mic_status != mic_status_temp)
            {
                Shadow_Server_Storage_Set(SHADOW_MicBiasSts, (uint8_t *)&mic_status_temp);
                mic_status = mic_status_temp;
            }
            break;
        case CS_MICBIAS_ERROR:
            break;

        default:
            break;
    }
    Semaphore_post(mic_sem);
    check_AntMicTest_Finished();
}

/***************************************************************************//**
*
* @fn         MicBias_Get_Status
*
* @brief      Return the MicBias status
*
* @param [in] None
*
* @return     MicBias_Status_T
*
******************************************************************************/
MicBias_Status_T MicBias_Get_Status (void)
{
    return (mic_status);
}

/***************************************************************************//**
*
* @fn         MicBias_Run_Test
*
* @brief      The eng app is requesting a new test
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void MicBias_Run_Test (void)
{
    Semaphore_pend(mic_sem, BIOS_WAIT_FOREVER);

    mic_status = MIC_NOT_INIT;
    cs_micbias_diag = CS_MICBIAS_INIT;

    Semaphore_post(mic_sem);
}
