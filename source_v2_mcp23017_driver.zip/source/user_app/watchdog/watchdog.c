/*===========================================================================*/
/**
 * @file WATCHDOG.c
 *
 * Watchdog interface
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include "watchdog.h"
#include "comm_protocol.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/***************************************************************************//**
*
* @fn         WD_Init
*
* @brief      Init function
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void WD_Init (void)
{
    LOG_PRINT_VER(DEBUG_WD, "WD_Init\r\n");
}

/***************************************************************************//**
*
* @fn         WD_Update
*
* @brief      Called every 1000mS to update the watchdog
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void WD_Update (void)
{
    LOG_PRINT_VER(DEBUG_WD, "WD_Update\r\n");
    //COMM_Protocol_KeepAlive(true);
}

/***************************************************************************//**
*
* @fn         WD_Update
*
* @brief      Disable the watchdog in the MSP. USE WITH CARE!
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void WD_Disable (void)
{
    LOG_PRINT_VER(DEBUG_WD, "WD_disable\r\n");
    COMM_Protocol_KeepAlive(false);
}

