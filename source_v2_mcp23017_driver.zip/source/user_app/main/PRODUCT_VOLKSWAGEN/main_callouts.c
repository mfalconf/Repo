/*===========================================================================*/
/**
 * @file main_callouts.c
 *
 * Callout implementations for main.c.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * DESCRIPTION:
 * Callouts functions for the main module.
 *
 * ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <antpwr.h>
#include <aswc.h>
#include <can.h>
#include <bap_appl.h>
#include <dimming.h>
#include <external_signals.h>
#include <micbias.h>
#include <famp_pm.h>
#include <sharedbus_server.h>
#include <shadow_manager.h>
#include <timer_tick.h>
#include <timedate.h>
#include <comm_interface.h>
#include <main_cfg.h>
#include <watchdog.h>
#include <clock_utils.h>
#include <hmi_manager.h>
#include <cpu_report.h>
#include <sar_ram.h>

#include <source/drv/board/board.h>
#include <xdc/std.h>
#include <xdc/runtime/Diags.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Log.h>
#include <xdc/runtime/System.h>

/* package header files */
#include <ti/ipc/Ipc.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/csl/hw_types.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/***************************************************************************//**
 *
 * @fn         MN_Immediate_Initialization
 *
 * @brief      Calls the initialize routines for various modules that must be 
 *             done on BEFORE beginning the power up sequence.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void MN_Immediate_Initialization(void)
{
    Board_Init();
}

/***************************************************************************//**
 *
 * @fn         MN_Save_Cause_Of_Reset
 *
 * @brief      Read RESF register and store it.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void MN_Save_Cause_Of_Reset(void)
{

}

/***************************************************************************//**
 *
 * @fn         MN_Critical_Initialization
 *
 * @brief      Calls the initialize routines for various modules that don't have to
 *             wait for power up.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void MN_Critical_Initialization(void)
{

}

/***************************************************************************//**
 *
 * @fn         MN_Initialize
 *
 * @brief      Calls the initialize routines for various modules.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void MN_Initialize(void)
{
    /* Note for developers: This line won't work every time you build, it is only
       "valid" when this file changes and the respective object is recompiled, but
       it is mainly intended for the automatic compilation in the CI process */
    System_printf("famp_ipu1 build date: %s %s\n", __DATE__, __TIME__);

    /* Spawn a new thread */
    Can_Task_Init();
    Bap_Task_Init();

    /* Spawn a new thread */
    CpuReport_Init();
    HmiManager_init();

    /* Do not spawn a thread */
    sar_ram_init();
    TD_Init();
    DIMMING_Init();
    ES_Init();
    AntPwr_Init();
    ASWC_Init();
    MicBias_Init();
    COMM_Init();
    ClockUtil_Init();

    FAMP_PM_Task_Init();
    TT_Task_Init();

    /* Does not spawn a thread */
    WD_Init(); /* TODO: Why is this so low??? */

    /* Spawn a new thread */
    Shadow_Task_Init();
    SharedBusServer_Task_Init();
}

/***************************************************************************//**
 *
 * @fn         MN_Initialize
 *
 * @brief      Checks if the threads should be runnin or the system is shuting down
 *
 * @param [in] None
 *
 * @return      True: True if the system is running
 *              False: The system is shutting down
 *
 * Note: Be careful with the synchronization, the variables called from this method should be already initialized
 *
 ******************************************************************************/
bool MN_Keep_Running(void)
{
    return FAMP_PM_Is_IpuRunning();
}


/***************************************************************************//**
 *
 * @fn         MN_Power_Begin_Awake_Sequence
 *
 * @brief      Begins power moding functionality to move the radio to a full awake state.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void MN_Power_Begin_Awake_Sequence(void)
{

}

/***************************************************************************//**
 *
 * @fn         MN_Power_Finish_Awake_Sequence
 *
 * @brief      Finishes power moding functionality to move the radio to a full awake state.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void MN_Power_Finish_Awake_Sequence(void)
{

}

/***************************************************************************//**
 *
 * @fn         MN_SAL_Create_Threads
 *
 * @brief      Calls creation routines for all SAL Threads.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void MN_Create_Threads(void)
{

}

/***************************************************************************//**
 *
 * @fn         MN_Start_Os
 *
 * @brief      Start the OS
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
void MN_Start_Os(void)
{
    BIOS_start();
}

/*===========================================================================*/
/*!
 * @file main_callouts.c
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 09-sep-2017 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
