/*===========================================================================*/
/**
 * @file main.c
 *
 * C main startup routine
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "standard.h"
#include "main_callouts.h"
#include <user_app/poc/poc.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
 /***************************************************************************//**
 *
 * @fn         main
 *
 * @brief      Main routine for 200C program. Called by startup code.
 *             This routine never terminates.
 *
 * @param [in] None
 *
 * @return     None
 *
 ******************************************************************************/
int main(void)
{
   /* run any initialization routines before beginning the power up sequeunce */
   MN_Immediate_Initialization();

   POC_Immediate_Initialization();
   
   /*if (Cold_Start())      */
   {                                            
      /* if cold start initialize all initialization data to */
      /* default values, otherwise they contain the values from */
      /* the previous ignition cycle */
      MN_Save_Cause_Of_Reset();
   }

   /* run init routines before beginning the power up sequeunce (after rcopy) */
   MN_Power_Begin_Awake_Sequence();

   /* create threads */
   MN_Create_Threads();

   /* run initialization that don't have to wait for power up */
   MN_Critical_Initialization();

   /* finish regulator on before reading EEPROM */
   MN_Power_Finish_Awake_Sequence();

   /* call initialization routines */
   MN_Initialize();

   POC_Initialize();

   /* Start the OS */
   MN_Start_Os();
   
   return (0);                  /* unused return value */
}

/*===========================================================================*/
/*!
 * @file main.c
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 19-May-2017 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
