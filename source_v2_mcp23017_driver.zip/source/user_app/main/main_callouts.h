#ifndef MAIN_CALLOUTS_H
#   define MAIN_CALLOUTS_H
/*===========================================================================*/
/**
 * @file main_callouts.h
 *
 * Callout function definitions for project main module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/
/**
 * Immediate Initialization
 *
 * Calls the initialize routines for various modules that must be done on BEFORE
 * beginning the power up sequence.
 *
 */
void MN_Immediate_Initialization(void);

/**
 * Read RESF register and store it.
 *
 */
void MN_Save_Cause_Of_Reset(void);

/**
 * Calls the initialize routines for various modules that don't have to
 * wait for power up.
 *
 */
void MN_Critical_Initialization(void);

/**
 * Calls the initialize routines for various modules.
 *
 */
void MN_Initialize(void);

/*
 * Returns
 * True: True if the system is running
 * False: The system is shutting down
 *
 * Note: Be careful with the synchronization, the variables called from this method should be already initialized
 *
 */
bool MN_Keep_Running(void);

/**
 * Begins power moding functionality to move the radio to a full awake state.
 *
 */
void MN_Power_Begin_Awake_Sequence(void);

/**
 * Finishes power moding functionality to move the radio to a full awake state..
 *
 */
void MN_Power_Finish_Awake_Sequence(void);

/**
 * Calls creation routines for all SAL Threads.
 *
 */
void MN_Create_Threads(void);

/**
 * Start the OS
 *
 */
void MN_Start_Os(void);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file main_callouts.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 09-sep-2017 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* MAIN_CALLOUTS_H */
