#ifndef COMM_INTERFACE_H_
#define COMM_INTERFACE_H_
/*===========================================================================*/
/**
 * @file COMM_INTERFACE.h
 *
 * Function definitions for the communication interface module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#define COMM_MSP_POWER_SLAVE_ADDRESS        0x31
#define COMM_PMIC_SLAVE_ADDRESS             0x58
#define COMM_TVP_SLAVE_ADDRESS              0x5C

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define COMM_MSP_TransferI2C(a,b,c,d)   COMM_TransferI2C(COMM_MSP_POWER_SLAVE_ADDRESS, a, b, c, d)
#define COMM_PMIC_TransferI2C(a,b,c,d,e)  COMM_TransferI2C(a, b, c, d, e)

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
int COMM_Init (void);
int COMM_TransferI2C (uint8_t slaveAddr, uint8_t regAddr, uint8_t txDataSize, uint8_t rxDataSize, uint8_t *pBuffer);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file COMM_INTERFACE.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 06-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* COMM_INTERFACE_H_ */
