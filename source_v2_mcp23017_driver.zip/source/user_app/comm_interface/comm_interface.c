/*===========================================================================*/
/**
 * @file COMM_INTERFACE.c
 *
 * I2C communication interface
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <drv/i2c/I2C.h>
#include <drv/i2c/I2C_soc.h>
#include <console.h>
#include <timer_tick.h>
#include "comm_interface.h"

#include <xdc/runtime/System.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>

#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define DEBUG_COMM_INTERFACE                0

#define COMM_I2C_BUFFER_SIZE                256U

/* Instance 0 is I2C1, this is the index in the structure i2cInitCfg in the file I2C_soc.c*/
#define COMM_I2C_INSTANCE                   0x00U

#define COMM_I2C_TIMEOUT                    1000U

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
I2C_Handle comm_handle;
I2C_Transaction comm_i2cTransaction;

uint8_t comm_i2cBuffer[COMM_I2C_BUFFER_SIZE];

static Semaphore_Handle comm_sem = NULL;
/* This is clearly a debug counter, but the issue is so critical that we will left it in case we need the
 * information for debug purposes
 */
static uint32_t comm_error_counter = 0;
/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void comm_restart (void);
static void comm_start (void);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
*
* @fn         comm_reset
*
* @brief      Reset the communication interface.
*             This function is called in such case an error is detected.
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
static void comm_restart (void)
{
    I2C_close(comm_handle);
    LOG_PRINT_ERR(DEBUG_COMM_INTERFACE, "reseting I2C interfase\r\n");
    comm_start();
}

/***************************************************************************//**
*
* @fn         comm_start
*
* @brief      Initialize the communication interface
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
static void comm_start (void)
{
    I2C_Params i2cParams;

    I2C_init();

    /* Default parameters */
    I2C_Params_init(&i2cParams);

    /* Open I2C1 instance */
    comm_handle = I2C_open(COMM_I2C_INSTANCE, &i2cParams);

    if (comm_handle == NULL)
    {
        LOG_PRINT_ERR(DEBUG_COMM_INTERFACE, "failed to open I2C1\n");
        return;
    }

    /* Configure some common transaction parameters now, for example we are always going to use the same buffer */
    /* Common transaction parameters */
    I2C_transactionInit(&comm_i2cTransaction);
    comm_i2cTransaction.writeBuf = comm_i2cBuffer;
    comm_i2cTransaction.readBuf = comm_i2cBuffer;
    comm_i2cTransaction.timeout = COMM_I2C_TIMEOUT;
}

/**************************************************************************//**
*
* @fn         COMM_TransferI2C
*
* @brief      Transfer data using the I2C. The answer is copied in the pBuffer
*
* @param [in] slaveAddr     I2C slave address
* @param [in] regAddr       I2C command address
* @param [in] txDataSize    Size of the data to send
* @param [in] rxDataSize    Size of the data to receive as answer
* @param [in] pBuffer       Data to send. The answer is returned on it.
*
* @return     -1 - Error
              Other - rxDataSize
*
******************************************************************************/
int COMM_TransferI2C (uint8_t slaveAddr, uint8_t regAddr, uint8_t txDataSize,
                      uint8_t rxDataSize, uint8_t *pBuffer)
{
   int ret = -1;

   LOG_PRINT_START_FUNC(DEBUG_COMM_INTERFACE);

   /* Check if the buffer has enough bytes to hold the result plus the '\0'
    * and to hold the txdata*/
   if ((COMM_I2C_BUFFER_SIZE >= rxDataSize) &&
      (COMM_I2C_BUFFER_SIZE > txDataSize) &&
      (NULL != pBuffer)){

      Semaphore_pend(comm_sem, BIOS_WAIT_FOREVER);

      comm_i2cTransaction.slaveAddress = slaveAddr;
      comm_i2cTransaction.writeCount = (1 + txDataSize);
      comm_i2cTransaction.readCount = rxDataSize;

      comm_i2cBuffer[0] = regAddr;
      /* position 0 is the regAddr, if there is more data add it after that */
      memcpy(&comm_i2cBuffer[1], pBuffer, txDataSize);

      #if 0 /*Do not generate unneeded loop*/
      int i;
      for(i = 0; i < comm_i2cTransaction.writeCount; i++){
          LOG_PRINT_SVER(DEBUG_COMM_INTERFACE, "[%d]=%d ", i, comm_i2cBuffer[i]);
      }
      LOG_PRINT_SVER(DEBUG_COMM_INTERFACE, "\r\n");
      #endif

      if((ret = I2C_transfer(comm_handle, &comm_i2cTransaction)) ==
          I2C_STS_SUCCESS){
         #if 0 /*Do not generate unneeded loop*/
         int 1;
         for(i = 0; i < rxDataSize; i++){
            LOG_PRINT_SVER(DEBUG_COMM_INTERFACE, "[%d]=%d ", i, comm_i2cBuffer[i]);
         }
         LOG_PRINT_SVER(DEBUG_COMM_INTERFACE, "\r\n");
         #endif
         /* Not terminated in '\0' !!! */
         memcpy(pBuffer, comm_i2cBuffer, rxDataSize);
         ret = rxDataSize;
         comm_error_counter = 0;
      }
      else{
         LOG_PRINT_ERR(DEBUG_COMM_INTERFACE, "transfer to slave 0x%02x failed: %d\n",
                       comm_i2cTransaction.slaveAddress, ret);
         comm_restart();
         ret = -1;
         comm_error_counter++;
         if (comm_error_counter > 1) {
             LOG_PRINT_ERR(DEBUG_COMM_INTERFACE, " I2C bus error number %d\n", comm_error_counter);
         }
      }
      Semaphore_post(comm_sem);
      /*Delay for MSP data processing*/
      Task_sleep(1000 / Clock_tickPeriod);
   }
   else{
       LOG_PRINT_ERR(DEBUG_COMM_INTERFACE, "Invalid TxSize:%d, RxSize:%d, Buffer:%p\n",
                     txDataSize, rxDataSize, pBuffer);
   }

   return ret;
}

/***************************************************************************//**
*
* @fn         COMM_Init
*
* @brief      Initialize the communication interface and create the local
*             semaphore
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
int COMM_Init (void)
{
    comm_start();

    comm_sem = Semaphore_create(1, NULL, NULL);

    return 0;
}

