/*===========================================================================*/
/**
 * @file COMM_OMICL.c
 *
 * I2C communication pmic
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2023 Mirgor Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

#ifndef SOURCE_USER_APP_COMM_INTERFACE_COMM_PMIC_65919_TYPES_H_
#define SOURCE_USER_APP_COMM_INTERFACE_COMM_PMIC_65919_TYPES_H_

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */

#include "comm_pmic_65919_cfg.h"

#define PMIC_65919_ADDRESS_0 0x40
#define PMIC_65919_ADDRESS_1 0x50

#if defined(PMIC_65919_ADDRESS_0_SELECTED)
    #define PMIC_65919_SLAVE_ADDRESS PMIC_65919_ADDRESS_0
#elif (PMIC_65919_ADDRESS_1_SELECTED)
    #define PMIC_65919_SLAVE_ADDRESS PMIC_65919_ADDRESS_1
#else
    #error "No address selected"
#endif

typedef enum {
    PMIC_65919_PAGE_0 = 0x12,
    PMIC_65919_PAGE_1 = PMIC_65919_SLAVE_ADDRESS | 0x08,
    PMIC_65919_PAGE_2 = PMIC_65919_SLAVE_ADDRESS | 0x09,
    PMIC_65919_PAGE_3 = PMIC_65919_SLAVE_ADDRESS | 0x0A,
    PMIC_65919_PAGE_4 = PMIC_65919_SLAVE_ADDRESS | 0x0B,
    PMIC_65919_NUM_PAGES,
}pmic_65919_page_number_t;

#define PMIC_65919_GPADC_REGISTERS \
        X(SMPS1_FORCE,          PMIC_65919_PAGE_1,      0x22) \
        X(SMPS1_VOLTAGE,        PMIC_65919_PAGE_1,      0x23) \
        X(SMPS3_FORCE,          PMIC_65919_PAGE_1,      0x2E) \
        X(SMPS3_VOLTAGE,        PMIC_65919_PAGE_1,      0x2F) \
        X(GPADC_SW_SELECT,      PMIC_65919_PAGE_2,      0xCD) \
        X(GPADC_CTRL1,          PMIC_65919_PAGE_2,      0xC0) \
        X(GPADC_SW_CONV0_MSB,   PMIC_65919_PAGE_2,      0xCF) \
        X(GPADC_SW_CONV0_LSB,   PMIC_65919_PAGE_2,      0xCE) \
        X(GPADC_INT3_MASK,      PMIC_65919_PAGE_2,      0x1B) \
        X(GPADC_INT3_STATUS,    PMIC_65919_PAGE_2,      0x1A) \
        X(GPADC_TRIM1,          PMIC_65919_PAGE_3,      0xCD) \
        X(GPADC_TRIM2,          PMIC_65919_PAGE_3,      0xCE) \

#define PMIC_65919_GPADC_SIGNALS \
        X(SW_CONV_ENABLE,         7, 1) \
        X(SW_START_CONV0,         4, 1) \
        X(SW_CONV0_SEL,           0, 4) \
        X(GPADC_FORCE,            0, 1) \
        X(SW_CONV0_MSB,           0, 4) \
        X(SW_CONV0_LSB,           0, 8) \
        X(EOC_SW_MASK,            2, 1) \
        X(EOC_SW_STATUS,          2, 1) \

#undef X
#define X(name, slave_address, reg_address)     PMIC_65919_##name##_SLAVE_ADDRESS = slave_address,
typedef enum
{
    PMIC_65919_GPADC_REGISTERS
    NUM_GPADC_SLAVE_SIGNALS
}pmic_65919_gpadc_slave_address_t;

#undef X
#define X(name, slave_address, reg_address)     PMIC_65919_##name##_REG_ADDRESS = reg_address,
typedef enum
{
    PMIC_65919_GPADC_REGISTERS
    NUM_GPADC_REG_SIGNALS
}pmic_65919_gpadc_reg_address_t;

#undef X
#define X(signal_name, start_bit, signal_size)     PMIC_65919_##signal_name##_START_BIT = start_bit,
typedef enum
{
    PMIC_65919_GPADC_SIGNALS
    NUM_GPADC_START_BYTES_SIGNALS
}pmic_65919_gpadc_start_byte_t;

#undef X
#define X(signal_name, start_bit, signal_size)     PMIC_65919_##signal_name##_SIGNAL_SIZE = signal_size,
typedef enum
{
    PMIC_65919_GPADC_SIGNALS
    NUM_GPADC_SIGNAL_SIZE_SIGNALS
}pmic_65919_gpadc_signal_size_t;

/* This definition is not used for the selection since it is hardcoded in the cfg file*/
#define PMIC_65919_GPADC_SW_SELECT_VALUES \
        X(GPADC_CHANNEL_0, 0x00) \
        X(GPADC_CHANNEL_1, 0x01) \
        X(GPADC_CHANNEL_2, 0x02) \
        X(GPADC_CHANNEL_3, 0x03) \
        X(GPADC_CHANNEL_4, 0x04) \
        X(GPADC_CHANNEL_5, 0x05) \
        X(GPADC_CHANNEL_6, 0x06) \
        X(GPADC_CHANNEL_7, 0x07)

#undef X
#define X(channel_name, channel_number) channel_name = channel_number,
typedef enum
{
    PMIC_65919_GPADC_SW_SELECT_VALUES
    NUM_GPADC_CHANNELS_SELECTIONS
}pmic_65919_gpadc_channel_selection_t;

#define PMIC_65919_GPADC_SW_START_CONV0 1

#define PMIC_65919_GPADC_SW_CONV_ENABLED    1
#define PMIC_65919_GPADC_SW_CONV_DISABLED   0

#define PMIC_65919_GPADC_CTRL1_FORCE_ON    1
#define PMIC_65919_GPADC_CTRL1_FORCE_OFF   0

#define PMIC_65919_GPADC_SW_INT3_ENABLED    0
#define PMIC_65919_GPADC_SW_INT3_MASKED     1

#define PMIC_65919_GPADC_SW_INT3_NO_INT             0
#define PMIC_65919_GPADC_SW_INT3_INT_DETECTED       1

typedef enum {
    CONVERSION_OK = 0,
    CONVERSION_NOT_READY = 1,
    CONVERSION_ERROR = 2,
}pmic_65919_conversion_result_t;


#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */


#endif /* SOURCE_USER_APP_COMM_INTERFACE_COMM_PMIC_65919_TYPES_H_ */
