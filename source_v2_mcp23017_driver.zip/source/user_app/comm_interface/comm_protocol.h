#ifndef COMM_PROTOCOL_H_
#define COMM_PROTOCOL_H_
/*===========================================================================*/
/**
 * @file COMM_PROTOCOL.h
 *
 * Function definitions for the communication protocol module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "famp_pm_types.h"
#include <can_appl.h>

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum
{
  COMM_PROTOCOL_TVS_STATUS_REGISTER_1,
  COMM_PROTOCOL_TVS_STATUS_REGISTER_2,
  COMM_PROTOCOL_TVS_STATUS_REGISTER_3,
  COMM_PROTOCOL_TVS_STATUS_REGISTER_4,
  COMM_PROTOCOL_TVS_STATUS_REGISTER_5,
  COMM_PROTOCOL_TVS_STATUS_REGISTER_MAX,
} COMM_Protocol_TvsStatusRegisterNumber_en;

pmIgnitionLineState_t COMM_Protocol_GetCurrentIgnitionState (void);
pmCanBusActivity_t COMM_Protocol_GetCanBusState(void);
pmPowerButtonStates_t COMM_Protocol_GetCurrentPowerButtonState (void);
pmWakeUpCondition_t COMM_Protocol_GetPowerupCondition (void);
bool COMM_Protocol_Shut_Down (uint8_t seconds);
void COMM_Protocol_Test_Easter_Egg (void);
uint8_t COMM_Protocol_IsColdStart (void);
void COMM_Protocol_SaveWarmStartCondition (void);
pmSwitchOn_t COMM_Protocol_GetSwitchOn (void);
void COMM_Protocol_SetSwitchOn (pmSwitchOn_t switchOn);
pmTransportMode_t COMM_Protocol_GetTransportModeStatus (void);
void COMM_Protocol_SetTransportModeStatus (pmTransportMode_t transportMode);
uint32_t COMM_Protocol_GetADStatus (uint8_t ad_channel);
void COMM_Protocol_GetTime (uint8_t* rtc_hr_mode, uint8_t* rtc_hour, uint8_t* rtc_minute, uint8_t* rtc_sec);
void COMM_Protocol_GetDate (uint8_t* day, uint8_t* month, uint8_t* year);
void COMM_Protocol_SetTime (uint8_t rtc_hr_mode, uint8_t rtc_hour, uint8_t rtc_minute, uint8_t rtc_sec);
void COMM_Protocol_SetDate (uint8_t day, uint8_t month, uint8_t year);
void COMM_Protocol_KeepAlive (bool_t enable);

/** Initialize the video decoder chip (TVP5150AM1) */
void COMM_Protocol_InitVideoDecoder(void);

/**
 * @brief Get a status register from the video decoder chip
 * 
 * @param register_number The desired status register number to be obtained
 * @param status Place to store the contents of the desired status register
 * @return int If read correctly, E_OK. Else E_ERR is returned
 */
int COMM_Protocol_GetVideoDecoderStatusRegisters(COMM_Protocol_TvsStatusRegisterNumber_en register_number, uint8_t *status);

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file COMM_PROTOCOL.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 06-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* COMM_PROTOCOL_H_ */
