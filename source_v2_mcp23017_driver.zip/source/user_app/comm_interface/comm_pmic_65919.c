/*===========================================================================*/
/**
 * @file COMM_OMICL.c
 *
 * I2C communication pmic
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2023 Mirgor Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include "comm_pmic_65919.h"
#include "battery_monitor.cfg"
#include "battery_monitor.h"

#include <console.h>
#include <comm_interface.h>

#include <xdc/runtime/System.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

/* TODO: use stringify to concatenate "GPADC_CHANNEL_" and "0" */
#define PMIC_65919_GPADC_CHANNEL_SELECTED  (GPADC_CHANNEL_USED)




/*===========================================================================*
 * Function like macros
 *===========================================================================*/
#define pmic_65919_write_one_register(register, pointer)  COMM_PMIC_TransferI2C(PMIC_65919_##register##_SLAVE_ADDRESS, PMIC_65919_##register##_REG_ADDRESS, 1, 0, pointer)
#define pmic_65919_read_one_register(register, pointer)   COMM_PMIC_TransferI2C(PMIC_65919_##register##_SLAVE_ADDRESS, PMIC_65919_##register##_REG_ADDRESS, 0, 1, pointer)
#define pmic_65919_set_mask_from_shift(value, signal)   (PMIC_65919_##value << PMIC_65919_##signal##_START_BIT)

static void pmic_65919_enable_conversion_and_select_channel();
static void pmic_65919_Disable_conversion();
static void pmic_65919_force_adc_enabled();
static void pmic_65919_adc_off();
static void pmic_65919_unmask_adc_interrupt();
static void pmic_65919_mask_adc_interrupt();
static void pmic_65919_start_conversion();
static int pmic_65919_is_conversion_finished();
static void pmic_65919_read_convertion_result(uint16_t *);
static void pmic_65919_Read_Calibration_Values (void);
static void pmic_65919_Correct_Thresholds();

static uint8_t pmic_65919_first_conversion = false;

int8_t  pmic_65919_CalibrationValue_CH0_D1   = 0;
int8_t  pmic_65919_CalibrationValue_CH0_D2   = 0;
float   pmic_65919_Calibration_Gain          = 0;
int16_t pmic_65919_Calibration_Offset        = 0;

uint16_t vbatSamplesBuffer[VBAT_SAMPLES_BUFFER_SIZE];
uint8_t vbatInsertionIndex = 0;
uint8_t numberOfSamples = 0;

int16_t batteryVoltage = -1;
static uint8_t batteryMonitorInitialized = false;

static Semaphore_Handle batteryMonitor_sem = NULL;

#define pmic_65919_get_first_conversion() (pmic_65919_first_conversion)
#define pmic_65919_set_first_conversion() (pmic_65919_first_conversion = true)
#define pmic_65919_clr_first_conversion() (pmic_65919_first_conversion = false)
#define pmic_65919_is_first_conversion()  (true == pmic_65919_first_conversion)

#define battery_monitor_is_initialized()  (true == batteryMonitorInitialized)
#define battery_monitor_set_initialized() (batteryMonitorInitialized = true)
#define battery_monitor_clr_initialized() (batteryMonitorInitialized = false)

/*
 * IMPORTANT NOTE:
 *
 * We are grouping all the configurations of a similar register in here to reduce the transactions, this
 * will make it less reusable
 *
 * We are saving the value of GPADC_SW_SELECT so it can be used in the subsequent start of conversions to
 * avoid making more transactions with the PMIC (we should read the value before writting).
 *
 */
static void pmic_65919_enable_conversion_and_select_channel()
{
    uint8_t val;

    /* TODO: channel is hardcoded here, move to CFG!!!!! */

    val = pmic_65919_set_mask_from_shift(GPADC_SW_CONV_ENABLED, SW_CONV_ENABLE) | 
            pmic_65919_set_mask_from_shift(GPADC_CHANNEL_SELECTED, SW_CONV0_SEL);

    pmic_65919_write_one_register(GPADC_SW_SELECT, &val);
}

static void pmic_65919_Disable_conversion() {

    uint8_t val;

    val = pmic_65919_set_mask_from_shift(GPADC_SW_CONV_DISABLED, SW_CONV_ENABLE);
    pmic_65919_write_one_register(GPADC_SW_SELECT, &val);
}

static void pmic_65919_force_adc_enabled()
{
    uint8_t val;

    val = pmic_65919_set_mask_from_shift(GPADC_CTRL1_FORCE_ON, GPADC_FORCE);
    pmic_65919_write_one_register(GPADC_CTRL1, &val);
}

static void pmic_65919_adc_off() {

    uint8_t val;

    val = pmic_65919_set_mask_from_shift(GPADC_CTRL1_FORCE_OFF, GPADC_FORCE);
    pmic_65919_write_one_register(GPADC_CTRL1, &val);
}

static void pmic_65919_unmask_adc_interrupt()
{
    uint8_t val;
    val = pmic_65919_set_mask_from_shift(GPADC_SW_INT3_ENABLED, EOC_SW_MASK);

    pmic_65919_write_one_register(GPADC_INT3_MASK, &val);
}

static void pmic_65919_mask_adc_interrupt() {

    uint8_t val;

    val = pmic_65919_set_mask_from_shift(GPADC_SW_INT3_MASKED, EOC_SW_MASK);
    pmic_65919_write_one_register(GPADC_INT3_MASK, &val);
}

static void pmic_65919_start_conversion()
{
    uint8_t val;

    val = pmic_65919_set_mask_from_shift(GPADC_SW_CONV_ENABLED, SW_CONV_ENABLE) | 
            pmic_65919_set_mask_from_shift(GPADC_CHANNEL_SELECTED, SW_CONV0_SEL) |
            pmic_65919_set_mask_from_shift(GPADC_SW_START_CONV0, SW_START_CONV0);

    pmic_65919_write_one_register(GPADC_SW_SELECT, &val);
}

static int pmic_65919_is_conversion_finished()
{
    uint8_t status;
    pmic_65919_read_one_register(GPADC_INT3_STATUS, &status);
    return (status & (PMIC_65919_GPADC_SW_INT3_INT_DETECTED << PMIC_65919_EOC_SW_STATUS_START_BIT));
}

static void pmic_65919_read_convertion_result(uint16_t *conversion_result)
{
    uint8_t     rawCountValueH, rawCountValueL;
    uint16_t    rawCountValue;

    /* Read de raw counts value from the ADC */
    pmic_65919_read_one_register(GPADC_SW_CONV0_MSB, &rawCountValueH);
    pmic_65919_read_one_register(GPADC_SW_CONV0_LSB, &rawCountValueL);
    rawCountValue = (rawCountValueH << 8) | rawCountValueL;

    *conversion_result = (uint16_t) ( ( ( rawCountValue - pmic_65919_Calibration_Offset ) / pmic_65919_Calibration_Gain ) + 1 );
    LOG_PRINT_VER(DEBUG_BM_RAW_COUNTS, "Battery Voltage correceted counts =  %d\n", *conversion_result);
    return;
}


static void pmic_65919_Read_Calibration_Values (void) {

    uint8_t aux;

    pmic_65919_read_one_register(GPADC_TRIM1, &aux);
    pmic_65919_CalibrationValue_CH0_D1 = ( (aux >> 1) & 0x7F );
    if (aux & 0x01) {
        pmic_65919_CalibrationValue_CH0_D1 *= -1;
    }

    pmic_65919_read_one_register(GPADC_TRIM2, &aux);
    pmic_65919_CalibrationValue_CH0_D2 = ( (aux >> 1) & 0x7F );
    if (aux & 0x01) {
        pmic_65919_CalibrationValue_CH0_D2 *= -1;
    }

    pmic_65919_Calibration_Gain = 1 + ( (float) (pmic_65919_CalibrationValue_CH0_D2 - pmic_65919_CalibrationValue_CH0_D1) /
                                                (PMIC_65919_CALIBRATION_VALUE_CH0_X2 - PMIC_65919_CALIBRATION_VALUE_CH0_X1) );

    pmic_65919_Calibration_Offset = ( int16_t) (pmic_65919_CalibrationValue_CH0_D1 - ((pmic_65919_Calibration_Gain - 1) * PMIC_65919_CALIBRATION_VALUE_CH0_X1));

    LOG_PRINT_VER(DEBUG_PMIC, "Calibration values for battery voltage measurement: D1=%d, D2=%d\n", pmic_65919_CalibrationValue_CH0_D1, pmic_65919_CalibrationValue_CH0_D2);
    return;
}



static void pmic_65919_Correct_Thresholds() {

    #undef X
    #define X(name, counts, time) counts,
    int rawVector[NUM_THRESHOLDS] = { BM_THRESHOLD_PARAMETERS };
    #undef X

    int i;
    int rawCounts;

    int corrected[NUM_THRESHOLDS];

    for (i=0 ; i<NUM_THRESHOLDS ; i++) {
        
        correctedThresholdCounts[i] = ( (rawVector[i] - pmic_65919_Calibration_Offset) / pmic_65919_Calibration_Gain);
        
        if (correctedThresholdCounts[i] >= (PMIC_MAX_ADC_COUNTS - ADC_SECURITY_FACTOR) ) {
            correctedThresholdCounts[i] = (PMIC_MAX_ADC_COUNTS - ADC_SECURITY_FACTOR);
        }
        if (correctedThresholdCounts[i] < (PMIC_MIN_ADC_COUNTS + ADC_SECURITY_FACTOR) ) {
            correctedThresholdCounts[i] = (PMIC_MAX_ADC_COUNTS + ADC_SECURITY_FACTOR);
        }
    }
}

void PMIC_65919_Continuos_Conversion() {

    typedef enum {
        START_CONVERSION = 0,
        WAIT_CONVERSION_READY,
        GET_CONVERSION_RESULT
    } fsm_ADC_Measurement;

    static fsm_ADC_Measurement fsm = START_CONVERSION;
    uint16_t aux;
    uint32_t tempBatteryVoltage;
    uint8_t i;

    if ( !battery_monitor_is_initialized() ) {
        return;
    }
    
    switch (fsm) {
        
        case START_CONVERSION:

            pmic_65919_start_conversion();
            fsm = WAIT_CONVERSION_READY;
            break;

        case WAIT_CONVERSION_READY:

            if (pmic_65919_is_conversion_finished()) {
                fsm = GET_CONVERSION_RESULT;
            }
            break;

        case GET_CONVERSION_RESULT:

                fsm = START_CONVERSION;

                /* According to the "Guide to Using GPADC in TPS65919-Q1 - SLIA087A"
                 * document, there is a known issue about the first conversion after
                 * a warm reset, so we have to discard this first conversion.
                 */
                if ( pmic_65919_is_first_conversion() ) {
                    pmic_65919_clr_first_conversion();
                    break;
                }
                
                pmic_65919_read_convertion_result(&aux);

                /* Prevent corrected values being grater than max count number. */
                if (aux > PMIC_MAX_ADC_COUNTS) {
                    aux = PMIC_MAX_ADC_COUNTS;
                }

                /* Put the sample in the ring buffer */
                vbatSamplesBuffer[vbatInsertionIndex] = aux;
                vbatInsertionIndex++;
                vbatInsertionIndex %= VBAT_SAMPLES_BUFFER_SIZE;

                if (numberOfSamples < VBAT_SAMPLES_BUFFER_SIZE) {
                    numberOfSamples++;
                }

                tempBatteryVoltage = 0;
                for ( i=0 ; i<numberOfSamples ; i++) {
                    tempBatteryVoltage += vbatSamplesBuffer[i];
                }

                Semaphore_pend(batteryMonitor_sem, BIOS_WAIT_FOREVER);            
                batteryVoltage = (int16_t) tempBatteryVoltage/numberOfSamples;
                Semaphore_post(batteryMonitor_sem);
            
            break;
        
        default:
            fsm = START_CONVERSION;
            break;
    }
}

int16_t get_Battery_Voltage() {

    int16_t voltage = -1;

    if (battery_monitor_is_initialized()) {
        Semaphore_pend(batteryMonitor_sem, BIOS_WAIT_FOREVER);
        voltage = batteryVoltage;
        Semaphore_post(batteryMonitor_sem);
    }
    return voltage;
}

/***************************************************************************//**
* @fn
* @brief
******************************************************************************/
void PMIC_65919_Configure_ADC()
{
    batteryMonitor_sem = Semaphore_create(1, NULL, NULL);

    pmic_65919_Read_Calibration_Values();
    pmic_65919_Correct_Thresholds();
    pmic_65919_enable_conversion_and_select_channel();
    pmic_65919_force_adc_enabled();
    pmic_65919_unmask_adc_interrupt();

    /* The first conversion is unrelaiable, so we do start one now */
    pmic_65919_start_conversion();
    pmic_65919_set_first_conversion();
    battery_monitor_set_initialized();
}

void PMIC_65919_Shutdown_ADC (void) {

    pmic_65919_Disable_conversion();
    pmic_65919_adc_off();
    pmic_65919_mask_adc_interrupt();
    pmic_65919_set_first_conversion();
    battery_monitor_clr_initialized();
}

/***************************************************************************//**
* @fn         COMM_Protocol_SetDate
* @brief      Communication protocol interface function
******************************************************************************/
void PMIC_65919_SetOperatingVoltages (uint8_t vsel_smps1, uint8_t vsel_smps3)
{
    uint8_t val;

    val = vsel_smps1 & 0x7F;
    pmic_65919_write_one_register(SMPS1_VOLTAGE, &val);
    pmic_65919_write_one_register(SMPS1_FORCE,   &val);

    val = vsel_smps3 & 0x7F;
    pmic_65919_write_one_register(SMPS3_VOLTAGE, &val);
    pmic_65919_write_one_register(SMPS3_FORCE,   &val);
}
