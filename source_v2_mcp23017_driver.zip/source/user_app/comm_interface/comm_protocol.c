/*===========================================================================*/
/**
 * @file COMM_PROTOCOL.c
 *
 * I2C communication protocol
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <console.h>
#include <comm_interface.h>
#include <comm_protocol.h>

#include <xdc/runtime/System.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/* general purpose memory number of bytes */
#define COMM_PROTOCOL_GPM_BYTES 20

#define COMM_PROTOCOL_GPM_COLD_CONDITION_OFFSET_START 0x00
#define COMM_PROTOCOL_GPM_COLD_CONDITION_OFFSET_END 0x01
#define COMM_PROTOCOL_GPM_SWITCHON_OFFSET_START 0x01
#define COMM_PROTOCOL_GPM_SWITCHON_OFFSET_END 0x02
#define COMM_PROTOCOL_GPM_TRANSPORT_MODE_STATUS_OFFSET_START 0x03
#define COMM_PROTOCOL_GPM_TRANSPORT_MODE_STATUS_OFFSET_END 0x04

/* Register definition for TVP5150AM1 chip */
#define COMM_PROTOCOL_TVS_VIDEO_INPUT_SRC_SEL_1_REG     (0x00)
#define COMM_PROTOCOL_TVS_MISC_CTRL_REG                 (0x03)
#define COMM_PROTOCOL_TVS_AUTOSWITCH_MASK_REG           (0x04)
#define COMM_PROTOCOL_TVS_OUTS_AND_DATA_RATES_SEL_REG   (0x0D)
#define COMM_PROTOCOL_TVS_CONFIGURATION_SHARED_PINS_REG (0x0F)

#define COMM_PROTOCOL_TVS_STATUS_REGISTER(n)            (0x88 + n)

/*
 * GPCL function
 * GPCL set to 1
 * GPCL output enabled
 * HVLK = 0
 * YCbCr output active
 * HSYNC, VSYNC/PALI, AVID and FID/GLCO active
 * Vertical Blanking (VBLK) on
 * SCLK output enabled
 */
#define COMM_PROTOCOL_TVS_MISC_CTRL_VAL                 (0x6F)

/* All autoswitches OFF */
#define COMM_PROTOCOL_TVS_AUTOSWITCH_MASK_VAL           (0x00)

/*
 * Using default
 * YCbCr output code range = ITU-R BT.601 coding range
 * CbCr code format = Straight binary code
 * YCbCr data path bypass = normal operation
 * YCbCr output format = 8-bit 4:2:2 YCbCr with discrete sync output
 */
#define COMM_PROTOCOL_TVS_OUTS_AND_DATA_RATES_SEL_VAL   (0x47)

/*
 * pin 23 = FID (enabled)
 * pin 24 = PALI (but not enabled used)
 * pin 27 = INTREQ
 */
#define COMM_PROTOCOL_TVS_CONFIGURATION_SHARED_PINS_VAL (0x02)

/* Payload:
 *      0x00 ColdStart <--- This value is taken from the MSP430 documentation
 *      0x55 WarmStart <--- This value is decided by us
 */
#define FAMP_COM_VALUE_COLD_CONDITION          0x00
#define FAMP_COM_VALUE_WARM_CONDITION          0x55

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
/* The list of supported commands */
typedef enum protocol_command_id_tag
{
    PROTOCOL_COMMAND_GET_AD_STATUS = 0x01,
    PROTOCOL_COMMAND_GET_TIME = 0x02,
    PROTOCOL_COMMAND_SET_TIME = 0x03,
    PROTOCOL_COMMAND_GET_CALENDAR = 0x04,
    PROTOCOL_COMMAND_SET_CALENDAR = 0x05,
    PROTOCOL_COMMAND_GET_INPUTS_STATUS = 0x06,
    PROTOCOL_COMMAND_GET_CAN_ACTIVITY = 0x07,

    PROTOCOL_COMMAND_KEEP_ALIVE = 0x08,
    PROTOCOL_COMMAND_SHUTDOWN = 0x09,

    PROTOCOL_COMMAND_GET_POWERUP_CONDITION = 0x0A,

    PROTOCOL_COMMAND_SET_SM = 0x0B,
    PROTOCOL_COMMAND_GET_SM = 0x0C,

    PROTOCOL_COMMAND_DUMMY1 = 0xAA,
    PROTOCOL_COMMAND_DUMMY2 = 0xBB,

    PROTOCOL_NUM_COMMANDS
}protocol_command_id_t;

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/***************************************************************************//**
* @fn         COMM_Protocol_Read_Easter_Egg
* @brief      Communication protocol interface function
******************************************************************************/
pmIgnitionLineState_t COMM_Protocol_GetCurrentIgnitionState (void)
{
   uint8_t ignitionLineState;
   LOG_PRINT_SVER(DEBUG_COMM_PROTOCOL, "Get Current ignition status\r\n");

   ignitionLineState = 0x01; /* The ignition index */
   if (COMM_MSP_TransferI2C(PROTOCOL_COMMAND_GET_INPUTS_STATUS, 1, 1, &ignitionLineState) < 0)
   {
       /* TODO: fix ugly cast */
       return((pmIgnitionLineState_t)(-1));
   }
   LOG_PRINT_SVER(DEBUG_COMM_PROTOCOL, "Ignition current status %d\r\n", ignitionLineState);
//   if (6 == ignitionState) {
//       LOG_PRINT_ERR(DEBUG_COMM_PROTOCOL, "Llego un 6\n");
//   }
   return (pmIgnitionLineState_t) ignitionLineState;
}

/***************************************************************************//**
* @fn         COMM_Protocol_GetCanBusState
* @brief      Communication protocol interface function
******************************************************************************/
pmCanBusActivity_t COMM_Protocol_GetCanBusState()
{
    uint8_t canBusActivity;
    LOG_PRINT_START_FUNC(DEBUG_COMM_PROTOCOL);

    if (COMM_MSP_TransferI2C(PROTOCOL_COMMAND_GET_CAN_ACTIVITY, 0, 1, &canBusActivity) < 0)
    {
        /* TODO: fix ugly cast */
        return((pmCanBusActivity_t) -1);
    }
    LOG_PRINT_SVER(DEBUG_COMM_PROTOCOL, "Can bus activity %d\r\n", canBusActivity);
    return (pmCanBusActivity_t) canBusActivity;
}

/***************************************************************************//**
* @fn         COMM_Protocol_Read_Easter_Egg
* @brief      Communication protocol interface function
******************************************************************************/
pmPowerButtonStates_t COMM_Protocol_GetCurrentPowerButtonState (void)
{
   uint8_t powerButtonState;
   LOG_PRINT_SVER(DEBUG_COMM_PROTOCOL, "Get Current power button status\r\n");

   powerButtonState = 0x00; /* The power button index */
   if (COMM_MSP_TransferI2C(PROTOCOL_COMMAND_GET_INPUTS_STATUS, 1, 1, &powerButtonState) < 0)
   {
       /* TODO: fix ugly cast */
       return((pmPowerButtonStates_t) -1);
   }
   LOG_PRINT_SVER(DEBUG_COMM_PROTOCOL, "Power button current status %d\r\n", powerButtonState);
   return (pmPowerButtonStates_t) powerButtonState;
}

/***************************************************************************//**
* @fn         COMM_Protocol_Read_Easter_Egg
* @brief      Communication protocol interface function
******************************************************************************/
pmWakeUpCondition_t COMM_Protocol_GetPowerupCondition (void)
{
   /* pmWakeUpCondition_t wakeUpCond; */
   uint8_t wakeUpCondAns;
   LOG_PRINT_VER(DEBUG_COMM_PROTOCOL, "Get power up condition\r\n");
   if (COMM_MSP_TransferI2C(PROTOCOL_COMMAND_GET_POWERUP_CONDITION, 0, 1, &wakeUpCondAns) < 0)
   {
       /* TODO: fix ugly cast */
       return((pmWakeUpCondition_t) -1);
   }
   LOG_PRINT_SVER(DEBUG_COMM_PROTOCOL, "Wake up condition %d\r\n", wakeUpCondAns);
   return (pmWakeUpCondition_t) wakeUpCondAns;
}

/***************************************************************************//**
* @fn         COMM_Protocol_Shut_Down
* @brief      Send the shutdown command to the msp_main
*
* 			  Returns: true if the command is acknowledge
*                      false if there is a communication error
*  				
******************************************************************************/
bool COMM_Protocol_Shut_Down (uint8_t seconds)
{
   LOG_PRINT_VER(DEBUG_COMM_PROTOCOL, "Shutdown command\r\n");
   return (COMM_MSP_TransferI2C(PROTOCOL_COMMAND_SHUTDOWN, 1, 0, &seconds) >= 0);
}

/***************************************************************************//**
* @fn         COMM_Protocol_Read_Easter_Egg
* @brief      Communication protocol interface function
******************************************************************************/
void COMM_Protocol_Test_Easter_Egg (void)
{
   uint8_t buffer[10];
   uint8_t buffer2[10];
   COMM_MSP_TransferI2C(PROTOCOL_COMMAND_DUMMY1, 0, 5, buffer);
   buffer[5] = 0x00;
   COMM_MSP_TransferI2C(PROTOCOL_COMMAND_DUMMY2, 0, 7, buffer2);
   buffer2[7] = 0x00;

   LOG_PRINT_SVER(DEBUG_COMM_PROTOCOL, "Register %d, %d, %s %s\r\n", 0xAA, 0xBB, buffer, buffer2);
}

/***************************************************************************//**
* @fn         COMM_Protocol_IsColdStart
* @brief      Communication protocol interface function
******************************************************************************/
uint8_t COMM_Protocol_IsColdStart (void)
{
    uint8_t buffer[2];
    buffer[0] = COMM_PROTOCOL_GPM_COLD_CONDITION_OFFSET_START;
    buffer[1] = COMM_PROTOCOL_GPM_COLD_CONDITION_OFFSET_END;
    COMM_MSP_TransferI2C(PROTOCOL_COMMAND_GET_SM, 2, 1, buffer);
    return (buffer[0] == 0x00);
}

/***************************************************************************//**
* @fn         COMM_Protocol_SaveWarmStartCondition
* @brief      Communication protocol interface function
******************************************************************************/
void COMM_Protocol_SaveWarmStartCondition (void)
{
    uint8_t buffer[3];
    buffer[0] = COMM_PROTOCOL_GPM_COLD_CONDITION_OFFSET_START;
    buffer[1] = COMM_PROTOCOL_GPM_COLD_CONDITION_OFFSET_END;
    buffer[2] = FAMP_COM_VALUE_WARM_CONDITION;
    COMM_MSP_TransferI2C(PROTOCOL_COMMAND_SET_SM, 3, 0, buffer);
}

/***************************************************************************//**
* @fn         COMM_Protocol_GetSwitchOn
* @brief      Communication protocol interface function
******************************************************************************/
pmSwitchOn_t COMM_Protocol_GetSwitchOn (void)
{
    uint8_t buffer[2];
    buffer[0] = COMM_PROTOCOL_GPM_SWITCHON_OFFSET_START;
    buffer[1] = COMM_PROTOCOL_GPM_SWITCHON_OFFSET_END;
    if (COMM_MSP_TransferI2C(PROTOCOL_COMMAND_GET_SM, 2, 1, buffer) < 0)
    {
       /* TODO: fix ugly cast */
       return((pmSwitchOn_t) -1);
    }

    return ( (pmSwitchOn_t) buffer[0]);
}

/***************************************************************************//**
* @fn         COMM_Protocol_SetSwitchOn
* @brief      Communication protocol interface function
******************************************************************************/
void COMM_Protocol_SetSwitchOn (pmSwitchOn_t switchOn)
{
    uint8_t buffer[3];
    buffer[0] = COMM_PROTOCOL_GPM_SWITCHON_OFFSET_START;
    buffer[1] = COMM_PROTOCOL_GPM_SWITCHON_OFFSET_END;
    buffer[2] = switchOn;
    COMM_MSP_TransferI2C (PROTOCOL_COMMAND_SET_SM, 3, 0, buffer);
}

/*******************************************************************************
* @fn         COMM_Protocol_GetTransportModeStatus
* @brief      Communication protocol interface function used to read the 
*             transport mode stored in the shared memory area of the MSP
******************************************************************************/
pmTransportMode_t COMM_Protocol_GetTransportModeStatus (void)
{
    pmTransportMode_t value = TRANSPORT_MODE_ERROR;

    uint8_t buffer[2];
    buffer[0] = COMM_PROTOCOL_GPM_TRANSPORT_MODE_STATUS_OFFSET_START;
    buffer[1] = COMM_PROTOCOL_GPM_TRANSPORT_MODE_STATUS_OFFSET_END;
    if (COMM_MSP_TransferI2C(PROTOCOL_COMMAND_GET_SM, 2, 1, buffer) >= 0) {
        value = (pmTransportMode_t) buffer[0];
    }
    return value;
}

/***************************************************************************//**
* @fn         COMM_Protocol_SetTransportModeStatus
* @brief      Communication protocol interface function
******************************************************************************/
void COMM_Protocol_SetTransportModeStatus (pmTransportMode_t transportMode)
{
    uint8_t buffer[3];
    buffer[0] = COMM_PROTOCOL_GPM_TRANSPORT_MODE_STATUS_OFFSET_START;
    buffer[1] = COMM_PROTOCOL_GPM_TRANSPORT_MODE_STATUS_OFFSET_END;
    buffer[2] = transportMode;
    COMM_MSP_TransferI2C (PROTOCOL_COMMAND_SET_SM, 3, 0, buffer);
}

/***************************************************************************//**
* @fn         COMM_Protocol_GetADStatus
* @brief      Communication protocol interface function
******************************************************************************/
uint32_t COMM_Protocol_GetADStatus (uint8_t ad_channel)
{
    uint8_t buffer[2];
    buffer[0] = ad_channel;
    COMM_MSP_TransferI2C (PROTOCOL_COMMAND_GET_AD_STATUS, 1, 2, buffer);
    return (((uint32_t)buffer[0]<<8) | ((uint32_t)buffer[1]));
}

/***************************************************************************//**
* @fn         COMM_Protocol_GetTime
* @brief      Communication protocol interface function
******************************************************************************/
void COMM_Protocol_GetTime (uint8_t* rtc_hr_mode, uint8_t* rtc_hour, uint8_t* rtc_minute, uint8_t* rtc_sec)
{
    uint8_t buffer_time[4];
    COMM_MSP_TransferI2C (PROTOCOL_COMMAND_GET_TIME, 0, 4, buffer_time);

    *rtc_hr_mode = buffer_time[0];
    *rtc_hour    = buffer_time[1];
    *rtc_minute  = buffer_time[2];
    *rtc_sec     = buffer_time[3];
}

/***************************************************************************//**
* @fn         COMM_Protocol_GetDate
* @brief      Communication protocol interface function
******************************************************************************/
void COMM_Protocol_GetDate (uint8_t* day, uint8_t* month, uint8_t* year)
{
    uint8_t buffer_date[3];
    COMM_MSP_TransferI2C (PROTOCOL_COMMAND_GET_CALENDAR, 0, 3, buffer_date);

    *year   = buffer_date[0];
    *month  = buffer_date[1];
    *day    = buffer_date[2];
}

/***************************************************************************//**
* @fn         COMM_Protocol_SetTime
* @brief      Communication protocol interface function
******************************************************************************/
void COMM_Protocol_SetTime (uint8_t rtc_hr_mode, uint8_t rtc_hour, uint8_t rtc_minute, uint8_t rtc_sec)
{
    uint8_t buffer_time[4];
    buffer_time[0] = rtc_hr_mode;
    buffer_time[1] = rtc_hour;
    buffer_time[2] = rtc_minute;
    buffer_time[3] = rtc_sec;

    COMM_MSP_TransferI2C (PROTOCOL_COMMAND_SET_TIME, 4, 0, buffer_time);
}

/***************************************************************************//**
* @fn         COMM_Protocol_SetDate
* @brief      Communication protocol interface function
******************************************************************************/
void COMM_Protocol_SetDate (uint8_t day, uint8_t month, uint8_t year)
{
    uint8_t buffer_date[3];
    buffer_date[0] = year;
    buffer_date[1] = month;
    buffer_date[2] = day;

    COMM_MSP_TransferI2C (PROTOCOL_COMMAND_SET_CALENDAR, 3, 0, buffer_date);
}


/***************************************************************************//**
* @fn         COMM_Protocol_KeepAlive
* @brief      Communication protocol interface function
******************************************************************************/
void COMM_Protocol_KeepAlive (bool_t enable)
{
   uint8_t buffer[1];
   buffer[0] = (uint8_t)enable;
   COMM_MSP_TransferI2C(PROTOCOL_COMMAND_KEEP_ALIVE, 1, 0, buffer);
}

void COMM_Protocol_InitVideoDecoder(void)
{
  uint8_t buff;
  int ret;

  buff = COMM_PROTOCOL_TVS_MISC_CTRL_VAL;
  ret = COMM_TransferI2C(COMM_TVP_SLAVE_ADDRESS, COMM_PROTOCOL_TVS_MISC_CTRL_REG, 1, 0, &buff);
  if (-1 == ret)
  {
    LOG_PRINT_ERR(DEBUG_COMM_PROTOCOL, "%s(): TVP Initialization failed! Cannot set miscleaneous control register.\r\n", __FUNCTION__);
    return;
  }

  buff = COMM_PROTOCOL_TVS_AUTOSWITCH_MASK_VAL;
  ret = COMM_TransferI2C(COMM_TVP_SLAVE_ADDRESS, COMM_PROTOCOL_TVS_AUTOSWITCH_MASK_REG, 1, 0, &buff);
  if (-1 == ret)
  {
    LOG_PRINT_ERR(DEBUG_COMM_PROTOCOL, "%s(): TVP Initialization failed! Cannot set autoswitch mask register.\r\n", __FUNCTION__);
    return;
  }

  buff = COMM_PROTOCOL_TVS_OUTS_AND_DATA_RATES_SEL_VAL;
  ret = COMM_TransferI2C(COMM_TVP_SLAVE_ADDRESS, COMM_PROTOCOL_TVS_OUTS_AND_DATA_RATES_SEL_REG, 1, 0, &buff);
  if (-1 == ret)
  {
    LOG_PRINT_ERR(DEBUG_COMM_PROTOCOL, "%s(): TVP Initialization failed! Cannot set outputs and data rates register.\r\n", __FUNCTION__);
    return;
  }

  buff = COMM_PROTOCOL_TVS_CONFIGURATION_SHARED_PINS_VAL;
  ret = COMM_TransferI2C(COMM_TVP_SLAVE_ADDRESS, COMM_PROTOCOL_TVS_CONFIGURATION_SHARED_PINS_REG, 1, 0, &buff);
  if (-1 == ret)
  {
    LOG_PRINT_ERR(DEBUG_COMM_PROTOCOL, "%s(): TVP Initialization failed! Cannot set shared pins configuration register.\r\n", __FUNCTION__);
    return;
  }

  LOG_PRINT_INFO(DEBUG_COMM_PROTOCOL, "%s(): TVP Initialization done!\r\n", __FUNCTION__);
}

int COMM_Protocol_GetVideoDecoderStatusRegisters(COMM_Protocol_TvsStatusRegisterNumber_en register_number, uint8_t *status)
{
  uint8_t buff;
  int ret;

  if (NULL == status)
    return E_INVALID_CONDITION;

  if (register_number >= COMM_PROTOCOL_TVS_STATUS_REGISTER_MAX)
    return E_OUT_OF_RANGE;

  ret = COMM_TransferI2C(COMM_TVP_SLAVE_ADDRESS, COMM_PROTOCOL_TVS_STATUS_REGISTER((int) register_number), 0, 1, &buff);

  if (-1 == ret)
    return E_ERROR;

  *status = buff;
  
  return E_OK;
}
