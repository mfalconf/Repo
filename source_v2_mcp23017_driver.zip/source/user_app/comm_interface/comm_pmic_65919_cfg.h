/*===========================================================================*/
/**
 * @file COMM_OMICL.c
 *
 * I2C communication pmic
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2023 Mirgor Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

#ifndef SOURCE_USER_APP_COMM_INTERFACE_COMM_PMIC_65919_CFG_H_
#define SOURCE_USER_APP_COMM_INTERFACE_COMM_PMIC_65919_CFG_H_

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */

#define PMIC_65919_ADDRESS_1_SELECTED   1

#define GPADC_CHANNEL_USED  0x00

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */


#endif /* SOURCE_USER_APP_COMM_INTERFACE_COMM_PMIC_65919_CFG_H_ */
