/*===========================================================================*/
/**
 * @file COMM_OMICL.c
 *
 * I2C communication pmic
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2023 Mirgor Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

#ifndef SOURCE_USER_APP_COMM_INTERFACE_COMM_PMIC_65919_H_
#define SOURCE_USER_APP_COMM_INTERFACE_COMM_PMIC_65919_H_

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */

#include "comm_pmic_65919_types.h"
#include <ti/sysbios/knl/Semaphore.h>

void PMIC_65919_Shutdown_ADC();
void PMIC_65919_Configure_ADC();
void PMIC_65919_SetOperatingVoltages (uint8_t vsel_smps1, uint8_t vsel_smps3);
void PMIC_65919_Continuos_Conversion();
int16_t get_Battery_Voltage();

#define VBAT_SAMPLES_BUFFER_SIZE            4

#define PMIC_65919_CALIBRATION_VALUE_CH0_X1 2064
#define PMIC_65919_CALIBRATION_VALUE_CH0_X2 3112

#define PMIC_MAX_ADC_COUNTS                 4095
#define PMIC_MIN_ADC_COUNTS                 0
#define ADC_SECURITY_FACTOR                 5

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */


#endif /* SOURCE_USER_APP_COMM_INTERFACE_COMM_PMIC_65919_H_ */
