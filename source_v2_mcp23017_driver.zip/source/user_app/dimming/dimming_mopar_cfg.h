#ifndef DIMMING_MOPAR_CFG_H
#   define DIMMING_MOPAR_CFG_H
/*===========================================================================*/
/**
 * @file dimming_mopar_cfg.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:micbias_cfg.h~2:incl:kok_basa#1 %
 * @version %version:2 %
 * @author  %derived_by:fzdbm3 %
 * @date    %date_modified:Fri Nov 29 15:26:54 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2013 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * #define Constants
 *===========================================================================*/
/*
 * Configurable parameters
 */
/**
 *  \brief PWM instance base address.
 *  Note: If changed to other instance, PRCM and pinmux changes needs to be
 *  taken care in the application.
 */
#define PWM_ONKEY_BASE_ADDR             (L4_REGISTER_ADDRESS_OFFSET + SOC_PWMSS3_IPWMSS_BASE)
#define PWM_CPBTN_BASE_ADDR             (L4_REGISTER_ADDRESS_OFFSET + SOC_PWMSS3_IPWMSS_BASE)

/**
 *  \brief Output channel - A or B.
 *  Note: If changed to channel B, pinmux changes needs to be taken care
 *  in the application.
 */
#define PWM_ONKEY_OUTPUT_CH             (CSL_EPWM_OUTPUT_CH_A)
#define PWM_CPBTN_OUTPUT_CH             (CSL_EPWM_OUTPUT_CH_B)

/** \brief Frequency of PWM output signal in Hz - 1 KHz is selected */
#define PWM_OUT_FREQ                    (1U * 1000U)

/**
 *  \brief Functional clock to the PWMSS.
 *  Fixed for the platform - can't be changed.
 */
#define PWM_MODULE_FREQ                 (133U * 1000U * 1000U)

/** \brief TimeBase frequency in Hz - so that /4 divider is used */
#define PWM_TIMEBASE_FREQ               (PWM_MODULE_FREQ / 4U)

/**
 *  \brief PRD value - this determines the period
 *  PRD = (TBCLK/PWM FREQ)
 */
#define PWM_PERIOD_VAL                  ((PWM_TIMEBASE_FREQ / PWM_OUT_FREQ))
/**
 *  \brief COMPARE value - this determines the duty cycle
 *  COMPARE = (PRD - ((dutycycle * PRD) / 100)
 */
//#define PWM_COMPARE_VAL                 (PWM_PERIOD_VAL - ((PWM_DUTY_CYCLE * PWM_PERIOD_VAL) / 100U))
#define PWM_DEFAULT_COMPARE_VAL         (PWM_PERIOD_VAL - ((DIMMING_MIN_LEVEL * PWM_PERIOD_VAL) / 100U))

//#define PWM_DEFAULT_COMPARE_VAL         (0)

/*===========================================================================*
 * #define MACROS
 *===========================================================================*/

/*
a: InternalLigthLevel, value receive via CAN.
b: Dimming on/off for the DIM_DISP channel
c: Dimming percentage [0-1000%] level for the DIM_ONKEY channel
d Dimming percentage level [0-1000%] for the DIM_CPBTN channel
*/
#define DIMMING_LEVEL \
   X( DIMMING_LEVEL_0,      0,     0,       0  )\
   X( DIMMING_LEVEL_1,      1,     42,      15 )\
   X( DIMMING_LEVEL_2,      1,     54,      19 )\
   X( DIMMING_LEVEL_3,      1,     66,      24 )\
   X( DIMMING_LEVEL_4,      1,     78,      28 )\
   X( DIMMING_LEVEL_5,      1,     89,      32 )\
   X( DIMMING_LEVEL_6,      1,     101,     36 )\
   X( DIMMING_LEVEL_7,      1,     113,     41 )\
   X( DIMMING_LEVEL_8,      1,     125,     45 )\

/* The maximum dimming value for each channel */
#define DIMMING_MAX_LEVELS       {1, 1000, 1000}
#define DIMMING_MIN_LEVEL        DIMMING_LEVEL_0
#define DIMMING_MAX_LEVEL        DIMMING_LEVEL_8

/** 
 * External dimming (pwm or discrete) should not turn off any led.
 * That is why the minimum level is 1 instead of 0.
 */
#define DIMMING_MIN_LEVEL_ES     DIMMING_LEVEL_1
#define DIMMING_MAX_LEVEL_ES     DIMMING_LEVEL_7

/*===========================================================================*
 * Custom Type Declarations
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file dimming_mopar_cfg.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 07-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* DIMMING_MOPAR_CFG_H */
