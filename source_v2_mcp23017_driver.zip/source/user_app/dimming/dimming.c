/*===========================================================================*/
/**
 * @file DIMMING.c
 *
 * DIMMING controller
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <drv/pwm/pwm.h>
#include <console.h>
#include <dimming.h>
#include "drv/board/board.h"

#include <ti/csl/soc.h>
#include <ti/csl/csl_gpio.h>
#include <ti/csl/hw_types.h>
#include <xdc/runtime/System.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

#if (USE_DIMMING_MOPAR == 1)
    #include <dimming_mopar_cfg.h>
#endif
#if (USE_DIMMING_AFTER == 1)
    #include <dimming_after_cfg.h>
#endif

/*===========================================================================*
 * Local X-MACROS Type Declarations
 *===========================================================================*/
#undef X
#define X(a,b,c,d)     a,
typedef enum dimming_level_id_Tag
{
    DIMMING_LEVEL
    NUM_DIMMING_LEVELS
}dimming_level_id_T;

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define DIMMING_DEFAULT_LEVEL       DIMMING_MAX_LEVEL

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static Semaphore_Handle dimming_sem = NULL;
static uint32_t dimming_lvl;
static uint32_t cmpValueOnKey = PWM_DEFAULT_COMPARE_VAL;
static uint32_t cmpValueCpBtn = PWM_DEFAULT_COMPARE_VAL;
static uint32_t dim_channel_status[DIM_NUM_CHANNELS];

#undef X
#define X(a,b,c,d)     {b,c,d},
static const uint32_t dimmingLevel[NUM_DIMMING_LEVELS][DIM_NUM_CHANNELS] = {DIMMING_LEVEL};

static const uint32_t dimmingMaxLevel[DIM_NUM_CHANNELS] = DIMMING_MAX_LEVELS;

static PWM_Obj_t pwmOnKey_Obj =
{
    PWM_ONKEY_OUTPUT_CH,                      /* pwmCh */
    PWM_ONKEY_BASE_ADDR,                      /* instAddr */
    PWM_MODULE_FREQ,                            /* funcClk */
    FALSE,                                      /* enableDeadband */
    FALSE,                                      /* enableChopper */
    FALSE,                                      /* enableTripzone */
    FALSE,                                      /* enableEventTrigger */
    FALSE,                                      /* enableHighResolution */
    /* PWM_Cfg_t*/
    {
        /* CSL_EpwmTimebaseCfg_t */
        {
            PWM_TIMEBASE_FREQ,                  /* tbClk */
            PWM_OUT_FREQ,                       /* pwmtbCounterFreqPrd */
            CSL_EPWM_TB_COUNTER_DIR_UP,    /* tbCntrDirection */
            FALSE,                              /* enableSynchronization */
            PWMSS_EPWM_TBCTL_PHSDIR_COUNT_UP,   /* cntDirAfterSync */
            0U,                                 /* phsCountAfterSync */
            PWMSS_EPWM_TBCTL_SYNCOSEL_EPWMXSYNC /* syncOutSrc */
        },
        /* CSL_EpwmCounterCmpCfg_t */
        {
            PWM_DEFAULT_COMPARE_VAL,                    /* cmpAValue */
            PWM_DEFAULT_COMPARE_VAL                     /* cmpBValue */
        },
        /* CSL_EpwmAqActionCfg_t */
        {
            CSL_EPWM_AQ_ACTION_LOW,             /* zeroAction */
            CSL_EPWM_AQ_ACTION_DONOTHING,       /* prdAction */
            CSL_EPWM_AQ_ACTION_HIGH,            /* cmpAUpAction */
            CSL_EPWM_AQ_ACTION_DONOTHING,       /* cmpADownAction */
            CSL_EPWM_AQ_ACTION_DONOTHING,       /* cmpBUpAction */
            CSL_EPWM_AQ_ACTION_DONOTHING        /* cmpBDownAction */
        },
        /* CSL_EpwmDeadbandCfg_t */
        {
            CSL_EPWM_DB_IN_MODE_A_RED_A_FED,    /* inputMode */
            CSL_EPWM_DB_OUT_MODE_BYPASS,        /* outputMode */
            CSL_EPWM_DB_POL_SEL_ACTV_HIGH,      /* polaritySelect */
            0U,                                 /* risingEdgeDelay */
            0U                                  /* fallingEdgeDelay */
        },
        /* CSL_EpwmChopperCfg_t */
        {
            CSL_EPWM_CHP_DUTY_CYCLE_PERC_12PNT5,    /* dutyCycle */
            CSL_EPWM_CHP_CLK_FREQ_DIV_BY_1,         /* clkFrequency */
            CSL_EPWM_CHP_OSHT_WIDTH_1XSYSOUT_BY_8   /* oneShotPulseWidth */
        },
        /* CSL_EpwmTripzoneCfg_t */
        {
            CSL_EPWM_TZ_TRIP_ACTION_DO_NOTHING, /* tripAction */
            CSL_EPWM_TZ_EVENT_ONE_SHOT,         /* tripEvtType */
            0U,                                 /* tripPin */
            FALSE                               /* enableTripIntr */
        },
        /* CSL_EpwmEtCfg_t */
        {
            CSL_EPWM_ET_INTR_EVT_CNT_EQ_ZRO,    /* intrEvtSource */
            CSL_EPWM_ET_INTR_PERIOD_FIRST_EVT   /* intrPrd */
        }
    }
};

static PWM_Obj_t pwmCpBtn_Obj =
{
    PWM_CPBTN_OUTPUT_CH,                      /* pwmCh */
    PWM_CPBTN_BASE_ADDR,                      /* instAddr */
    PWM_MODULE_FREQ,                            /* funcClk */
    FALSE,                                      /* enableDeadband */
    FALSE,                                      /* enableChopper */
    FALSE,                                      /* enableTripzone */
    FALSE,                                      /* enableEventTrigger */
    FALSE,                                      /* enableHighResolution */
    /* PWM_Cfg_t*/
    {
        /* CSL_EpwmTimebaseCfg_t */
        {
            PWM_TIMEBASE_FREQ,                  /* tbClk */
            PWM_OUT_FREQ,                       /* pwmtbCounterFreqPrd */
            CSL_EPWM_TB_COUNTER_DIR_UP,    /* tbCntrDirection */
            FALSE,                              /* enableSynchronization */
            PWMSS_EPWM_TBCTL_PHSDIR_COUNT_UP,   /* cntDirAfterSync */
            0U,                                 /* phsCountAfterSync */
            PWMSS_EPWM_TBCTL_SYNCOSEL_EPWMXSYNC /* syncOutSrc */
        },
        /* CSL_EpwmCounterCmpCfg_t */
        {
            PWM_DEFAULT_COMPARE_VAL,                    /* cmpAValue */
            PWM_DEFAULT_COMPARE_VAL                     /* cmpBValue */
        },
        /* CSL_EpwmAqActionCfg_t */
        {
            CSL_EPWM_AQ_ACTION_LOW,             /* zeroAction */
            CSL_EPWM_AQ_ACTION_DONOTHING,       /* prdAction */
            CSL_EPWM_AQ_ACTION_DONOTHING,       /* cmpAUpAction */
            CSL_EPWM_AQ_ACTION_DONOTHING,       /* cmpADownAction */
            CSL_EPWM_AQ_ACTION_HIGH,            /* cmpBUpAction */
            CSL_EPWM_AQ_ACTION_DONOTHING        /* cmpBDownAction */
        },
        /* CSL_EpwmDeadbandCfg_t */
        {
            CSL_EPWM_DB_IN_MODE_A_RED_A_FED,    /* inputMode */
            CSL_EPWM_DB_OUT_MODE_BYPASS,        /* outputMode */
            CSL_EPWM_DB_POL_SEL_ACTV_HIGH,      /* polaritySelect */
            0U,                                 /* risingEdgeDelay */
            0U                                  /* fallingEdgeDelay */
        },
        /* CSL_EpwmChopperCfg_t */
        {
            CSL_EPWM_CHP_DUTY_CYCLE_PERC_12PNT5,    /* dutyCycle */
            CSL_EPWM_CHP_CLK_FREQ_DIV_BY_1,         /* clkFrequency */
            CSL_EPWM_CHP_OSHT_WIDTH_1XSYSOUT_BY_8   /* oneShotPulseWidth */
        },
        /* CSL_EpwmTripzoneCfg_t */
        {
            CSL_EPWM_TZ_TRIP_ACTION_DO_NOTHING, /* tripAction */
            CSL_EPWM_TZ_EVENT_ONE_SHOT,         /* tripEvtType */
            0U,                                 /* tripPin */
            FALSE                               /* enableTripIntr */
        },
        /* CSL_EpwmEtCfg_t */
        {
            CSL_EPWM_ET_INTR_EVT_CNT_EQ_ZRO,    /* intrEvtSource */
            CSL_EPWM_ET_INTR_PERIOD_FIRST_EVT   /* intrPrd */
        }
    }
};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void DIMMING_ConfigChannel (Dim_Channel_T channel, uint32_t cmpValue);
//static void DIMMING_SetEnable (Dim_Channel_T channel, uint32_t lvl);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/***************************************************************************//**
*
* @fn         DIMMING_Init
*
* @brief      Function to initialize the PWM related registers.
*
* @param [in] None
*
* @return     None
*
******************************************************************************/
void DIMMING_Init (void)
{
    uint8_t i;

    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_Init -3- \r\n");

    dimming_sem = Semaphore_create(1, NULL, NULL);

    dimming_lvl = DIMMING_DEFAULT_LEVEL;

    DIMMING_InitChannel(DIM_DISP);
    DIMMING_InitChannel(DIM_ONKEY);
    DIMMING_InitChannel(DIM_CPBTN);

    for( i = 0; i < DIM_NUM_CHANNELS; i++ )
    {
        dim_channel_status[i] = 0;
    }
}

/***************************************************************************//**
*
* @fn           DIMMING_SetLevel_CAN
*
* @brief        Set dimming level for all channels with
*               internalLightLevel CAN signal value.
*
* @param [in]   uint8_t InternalLightLevel
* @param [in]   uint8_t InternalLightSts
*
* @return       None
*
******************************************************************************/
void DIMMING_SetLevel_CAN( uint8_t InternalLightLevel, uint8_t InternalLightSts )
{
    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_SetLevel_CAN\r\n");

    if(InternalLightSts)
    {
        if( InternalLightLevel < (NUM_DIMMING_LEVELS-1) )
        {
            DIMMING_SetDimmingLevel(InternalLightLevel + 1);    /* The minimum dimming CAN signal belongs to the level 1 */
        }
        else
        {
            DIMMING_SetDimmingLevel(DIMMING_MAX_LEVEL);
        }
    }
    else
    {
        DIMMING_SetDimmingLevel(DIMMING_MAX_LEVEL);
    }
}

/***************************************************************************//**
*
* @fn         DIMMING_GetLimits_ES
*
* @brief      Getter of level limits for ES.
*
* @param [in] uint8_t * Min
* @param [in] uint8_t * Max
*
* @return     None
*
******************************************************************************/
void DIMMING_GetLimits_ES (uint8_t * Min, uint8_t * Max)
{
    *Min = DIMMING_MIN_LEVEL_ES;
    *Max = DIMMING_MAX_LEVEL_ES;
}

/***************************************************************************//**
*
* @fn           DIMMING_SetLevel_ES
*
* @brief        Set dimming level for all channels with
*               internalLightLevel ES signal value.
*
* @param [in]   uint8_t InternalLightSts
*
* @return       None
*
******************************************************************************/
void DIMMING_SetLevel_ES( uint8_t InternalLightLevel, uint8_t level )
{
    LOG_PRINT_INFO(1, "DIMMING_SetLevel_ES | InternalLightLevel: %d\r\n", InternalLightLevel);

    if (level == 0) {
        /* DAY MODE */
        DIMMING_SetDimmingLevel(DIMMING_MAX_LEVEL_ES);
    } else if (level == 100) {
        /* NIGHT MODE */
        DIMMING_SetDimmingLevel(DIMMING_MIN_LEVEL_ES);
    } else {
        /* NIGHT MODE */
        DIMMING_SetDimmingLevel(InternalLightLevel);
    }
}

/***************************************************************************//**
*
* @fn         DIMMING_SetLevel
*
* @brief     Configure the PWM for the required dimming level for all channels
*
* @param [in] lvl - Dimmming level from 0% to 100%
*
* @return     None
*
******************************************************************************/
void DIMMING_SetLevel (Dim_Channel_T channel, uint32_t lvl)
{
    uint32_t cmpValue;

    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_SetLevel: channel %d level %d\r\n", channel, lvl);

    switch(channel)
    {
        case DIM_DISP:
            if(lvl == 0)
            {
                GPIOPinWrite(DIMM_DISP_CTRL_GPIO_ADDR, DIMM_DISP_CTRL_GPIO_PIN, GPIO_PIN_LOW);
            }
            else
            {
                GPIOPinWrite(DIMM_DISP_CTRL_GPIO_ADDR, DIMM_DISP_CTRL_GPIO_PIN, GPIO_PIN_HIGH);
            }
            break;

        case DIM_ONKEY:
            Board_CheckDimmingClock();
            break;

        case DIM_CPBTN:
            Board_CheckDimmingClock();
            if(lvl == 0)
            {
                GPIOPinWrite(DIMM_ENC2_CTRL_GPIO_ADDR, DIMM_ENC2_CTRL_GPIO_PIN, GPIO_PIN_LOW);
            }
            else
            {
                GPIOPinWrite(DIMM_ENC2_CTRL_GPIO_ADDR, DIMM_ENC2_CTRL_GPIO_PIN, GPIO_PIN_HIGH);
            }
            break;

        default:
            break;
    }

    cmpValue = (PWM_PERIOD_VAL - ((dimmingLevel[lvl][channel] * PWM_PERIOD_VAL) / dimmingMaxLevel[channel]));    /* Calculate the comparisson pwm value*/
    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_SetLevel: %d\r\n", cmpValue);
    DIMMING_ConfigChannel(channel, cmpValue);
}

/***************************************************************************//**
*
* @fn         DIMMING_SetEnableGPIO
*
* @brief     Enable or disable the GPIO enable associated with the channel
*
* @param [in]   channel - Channel to change
*               lvl - Dimmming level from 0% to 100%
*
* @return     None
*
******************************************************************************/
static void DIMMING_SetEnableGPIO (Dim_Channel_T channel, uint32_t lvl)
{
    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_SetLevel: channel %d level %d\r\n", channel, lvl);

    switch(channel)
    {
        case DIM_DISP:
            if(lvl == 0)
            {
                GPIOPinWrite(DIMM_DISP_CTRL_GPIO_ADDR, DIMM_DISP_CTRL_GPIO_PIN, GPIO_PIN_LOW);
            }
            else
            {
                GPIOPinWrite(DIMM_DISP_CTRL_GPIO_ADDR, DIMM_DISP_CTRL_GPIO_PIN, GPIO_PIN_HIGH);
            }
            break;

        case DIM_ONKEY:
            break;

        case DIM_CPBTN:
            if(lvl == 0)
            {
                GPIOPinWrite(DIMM_ENC2_CTRL_GPIO_ADDR, DIMM_ENC2_CTRL_GPIO_PIN, GPIO_PIN_LOW);
            }
            else
            {
                GPIOPinWrite(DIMM_ENC2_CTRL_GPIO_ADDR, DIMM_ENC2_CTRL_GPIO_PIN, GPIO_PIN_HIGH);
            }
            break;

        default:
            break;
    }
}

/***************************************************************************//**
*
* @fn         DIMMING_SetChannelOn
*
* @brief      Set the dimming to the current configure level
*
* @param [in] channel
*
* @return     None
*
******************************************************************************/
void DIMMING_SetChannelOn (Dim_Channel_User_T user, Dim_Channel_T channel)
{
    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_SetChannelOn %d\r\n", channel);

    if( channel < DIM_NUM_CHANNELS )
    {
        dim_channel_status[channel] |= (1<<user);
        DIMMING_SetLevel(channel, dimming_lvl);
    }
}

/***************************************************************************//**
*
* @fn         DIMMING_SetChannelOff
*
* @brief      Set the dimming to 0% the channel dimming
*
* @param [in] channel
*
* @return     None
*
******************************************************************************/
void DIMMING_SetChannelOff (Dim_Channel_User_T user, Dim_Channel_T channel)
{
    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_SetChannelOff %d\r\n", channel);

    if( channel < DIM_NUM_CHANNELS )
    {
        dim_channel_status[channel] &= ~(1<<user);
        if (0 == dim_channel_status[channel])
        {
            DIMMING_SetLevel(channel, DIMMING_MIN_LEVEL);
        }
    }
}

/***************************************************************************//**
*
* @fn         DIMMING_SetDimmingLevel
*
* @brief      Configure the dimming level
*
* @param [in] lvl - Dimmming level from 0% to 100%
*
* @return     None
*
******************************************************************************/
void DIMMING_SetDimmingLevel (uint32_t lvl)
{
    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_SetDimmingLevel %d\r\n", lvl);

    dimming_lvl = lvl;

    if(dim_channel_status[DIM_DISP])
    {
        DIMMING_SetLevel(DIM_DISP, dimming_lvl);
    }

    if(dim_channel_status[DIM_ONKEY])
    {
        DIMMING_SetLevel(DIM_ONKEY, dimming_lvl);
    }

    if(dim_channel_status[DIM_CPBTN])
    {
        DIMMING_SetLevel(DIM_CPBTN, dimming_lvl);
    }
}

/***************************************************************************//**
*
* @fn         DIMMING_InitChannel
*
* @brief      Start the timer related pwm channel
*
* @param [in] channel
*
* @return     None
*
******************************************************************************/
void DIMMING_InitChannel (Dim_Channel_T channel)
{
    PWM_Obj_t *pObj;

    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_StartChannel\r\n");

    Semaphore_pend(dimming_sem, BIOS_WAIT_FOREVER);
    switch(channel)
    {
        case DIM_DISP:
//            pObj = &pwmDisplay_Obj;
//            PWM_ChannelStart(pObj);
            GPIOModuleEnable(DIMM_DISP_CTRL_GPIO_ADDR);
            GPIODirModeSet(DIMM_DISP_CTRL_GPIO_ADDR, DIMM_DISP_CTRL_GPIO_PIN, GPIO_DIR_OUTPUT);
            GPIOPinWrite(DIMM_DISP_CTRL_GPIO_ADDR, DIMM_DISP_CTRL_GPIO_PIN, GPIO_PIN_LOW);
            break;

        case DIM_ONKEY:
            Board_CheckDimmingClock();
            pObj = &pwmOnKey_Obj;
            PWM_ChannelStart(pObj);
            break;

        case DIM_CPBTN:
            Board_CheckDimmingClock();
            pObj = &pwmCpBtn_Obj;
            PWM_ChannelStart(pObj);
            GPIOModuleEnable(DIMM_ENC2_CTRL_GPIO_ADDR);
            GPIODirModeSet(DIMM_ENC2_CTRL_GPIO_ADDR, DIMM_ENC2_CTRL_GPIO_PIN, GPIO_DIR_OUTPUT);
            GPIOPinWrite(DIMM_ENC2_CTRL_GPIO_ADDR, DIMM_ENC2_CTRL_GPIO_PIN, GPIO_PIN_LOW);
            break;

        default:
            break;
    }
    Semaphore_post(dimming_sem);
}

/***************************************************************************//**
*
* @fn         DIMMING_Refresh_Level
*
* @brief      Refresh the current value of the enable gpio in the channel. If the channel is not
*             enabled then disable it again
*
* @param [in] channel
*
* @return     None
*
* NOTE: This is needed to avoid a problem when restoring the context from hibernation, the
*       GPIOs values are also restored even when the are managed by the M4.
*       So we need to refresh the GPIO state with the correct value.
*       A glitch can be seen when measuring with an oscilloscope, but there is
*       no visual effect.
*
******************************************************************************/
void DIMMING_Refresh_Level(Dim_Channel_User_T user, Dim_Channel_T channel)
{
    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_Refresh_Level %d\r\n", channel);
    if(dim_channel_status[channel]) {
        DIMMING_SetEnableGPIO (channel, dimming_lvl);
    } else {
        DIMMING_SetEnableGPIO (channel, DIMMING_MIN_LEVEL);
    }
}


/***************************************************************************//**
*
* @fn         DIMMING_CloseChannel
*
* @brief      Stop the timer related pwm channel
*
* @param [in] channel
*
* @return     None
*
******************************************************************************/
void DIMMING_CloseChannel (Dim_Channel_T channel)
{
    PWM_Obj_t *pObj;

    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_StopChannel %d\r\n", channel);

    Semaphore_pend(dimming_sem, BIOS_WAIT_FOREVER);
    switch(channel)
    {
        case DIM_DISP:
//            pObj = &pwmDisplay_Obj;
//            PWM_ChannelStop(pObj);
            GPIOModuleEnable(DIMM_DISP_CTRL_GPIO_ADDR);
            GPIODirModeSet(DIMM_DISP_CTRL_GPIO_ADDR, DIMM_DISP_CTRL_GPIO_PIN, GPIO_DIR_OUTPUT);
            GPIOPinWrite(DIMM_DISP_CTRL_GPIO_ADDR, DIMM_DISP_CTRL_GPIO_PIN, GPIO_PIN_LOW);
            break;

        case DIM_ONKEY:
            pObj = &pwmOnKey_Obj;
            PWM_ChannelStop(pObj);
            break;

        case DIM_CPBTN:
            pObj = &pwmCpBtn_Obj;
            PWM_ChannelStop(pObj);
            GPIOModuleEnable(DIMM_ENC2_CTRL_GPIO_ADDR);
            GPIODirModeSet(DIMM_ENC2_CTRL_GPIO_ADDR, DIMM_ENC2_CTRL_GPIO_PIN, GPIO_DIR_OUTPUT);
            GPIOPinWrite(DIMM_ENC2_CTRL_GPIO_ADDR, DIMM_ENC2_CTRL_GPIO_PIN, GPIO_PIN_LOW);
            break;

        default:
            break;
    }
    Semaphore_post(dimming_sem);
}

/***************************************************************************//**
*
* @fn         DIMMING_ConfigChannel
*
* @brief      Configure the related pwm channel
*
* @param [in] channel
*
* @return     None
*
******************************************************************************/
static void DIMMING_ConfigChannel (Dim_Channel_T channel, uint32_t cmpValue)
{
    PWM_Obj_t *pObj;

    LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_ConfigChannel %d, lvl %d\r\n", channel, cmpValue);

    Semaphore_pend(dimming_sem, BIOS_WAIT_FOREVER);
    switch(channel)
    {
        case DIM_DISP:
//            cmpValueDisplay = cmpValue;
//            pObj = &pwmDisplay_Obj;
//            pObj->pwmCfg.ccCfg.cmpAValue = cmpValueDisplay;
//            pObj->pwmCfg.ccCfg.cmpBValue = cmpValueDisplay;
            break;

        case DIM_ONKEY:
            cmpValueOnKey = cmpValue;
            pObj = &pwmOnKey_Obj;

            if (PWM_DEFAULT_COMPARE_VAL == cmpValue)
            {
                pObj->pwmCfg.aqCfg.cmpAUpAction = CSL_EPWM_AQ_ACTION_DONOTHING;
            }
            else
            {
                pObj->pwmCfg.aqCfg.cmpAUpAction = CSL_EPWM_AQ_ACTION_HIGH;
            }
            pObj->pwmCfg.ccCfg.cmpAValue = cmpValueOnKey;
            pObj->pwmCfg.ccCfg.cmpBValue = cmpValueCpBtn;
            LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_ConfigChannel A: %d\r\n", pObj->pwmCfg.ccCfg.cmpAValue);
            LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_ConfigChannel B: %d\r\n", pObj->pwmCfg.ccCfg.cmpBValue);
            PWM_ChannelConfig(pObj);                    /* EPWM channel configuration */
            break;

        case DIM_CPBTN:
            cmpValueCpBtn = cmpValue;
            pObj = &pwmCpBtn_Obj;
            if (PWM_DEFAULT_COMPARE_VAL == cmpValue)
            {
                pObj->pwmCfg.aqCfg.cmpBUpAction = CSL_EPWM_AQ_ACTION_DONOTHING;
            }
            else
            {
                pObj->pwmCfg.aqCfg.cmpBUpAction = CSL_EPWM_AQ_ACTION_HIGH;
            }
            pObj->pwmCfg.ccCfg.cmpAValue = cmpValueOnKey;
            pObj->pwmCfg.ccCfg.cmpBValue = cmpValueCpBtn;
            LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_ConfigChannel A: %d\r\n", pObj->pwmCfg.ccCfg.cmpAValue);
            LOG_PRINT_INFO(DEBUG_DIMMING, "DIMMING_ConfigChannel B: %d\r\n", pObj->pwmCfg.ccCfg.cmpBValue);
            PWM_ChannelConfig(pObj);                    /* EPWM channel configuration */
            break;

        default:
            break;
    }
    Semaphore_post(dimming_sem);
}
