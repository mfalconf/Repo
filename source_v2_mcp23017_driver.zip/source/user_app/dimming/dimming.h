#ifndef DIMMING_H_
#define DIMMING_H_
/*===========================================================================*/
/**
 * @file DIMMING.h
 *
 * Function definitions for the DIMMING interface module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum Dim_Channel_Tag
{
   DIM_DISP,
   DIM_ONKEY,
   DIM_CPBTN,

   DIM_NUM_CHANNELS
} Dim_Channel_T;

typedef enum Dim_Channel_User_Tag
{
    DIM_USER_A,
    DIM_USER_B,
    DIM_USER_C,
    DIM_USER_D,
}Dim_Channel_User_T;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
void DIMMING_Init (void);
void DIMMING_SetLevel_CAN( uint8_t InternalLightLevel, uint8_t InternalLightSts );
void DIMMING_GetLimits_ES (uint8_t * Min, uint8_t * Max);
void DIMMING_SetLevel_ES ( uint8_t InternalLightLevel, uint8_t level );
void DIMMING_SetLevel (Dim_Channel_T channel, uint32_t lvl);
void DIMMING_SetChannelOn (Dim_Channel_User_T user, Dim_Channel_T channel);
void DIMMING_SetChannelOff (Dim_Channel_User_T user, Dim_Channel_T channel);
void DIMMING_SetDimmingLevel (uint32_t lvl);
void DIMMING_InitChannel (Dim_Channel_T channel);
void DIMMING_Refresh_Level(Dim_Channel_User_T user, Dim_Channel_T channel);
void DIMMING_CloseChannel (Dim_Channel_T channel);


#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file DIMMING.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 28-Jun-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* DIMMING_H_ */
