//  MCP23017 library

#ifndef _MCP23017_H_
#define _MCP23017_H_

#include <standard.h>

//Register defines from data sheet - we set IOCON.BANK to 0
//as it is easier to manage the registers sequentially.
#define MCP23X17_REG_DEFAULT_IOCON 0x05
#define MCP23X17_REG_IODIR 0x00
#define MCP23X17_REG_IPOL 0x02
#define MCP23X17_REG_GPINTEN 0x04
#define MCP23X17_REG_DEFVAL 0x06
#define MCP23X17_REG_INTCON 0x08
#define MCP23X17_REG_IOCON 0x0A
#define MCP23X17_REG_GPPU 0x0C
#define MCP23X17_REG_INTF 0x0E
#define MCP23X17_REG_INTCAP 0x10
#define MCP23X17_REG_GPIO 0x12
#define MCP23X17_REG_OLAT 0x14

//IOCON Bit definition
#define MCP23X17_IOCON_BANK 7
#define MCP23X17_IOCON_MIRROR 6
#define MCP23X17_IOCON_SEQOP 5
#define MCP23X17_IOCON_DISSLW 4
#define MCP23X17_IOCON_HAEN 3
#define MCP23X17_IOCON_ODR 2
#define MCP23X17_IOCON_INTPOL 1

#define MCP23017_BASE_ADDRESS 0x20

#define MCP23X17_INIT_VAL_REG_IODIR 0xFFFF
#define MCP23X17_INIT_VAL_REG_IPOL 0x0000
#define MCP23X17_INIT_VAL_REG_GPINTEN 0x0000
#define MCP23X17_INIT_VAL_REG_DEFVAL 0x0000
#define MCP23X17_INIT_VAL_REG_INTCON 0x0000
#define MCP23X17_INIT_VAL_REG_IOCON ((1 << MCP23X17_IOCON_MIRROR) | (1 << MCP23X17_IOCON_SEQOP))
#define MCP23X17_INIT_VAL_REG_GPPU 0x0000
#define MCP23X17_INIT_VAL_REG_GPIO 0x0000

/**
 * GPIO mode
 */
typedef enum
{
    MCP23X17_GPIO_OUTPUT = 0,
    MCP23X17_GPIO_INPUT
} mcp23x17_gpio_mode_t;

typedef struct
{
  uint8_t Address;

  uint16_t IOCON;
  uint16_t IODIR;
  uint16_t IPOL;
  uint16_t GPINTEN;
  uint16_t DEFVAL;
  uint16_t INTCON;
  uint16_t GPPU;
  uint16_t GPIO;
} mcp23x17_dev_t;

//The i2c address here is the value of the A0, A1, A2 pins ONLY
//as the function takes care of its internal base address.
//So i2cAddress should be between 0 and 7
bool MCP23017_Init(mcp23x17_dev_t *dev, uint8_t i2cAddress);
//These functions provide functionality for accessing pin states/pullups etc.
bool MCP23017_PinMode(mcp23x17_dev_t *dev, uint8_t pin, mcp23x17_gpio_mode_t mode);
bool MCP23017_DigitalPinRead(mcp23x17_dev_t *dev, uint8_t pin, uint8_t *pinVal);
bool MCP23017_DigitalPinWrite(mcp23x17_dev_t *dev, uint8_t pin, uint8_t pinVal);

//These provide a more advanced mapping of the chip functionality
//See the data sheet for more information on what they do

//Returns a word with the current pin states (ie contents of the GPIO register)
bool MCP23017_DigitalPortRead(mcp23x17_dev_t *dev, uint16_t *gpio);
//Allows you to write a word to the GPIO register
bool MCP23017_DigitalPortWrite(mcp23x17_dev_t *dev, uint16_t w);

//Set IO Control mode
bool MCP23017_ConfigIOControlRegister(mcp23x17_dev_t *dev, uint16_t regVal);
//Sets up the polarity mask that the MCP23017 supports
//if set to 1, it will flip the actual pin value.
bool MCP23017_ConfigInputPolarityMaskRegister(mcp23x17_dev_t *dev, uint16_t mask);
//Sets which pins are inputs or outputs (1 = input, 0 = output)
bool MCP23017_ConfigInputOutputMaskRegister(mcp23x17_dev_t *dev, uint16_t mask);
//Allows enabling of the internal 100k pullup resisters (1 = enabled, 0 = disabled)
bool MCP23017_ConfigInternalPullupMaskRegister(mcp23x17_dev_t *dev, uint16_t mask);

bool MCP23017_ConfigInterruptOnChangeMaskRegister(mcp23x17_dev_t *dev, uint16_t mask);
bool MCP23017_ConfigDefaultCompareValueRegister(mcp23x17_dev_t *dev, uint16_t defVal);
bool MCP23017_ConfigInterruptOnChangeControlMaskRegister(mcp23x17_dev_t *dev, uint16_t mask);
bool MCP23017_ReadInterruptFlagRegister(mcp23x17_dev_t *dev, uint16_t *regVal);
bool MCP23017_ReadInterruptCaptureRegister(mcp23x17_dev_t *dev, uint16_t *regVal);

#endif //_MCP23017_H_
