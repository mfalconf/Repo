#include <user_app/comm_interface/comm_interface.h>
#include "MCP23017.h"

#define BitSet(x, bit) (x | (1 << bit))
#define BitClear(x ,bit) (x & ~(1 << bit))

#define WritePinAndUpdate(addr, reg, pin, condition, reg_update, result) do {                                                    \
                                                                           uint16_t x = reg_update;                              \
                                                                           x = condition ? BitSet(x, pin) : BitClear(x, pin);    \
                                                                           bool eval = MCP23017_WriteWordRegister(addr, reg, x); \
                                                                           if(eval) {                                            \
                                                                             reg_update = x;                                     \
                                                                           }                                                     \
                                                                           result = eval;                                        \
                                                                         } while(0)

#define WriteWordAndUpdate(addr, reg, value, reg_update, result) do {                                                        \
                                                                   bool eval = MCP23017_WriteWordRegister(addr, reg, value); \
                                                                   if(eval) {                                                \
                                                                     reg_update = value;                                     \
                                                                   }                                                         \
                                                                   result = eval;                                            \
                                                                 } while(0)

#define I2cTransfer_Write(addr, reg, data, data_size) COMM_TransferI2C(addr, reg, data_size, 0, data)

#define I2cTransfer_Read(addr, reg, data, data_size) COMM_TransferI2C(addr, reg, 0, data_size, data)

extern void IOExpander_Callback(uint16_t value);

//IO Expander Service routine
ISR (PCINT2_vect)
{
  uint16_t value;
  
  //wdt_reset(); //Kick the watchdog timer  
  if(!(PINC&(1<<PINC7))) //Si hay un cambio en el pin PC7 y es cero logico, indica un cambio en la salida de interrupcion del IOExpander
  {
    MCP23017_ReadInterruptCaptureRegister((uint16_t *)&value); //Obtengo el valor capturado y limpio el flag de interrupcion en el chip IOExpander
	  IOExpander_Callback(value);
  }  
}

//i2cAddress = 0..7
//Default mode: All input
bool MCP23017_Init(mcp23x17_dev_t *dev, uint8_t i2cAddress)
{
  dev->Address = (MCP23017_BASE_ADDRESS | (i2cAddress&0x07)) << 1;

  uint16_t reg_val_list[] = {
    MCP23X17_INIT_VAL_REG_INTCON,
    MCP23X17_INIT_VAL_REG_IODIR,
    MCP23X17_INIT_VAL_REG_IPOL,
    MCP23X17_INIT_VAL_REG_GPINTEN,
    MCP23X17_INIT_VAL_REG_DEFVAL, 
    MCP23X17_INIT_VAL_REG_IOCON,
    MCP23X17_INIT_VAL_REG_GPPU,
    MCP23X17_INIT_VAL_REG_GPIO
  };

  uint8_t reg_list[] = {
    MCP23X17_REG_INTCON,
    MCP23X17_REG_IODIR,
    MCP23X17_REG_IPOL,
    MCP23X17_REG_GPINTEN,
    MCP23X17_REG_DEFVAL, 
    MCP23X17_REG_IOCON,
    MCP23X17_REG_GPPU,
    MCP23X17_REG_GPIO
  };

  int total_regs = sizeof(reg_list) / sizeof(uint8_t);

  uint16_t *p_reg = &dev->IOCON;

  for(int i = 0; i < total_regs; i++) 
  {
    bool result;
    
    WriteWordAndUpdate(dev->Address, reg_list[i], reg_val_list[i], *p_reg, result);
    if(!result) {
      return false;
    }
    p_reg++;
  }
  return true;
}

bool MCP23017_PinMode(mcp23x17_dev_t *dev, uint8_t pin, mcp23x17_gpio_mode_t mode) 
{
  bool result;
  
  WritePinAndUpdate(dev->Address, MCP23X17_REG_IODIR, pin, (mode == MCP23X17_GPIO_INPUT), dev->IODIR, result);
  return result;
}

bool MCP23017_DigitalPinRead(mcp23x17_dev_t *dev, uint8_t pin, uint8_t *pinVal) 
{
  uint16_t gpio;

  if(MCP23017_ReadRegister(dev->Address, MCP23X17_REG_GPIO, &gpio))
  {
    dev->GPIO = gpio;
    *pinVal = (gpio & (1 << pin))? 1 : 0;
	  return true;    
  }
  return false;
}

bool MCP23017_DigitalPinWrite(mcp23x17_dev_t *dev, uint8_t pin, uint8_t pinVal) 
{
  //If this pin is an INPUT pin, a write here will enable the internal pullup
  //otherwise, it will set the OUTPUT voltage as appropriate.
  uint8_t is_input = (dev->IODIR & (1 << pin));
  bool result;

  if(is_input)
  {
    WritePinAndUpdate(dev->Address, MCP23X17_REG_GPPU, pin, pinVal, dev->GPPU, result);
	}
  else 
  {
	  WritePinAndUpdate(dev->Address, MCP23X17_REG_GPIO, pin, pinVal, dev->GPIO, result);
  }
  return result;
}

bool MCP23017_DigitalPortRead(mcp23x17_dev_t *dev, uint16_t *gpio) 
{
  if(MCP23017_ReadRegister(dev->Address, MCP23X17_REG_GPIO, gpio))
  {
    dev->GPIO = *gpio;
    return true;    
  }
  return false;
}

bool MCP23017_DigitalPortWrite(mcp23x17_dev_t *dev, uint16_t w)
{
  bool result;

  WriteWordAndUpdate(dev->Address, MCP23X17_REG_GPIO, w, dev->GPIO, result);
  return result;
}

bool MCP23017_ConfigIOControlRegister(mcp23x17_dev_t *dev, uint16_t regVal)
{
  bool result;

  WriteWordAndUpdate(dev->Address, MCP23X17_REG_IOCON, regVal, dev->IOCON, result);
  return result;
}


bool MCP23017_ConfigInputPolarityMaskRegister(mcp23x17_dev_t *dev, uint16_t mask) 
{
  bool result;

  WriteWordAndUpdate(dev->Address, MCP23X17_REG_IPOL, mask, dev->IPOL, result);
  return result;
}

bool MCP23017_ConfigInputOutputMaskRegister(mcp23x17_dev_t *dev, uint16_t mask) 
{
  bool result;

  WriteWordAndUpdate(dev->Address, MCP23X17_REG_IODIR, mask, dev->IODIR, result);
  return result;
}

bool MCP23017_ConfigInternalPullupMaskRegister(mcp23x17_dev_t *dev, uint16_t mask) 
{
  bool result;
  
  WriteWordAndUpdate(dev->Address, MCP23X17_REG_GPPU, mask, dev->GPPU, result);
  return result;
}

bool MCP23017_ConfigInterruptOnChangeMaskRegister(mcp23x17_dev_t *dev, uint16_t mask) 
{
  bool result;
  
  WriteWordAndUpdate(dev->Address, MCP23X17_REG_GPINTEN, mask, dev->GPINTEN, result);
  return result;
}

bool MCP23017_ConfigDefaultCompareValueRegister(mcp23x17_dev_t *dev, uint16_t defVal)
{
  bool result;
  
  WriteWordAndUpdate(dev->Address, MCP23X17_REG_DEFVAL, defVal, dev->DEFVAL, result);
  return result;
}

bool MCP23017_ConfigInterruptOnChangeControlMaskRegister(mcp23x17_dev_t *dev, uint16_t mask) 
{
  bool result;
  
  WriteWordAndUpdate(dev->Address, MCP23X17_REG_INTCON, mask, dev->INTCON, result);
  return result;
}

bool MCP23017_ReadInterruptFlagRegister(mcp23x17_dev_t *dev, uint16_t *regVal) 
{
  return MCP23017_ReadRegister(dev->Address, MCP23X17_REG_INTF, regVal);
}

bool MCP23017_ReadInterruptCaptureRegister(mcp23x17_dev_t *dev, uint16_t *regVal) 
{
  return MCP23017_ReadRegister(dev->Address, MCP23X17_REG_INTCAP, regVal);
}

/////////// Low level Access Functions //////////////

static bool MCP23017_WriteByteRegister(uint8_t i2cAddress, uint8_t regAddress, uint8_t data)
{
  return (-1 != I2cTransfer_Write(i2cAddress, regAddress, &data, 1));
}

static bool MCP23017_WriteWordRegister(uint8_t i2cAddress, uint8_t regAddress, uint16_t data)
{
  uint8_t buf[2] = {(uint8_t) (data >> 8), (uint8_t) data};
  
  return (-1 != I2cTransfer_Write(i2cAddress, regAddress, buf, 2));
}

static bool MCP23017_ReadRegister(uint8_t i2cAddress, uint8_t regAddress, uint16_t *word)
{
  uint8_t buf[2];
 
  if(-1 != -I2cTransfer_Read(i2cAddress, regAddress, buf, 2)) 
  {
    *word = (buf[0] << 8) | buf[1];
    return true;
  }

  return false;
} 
