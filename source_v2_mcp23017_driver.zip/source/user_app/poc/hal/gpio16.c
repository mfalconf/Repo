#include <user_app/poc/drivers/MCP23017.h>
#include "gpio16.h"

#define MaskSet(x, mask) (x | mask)
#define MaskClear(x ,mask) (x & ~(mask))

typedef struct {
  volatile uint16_t last_read_value;
  GPIO16_cb_t cb;
  mcp23x17_dev_t dev;
} GPIO16_t;

static GPIO16_t gpio16_params;

typedef void (*GPIO16_cb_t)(uint16_t regVal);

bool GPIO16_Init(uint8_t addr)
{
  return MCP23017_Init(&gpio16_params.dev, addr);
}

bool GPIO16_SetupIOModeMask(uint16_t outMask, uint16_t inPullupMask)
{
  //outMask -> out = 1, in = 0
  uint16_t mask = ~outMask;
  if(MCP23017_ConfigInputOutputMaskRegister(&gpio16_params.dev, mask))
  {
    if(MCP23017_ConfigInternalPullupMaskRegister(&gpio16_params.dev, inPullupMask))
    {
      return true;
    }
  }
  return false;
}

bool GPIO16_SetupIntSource(uint16_t sourceMask, gpio16_int_mode_t intMode, gpio16_int_out_mode_t intOutMode, GPIO16_cb_t cb)
{
  uint16_t gpinten = gpio16_params.dev.GPINTEN;
  if(intMode == GPIO16_INT_DISABLED)
  {
    // disable interrupts
    gpinten = MaskClear(gpinten, sourceMask);
    if(MCP23017_ConfigInterruptOnChangeMaskRegister(&gpio16_params.dev, gpinten))
    {
      gpio16_params.cb = NULL;
      return true;
    }
    return false;
  }

  uint16_t intcon = gpio16_params.dev.INTCON;
  if(intMode == GPIO16_INT_ANY_EDGE) 
  { 
    intcon = MaskClear(intcon, sourceMask);
  }
  else
  {
    intcon = MaskSet(intcon, sourceMask);

    uint16_t defval = gpio16_params.dev.DEFVAL;
    
    defval = (intMode == GPIO16_INT_LOW_EDGE)? MaskSet(defval, sourceMask) : MaskClear(defval, sourceMask);
    if(!MCP23017_ConfigDefaultCompareValueRegister(&gpio16_params.dev, defval))
    {
      return false;
    }
  }
  
  if(!MCP23017_ConfigInterruptOnChangeControlMaskRegister(&gpio16_params.dev, intcon))
  {
    return false;
  }
  
  // enable interrupts
  gpinten = MaskSet(gpinten, sourceMask);
  if(!MCP23017_ConfigInterruptOnChangeMaskRegister(&gpio16_params.dev, gpinten))
  {
    return false;
  }

  uint16_t iocon = gpio16_params.dev.IOCON;
  if(intOutMode == GPIO16_OPEN_DRAIN)
  {
    iocon |= (1 << MCP23X17_IOCON_ODR);
    return MCP23017_ConfigIOControlRegister(&gpio16_params.dev, iocon); 
  }

  uint16_t mask = (1 <<  MCP23X17_IOCON_ODR) | (1 << MCP23X17_IOCON_INTPOL);
  iocon = MaskClear(iocon, mask);
  if(intOutMode == GPIO16_ACTIVE_HIGH) 
  {
    iocon |= (1 << MCP23X17_IOCON_INTPOL);
  }
  
  if(!MCP23017_ConfigIOControlRegister(&gpio16_params.dev, iocon))
  {
    return false;
  }
  gpio16_params.cb = cb;
  return true;
}

bool GPIO16_Read(uint16_t *gpioVal)
{
  if(CP23017_DigitalPortRead(&gpio16_params.dev, gpioVal))
  {
    gpio16_params.last_read_value = *gpioVal;
    return true;
  }
  return false;
}

bool GPIO16_Write(uint16_t gpioVal)
{
  return MCP23017_DigitalPortWrite(&gpio16_params.dev, gpioVal);
}

uint16_t GPIO16_GetLastReadValue()
{
  return gpio16_params.last_read_value;
}