#ifndef _GPIO16_H_
#define _GPIO16_H_

#include <standard.h>

/**
 * INTA/INTB pins mode
 */
typedef enum
{
    GPIO16_ACTIVE_LOW = 0, //!< Low level on interrupt
    GPIO16_ACTIVE_HIGH,    //!< High level on interrupt
    GPIO16_OPEN_DRAIN      //!< Open drain
} gpio16_int_out_mode_t;

/**
 * Interrupt mode
 */
typedef enum
{
    GPIO16_INT_DISABLED = 0, //!< No interrupt
    GPIO16_INT_LOW_EDGE,     //!< Interrupt on low edge
    GPIO16_INT_HIGH_EDGE,    //!< Interrupt on high edge
    GPIO16_INT_ANY_EDGE      //!< Interrupt on any edge
} gpio16_int_mode_t;

typedef void (*GPIO16_cb_t)(uint16_t regVal);

bool GPIO16_Init(uint8_t addr);
bool GPIO16_SetupIOModeMask(uint16_t outMask, uint16_t inPullupMask);
bool GPIO16_SetupIntSource(uint16_t sourceMask, gpio16_int_mode_t intMode, gpio16_int_out_mode_t intOutMode, GPIO16_cb_t cb);
bool GPIO16_Read(uint16_t *gpioVal);
bool GPIO16_Write(uint16_t gpioVal);
uint16_t GPIO16_GetLastReadValue();

#endif //_GPIO16_H_