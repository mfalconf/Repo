#ifndef _POC_H_
#define _POC_H_

void POC_Immediate_Initialization();
void POC_Initialize(void);

#endif