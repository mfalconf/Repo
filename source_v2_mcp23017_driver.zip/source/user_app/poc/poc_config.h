#ifndef _POC_CONFIG_H_
#define _POC_CONFIG_H_

//UART
#define _POC_BOARD_UART_INSTANCE_ (0) //UART1
#define _USE_INTERRUPT_ true

//Video
#define _POC_USE_90_DEG_ROTATION_ false

#endif //_POC_CONFIG_H_