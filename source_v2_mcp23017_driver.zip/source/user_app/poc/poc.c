#include <xdc/runtime/System.h> //UInt32

/* UART Header files */
#include <ti/csl/soc.h> //CTRL_CORE_PAD_UART1_RXD
#include <ti/drv/vps/include/platforms/bsp_platform.h> //Bsp_platformSetPinmuxRegs()

#include "poc_uart1.h"
#include "poc.h"

void POC_Immediate_Initialization() 
{
  // UART1
  // Rx
  Bsp_platformSetPinmuxRegs((UInt32) 0U, (UInt32) CTRL_CORE_PAD_UART1_RXD, BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  // Tx
  Bsp_platformSetPinmuxRegs((UInt32) 0U, (UInt32) CTRL_CORE_PAD_UART1_TXD, BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_OUT);
}

void POC_Initialize()
{
  POC_UART1_Initialize();
}