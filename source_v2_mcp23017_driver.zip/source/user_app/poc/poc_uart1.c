/**
 * @file   main_uart_example.c
 *
 * @brief  This file tests the UART driver APIs with all the suported
 *         input parameters values
 */
/*
 * Copyright (c) 2014 - 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/cfg/global.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <console.h>

/* UART Header files */
#include <ti/drv/vps/include/osal/bsp_osal.h>
#include <drv/uart/UART_stdio.h>
#include <drv/uart/UART_osal.h>
#include <drv/uart/UART_soc.h>

#include <ti/drv/vps/include/platforms/bsp_platform.h>
#include <ti/csl/soc.h>

#include "poc_config.h"

/*
 *  ======== echoFxn ========
 *  Task for this function is created statically. See the project's .cfg file.
 *
 */

 /* Length of the input in number of characters */
#define INPUT_LENGTH           (21U)

char echoPrompt[]="\nuart driver and utils example test cases :\nEnter 150 characters or press Esc \n";
char echoPrompt1[]="DATA RECEIVED IS\n ";

/* Default UART parameters structure */
static UART_Params UART_customParams = {
    UART_MODE_BLOCKING,   /* readMode */
    UART_MODE_BLOCKING,   /* writeMode */
    10,                    /* readTimeout - SemaphoreP_WAIT_FOREVER */
    10,                    /* writeTimeout - SemaphoreP_WAIT_FOREVER */
    NULL,                 /* readCallback */
    NULL,                 /* writeCallback */
    UART_RETURN_NEWLINE,  /* readReturnMode */
    UART_DATA_TEXT,       /* readDataMode */
    UART_DATA_TEXT,       /* writeDataMode */
    UART_ECHO_OFF,        /* readEcho */
    115200,               /* baudRate */
    UART_LEN_8,           /* dataLength */
    UART_STOP_ONE,        /* stopBits */
    UART_PAR_NONE,        /* parityType */
    NULL,                 /* readCallback2 */
    NULL,                 /* writeCallback2 */
};

static void UART1_init(void)
{
  UART_HwAttrs uartInitCfg;

  UART_socGetInitCfg(_POC_BOARD_UART_INSTANCE_, &uartInitCfg);

  #if _USE_INTERRUPT_
    LOG_PRINT_INFO(DEBUG_MIF, "Uart Mode: INTERRUPT\n");
    uartInitCfg.enableInterrupt = TRUE;
    UART_socSetInitCfg(_POC_BOARD_UART_INSTANCE_,&uartInitCfg);
  #else
    LOG_PRINT_INFO(DEBUG_MIF, "Uart Mode: POLLING\n");
    uartInitCfg.enableInterrupt = FALSE;
    UART_socSetInitCfg(_POC_BOARD_UART_INSTANCE_,&uartInitCfg);
  #endif

  UART_stdioInit2(_POC_BOARD_UART_INSTANCE_, &UART_customParams);
  
  LOG_PRINT_INFO(DEBUG_MIF, "Uart configured\n");   
}

static void uart_test(UArg arg0, UArg arg1)
{
    char input = '\n';
    char *buffPointer;

    buffPointer = (char*)malloc(INPUT_LENGTH);
    memset(buffPointer,0,INPUT_LENGTH);

    while(1) {
        UART_puts("Enter 16 characters or press Esc or carriage return\n",sizeof("Enter 16 characters or press Esc or carriage return\n"));
        memset(buffPointer,0,INPUT_LENGTH);
        UART_gets(buffPointer, INPUT_LENGTH);
        UART_puts(&input,1);
        UART_printf("Data received is\n");
        UART_puts(buffPointer, INPUT_LENGTH);
        UART_printStatus("\nTest Passed\n");
    }
} /* uart_test */

static void uart_test_tx(UArg arg0, UArg arg1)
{
    LOG_PRINT_INFO(DEBUG_MIF, "Thread Tx is runnning\n");
    
    while(1) {
        UART_puts("hola", 5);
        LOG_PRINT_INFO(DEBUG_MIF, "Sending: \"hola\"\n");
        UART_osalDelay(1000);
    }
} /* uart_test Tx*/


static bool getChar(uint8_t *r_data) {
  uint8_t data = UART_getc();
  
  *r_data = data;
  if(data) {
    LOG_PRINT_INFO(DEBUG_MIF, "Read: %c\n",(char)data);
  }
  return r_data != 0;
}

static int getLine(char line[], int dim) {
  int bytes_r = UART_gets(line, dim);
  
  if(bytes_r) {
    line[bytes_r] = '\0';
    LOG_PRINT_INFO(DEBUG_MIF, "Read: %s\n", line);
  }
  
  return bytes_r != 0;
}

static void uart_test_rx(UArg arg0, UArg arg1)
{
    LOG_PRINT_INFO(DEBUG_MIF, "Thread Rx is runnning\n");
    while(1) {
        //uint8_t data;
        char dataBuff[10];

        //while(getChar(&data));
        while(getLine(dataBuff, sizeof(dataBuff)-1));
        //UART_osalDelay(20);
    }
} /* uart_test Rx*/

static void Create_Txtask() {
    Task_Handle task;
    Error_Block eb;

    Error_init(&eb);
    task = Task_create(uart_test_tx, NULL, &eb);
    if (task == NULL) {
       LOG_PRINT_INFO(DEBUG_MIF, "Tx Task_create() failed!\n");
       BIOS_exit(0);
    }
    LOG_PRINT_INFO(DEBUG_MIF, "Thread Tx created\n");
}

static void Create_Rxtask() {
    Task_Handle task;
    Error_Block eb;

    Error_init(&eb);
    task = Task_create(uart_test_rx, NULL, &eb);
    if (task == NULL) {
       LOG_PRINT_INFO(DEBUG_MIF, "Rx Task_create() failed!\n");
       BIOS_exit(0);
    }
    LOG_PRINT_INFO(DEBUG_MIF, "Thread Rx created\n");
}


/*
 *  ======== main ========
 */
void POC_UART1_Initialize(void)
{
    /* Call board init functions */
    UART1_init();

    Create_Rxtask();
    Create_Txtask();
} /* main */
