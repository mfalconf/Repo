#ifndef _POC_UART1_H_
#define _POC_UART1_H_

void POC_UART1_Initialize(void);

#endif //_POC_UART1_H_