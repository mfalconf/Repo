/******************************************************************************
 *
 * \file    gfx_composer.h
 *
 * \brief   Graphic Composer header file
 *
 * \author  Esteban Pupillo
 *
 * \date    10 Ago 2022
 *
 *****************************************************************************/
#ifndef __GFX_COMPOSER_H__
#define __GFX_COMPOSER_H__

/**
 * @addtogroup GfxComposer
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>
#include "gfx_layer.h"
#include "gfx_blender.h"

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief VideoCapture data type
 */
typedef struct gfx_composer_tag* GfxComposer;

typedef void (*gfx_composer_focus_gained_callback)(GfxLayer, void*);


/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initialize Graphic composer subsystem
 *
 * This function has to be called before any other function of this
 * module API
 *
 * @param GfxComposer pointer to the instance to initialize
 * @param callback Callback to be executed on focus gained
 * @param context Context to pass to the callback
 * @return #E_OK on success
 */
Int32 GfxComposer_init(GfxComposer *gfxComposer, gfx_composer_focus_gained_callback callback, void *context);

/**
 * @brief Starts composition
 *
 * @param gfxComposer composer instance
 * @param fade_in Fade in property for start
 *
 * @return #E_OK on success, error code otherwise
 */
Int32 GfxComposer_start(GfxComposer gxfComposer, bool_t fade_in);

/**
 * @brief Stops composition
 *
 * @param gfxComposer composer instance
 *
 * @return #E_OK on success, error code otherwise
 */
Int32 GfxComposer_stop(GfxComposer gfxComposer);

/**
 * @brief Gets graphic composer instance
 *
 * @param gfxComposer pointer to GfxComposer to receive instance
 *
 * @return #E_OK on success, error code otherwise
 */
Int32 GfxComposer_getInstance(GfxComposer *gfxComposer);

/**
 * @brief Adds a graphic layer to the composition
 *
 * @param gfxComposer GfxComposer instance
 * @param gfxLayer GfxLayer to add
 *
 * @return #E_OK on success, error code otherwise
 */
Int32 GfxComposer_addLayer(GfxComposer gfxComposer, GfxLayer layer);

/**
 * @brief Gets a reference to the composition blender
 *
 * @param gfxComposer GfxComposer instance
 * @param gfxBlender pointer to GfxBlender to receive the composer 
 *                   blender instance
 *
 * @return #E_OK on success, error code otherwise
 */
Int32 GfxComposer_getBlender(GfxComposer gfxComposer, GfxBlender *gfxBlender);

/**
 * @brief Moves layer to the top of the composer stack
 *
 * This makes the layer to change it Z-order
 *
 * @param gfxComposer GfxComposer instance
 * @param layer GfxLayer instance to move
 *
 * @return #E_OK on success, error code otherwise
 */
Int32 GfxComposer_setTopMostLayer(GfxComposer gfxComposer, GfxLayer layer);

/**
 * @brief Checks if the Graphic Composer is started
 *
 * @param gfxComposer GfxComposer instance
 *
 * @return TRUE if started, FALSE otherwise
 */
bool_t GfxComposer_isStarted(GfxComposer gfxComposer);

/**
 * @brief Checks if the Graphic Composer is starting
 *
 * @param gfxComposer GfxComposer instance
 *
 * @return TRUE if starting, FALSE otherwise
 */
bool_t GfxComposer_isStarting(GfxComposer gfxComposer);
/**
 * Close doxygen group
 * @}
 */

#endif //__GFX_COMPOSER_H__
