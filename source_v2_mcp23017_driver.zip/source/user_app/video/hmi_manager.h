/******************************************************************************
 *
 * \file    hmi_manager.h
 *
 * \brief   HMI Manager module header file
 *
 * \author  Esteban Pupillo
 *
 * \date    25 Jul 2022
 *
 *****************************************************************************/
#ifndef __HMI_MANAGER_H__
#define __HMI_MANAGER_H__

#include <xdc/std.h>

#include "renderer.h"

/**
 * @addtogroup HmiManager
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief VideoCapture data type
 */
typedef struct hmi_manager_tag* HmiManager;


/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initialize HMI
 *
 * This function has to be called before any other function of this
 * module API
 *
 * @return #FVID2_SOK on success
 */
Int32 HmiManager_init(void);

/** Signal HMI manager to start drawing in the display */
void HmiManager_start(void);

/**
 * @brief Set the internal state of the RVC signal of the HMI
 * 
 * @param rvc_state New state of the RVC signal
 */
void HmiManager_set_rvc_state(bool_t rvc_state);

/**
 * @brief Set the internal state of the request audio lower volume signal
 * 
 * @param rvc_state New state of the request audio lower volume signal
 */
void HmiManager_set_pdc_key_state(bool_t pdc_key_state);

/**
 * @brief Update the internal status of the front parking sensors
 * 
 * @param front_sensors 4 item array containing the information of the front sensors
 * in cm
 */
void HmiManager_update_front_parking_sensors(Uint8 *front_sensors);

/**
 * @brief Update the internal status of the rear parking sensors
 * 
 * @param rear_sensors 4 item array containing the information of the rear sensors
 * in cm
 */
void HmiManager_update_rear_parking_sensors(Uint8 *rear_sensors);

/**
 * @brief Update the internal status of the transport mode flag
 * 
 * @param transport_mode_active New transport mode flag
 */
void HmiManager_update_transport_mode(bool_t transport_mode_active);

/**
 * @brief Update the internal status of the reflashing state
 * 
 * @param reflashing_state New reflashing state
 */
void HmiManager_update_reflashing_state(bool_t reflashing_state);

/**
 * @brief Set the internal desired state for the backlight of the screen
 *
 * @param screen_state Desired actual state for the backlight of the screen
 */
void HmiManager_set_desired_screen_state(bool screen_state);

/**
 * @brief Set the detected car model to acoomodate the RVC and PDC layouts
 * 
 * @param car Detected car model
 */
void HmiManager_set_car(RendererCar car);

/**
 * @brief Set the language for HMI resources
 * 
 * @param language Desired language
 */
void HmiManager_set_language(Language_en language);

/**
 * @brief Set the current switch on state
 * 
 * @param switchOn Switch on state
 */
void HmiManager_set_switch_on(bool_t switch_on_state);

/**
 * @brief Check if the any of the ADAS view should be ON
 * @note This function does not take in account the GUI buttons interactions
 * This shouldn't be a problem, since it should only be used only to turn on
 * or off the screen in IDLE modes
 * 
 * @param car Vehicle to base the analysis
 * @param pdc PDC status
 * @param rvc RVC status
 * @return true ADAS view should be ON
 * @return false ADAS view should not be ON
 */
bool HmiManager_get_adas_view_on(RendererCar car, bool pdc, bool rvc);

/**
 * Close doxygen group
 * @}
 */

#endif //__HMI_MANAGER_H__
