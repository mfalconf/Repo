/******************************************************************************
 *
 * \file    rvc_view.c
 *
 * \brief   Rear Camera view source file
 *
 * \author  Esteban Pupillo
 *
 * \date    22 Sep 2022
 *
 *****************************************************************************/

#include <standard.h>

#include "rvc_view.h"

#include <console.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/heaps/HeapMem.h>

#include "rvc_manager.h"
#include "gfx_layer.h"
#include "display.h"
#include "renderer.h"
#include "video_dma.h"

/**
 * @addtogroup RvcView
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DEBUG_RVC_VIEW  0
#define RVC_VIEW_BPP    (4)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
struct rvc_view_type {
	bool_t isInitialized;
	/**< flag to know if the view is initialized */
	
	GfxLayer gfxLayer;
	/**< Graphic layer associated with this view */

	Renderer renderer;
	/**< Reference to the renderer engine */

	RvcManager rvcManager;
	/**< Reference to the RVC manager */

  bool showingView;
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static struct rvc_view_type gRvcView = {
	/* isInitialized */
	FALSE,

	/* gfxLayer */
	NULL,

	/* renderer */
	NULL,
};

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

static Int32 rvcView_onNewRvcFrame(Fvid2_Handle handle, Ptr appData, Ptr reserved)
{
  Int32 retVal;
  RvcView rvcView = (RvcView) appData;
  Fvid2_FrameList frameList;
	Renderer r;
	RendererFrame rFrame;

  LOG_PRINT_SVER(DEBUG_RVC_VIEW, "%s() START\r\n", __FUNCTION__);

	/* Get a new filled graphic frame */
  RvcManager_dequeueBuffer(rvcView->rvcManager, &frameList);

	/* Queue a new composed (RVC + PDC) frame to the graphic layer */
	GfxLayer_queueFrame(rvcView->gfxLayer, frameList.frames[0]);

  /* Request a free frame from the graphic layer to be filled */
	retVal = GfxLayer_dequeueFrame(rvcView->gfxLayer, &frameList.frames[0]);
	if (E_OK == retVal)
	{
		/* Get a reference to the Render engine to make the image composition between the
		 * raw camera frame and the PDC sensors information
		 */
			Renderer_getInstance(&r);

			/* Acquire a frame with the PDC sensor information */
			retVal = Renderer_acquireViewFrame(r, Renderer_getRvcAndPdcLayout(), &rFrame);

			if (E_OK == retVal)
			{
				UInt32 displayWidth, displayHeight;

				Display_getResolution(NULL, &displayWidth, &displayHeight);

				/* Copy the frame content to the RVC frame buffer */
				VideoDMA_copyFrame(PHY_TO_DA_ADDR((UInt8 *) frameList.frames[0]->addr[0][0]), RVC_VIEW_BPP, displayWidth * RVC_VIEW_BPP,
													PHY_TO_DA_ADDR((UInt8 *) rFrame.addr), rFrame.bpp, rFrame.stride, 
													rFrame.width, rFrame.height);

				/* We are done with the PDC frame; we have to release it */
				Renderer_releaseViewFrame(r, Renderer_getRvcAndPdcLayout(), &rFrame);
			}
			else
			{
				LOG_PRINT_ERR(DEBUG_RVC_VIEW, "%s(): Unable to acquire view frame from renderer\r\n", __FUNCTION__);
			}
			
		/* Push the new free frame to the RVC manager to fill it with RVC content */
		Int32 queueRet = RvcManager_queueBuffer(rvcView->rvcManager, &frameList);

    if (E_OK != queueRet)
    {
      LOG_PRINT_ERR(DEBUG_RVC_VIEW, "%s(): Error queuing buffer to RVC manager (%d)\r\n", __FUNCTION__, queueRet);
    }
	}
	else
	{
		LOG_PRINT_ERR(DEBUG_RVC_VIEW, "%s(): Unable to get a new free frame from Graphic layer (%d)\r\n", __FUNCTION__, retVal);
    GfxLayer_dump(rvcView->gfxLayer);
	}

  LOG_PRINT_SVER(DEBUG_RVC_VIEW, "%s() END\r\n", __FUNCTION__);

	return retVal;
}

static Int32 rvcView_onFocusChangeCallback(GfxLayer gfxLayer, Ptr appData, bool_t newState)
{
	RvcView rvcView = (RvcView) appData;

	LOG_PRINT_INFO(DEBUG_RVC_VIEW, "%s(): newState = %d\r\n", __FUNCTION__, newState);

	if (!rvcView->isInitialized)
		return E_OK;

	if (newState)
	{
		Renderer_setLayout(rvcView->renderer, Renderer_getRvcAndPdcLayout());
		GfxLayer_setEnableState(rvcView->gfxLayer, TRUE);
	}
	else
	{
		RvcManager_stop(rvcView->rvcManager);
		GfxLayer_setEnableState(rvcView->gfxLayer, FALSE);
	}
	
	return E_OK;
}

static Int32 rvcView_onDraw(GfxLayer gfxLayer, Ptr appData)
{
	// TODO: AJS What is the use of this function?
	return E_OK;
}

Int32 RvcView_init(RvcView *rvcView, RvcViewParams *params)
{
	Int32 retVal = E_OK;
	UInt32 width, height;

	/* check input parameters */
	if (NULL == rvcView)
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* Get a reference to the Rvc manager */
	retVal = RvcManager_getInstance(&gRvcView.rvcManager);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_RVC_VIEW, "%s(): Unable to get a reference to the RVC manager\r\n");
		return E_ERROR;
	}

	/* Register our callback to the RVC manager */
  Fvid2_CbParams rvcManagerCb;
  Fvid2CbParams_init(&rvcManagerCb);
  rvcManagerCb.cbFxn = rvcView_onNewRvcFrame;
	rvcManagerCb.appData = &gRvcView;
  retVal = RvcManager_registerCallback(gRvcView.rvcManager, rvcManagerCb);
  if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_RVC_VIEW, "%s(): Unable to register callback to the RVC manager\r\n", __FUNCTION__);
		return E_ERROR;
	}

	/* retrieve default display resolution */
	Display_getResolution(NULL, &width, &height);

	/* Create Graphic Layer */
	GfxLayerParams layerParams;
	GfxLayerParams_init(&layerParams);
	layerParams.name = "rvc";
	layerParams.zOrder = 4;
	layerParams.alpha = 0x0;
	layerParams.width = width;
	layerParams.height = height;
	layerParams.xPos = 0;
	layerParams.yPos = 0;
	layerParams.onDrawCallback = rvcView_onDraw;
	layerParams.onFocusChangeCallback = rvcView_onFocusChangeCallback;
	layerParams.appData = &gRvcView;
	GfxQueueParams_init(&layerParams.queueParams);
	layerParams.queueParams.maxSize = 3;
	layerParams.queueParams.frameWidth = layerParams.width;
	layerParams.queueParams.frameHeight = layerParams.height;
	layerParams.queueParams.frameBytePerPixel = RVC_VIEW_BPP;

	retVal = GfxLayer_create(&gRvcView.gfxLayer, &layerParams, GFX_LAYER_TAG_RVC);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_RVC_VIEW, "%s(): Unable to create graphic layer\r\n", __FUNCTION__);
		return E_ERROR;
	}

  gRvcView.showingView = false;

	/* Obtain a reference of the renderer engine */
	Renderer_getInstance(&gRvcView.renderer);

	/* we are now initialized */
	gRvcView.isInitialized = TRUE;

	/* return instance */
	*rvcView = &gRvcView;

	LOG_PRINT_INFO(DEBUG_PDC_VIEW, "%s(): RvcView initialized at %p\r\n", __FUNCTION__, &gRvcView);

	return E_OK;
}

Int32 RvcView_show(RvcView rvcView)
{
  int retVal = E_OK;
  UInt32 current_renderer_layout;

	/* Check parameters */
	if (NULL == rvcView)
	{
		return E_ERROR;
	}

  retVal = Renderer_getCurrentLayout(rvcView->renderer, &current_renderer_layout);

  if (retVal != E_OK)
  {
    LOG_PRINT_ERR(DEBUG_RVC_VIEW, "(%s) [%d]: Error obtaining current Renderer layout: %d\r\n", __FUNCTION__, __LINE__, retVal);
    return retVal;
  }

  if ((current_renderer_layout == Renderer_getRvcAndPdcLayout()) && (rvcView->showingView))
    return E_OK;
	
  LOG_PRINT_INFO(DEBUG_RVC_VIEW, "%s(): Showing view\r\n", __FUNCTION__);

	Renderer_setLayout(rvcView->renderer, Renderer_getRvcAndPdcLayout());
  rvcView->showingView = true;

	GfxLayer_setEnableState(rvcView->gfxLayer, TRUE);

	/* Queue 1st empty frame to RVC manager */
	Fvid2_FrameList frmList;
	frmList.numFrames = 1;

  retVal = GfxLayer_dequeueFrame(rvcView->gfxLayer, &frmList.frames[0]);
	if (E_OK == retVal)
	{
		RvcManager_queueBuffer(rvcView->rvcManager, &frmList);

		RvcManager_start(rvcView->rvcManager);

		retVal = GfxLayer_show(rvcView->gfxLayer, FALSE);
	}
  else
  {
    LOG_PRINT_ERR(DEBUG_RVC_VIEW, "(%s) [%d]: Error dequeing 1st empty frame to RVC manager: %d\r\n", __FUNCTION__, __LINE__, retVal);
  }
	
	return retVal;
}

Int32 RvcView_hide(RvcView rvcView)
{
	/* Check parameters */
	if (NULL == rvcView)
	{
		return E_ERROR;
	}

  if (!rvcView->showingView)
    return E_OK;

  rvcView->showingView = false;

	LOG_PRINT_INFO(DEBUG_RVC_VIEW, "%s(): Hiding view\r\n", __FUNCTION__);

	GfxLayer_hide(rvcView->gfxLayer, FALSE);

	return GfxLayer_setEnableState(rvcView->gfxLayer, FALSE);
}

/**
 * Close doxygen group
 * @}
 */

