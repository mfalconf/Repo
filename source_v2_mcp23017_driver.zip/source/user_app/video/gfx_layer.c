/******************************************************************************
 *
 * \file    gfx_layer.c
 *
 * \brief   Graphic layer module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    13 Sep 2022
 *
 *****************************************************************************/

#include <standard.h>

#include "gfx_layer.h"
#include "gfx_queue.h"
#include "gfx_composer.h"
#include "gfx_animator.h"
#include "display.h"

#include <console.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/heaps/HeapMem.h>
#include <ti/sysbios/gates/GateTask.h>
#include <ti/sysbios/gates/GateMutexPri.h>


/**
 * @addtogroup GfxLayer
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DEBUG_GFX_LAYER  0

// The time scaling factor will affect the fade out transition time
// The relation (lutSize/timeScaleFactor) will set the amount of steps in the transition
// So, with a desired amount of steps (the steps will be executed at each frame updated by the gfxComposer)
// you can define this as: timeScaleFactor = lutSize / desiredSteps
#define GFX_LAYER_DESIRED_STEPS_AMOUNT   (20)
#define GFX_LAYER_TIME_SCALE_FACTOR      (GfxAnimator_getLutSize() / GFX_LAYER_DESIRED_STEPS_AMOUNT)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
typedef enum gfx_layer_state_flags_tag {
	GFXLAYER_NO_CHANGE = 0,
	GFXLAYER_ALPHA_CHANGE = 1,
	GFXLAYER_VERTICAL_POSITION_CHANGE = 2,

} GfxLayerStateFlags;

struct gfx_layer_type {
	GfxLayerParams params;
	/**< Layer parameters */

	//GateTask_Handle gate;
	/**< Gate used to protect critical sections */

	GateMutexPri_Handle gateMutex;
	/**< Gate used to protect critical sections */

	bool_t enabled;
	/**< flag to know if the layer is enabled or disabled */

	GfxQueue gfxQueue;
	/**< Graphic queue associated with layer */

	GfxComposer gfxComposer;
	/**< Graphic composer associated with layer */

	GfxLayerState currentState;
	/**< Current layer state */

	GfxLayerState displayState;
	/**< Last displayed layer state */

	GfxLayerStateFlags stateFlags;
	/**< Flags used to inform several state change events */

	GfxAnimator animator;
	/**< Animator instance used for animating state changes */

  GfxLayerTag layerTag;
  /**< Layer tag */
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Functions implementation
 *****************************************************************************/
static void gfxLayer_updateState(GfxLayer gfxLayer)
{
	UInt32 flags, cookie;
	
	/* Check input parameter */
	if (NULL == gfxLayer)
		return;
	
	cookie = GateMutexPri_enter(gfxLayer->gateMutex);

	flags = gfxLayer->stateFlags;
	/* Check if there is a pending change */
	if (0 == flags)
	{
		/* There are no pending changes */
		GateMutexPri_leave(gfxLayer->gateMutex, cookie);
		return;
	}

	/* Handle vertical position change */
	if (GFXLAYER_VERTICAL_POSITION_CHANGE == (flags & GFXLAYER_VERTICAL_POSITION_CHANGE))
	{
		/* apply change */
		gfxLayer->displayState.yPos = gfxLayer->currentState.yPos;

		/* clear flag */
		gfxLayer->stateFlags &= ~(GFXLAYER_VERTICAL_POSITION_CHANGE);

		LOG_PRINT_INFO(DEBUG_GFX_LAYER, "%s(): xpos = %d, ypos = %d\r\n", __FUNCTION__, gfxLayer->displayState.xPos, gfxLayer->displayState.yPos);
	}

	/* Handle alpha change */
	if (GFXLAYER_ALPHA_CHANGE == (flags & GFXLAYER_ALPHA_CHANGE))
	{
		/* apply change */
		gfxLayer->displayState.alpha = gfxLayer->currentState.alpha;
		
		/* clear flag */
		gfxLayer->stateFlags &= ~(GFXLAYER_ALPHA_CHANGE);

		if (0 != gfxLayer->displayState.alpha)
		{
			/* Notify Graphic composer that we want this layer on top */
			GfxComposer_setTopMostLayer(gfxLayer->gfxComposer, gfxLayer);
		}
	}

	GateMutexPri_leave(gfxLayer->gateMutex, cookie);
}

static void gfxLayer_updateAnim(GfxLayer gfxLayer)
{
	UInt32 cookie;
	GfxAnimatorValue newValue;
	bool_t hasEnded;

	/* if we don't have a valid animator do nothing */
	if (NULL == gfxLayer->animator)
	{
		return;
	}

	cookie = GateMutexPri_enter(gfxLayer->gateMutex);

	/* update animator and get a new value */
	GfxAnimator_update(gfxLayer->animator, &newValue, &hasEnded);

	/* update current layer state */
	if (GFXLAYER_VERTICAL_POSITION_CHANGE == newValue.parameterKey)
	{
		gfxLayer->currentState.yPos = newValue.value;
		gfxLayer->stateFlags |= newValue.parameterKey;
	}

	if (hasEnded)
	{
		GfxAnimator_destroy(gfxLayer->animator);
		gfxLayer->animator = NULL;
	}

	GateMutexPri_leave(gfxLayer->gateMutex, cookie);
}

static void gfxLayer_invalidate(GfxLayer gfxLayer)
{
	gfxLayer_updateAnim(gfxLayer);
	gfxLayer_updateState(gfxLayer);
}


Int32 GfxLayer_create(GfxLayer *gfxLayer, GfxLayerParams *gfxLayerParams, GfxLayerTag tag)
{
	Int32 retVal;
	GfxLayer newLayer;

	/* Check input parameters */
	if ((NULL == gfxLayer) || (NULL == gfxLayerParams))
	{
		return E_ERROR;
	}

	/* Allocate new layer */
	newLayer = (GfxLayer) Memory_alloc(NULL, sizeof(struct gfx_layer_type), 0, NULL);
	if (NULL == newLayer)
	{
		/* we couldn't allocate a new layer object */
		return E_ERROR;
	}

	/* copy parameters */
	memcpy(&newLayer->params, gfxLayerParams, sizeof(GfxLayerParams));

  /* Create gate used for synchronization */
	Error_Block eb;

	GateMutexPri_Params gateMutexParams;
	GateMutexPri_Params_init(&gateMutexParams);
	newLayer->gateMutex = GateMutexPri_create(&gateMutexParams, &eb);
	if (NULL == newLayer->gateMutex)
	{
		LOG_PRINT_ERR(DEBUG_GFX_LAYER, "%s(): Unable to create GateMutex for synchronization\r\n", __FUNCTION__);
		
		/* free allocated Memory */
		Memory_free(NULL, newLayer, sizeof(struct gfx_layer_type));

		return E_ERROR;
	}


	/* create graphic queue */
	retVal = GfxQueue_create(&newLayer->gfxQueue, &newLayer->params.queueParams);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_GFX_LAYER, "%s(): Unable to create graphic queue\r\n", __FUNCTION__);

		/* free allocated Memory */
		Memory_free(NULL, newLayer, sizeof(struct gfx_layer_type));

		return retVal;
	}

	/* initialize layer states */
	newLayer->enabled = FALSE;
  newLayer->layerTag = tag;
	newLayer->currentState.xPos = gfxLayerParams->xPos;
	newLayer->currentState.yPos = gfxLayerParams->yPos;
	newLayer->currentState.width = gfxLayerParams->width;
	newLayer->currentState.height = gfxLayerParams->height;
	newLayer->currentState.alpha = gfxLayerParams->alpha;
	newLayer->currentState.zOrder = gfxLayerParams->zOrder;
	
	/* now the current and displayed states are equal */
	newLayer->displayState = newLayer->currentState;

	/* initialize animator */
	newLayer->animator = NULL;

  /* Obtain the graphic composer instance */
	retVal = GfxComposer_getInstance(&newLayer->gfxComposer);
	if ((E_OK != retVal) || (NULL == newLayer->gfxComposer))
	{
		LOG_PRINT_ERR(DEBUG_GFX_LAYER, "%s(): Unable to get a reference to the Graphic composer\r\n", __FUNCTION__);
		/* force to null the graphic composer object */
		newLayer->gfxComposer = NULL;
	}
	else 
	{
		/* add layer in graphic composer */
		GfxComposer_addLayer(newLayer->gfxComposer, newLayer);
	}

	/* return newly created layer */
	*gfxLayer = newLayer;

	LOG_PRINT_INFO(DEBUG_GFX_LAYER, "%s(): Layer %p created\r\n", __FUNCTION__, newLayer);

	return E_OK;
}

void GfxLayer_dump(GfxLayer gfxLayer)
{
  GfxQueue_dump(gfxLayer->gfxQueue);
}

Int32 GfxLayer_queueFrame(GfxLayer gfxLayer, Fvid2_Frame *frame)
{
	/* Check input parameters */
	if ((NULL == gfxLayer) || (NULL == frame) || (!gfxLayer->enabled))
	{
		return E_ERROR;
	}

	/* Queue frame to graphic queue */
	return GfxQueue_queue(gfxLayer->gfxQueue, frame);
}

Int32 GfxLayer_dequeueFrame(GfxLayer gfxLayer, Fvid2_Frame **frame)
{
	/* Check input parameters */
	if ((NULL == gfxLayer) || (NULL == frame) || (!gfxLayer->enabled))
	{
		return E_ERROR;
	}

	/* Dequeue frame from graphic queue */
	return GfxQueue_dequeue(gfxLayer->gfxQueue, frame);
}

Int32 GfxLayer_acquireFrame(GfxLayer gfxLayer, Fvid2_Frame **frame)
{
	/* Check input parameters */
	if ((NULL == gfxLayer) || (NULL == frame) || (!gfxLayer->enabled))
	{
		return E_ERROR;
	}

	/* Acquire a frame */
	return GfxQueue_acquire(gfxLayer->gfxQueue, frame);
}

Int32 GfxLayer_releaseFrame(GfxLayer gfxLayer, Fvid2_Frame *frame)
{
	/* Check input parameters */
	if ((NULL == gfxLayer) || (NULL == frame) || (!gfxLayer->enabled))
	{
		return E_ERROR;
	}

	/* Release frame */
	return GfxQueue_release(gfxLayer->gfxQueue, frame);
}


Int32 GfxLayer_compareZorder(void *a, void *b)
{
	GfxLayer *aLayer = (GfxLayer*) (a);
	GfxLayer *bLayer = (GfxLayer*) (b);

	return ((*aLayer)->params.zOrder - (*bLayer)->params.zOrder);
}

Int32 GfxLayer_draw(GfxLayer gfxLayer, Fvid2_Frame *displayFrame)
{
	Int32 retVal = E_OK;
	Fvid2_Frame *layerFrame = NULL;
	GfxComposer gfxComposer = NULL;
	GfxBlender gfxBlender = NULL;

	/* Check input parameters */
	if ((NULL == gfxLayer) || (NULL == displayFrame) || (!gfxLayer->enabled))
	{
		return E_ERROR;
	}

	/* invoke onDrawCallback */
	if (gfxLayer->params.onDrawCallback)
	{
		retVal = (*gfxLayer->params.onDrawCallback)(gfxLayer, gfxLayer->params.appData);
		if (E_OK != retVal)
		{
			/* our client has nothing to draw, then return */
			//return E_OK;
		}
	}

	/* Update animator */
	gfxLayer_updateAnim(gfxLayer);

	/* update layer state */
	gfxLayer_updateState(gfxLayer);

	/* Acquire a layer frame */
	retVal = GfxLayer_acquireFrame(gfxLayer, &layerFrame);
	if (E_OK != retVal)
	{
		/* There was no frame ready to acquire, do nothing for the time being */
		return E_OK;
	}

	/* if the layer is not visible don't blend it */
	if (0 != gfxLayer->displayState.alpha)
	{
		/* Obtain a graphic blender */
		gfxComposer = gfxLayer->gfxComposer;
		if (gfxComposer)
		{
			GfxComposer_getBlender(gfxComposer, &gfxBlender);
		}

		/* Blend layer frame onto displayFrame */
		if (gfxBlender)
		{
			GfxBitblitParams bParams;

			/* configure blender bitblit parameters */
			bParams.xPos = gfxLayer->displayState.xPos;
			bParams.yPos = gfxLayer->displayState.yPos;
			bParams.width = gfxLayer->displayState.width;
			bParams.height = gfxLayer->displayState.height;
			bParams.inFrameParams.width = gfxLayer->params.width;
			bParams.inFrameParams.height = gfxLayer->params.height;
			bParams.inFrameParams.stride = gfxLayer->params.queueParams.frameBytePerPixel * gfxLayer->params.queueParams.frameWidth;
			bParams.inFrameParams.bpp = gfxLayer->params.queueParams.frameBytePerPixel;

			/* do bitblit */
			retVal = GfxBlender_bitblit(gfxBlender, displayFrame, layerFrame, &bParams);
			if (E_OK != retVal)
			{
				LOG_PRINT_ERR(DEBUG_GFX_LAYER, "%s(): Unable to blend layer frame buffer onto display frame buffer\r\n", __FUNCTION__);
			}
		}
	}

	/* Release acquired frame */
	retVal = GfxLayer_releaseFrame(gfxLayer, layerFrame);

	return retVal;
}

Int32 GfxLayer_show(GfxLayer gfxLayer, bool_t animated)
{
	Int32 retVal = E_OK;

	/* Check input parameters */
	if (NULL == gfxLayer)
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	gfxLayer->currentState.alpha = 0xFF;
	gfxLayer->stateFlags |= GFXLAYER_ALPHA_CHANGE;

	/* If no animation is needed update the current state directly */
	if (animated)
	{
		/* we have to animate, make it happen */

		/* currently we support only one animation at a time
		 * therefore if we have a valid animator instance 
		 * we have to destroy it first
		 */
		if (NULL != gfxLayer->animator)
		{
			/* there is an old animator instance */
			GfxAnimator_destroy(gfxLayer->animator);
			gfxLayer->animator = NULL;
		}

		if (NULL == gfxLayer->animator)
		{
			/* we have to create the animator */
			GfxAnimatorParams animParams;

			GfxAnimatorParams_init(&animParams);
			animParams.startValue = gfxLayer->params.height;
			animParams.endValue = gfxLayer->params.yPos;
			animParams.parameterKey = GFXLAYER_VERTICAL_POSITION_CHANGE;
			animParams.timeScaleFactor = GFX_LAYER_TIME_SCALE_FACTOR;

			GfxAnimator_create(&gfxLayer->animator, &animParams);
			GfxAnimator_start(gfxLayer->animator);
		}
	}

	/* Invalidate layer */
	gfxLayer_invalidate(gfxLayer);

	return retVal;
}

Int32 GfxLayer_hide(GfxLayer gfxLayer, bool_t animated)
{
	Int32 retVal = E_OK;

	/* Check input parameters */
	if (NULL == gfxLayer)
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	if (!animated)
	{
		gfxLayer->currentState.alpha = 0;
		gfxLayer->stateFlags |= GFXLAYER_ALPHA_CHANGE;
	}

	return retVal;
}

Int32 GfxLayer_freeAllFrames(GfxLayer gfxLayer)
{
	Int32 retVal = E_OK;

	/* Check input parameters */
	if ((NULL == gfxLayer) || (gfxLayer->enabled))
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* first disable graphic queue */
	retVal = GfxQueue_setEnableState(gfxLayer->gfxQueue, FALSE);
	if (E_OK == retVal)
	{
		/* now, make all graphic frames free again */
		retVal = GfxQueue_freeAll(gfxLayer->gfxQueue);
	}
	return retVal;
}

Int32 GfxLayer_setEnableState(GfxLayer gfxLayer, bool_t newState)
{
	Int32 retVal = E_OK;

	/* Check input parameters */
	if (NULL == gfxLayer)
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	retVal = GfxQueue_setEnableState(gfxLayer->gfxQueue, newState);
	gfxLayer->enabled = newState;

	if (FALSE == newState)
	{
		retVal = GfxQueue_freeAll(gfxLayer->gfxQueue);
		
		/* update pending changes */
		gfxLayer_updateState(gfxLayer);
	}

	return retVal;
}

bool_t GfxLayer_getSize(GfxLayer gfxLayer, UInt32 *width, UInt32 *height)
{
  /* Check input parameters */
	if (NULL == gfxLayer)
		return FALSE;
  
  if (NULL == width)
		return FALSE;

  if (NULL == height)
		return FALSE;
  
  *width = gfxLayer->displayState.width;
  *height = gfxLayer->displayState.height;

  return TRUE;
}

bool_t GfxLayer_isFullScreen(GfxLayer gfxLayer)
{
	UInt32 displayWidth, displayHeight;

	/* Check input parameters */
	if (NULL == gfxLayer)
		return FALSE;

	/* if the layer is translucent we return false
	 * This needs a better handling because we can do 
	 * this knowing that the graphic composer uses this
	 * function to know if it's required to draw a layer
	 * below this one
	 */
	if (0xFF != gfxLayer->displayState.alpha)
	{
		return FALSE;
	}

	Display_getResolution(NULL, &displayWidth, &displayHeight);

	if ( (0 == gfxLayer->displayState.xPos) &&
			 (0 == gfxLayer->displayState.yPos) &&
			 ( displayWidth == gfxLayer->displayState.width ) &&
			 ( displayHeight == gfxLayer->displayState.height ))
	{
		return TRUE;
	}

	return FALSE;
}

GfxLayerTag GfxLayer_getTag(GfxLayer gfxLayer)
{
  return gfxLayer->layerTag;
}

Int32 GfxLayer_onFocusChange(GfxLayer gfxLayer, bool_t newState)
{
	UInt32 retVal = E_OK;

	/* Check parameters */
	if (NULL == gfxLayer)
	{
		return E_ERROR;
	}

	LOG_PRINT_INFO(DEBUG_GFX_LAYER, "%s(): layer = %p, newState = %d\r\n", __FUNCTION__, gfxLayer, newState);

	/* if defined execute client callback */
	if (gfxLayer->params.onFocusChangeCallback)
	{
		retVal = (*gfxLayer->params.onFocusChangeCallback)(gfxLayer, gfxLayer->params.appData, newState);
	}

	return retVal;
}
UInt32 GfxLayer_getAlpha(GfxLayer gfxLayer)
{
	/* Check parameters */
	if (NULL == gfxLayer)
	{
		return 0;
	}

	return gfxLayer->displayState.alpha;
}

char* GfxLayer_getName(GfxLayer gfxLayer)
{
	/* Check parameters */
	if (NULL == gfxLayer)
	{
		return 0;
	}

	return gfxLayer->params.name;
}

UInt32 GfxLayer_getDisplayState(GfxLayer gfxLayer, GfxLayerState *state)
{
	if (NULL == gfxLayer || NULL == state)
		return 0;

	memcpy(state, &gfxLayer->displayState, sizeof(gfxLayer->displayState));

	return 1;
}

/**
 * Close doxygen group
 * @}
 */

