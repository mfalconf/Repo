/******************************************************************************
 *
 * \file    splash_animator.h
 *
 * \brief   Splash animator module header file
 *
 * \author  Esteban Pupillo
 *
 * \date    23 Jun 2022
 *
 *****************************************************************************/
#ifndef __SPLASH_ANIMATOR_H__
#define __SPLASH_ANIMATOR_H__

/**
 * @addtogroup SplashAnimator
 * @{
 */

#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define SPLASH_ANIMATOR_MAX_OUTPUT_FRAMES (4)
#define SPLASH_ANIMATOR_SPLASH_ADDR       (0x8BF80000)

#define SPLASH_WIDTH                      (800)
#define SPLASH_HEIGHT                     (480)
#define SPLASH_BPP                        (4)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief VideoCapture data type
 */
typedef struct splash_animator_tag* SplashAnimator;


/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initialize Splash Animator
 *
 * This function has to be called before any other function of this
 * module API
 *
 * @param SplashAnimator pointer to the video capture instance to initialize
 * @return #FVID2_SOK on success
 */
Int32 SplashAnimator_init(SplashAnimator *splashAnimator);

Int32 SplashAnimator_start(SplashAnimator splashAnimator);

Int32 SplashAnimator_show(SplashAnimator splashAnimator);
Int32 SplashAnimator_hide(SplashAnimator splashAnimator);

/**
 * @brief Queues frame list to module
 *
 * @param SplashAnimator splashAnimator instance
 * @param frameList list of frames to queue
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
//Int32 SplashAnimator_queueBuffer(SplashAnimator splashAnimator, Fvid2_FrameList *frameList);

/**
 * @brief Deueues frame list from module
 *
 * @param SplashAnimator splashAnimator instance
 * @param frameList pointer to a list of frames dequeued
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
//Int32 SplashAnimator_dequeueBuffer(SplashAnimator splashAnimator, Fvid2_FrameList *frameList);


/**
 * Close doxygen group
 * @}
 */

#endif //__SPLASH_ANIMATOR_H__
