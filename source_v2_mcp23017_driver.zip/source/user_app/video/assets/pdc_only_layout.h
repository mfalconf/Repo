/* This file was auto created, do not modify by hand! */
#ifndef __PDC_ONLY_LAYOUT_H__
#define __PDC_ONLY_LAYOUT_H__

#define PDC_ONLY_LAYOUT_DEFINITION \
	X(PDC_ONLY_LAYOUT, BACKGROUND, img_big_background, 0, 0, 1024, 528, 1) \
	X(PDC_ONLY_LAYOUT, F_SENSOR_AREA, img_big_f_sensor_area, 147, 181, 160, 235, 0) \
	X(PDC_ONLY_LAYOUT, R_SENSOR_AREA, img_big_r_sensor_area, 716, 181, 160, 235, 0) \
	X(PDC_ONLY_LAYOUT, CAR_AMAROK, img_big_car_amarok, 283, 200, 455, 201, 1) \
	X(PDC_ONLY_LAYOUT, CAR_SAVEIRO, img_big_car_saveiro, 283, 200, 455, 198, 0) \
	X(PDC_ONLY_LAYOUT, CAR_SAVEIRO_DOUBLE, img_big_car_saveiro_double, 281, 200, 456, 198, 0) \
	X(PDC_ONLY_LAYOUT, EXIT_DISABLED, img_big_exit_disabled, 30, 30, 64, 64, 1) \
	X(PDC_ONLY_LAYOUT, EXIT_ENABLED, img_big_exit_enabled, 30, 30, 64, 64, 0) \
	X(PDC_ONLY_LAYOUT, SWITCH_DISABLED, img_big_switch_disabled, 920, 30, 83, 64, 1) \
	X(PDC_ONLY_LAYOUT, SWITCH_ENABLED, img_big_switch_enabled, 920, 30, 84, 63, 0) \
	X(PDC_ONLY_LAYOUT, ALERT_BACKGROUND, img_big_alert_background, 0, 528, 1024, 72, 1) \
	X(PDC_ONLY_LAYOUT, ALERT_ENGLISH, img_big_alert_english, 316, 543, 390, 40, 1) \
	X(PDC_ONLY_LAYOUT, ALERT_SPANISH, img_big_alert_spanish, 264, 543, 494, 40, 0) \
	X(PDC_ONLY_LAYOUT, ALERT_PORTUGUESE, img_big_alert_portuguese, 325, 543, 373, 40, 0) \
	X(PDC_ONLY_LAYOUT, FS_L_1, img_big_fs_l_1, 264, 336, 32, 48, 0) \
	X(PDC_ONLY_LAYOUT, FS_L_2, img_big_fs_l_2, 250, 344, 35, 52, 0) \
	X(PDC_ONLY_LAYOUT, FS_L_3, img_big_fs_l_3, 238, 353, 38, 54, 0) \
	X(PDC_ONLY_LAYOUT, FS_L_4, img_big_fs_l_4, 225, 360, 42, 58, 0) \
	X(PDC_ONLY_LAYOUT, FS_ML_1, img_big_fs_ml_1, 256, 299, 22, 46, 0) \
	X(PDC_ONLY_LAYOUT, FS_ML_2, img_big_fs_ml_2, 240, 299, 24, 54, 0) \
	X(PDC_ONLY_LAYOUT, FS_ML_3, img_big_fs_ml_3, 225, 299, 26, 62, 0) \
	X(PDC_ONLY_LAYOUT, FS_ML_4, img_big_fs_ml_4, 209, 299, 29, 70, 0) \
	X(PDC_ONLY_LAYOUT, FS_ML_5, img_big_fs_ml_5, 194, 299, 32, 78, 0) \
	X(PDC_ONLY_LAYOUT, FS_ML_6, img_big_fs_ml_6, 178, 299, 34, 86, 0) \
	X(PDC_ONLY_LAYOUT, FS_ML_7, img_big_fs_ml_7, 163, 299, 36, 94, 0) \
	X(PDC_ONLY_LAYOUT, FS_ML_8, img_big_fs_ml_8, 147, 299, 38, 102, 0) \
	X(PDC_ONLY_LAYOUT, FS_MR_1, img_big_fs_mr_1, 256, 253, 22, 46, 0) \
	X(PDC_ONLY_LAYOUT, FS_MR_2, img_big_fs_mr_2, 240, 245, 24, 54, 0) \
	X(PDC_ONLY_LAYOUT, FS_MR_3, img_big_fs_mr_3, 225, 237, 26, 62, 0) \
	X(PDC_ONLY_LAYOUT, FS_MR_4, img_big_fs_mr_4, 209, 229, 29, 70, 0) \
	X(PDC_ONLY_LAYOUT, FS_MR_5, img_big_fs_mr_5, 194, 221, 31, 78, 0) \
	X(PDC_ONLY_LAYOUT, FS_MR_6, img_big_fs_mr_6, 178, 213, 33, 86, 0) \
	X(PDC_ONLY_LAYOUT, FS_MR_7, img_big_fs_mr_7, 163, 205, 36, 94, 0) \
	X(PDC_ONLY_LAYOUT, FS_MR_8, img_big_fs_mr_8, 147, 197, 38, 102, 0) \
	X(PDC_ONLY_LAYOUT, FS_R_1, img_big_fs_r_1, 264, 214, 32, 48, 0) \
	X(PDC_ONLY_LAYOUT, FS_R_2, img_big_fs_r_2, 250, 201, 36, 52, 0) \
	X(PDC_ONLY_LAYOUT, FS_R_3, img_big_fs_r_3, 238, 191, 38, 54, 0) \
	X(PDC_ONLY_LAYOUT, FS_R_4, img_big_fs_r_4, 225, 179, 43, 59, 0) \
	X(PDC_ONLY_LAYOUT, RS_L_1, img_big_rs_l_1, 727, 336, 32, 48, 0) \
	X(PDC_ONLY_LAYOUT, RS_L_2, img_big_rs_l_2, 737, 344, 35, 52, 0) \
	X(PDC_ONLY_LAYOUT, RS_L_3, img_big_rs_l_3, 747, 353, 38, 54, 0) \
	X(PDC_ONLY_LAYOUT, RS_L_4, img_big_rs_l_4, 755, 360, 42, 58, 0) \
	X(PDC_ONLY_LAYOUT, RS_ML_1, img_big_rs_ml_1, 745, 299, 22, 46, 0) \
	X(PDC_ONLY_LAYOUT, RS_ML_2, img_big_rs_ml_2, 758, 299, 24, 54, 0) \
	X(PDC_ONLY_LAYOUT, RS_ML_3, img_big_rs_ml_3, 772, 299, 26, 62, 0) \
	X(PDC_ONLY_LAYOUT, RS_ML_4, img_big_rs_ml_4, 784, 299, 29, 70, 0) \
	X(PDC_ONLY_LAYOUT, RS_ML_5, img_big_rs_ml_5, 797, 299, 31, 78, 0) \
	X(PDC_ONLY_LAYOUT, RS_ML_6, img_big_rs_ml_6, 811, 299, 34, 86, 0) \
	X(PDC_ONLY_LAYOUT, RS_ML_7, img_big_rs_ml_7, 824, 299, 36, 94, 0) \
	X(PDC_ONLY_LAYOUT, RS_ML_8, img_big_rs_ml_8, 837, 299, 38, 102, 0) \
	X(PDC_ONLY_LAYOUT, RS_MR_1, img_big_rs_mr_1, 745, 253, 22, 46, 0) \
	X(PDC_ONLY_LAYOUT, RS_MR_2, img_big_rs_mr_2, 758, 245, 24, 54, 0) \
	X(PDC_ONLY_LAYOUT, RS_MR_3, img_big_rs_mr_3, 772, 237, 26, 62, 0) \
	X(PDC_ONLY_LAYOUT, RS_MR_4, img_big_rs_mr_4, 784, 229, 29, 70, 0) \
	X(PDC_ONLY_LAYOUT, RS_MR_5, img_big_rs_mr_5, 797, 221, 31, 78, 0) \
	X(PDC_ONLY_LAYOUT, RS_MR_6, img_big_rs_mr_6, 811, 213, 33, 86, 0) \
	X(PDC_ONLY_LAYOUT, RS_MR_7, img_big_rs_mr_7, 824, 205, 36, 94, 0) \
	X(PDC_ONLY_LAYOUT, RS_MR_8, img_big_rs_mr_8, 837, 197, 38, 102, 0) \
	X(PDC_ONLY_LAYOUT, RS_R_1, img_big_rs_r_1, 727, 214, 32, 48, 0) \
	X(PDC_ONLY_LAYOUT, RS_R_2, img_big_rs_r_2, 737, 201, 36, 52, 0) \
	X(PDC_ONLY_LAYOUT, RS_R_3, img_big_rs_r_3, 747, 191, 38, 54, 0) \
	X(PDC_ONLY_LAYOUT, RS_R_4, img_big_rs_r_4, 755, 179, 43, 59, 0) \

#define  PDC_ONLY_ASSET_AMOUNT	(62)
#define  PDC_ONLY_LAYOUT_WIDTH	(1024)
#define  PDC_ONLY_LAYOUT_HEIGHT	(600)

#endif /* __PDC_ONLY_LAYOUT_H__ */
