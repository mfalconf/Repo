/* This file was auto created, do not modify by hand! */
#ifndef __RVC_AND_PDC_LAYOUT_H__
#define __RVC_AND_PDC_LAYOUT_H__

#define RVC_AND_PDC_LAYOUT_DEFINITION \
	X(RVC_AND_PDC_LAYOUT, BACKGROUND, img_small_background, 0, 0, 240, 600, 1) \
	X(RVC_AND_PDC_LAYOUT, F_SENSOR_AREA, img_small_f_sensor_area, 44, 123, 148, 98, 0) \
	X(RVC_AND_PDC_LAYOUT, R_SENSOR_AREA, img_small_r_sensor_area, 44, 472, 147, 98, 0) \
	X(RVC_AND_PDC_LAYOUT, BACKGROUND_NO_PDC, img_small_background_no_pdc, 0, 0, 240, 600, 0) \
	X(RVC_AND_PDC_LAYOUT, CAR_AMAROK, img_small_car_amarok, 57, 207, 123, 280, 1) \
	X(RVC_AND_PDC_LAYOUT, CAR_SAVEIRO, img_small_car_saveiro, 57, 207, 122, 280, 0) \
	X(RVC_AND_PDC_LAYOUT, CAR_SAVEIRO_DOUBLE, img_small_car_saveiro_double, 57, 207, 121, 280, 0) \
	X(RVC_AND_PDC_LAYOUT, EXIT_DISABLED, img_small_exit_disabled, 30, 30, 64, 64, 1) \
	X(RVC_AND_PDC_LAYOUT, EXIT_ENABLED, img_small_exit_enabled, 30, 30, 63, 64, 0) \
	X(RVC_AND_PDC_LAYOUT, SWITCH_DISABLED, img_small_switch_disabled, 135, 30, 84, 63, 1) \
	X(RVC_AND_PDC_LAYOUT, SWITCH_ENABLED, img_small_switch_enabled, 135, 30, 83, 64, 0) \
	X(RVC_AND_PDC_LAYOUT, ALERT_BACKGROUND, img_small_alert_background, 240, 528, 784, 72, 1) \
	X(RVC_AND_PDC_LAYOUT, ALERT_ENGLISH, img_small_alert_english, 436, 543, 390, 40, 1) \
	X(RVC_AND_PDC_LAYOUT, ALERT_SPANISH, img_small_alert_spanish, 384, 543, 495, 40, 0) \
	X(RVC_AND_PDC_LAYOUT, ALERT_PORTUGUESE, img_small_alert_portuguese, 445, 543, 373, 40, 0) \
	X(RVC_AND_PDC_LAYOUT, ALERT_NO_PDC_ENGLISH, img_small_alert_no_pdc_english, 21, 133, 196, 65, 0) \
	X(RVC_AND_PDC_LAYOUT, ALERT_NO_PDC_SPANISH, img_small_alert_no_pdc_spanish, 31, 133, 177, 59, 0) \
	X(RVC_AND_PDC_LAYOUT, ALERT_NO_PDC_PORTUGUESE, img_small_alert_no_pdc_portuguese, 17, 133, 204, 59, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_L_1, img_small_fs_l_1, 66, 195, 29, 19, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_L_2, img_small_fs_l_2, 59, 187, 32, 21, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_L_3, img_small_fs_l_3, 52, 179, 33, 23, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_L_4, img_small_fs_l_4, 45, 171, 36, 26, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_ML_1, img_small_fs_ml_1, 90, 190, 28, 13, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_ML_2, img_small_fs_ml_2, 85, 180, 33, 14, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_ML_3, img_small_fs_ml_3, 80, 171, 38, 16, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_ML_4, img_small_fs_ml_4, 75, 161, 43, 18, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_ML_5, img_small_fs_ml_5, 70, 152, 48, 19, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_ML_6, img_small_fs_ml_6, 65, 142, 53, 20, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_ML_7, img_small_fs_ml_7, 60, 133, 58, 22, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_ML_8, img_small_fs_ml_8, 56, 124, 63, 23, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_MR_1, img_small_fs_mr_1, 118, 190, 28, 13, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_MR_2, img_small_fs_mr_2, 118, 180, 33, 14, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_MR_3, img_small_fs_mr_3, 118, 171, 38, 16, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_MR_4, img_small_fs_mr_4, 118, 161, 43, 18, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_MR_5, img_small_fs_mr_5, 118, 152, 48, 19, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_MR_6, img_small_fs_mr_6, 118, 142, 53, 20, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_MR_7, img_small_fs_mr_7, 118, 133, 58, 22, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_MR_8, img_small_fs_mr_8, 118, 124, 62, 23, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_R_1, img_small_fs_r_1, 141, 195, 30, 19, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_R_2, img_small_fs_r_2, 146, 187, 32, 22, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_R_3, img_small_fs_r_3, 151, 179, 33, 23, 0) \
	X(RVC_AND_PDC_LAYOUT, FS_R_4, img_small_fs_r_4, 156, 171, 36, 26, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_L_1, img_small_rs_l_1, 66, 479, 29, 19, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_L_2, img_small_rs_l_2, 59, 485, 32, 21, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_L_3, img_small_rs_l_3, 52, 491, 33, 23, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_L_4, img_small_rs_l_4, 45, 496, 36, 26, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_ML_1, img_small_rs_ml_1, 90, 490, 28, 13, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_ML_2, img_small_rs_ml_2, 85, 498, 33, 14, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_ML_3, img_small_rs_ml_3, 80, 507, 38, 16, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_ML_4, img_small_rs_ml_4, 75, 514, 43, 18, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_ML_5, img_small_rs_ml_5, 70, 522, 48, 19, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_ML_6, img_small_rs_ml_6, 65, 530, 53, 20, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_ML_7, img_small_rs_ml_7, 60, 538, 58, 22, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_ML_8, img_small_rs_ml_8, 56, 546, 63, 23, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_MR_1, img_small_rs_mr_1, 118, 490, 28, 13, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_MR_2, img_small_rs_mr_2, 118, 498, 33, 14, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_MR_3, img_small_rs_mr_3, 118, 507, 38, 16, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_MR_4, img_small_rs_mr_4, 118, 514, 43, 18, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_MR_5, img_small_rs_mr_5, 118, 522, 48, 19, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_MR_6, img_small_rs_mr_6, 118, 530, 53, 20, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_MR_7, img_small_rs_mr_7, 118, 538, 58, 22, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_MR_8, img_small_rs_mr_8, 118, 547, 62, 23, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_R_1, img_small_rs_r_1, 141, 479, 30, 19, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_R_2, img_small_rs_r_2, 146, 485, 32, 22, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_R_3, img_small_rs_r_3, 151, 491, 33, 23, 0) \
	X(RVC_AND_PDC_LAYOUT, RS_R_4, img_small_rs_r_4, 156, 496, 36, 26, 0) \

#define  RVC_AND_PDC_ASSET_AMOUNT	(66)
#define  RVC_AND_PDC_LAYOUT_WIDTH	(1024)
#define  RVC_AND_PDC_LAYOUT_HEIGHT	(600)

#endif /* __RVC_AND_PDC_LAYOUT_H__ */
