/******************************************************************************
 *
 * \file    video_heap.h
 *
 * \brief   Video Heap module header file
 *
 * \author  Esteban Pupillo
 *
 * \date    11 Jun 2022
 *
 *****************************************************************************/
#ifndef __VIDEO_HEAP_H__
#define __VIDEO_HEAP_H__

#include <standard.h>
#include <xdc/std.h>
#include <ti/sysbios/heaps/HeapMem.h>

/**
 * @addtogroup VideoHeap
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/


/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * \brief Initializes Video Heap Module
 *
 * This function shall be called before any other function of of the video
 * heap module
 *
 */
Int32 VideoHeap_init(void);

/**
 * \brief Allocates a buffer
 *
 * @param size Size in bytes of the buffer
 * @param align Required buffer aligmnet
 *
 * @return pointer to the allocated buffer
 */
Ptr VideoHeap_alloc(UInt32 size, UInt32 align);

/**
 * \brief Allocates a video frame buffer
 *
 * @param width width of the frame buffer in pixels
 * @param height height of the frame buffer in pixels
 * @param bpp bytes per pixel
 *
 * @return pointer to the allocated buffer
 */
Ptr VideoHeap_allocFrame(UInt32 width, UInt32 height, UInt32 bpp);

/**
 * \brief Checks pointer validity
 */
Int32 VideoHeap_isValidPtr(Ptr ptr);

/**
 * \brief Frees a buffer from video heap
 *
 * @param ptr Pointer to the buffer to free
 *
 * @return E_OK if success
 */
Int32 VideoHeap_free(Ptr ptr);

Int32 VideoHeap_getHeapHandle(HeapMem_Handle *handle); 

/**
 * Close doxygen group
 * @}
 */

#endif //__VIDEO_HEAP_H__
