/******************************************************************************
 *
 * \file    video_capture.c
 *
 * \brief   Video Capture module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    11 Jun 2022
 *
 *****************************************************************************/

#define TRACE_ENABLE
// #define LOG_DEBUG_SUPER_VERBOSE 1

#include <drv/board/board.h>
#include <standard.h>
#include "video_capture.h"
#include "comm_protocol.h"

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>
#include <ti/csl/csl_gpio.h>
#include <ti/csl/cslr_dss.h>
#include "clock_utils.h"

#include <ti/drv/vps/include/devices/bsp_lcdController.h>
#include <ti/drv/vps/include/platforms/bsp_platform.h>
#include <ti/drv/vps/include/boards/bsp_board.h>
#include <shadow_storage.h>

/**
 * @addtogroup VideoCapture
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/**
 * Number of buffers used for capturing frames
 */
#define VIDEOCAPTURE_MAX_FRAMES (3)

#define DEBUG_VIDEO_CAPT 0

#define VIDEOCAPTURE_CAPTURE_TASK_SIZE      (0x1000)
#define VIDEOCAPTURE_DIAGNOSTIC_TASK_SIZE   (0x1000)

#define VIDEOCAPTURE_DIAGNOSTIC_TASK_LOOP_TIME_MS       (50)
#define VIDEOCAPTURE_MIN_DIAGNOSTICS_TO_VALID           (10)

#define VIDEOCAPTURE_TVS_LOST_LOCK_DETECT_MASK          (1 << 4)
#define VIDEOCAPTURE_TVS_COLOR_SUBCARRIER_LOCK_MASK     (1 << 3)
#define VIDEOCAPTURE_TVS_VERTICAL_SYNC_LOCK_MASK        (1 << 2)
#define VIDEOCAPTURE_TVS_HORIZONTAL_SYNC_LOCK_MASK      (1 << 1)

#define VIDEOCAPTURE_CROP_WIDTH_LEFT                    (8)
#define VIDEOCAPTURE_CROP_WIDTH_RIGHT                   (16)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

struct video_capture_tag {
  bool_t isInitialized;

  Task_Handle vCaptHandle;
  /**< Video capture task handler */

  Task_Handle vCaptDiagnosticHandle;

  Semaphore_Handle newFrameSem;
  /**< new frame available semaphore */
  Fvid2_CbParams userCbPrms;
  /**< User callback parameters */

  Fvid2_Handle fvidHandleAll;

  UInt32 instId;
  UInt32 decDrvId;

  UInt32 inWidth;
  UInt32 inHeight;

  Vps_CaptCreateParams createPrms;
  Vps_CaptCreateStatus createStatus;
  Vps_CaptVipParams vipPrms;
  Vps_VipPortConfig vipPortCfg;
  Vps_CaptVipScParams scPrms;

  Fvid2_Format allocFmt;
  Fvid2_Frame frames[VIDEOCAPTURE_MAX_FRAMES];

  Fvid2_Handle drvHandle;
  Fvid2_CbParams cbPrms;

  UInt8 isCapturing;
};

static Semaphore_Handle __perform_diagnostic_sem;

static bool __diagnostic_made = false;
static bool __diagnostic_reverse_camera_ok = false;

static bool __diagnostic_frames_got = false;
static int __diagnostic_counter = 0;

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static struct video_capture_tag gVideoCapture;
/* Task stack size */
static uint8_t capture_stack[VIDEOCAPTURE_CAPTURE_TASK_SIZE];
static uint8_t diagnostic_stack[VIDEOCAPTURE_DIAGNOSTIC_TASK_SIZE];

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

/**
 * @brief Set the video decoder power down state
 * 
 * @param state Desired power down state. i.e. If this is true, the video
 * decoder will be put in power down mode
 */
static void videoCapture_SetPowerDown(bool_t state)
{
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s(): state=%d\r\n", __FUNCTION__);
  state ? GPIOPinWrite(VIDEO_CAMERA_PDN_GPIO_ADDR, VIDEO_CAMERA_PDN_GPIO_PIN, 0) : GPIOPinWrite(VIDEO_CAMERA_PDN_GPIO_ADDR, VIDEO_CAMERA_PDN_GPIO_PIN, 1);
}

/**
 * @brief Set the video decoder reset state
 * 
 * @param state Desired reset state. i.e. If this is true, the video
 * decoder will be put in reset mode
 */
static void videoCapture_SetReset(bool_t state)
{
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s(): state=%d\r\n", __FUNCTION__);
  state ? GPIOPinWrite(VIDEO_CAMERA_RST_GPIO_ADDR, VIDEO_CAMERA_RST_GPIO_PIN, 0) : GPIOPinWrite(VIDEO_CAMERA_RST_GPIO_ADDR, VIDEO_CAMERA_RST_GPIO_PIN, 1);
}

/** Initialize GPIOs related to the video capture module */
static void videoCapture_InitGpio()
{
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s() Initializing GPIOs...\r\n", __FUNCTION__);

  GPIOModuleEnable(VIDEO_CAMERA_PDN_GPIO_ADDR);
  GPIODirModeSet(VIDEO_CAMERA_PDN_GPIO_ADDR, VIDEO_CAMERA_PDN_GPIO_PIN, GPIO_DIR_OUTPUT);
  videoCapture_SetPowerDown(FALSE);

  GPIOModuleEnable(VIDEO_CAMERA_RST_GPIO_ADDR);
  GPIODirModeSet(VIDEO_CAMERA_RST_GPIO_ADDR, VIDEO_CAMERA_RST_GPIO_PIN, GPIO_DIR_OUTPUT);
}

/**
 * @brief Get the status registers from the video decoder chip
 * 
 * @param status_registers Buffer to store the status registers
 * @note The @a status_registers buffer shall be at least COMM_PROTOCOL_TVS_STATUS_REGISTER_MAX
 * long
 * @return int Result of the operation. E_OK if everything ok, error code otherwise
 */
static int videoCapture_ReadStatusRegisters(uint8_t *status_registers)
{
  int ret = E_OK, i;

  if (!status_registers)
    return E_ERROR;

  /* Obtain the current status registers from the TV decoder chip */
  for (i = 0; i < COMM_PROTOCOL_TVS_STATUS_REGISTER_MAX && ret == E_OK; i++)
    ret = COMM_Protocol_GetVideoDecoderStatusRegisters((int)COMM_PROTOCOL_TVS_STATUS_REGISTER_1 + i, &status_registers[i]);

  if (ret != E_OK)
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "(%s) [%d]: Error reading status register #%d: %d\r\n", __FUNCTION__, __LINE__, i, ret);

  return ret;
}

/**
 * @brief Get a single status register from the TV decoder chip
 *
 * @param reg_number Desired register number to be read
 * @param status_register Pointer to store the status of the desired register
 * @return int Result of the operation
 */
static int videoCapture_ReadSingleStatusRegister(COMM_Protocol_TvsStatusRegisterNumber_en reg_number, uint8_t *status_register)
{
  int ret = E_OK;

  if (!status_register)
    return E_ERROR;
  
  if (reg_number >= COMM_PROTOCOL_TVS_STATUS_REGISTER_MAX)
    return E_ERROR;

  ret = COMM_Protocol_GetVideoDecoderStatusRegisters((int) reg_number, status_register);

  if (ret != E_OK)
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "(%s) [%d]: Error reading status register #%d: %d\r\n", __FUNCTION__, __LINE__, reg_number, ret);
  
  return ret;
}

static Int32 videoCapture_callback(Fvid2_Handle handle, Ptr appData, Ptr reserved)
{
  Int32 retVal = FVID2_SOK;
  VideoCapture videoCapture = (VideoCapture) appData;

  if (videoCapture->isCapturing)
  {
    /* New Frame available. Signal it */
    if (NULL != videoCapture->userCbPrms.cbFxn)
    {
        (*videoCapture->userCbPrms.cbFxn)(NULL, videoCapture->userCbPrms.appData, NULL);
    }
  }
  else
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "%s [%d]: VideoCapture not capturing!\r\n", __FUNCTION__, __LINE__);
  }

  return retVal;
}

static void videoCapture_initParams(VideoCapture videoCapture)
{
  Vps_CaptCreateParams *createPrms;
  Vps_CaptVipParams *vipPrms;
  Vps_CaptVipScParams *scPrms;
  Vps_CaptVipOutInfo *outInfo;

  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s()\r\n", __FUNCTION__);
  
  Fvid2CbParams_init(&videoCapture->cbPrms);
  videoCapture->cbPrms.cbFxn = &videoCapture_callback;
  videoCapture->cbPrms.appData = videoCapture;

  createPrms = &videoCapture->createPrms;
  VpsCaptCreateParams_init(createPrms);
  createPrms->videoIfMode = FVID2_VIFM_SCH_ES;
  createPrms->videoIfWidth = FVID2_VIFW_8BIT;
  createPrms->bufCaptMode = VPS_CAPT_BCM_FRM_DROP; //VPS_CAPT_BCM_LAST_FRM_REPEAT;
  createPrms->numCh = 1U;
  createPrms->numStream = 1U;
  createPrms->chNumMap[0][0] = Vps_captMakeChNum(videoCapture->instId, 0U, 0U);


  vipPrms = &videoCapture->vipPrms;
  VpsCaptVipParams_init(vipPrms);
  vipPrms->inFmt.chNum = 0U;
  vipPrms->inFmt.width = videoCapture->inWidth;
  vipPrms->inFmt.height = videoCapture->inHeight;
  vipPrms->inFmt.pitch[0] = 0U;
  vipPrms->inFmt.pitch[1] = 0U;
  vipPrms->inFmt.pitch[2] = 0U;

  vipPrms->inFmt.fieldMerged[0] = FALSE;
  vipPrms->inFmt.fieldMerged[1] = FALSE;
  vipPrms->inFmt.fieldMerged[2] = FALSE;
  vipPrms->inFmt.dataFormat = FVID2_DF_YUV422P;
  vipPrms->inFmt.scanFormat = FVID2_SF_INTERLACED; //FVID2_SF_PROGRESSIVE;
  vipPrms->inFmt.bpp = FVID2_BPP_BITS16; //FVID2_BPP_BITS16;
  vipPrms->inFmt.reserved = NULL;
  vipPrms->cscCfg = NULL;
  vipPrms->vipPortCfg = &videoCapture->vipPortCfg;
  VpsVipPortConfig_init(vipPrms->vipPortCfg);

  outInfo = &vipPrms->outStreamInfo[0];
  VpsCaptVipOutInfo_init(outInfo);
  outInfo->outFmt.chNum = 0U;
  outInfo->outFmt.width = vipPrms->inFmt.width;
  outInfo->outFmt.height = vipPrms->inFmt.height;
  outInfo->outFmt.fieldMerged[0] = FALSE;
  outInfo->outFmt.fieldMerged[1] = FALSE;
  outInfo->outFmt.fieldMerged[2] = FALSE;
  outInfo->outFmt.dataFormat = FVID2_DF_YUV422I_YUYV;
  outInfo->outFmt.scanFormat = FVID2_SF_INTERLACED; //FVID2_SF_PROGRESSIVE;
  outInfo->outFmt.bpp = FVID2_BPP_BITS16; //FVID2_BPP_BITS16;
  outInfo->outFmt.pitch[0] = 0U;
  outInfo->outFmt.pitch[1] = 0U;
  outInfo->outFmt.pitch[2] = 0U;
  outInfo->outFmt.pitch[FVID2_YUV_INT_ADDR_IDX] = VpsUtils_align(outInfo->outFmt.width * 2U, VPS_BUFFER_ALIGNMENT);

  outInfo->bufFmt = FVID2_BUF_FMT_FIELD;
  outInfo->memType = VPS_VPDMA_MT_NONTILEDMEM;
  outInfo->scEnable = TRUE;
  outInfo->subFrmPrms.subFrameEnable = FALSE;
  outInfo->subFrmPrms.numLinesPerSubFrame = 0U;
  outInfo->subFrmPrms.subFrameCb = NULL;

  
  scPrms = &videoCapture->scPrms;
  VpsCaptVipScParams_init(scPrms);
  scPrms->inCropCfg.cropStartX = VIDEOCAPTURE_CROP_WIDTH_LEFT;
  scPrms->inCropCfg.cropStartY = 0U;
  scPrms->inCropCfg.cropWidth = outInfo->outFmt.width - VIDEOCAPTURE_CROP_WIDTH_LEFT - VIDEOCAPTURE_CROP_WIDTH_RIGHT; //vipPrms->inFmt.width;
  scPrms->inCropCfg.cropHeight = outInfo->outFmt.height; //vipPrms->inFmt.height;
  scPrms->scCfg.bypass = FALSE;
  scPrms->scCfg.nonLinear = FALSE;
  scPrms->scCfg.stripSize = 0U;
  scPrms->scCfg.enableEdgeDetect = TRUE;
  scPrms->scCfg.enablePeaking = TRUE;
  scPrms->scCfg.advCfg = NULL;
  scPrms->scCoeffCfg = NULL;
  scPrms->enableCoeffLoad = FALSE;
  
  vipPrms->scPrms = scPrms;
}

static Int32 videoCapture_create(VideoCapture videoCapture)
{
  Int32 retVal = FVID2_SOK;
  Vps_VpdmaMaxSizeParams vipMaxSizePrms;

  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s()\r\n", __FUNCTION__);
  
  videoCapture->fvidHandleAll = Fvid2_create(FVID2_VPS_CAPT_VID_DRV, 
                                             VPS_CAPT_INST_ALL, 
                                             NULL, 
                                             NULL, 
                                             NULL);
  if (NULL == videoCapture->fvidHandleAll)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "VideoCapture: Global capture driver create failed!!\r\n");
    retVal = FVID2_EFAIL;
    return retVal;
  }

  videoCapture_initParams(videoCapture);

  VpsVpdmaMaxSizeParams_init(&vipMaxSizePrms);
  vipMaxSizePrms.instId = Vps_captGetVipId(videoCapture->instId);
  vipMaxSizePrms.maxOutWidth[0] = videoCapture->vipPrms.inFmt.width*2;
  vipMaxSizePrms.maxOutHeight[0] = videoCapture->vipPrms.inFmt.height*2;
  vipMaxSizePrms.maxOutWidth[1] = videoCapture->vipPrms.inFmt.width*2;
  vipMaxSizePrms.maxOutHeight[1] = videoCapture->vipPrms.inFmt.height*2;
  vipMaxSizePrms.maxOutWidth[2] = videoCapture->vipPrms.inFmt.width*2;
  vipMaxSizePrms.maxOutHeight[2] = videoCapture->vipPrms.inFmt.height*2;

  retVal = Fvid2_control(videoCapture->fvidHandleAll, 
                         IOCTL_VPS_CAPT_SET_VIP_MAX_SIZE, 
                         &vipMaxSizePrms, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "VideoCapture: VIP Set max frame size params IOCTL failed! Error code = %d\r\n", retVal);
    return retVal;
  }

  videoCapture->drvHandle = Fvid2_create(FVID2_VPS_CAPT_VID_DRV,
                                         videoCapture->instId,
                                         &videoCapture->createPrms,
                                         &videoCapture->createStatus,
                                         &videoCapture->cbPrms);
  if ((NULL == videoCapture->drvHandle) ||
      (FVID2_SOK != videoCapture->createStatus.retVal))
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "VideoCapture: Capture driver create failed!!\r\n", );
    retVal = videoCapture->createStatus.retVal;
    return retVal;
  }

  retVal = Fvid2_control(videoCapture->drvHandle, 
                         IOCTL_VPS_CAPT_SET_VIP_PARAMS, 
                         &videoCapture->vipPrms,
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "VideoCapture: VIP Set Params IOCTL failed(%d)!!\r\n", retVal);
    Fvid2_delete(videoCapture->drvHandle, NULL);
    return retVal;
  }

  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_MDIO_MCLK,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_MDIO_D,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_UART3_RXD,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_UART3_TXD,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_RGMII0_TXC,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_RGMII0_TXCTL,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_RGMII0_TXD3,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
   Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_RGMII0_TXD2,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
   Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_RGMII0_TXD1,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_RGMII0_RXC,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_RGMII0_RXCTL,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_RGMII0_RXD3,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  Bsp_platformSetPinmuxRegs(
      (UInt32) 5U,
      (UInt32) CTRL_CORE_PAD_RGMII0_RXD0,
      BSP_PLATFORM_IOPAD_CFG_INPUTENABLE_BI);
  
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s(): Creation done\r\n", __FUNCTION__);
  return retVal;
}

static void videoCapture_captureTask(UArg arg0, UArg arg1)
{
  UInt32 exit = FALSE;
  VideoCapture videoCapture = (VideoCapture) arg0;

  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s(): Starting video capture task. inst = %p\r\n", __FUNCTION__, videoCapture);

  while(!exit)
  {
    /* Wait till frames are ready */
    Semaphore_pend(videoCapture->newFrameSem, BIOS_WAIT_FOREVER);

    LOG_PRINT_SVER(DEBUG_VIDEO_CAPT, "%s(): New Frame...\r\n", __FUNCTION__);

    if (NULL != videoCapture->userCbPrms.cbFxn)
    {
       (*videoCapture->userCbPrms.cbFxn)(NULL, videoCapture->userCbPrms.appData, NULL);
    }
  }
}

static void videoCapture_diagnosticTask(UArg arg0, UArg arg1)
{
  static const int DIAGNOSTICS_NEEDED = VIDEOCAPTURE_MIN_DIAGNOSTICS_TO_VALID;
  static const int MIN_DIAGNOSTICS_OK = (VIDEOCAPTURE_MIN_DIAGNOSTICS_TO_VALID / 2);
  
  bool last_diagnostic = false;
  int diagnostic_values = 0;
  uint8_t status_register;

  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "(%s) [%d]: Starting Video Capture diagnostic task!\r\n", __FUNCTION__, __LINE__);
  uint8_t diagnosticRVC = (uint8_t) E_INVALID_CONDITION;
  Shadow_Server_Storage_Set(SHADOW_DiagnosticRVC, (uint8_t *)&diagnosticRVC);

  while (1)
  {
    Semaphore_pend(__perform_diagnostic_sem, BIOS_WAIT_FOREVER);

    if (!__diagnostic_made)
    {
      bool this_diagnostic_res = false;
      int ret = videoCapture_ReadSingleStatusRegister(COMM_PROTOCOL_TVS_STATUS_REGISTER_1, &status_register);

      if (__diagnostic_counter == 0)
        diagnostic_values = 0;

      if (E_OK == ret)
      {
        /* Now lets check if the related register is ok */
        bool lock_detect = (status_register & VIDEOCAPTURE_TVS_LOST_LOCK_DETECT_MASK) != VIDEOCAPTURE_TVS_LOST_LOCK_DETECT_MASK;
        bool color_carrier_lock = (status_register & VIDEOCAPTURE_TVS_COLOR_SUBCARRIER_LOCK_MASK) == VIDEOCAPTURE_TVS_COLOR_SUBCARRIER_LOCK_MASK;
        bool vertical_sync_lock = (status_register & VIDEOCAPTURE_TVS_VERTICAL_SYNC_LOCK_MASK) == VIDEOCAPTURE_TVS_VERTICAL_SYNC_LOCK_MASK;
        bool horizontal_sync_lock = (status_register & VIDEOCAPTURE_TVS_HORIZONTAL_SYNC_LOCK_MASK) == VIDEOCAPTURE_TVS_HORIZONTAL_SYNC_LOCK_MASK;

        if (lock_detect && color_carrier_lock && vertical_sync_lock && horizontal_sync_lock)
          diagnostic_values++;
        
        __diagnostic_counter++;
        if (__diagnostic_counter >= VIDEOCAPTURE_MIN_DIAGNOSTICS_TO_VALID)
        {
          /* Diagnostic result will be OK only if at least half of the checks where OK */
          /*
              TODO: This is kind of cheating... Maybe the camera has micro-disconnections and
              the majority of the checks where ok but the frame rate would be ugly. I don't have
              at the moment any way of recreating this scenario, so I'm leaving this as-is
           */
          if (diagnostic_values >= MIN_DIAGNOSTICS_OK)
          {
            __diagnostic_reverse_camera_ok = true;
            diagnosticRVC = (uint8_t) E_OK;
            Shadow_Server_Storage_Set(SHADOW_DiagnosticRVC, (uint8_t *)&diagnosticRVC);
          }
          else
          {
            __diagnostic_reverse_camera_ok = false;
            diagnosticRVC = (uint8_t) E_ERROR;
            Shadow_Server_Storage_Set(SHADOW_DiagnosticRVC, (uint8_t *)&diagnosticRVC);
          }

          __diagnostic_made = true;

          LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "(%s) [%d]: Diagnostic of reverse camera finished! Diagnostic result: %d/%d => %s\r\n",
                         __FUNCTION__,
                         __LINE__,
                         diagnostic_values,
                         MIN_DIAGNOSTICS_OK,
                         __diagnostic_reverse_camera_ok ? "OK" : "NOT OK");
        }
      }
    }

    Semaphore_post(__perform_diagnostic_sem);

    Task_sleep_ms(VIDEOCAPTURE_DIAGNOSTIC_TASK_LOOP_TIME_MS);
  }
}

static Int32 videoCapture_createCaptureTask(VideoCapture videoCapture)
{
  Error_Block eb;
  Task_Params taskParams;
  Task_Handle taskHandle;

  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s()\r\n", __FUNCTION__);

  Error_init(&eb);

  /* create main thread (interrupts not enabled in main on BIOS) */
  Task_Params_init(&taskParams);
  taskParams.instance->name = "vcaptcapt";
  taskParams.arg0 = (xdc_UArg) videoCapture;
  taskParams.stackSize = VIDEOCAPTURE_CAPTURE_TASK_SIZE;
  taskParams.stack = capture_stack;
  taskParams.affinity = VIDEO_CORE_NUM;
 
  taskHandle = Task_create(videoCapture_captureTask, &taskParams, &eb);
  if (NULL == taskHandle)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "Couldn't create video capture capture task\n");
    return FVID2_EFAIL;
  }

  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "Video capture capture task created successfully\n");
  videoCapture->vCaptHandle = taskHandle;

  Task_Params_init(&taskParams);
  taskParams.instance->name = "vcaptdiag";
  taskParams.arg0 = (xdc_UArg) videoCapture;
  taskParams.stackSize = VIDEOCAPTURE_DIAGNOSTIC_TASK_SIZE;
  taskParams.stack = diagnostic_stack;
  taskParams.affinity = VIDEO_CORE_NUM;
 
  taskHandle = Task_create(videoCapture_diagnosticTask, &taskParams, &eb);
  if (NULL == taskHandle)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "Couldn't create video capture diagnostic task\n");
    return FVID2_EFAIL;
  }

  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "Video capture diagnostic task created successfully\n");
  videoCapture->vCaptDiagnosticHandle = taskHandle;

  return FVID2_SOK;
}

Int32 VideoCapture_init(VideoCapture *videoCapture, UInt32 instId, UInt32 inWidth, UInt32 inHeight, Fvid2_CbParams callback)
{
  Int32 retVal;
  Semaphore_Params semPrms;

  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s()\r\n", __FUNCTION__);

  /* Check for input parameter */
  if (NULL == videoCapture) 
    return FVID2_EBADARGS;

  /* The 50msecs are necessary for a correct reset of the video decoder (see datasheet) */
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s() Resetting camera decoder reset...\r\n", __FUNCTION__);
  videoCapture_SetReset(TRUE);
  Task_sleep_ms(50);
  videoCapture_SetReset(FALSE);

  /* Configuration commands via I2C */
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "%s() Configuring video decoder...\r\n", __FUNCTION__);
  COMM_Protocol_InitVideoDecoder();

  *videoCapture = &gVideoCapture;

  /* Initialize internal variables */
  gVideoCapture.isInitialized = FALSE;

  /* Initialize video video capture instance id */
  gVideoCapture.instId = instId;

  /* Initialize input dimensions */
  gVideoCapture.inWidth = inWidth;
  gVideoCapture.inHeight = inHeight;
  
  /* Create a local copy of callback object */
  memcpy(&gVideoCapture.userCbPrms, &callback, sizeof(callback));
  
  Semaphore_Params_init(&semPrms);
  gVideoCapture.newFrameSem = Semaphore_create(0, &semPrms, NULL);
  if (NULL == gVideoCapture.newFrameSem)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "%s(): New frame semaphore create failed!!\r\n", __FUNCTION__);
    return FVID2_EFAIL;
  }

  __perform_diagnostic_sem = Semaphore_create(0, &semPrms, NULL);
  if (NULL == __perform_diagnostic_sem)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "(%s) [%d]: Error creating necessary semaphore to perform reverse camera diagnostics.\r\n", __FUNCTION__, __LINE__);
    return FVID2_EFAIL;
  }

  retVal = videoCapture_createCaptureTask(&gVideoCapture);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "%s(): Capture task creation failed!!\r\n");
    return retVal;
  }

  /* Create and configure capture device */
  retVal = videoCapture_create(*videoCapture);
  if (FVID2_SOK == retVal)
  {
    /* If everything went OK update the initialization flag */
    gVideoCapture.isInitialized = TRUE;
  }

  return retVal;
}

Int32 VideoCapture_startDiagnostic(VideoCapture videoCapture)
{
  Int32 retVal = FVID2_SOK;

  /* Check input arguments */
  if (NULL == videoCapture)
    return FVID2_EBADARGS;

  __diagnostic_made = false;
  __diagnostic_frames_got = false;
  __diagnostic_counter = 0;
  Semaphore_post(__perform_diagnostic_sem);

  return retVal;
}

Int32 VideoCapture_start(VideoCapture videoCapture)
{
  Int32 retVal;
  UInt32 cookie;

  /* Check for a valid instance */
  if (NULL == videoCapture)
    return FVID2_EBADARGS;

  /* If the driver is not initialized return an error */
  if (!videoCapture->isInitialized)
    return FVID2_EINVALID_PARAMS;
  
  /* If the capture is already capturing, do nothing */
  if (videoCapture->isCapturing)
    return FVID2_SOK;

  /* Start capture device */
  retVal = Fvid2_start(gVideoCapture.drvHandle, NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "VideoCapture start failed!!\r\n");
  }

  cookie = BspOsal_disableInterrupt();
  videoCapture->isCapturing = 1;
  BspOsal_restoreInterrupt(cookie);

  return retVal;
}

Int32 VideoCapture_stopDiagnostic(VideoCapture videoCapture)
{
  Int32 retVal = FVID2_SOK;

  /* Check for a valid instance */
  if (NULL == videoCapture)
    return FVID2_EBADARGS;
  
  Semaphore_pend(__perform_diagnostic_sem, BIOS_WAIT_FOREVER);

  return retVal;
}

Int32 VideoCapture_stop(VideoCapture videoCapture)
{
  Int32 retVal;
  Vps_CaptStatus captStatus;
  UInt32 cookie;

  /* Check for a valid instance */
  if (NULL == videoCapture)
    return FVID2_EBADARGS;

  /* If the driver is not initialized return an error */
  if (!videoCapture->isInitialized)
    return FVID2_EINVALID_PARAMS;

  /* If the capture is not capturing, do nothing */
  if (!videoCapture->isCapturing)
    return FVID2_SOK;
  
  cookie = BspOsal_disableInterrupt();
  videoCapture->isCapturing = 0;
  BspOsal_restoreInterrupt(cookie);

  /* Stop capture device */
  retVal = Fvid2_stop(gVideoCapture.drvHandle, NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "VideoCapture stop failed!!\r\n");
    return retVal;
  }

  /* Get current driver status */
  retVal = Fvid2_control(videoCapture->drvHandle, 
                         IOCTL_VPS_CAPT_GET_STATUS, 
                         &captStatus, NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "Video capture get status IOCTL failed!!\r\n");
    return retVal;
  }

  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "Video Capture status: queueCount = %d, dequeueCount = %d, overflowCount = %d\r\n", 
      captStatus.queueCount, captStatus.dequeueCount, captStatus.overflowCount);

  return retVal;
}

Int32 VideoCapture_dumpStats(VideoCapture videoCapture)
{
  UInt32 retVal;
  Vps_CaptChStatusArgs chStatusArgs;
  Vps_CaptChStatus chStatus;
  chStatusArgs.chNum = 0;
  chStatusArgs.frameInterval = 20000 / Clock_tickPeriod;

  /* Check for a valid instance */
  if (NULL == videoCapture)
    return FVID2_EBADARGS;

  /* If the driver is not initialized return an error */
  if (!videoCapture->isInitialized)
    return FVID2_EINVALID_PARAMS;

  /* Retrive stats from underlaying driver */
  retVal = Fvid2_control(videoCapture->drvHandle, IOCTL_VPS_CAPT_GET_CH_STATUS, &chStatusArgs, &chStatus);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "%s(): Get channel stats IOCTL failed!!\r\n", __FUNCTION__);
  }

  /* Print stat report */
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "v---------------------------\r\n");
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "| isVideoDetected = %d, queueCount = %d, dequeueCount = %d, captFrmCount = %d\r\n", 
      chStatus.isVideoDetected, chStatus.queueCount, chStatus.dequeueCount, chStatus.captFrmCount);
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "| fldCount[0] = %d, fldCount[1] = %d, maxRecvFrmWidth = %d, minRecvFrmWidth = %d\r\n",
      chStatus.fldCount[0], chStatus.fldCount[1], chStatus.maxRecvFrmWidth, chStatus.minRecvFrmWidth);
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "| maxRecvFrmHeight = %d, minRecvFrmHeight = %d, droppedFrmCount = %d, repeatFrmCount = %d\r\n",
      chStatus.maxRecvFrmHeight, chStatus.minRecvFrmHeight, chStatus.droppedFrmCount, chStatus.repeatFrmCount);
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "| fidRepeatCount = %d, lastFrmWith = %d, lastFrmHeight = %d, lastFid = %d\r\n",
      chStatus.fidRepeatCount, chStatus.lastFrmWidth, chStatus.lastFrmHeight, chStatus.lastFid);
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "| lastFrmTimeStamp = %d, descErrCount = %d\r\n", chStatus.lastFrmTimeStamp, chStatus.descErrCount);
  LOG_PRINT_INFO(DEBUG_VIDEO_CAPT, "^---------------------------\r\n");

  return FVID2_SOK;
}

int VideoCapture_cameraOk(bool *ok)
{
  if (!__diagnostic_made)
    return E_INVALID_CONDITION;

  if (!ok)
    return E_ERROR;

  *ok = __diagnostic_reverse_camera_ok;

  return E_OK;
}

void VideoCapture_initGpios(void)
{
  videoCapture_InitGpio();
}

Int32 VideoCapture_queueBuffer(VideoCapture videoCapture, Fvid2_FrameList *frmList)
{
  Int32 retVal;
  UInt32 cnt;
  UInt32 cookie;

  /* Check for a valid instance */
  if ((NULL == videoCapture) || (NULL == frmList))
    return FVID2_EBADARGS;

  /* If the driver is not initialized return an error */
  if (!videoCapture->isInitialized)
    return FVID2_EINVALID_PARAMS;

  cookie = BspOsal_disableInterrupt();
  
  /* Reset channel number */
  for(cnt = 0; cnt < frmList->numFrames; cnt++)
  {
    frmList->frames[cnt]->chNum = Vps_captMakeChNum(videoCapture->instId, 0, 0);
  }
  /* queue frame list to underlaying driver */
  retVal = Fvid2_queue(videoCapture->drvHandle, frmList, 0);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "VideoCapture: queue failed!!\r\n");
  }

  BspOsal_restoreInterrupt(cookie);

  return retVal;
}

Int32 VideoCapture_dequeueBuffer(VideoCapture videoCapture, Fvid2_FrameList *frmList)
{
  Int32 retVal;

  /* Check for a valid instance */
  if ((NULL == videoCapture) || (NULL == frmList))
    return FVID2_EBADARGS;

  /* If the driver is not initialized return an error */
  if (!videoCapture->isInitialized)
    return FVID2_EINVALID_PARAMS;

  /* dequeue frame list from underlaying driver */
  retVal = Fvid2_dequeue(videoCapture->drvHandle, frmList, 0, FVID2_TIMEOUT_NONE);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_CAPT, "%s(): dequeue failed (%d)!!\r\n", __FUNCTION__, retVal);
  }

  return retVal;
}

/**
 * Close doxygen group
 * @}
 */
