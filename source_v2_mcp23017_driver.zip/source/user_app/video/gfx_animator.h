/******************************************************************************
 *
 * \file    gfx_animator.h
 *
 * \brief   Graphic animator header file
 *
 * \author  Esteban Pupillo
 *
 * \date    17 Sep 2022
 *
 *****************************************************************************/
#ifndef __GFX_ANIMATOR_H__
#define __GFX_ANIMATOR_H__

/**
 * @addtogroup GfxAnimator
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief GfxAnimator abstract data type
 */
typedef struct gfx_animator_type* GfxAnimator;

/**
 * @brief GfxAnimator parameters 
 */
typedef struct gfx_animator_params_tag {
	Int32 startValue;
	Int32 endValue;
	UInt32 parameterKey;

	UInt32 timeScaleFactor;

} GfxAnimatorParams;

typedef struct gfx_animator_value_type {
	Int32 value;
	UInt32 parameterKey;
} GfxAnimatorValue;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initializes Graphic Animator parameters
 */
void inline GfxAnimatorParams_init(GfxAnimatorParams *params)
{
	if (NULL != params)
	{
		memset(params, 0, sizeof(GfxAnimatorParams));
		params->timeScaleFactor = 1;
	}
}

/**
 * @brief Creates a graphic animator
 *
 * @param gfxAnimator pointer to a graphic animator to create
 * @param params pointer the graphic animator parameters
 * 
 * @return #E_OK on success
 */
Int32 GfxAnimator_create(GfxAnimator *gfxAnimator, GfxAnimatorParams *params);

Int32 GfxAnimator_update(GfxAnimator gfxAnimator, GfxAnimatorValue *outValue, bool_t *hasEnded);

Int32 GfxAnimator_start(GfxAnimator gfxAnimator);

Int32 GfxAnimator_destroy(GfxAnimator gfxAnimator);

UInt32 GfxAnimator_getLutSize();

/**
 * Close doxygen group
 * @}
 */

#endif //__GFX_ANIMATOR_H__
