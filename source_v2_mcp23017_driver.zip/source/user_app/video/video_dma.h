/******************************************************************************
 *
 * \file    video_dma.h
 *
 * \brief   Video DMA module header file
 *
 * \author  Esteban Pupillo
 *
 * \date    19 Jul 2022
 *
 *****************************************************************************/
#ifndef __VIDEO_DMA_H__
#define __VIDEO_DMA_H__

#include <standard.h>
#include <xdc/std.h>


/**
 * @addtogroup VideoDma
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define _USE_DMA_ 1

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/


/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * \brief Initializes Video DMA Module
 *
 * This function shall be called before any other function of of the video
 * dma module
 *
 */
Int32 VideoDMA_init(void);

/**
 * \brief Deinitializes Video DMA Module
 *
 * After calling this function is prohibited to call any other function of 
 * this API
 *
 */
Int32 VideoDMA_deinit(void);

Int32 VideoDMA_copyFrame(void *dstFrame, UInt32 dstBpp, UInt32 dstStride, 
                         void *srcFrame, UInt32 srcBpp, UInt32 srcStride,
                         UInt32 width, UInt32 height);

Int32 VideoDMA_copyFrame_RVC(void *dstFrame, UInt32 dstBpp, UInt32 dstStride, 
                         void *srcFrame, UInt32 srcBpp, UInt32 srcStride,
                         UInt32 width, UInt32 height);

Int32 VideoDMA_copy(void *dst, const void *src, size_t size);

void Video_AutoTurn90_YUV422I(uint8_t *srcp, int width, int height, int src_stride, int dst_stride);

/**
 * Close doxygen group
 * @}
 */

#endif //__VIDEO_DMA_H__
