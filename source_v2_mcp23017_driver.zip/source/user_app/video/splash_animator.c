/******************************************************************************
 *
 * \file    splash_animator.c
 *
 * \brief   Splash animator module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    23 Jun 2022
 *
 *****************************************************************************/
#include <standard.h>
#include "console.h"
#include <xdc/std.h>
#include "junzip/junzip.h"
#include "splash_animator.h"

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/sysbios/hal/Cache.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Mailbox.h>


#include <ti/drv/vps/include/platforms/bsp_platform.h>
#include <ti/drv/vps/include/common/bsp_utilsQue.h>

#include "gfx_layer.h"
#include "zip_memory_file.h"
#include "libs/lodepng/lodepng.h"
#include <lodepng_allocator.h>

#if defined PRODUCT_VOLKSWAGEN
#include <displays/9inches_4D_display_cfg.h>
// Place other display definitions here depending on the product
// #elif defined PRODUCT_OTHER
// #include <displays/...>
#else
#error  "No product is defined!"
#endif

/**
 * @addtogroup SplashAnimator
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define SPLASH_ANIMATOR_TASK_STACK_SIZE   (0x1000)

#define SPLASH_ANIMATOR_MAX_FRAMES        (4)

#define DEBUG_SPLASH     0

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
typedef enum splash_animator_message_id_tag {
	SPLASH_ANIMATOR_MSG_NONE,
	SPLASH_ANIMATOR_MSG_NEW_FRAME_REQ,
	SPLASH_ANIMATOR_MSG_PLAY,
	SPLASH_ANIMATOR_MSG_STOP,

	SPLASH_ANIMATOR_MSG_NUM,
} SplashAnimatorMessageId;

typedef struct splash_animator_msg_tag {
	SplashAnimatorMessageId id;
	UInt32 param1;
	UInt32 param2;
	Ptr appData;
} SplashAnimatorMessage;

struct splash_animator_tag {
  bool_t isInitialized;
	bool_t isDecoding;
	bool_t isPlaying;

  Task_Handle procHandle;

	Mailbox_Handle msgMailbox;

	Fvid2_Frame frames[SPLASH_ANIMATOR_MAX_OUTPUT_FRAMES];
	Ptr qFramesData[SPLASH_ANIMATOR_MAX_OUTPUT_FRAMES];
	BspUtils_QueHandle qOutFrames;

	GfxLayer gfxLayer;
	JZFile *zipFile;
	JZFileHeader *fileHeaders;
	UInt32 fileHeadersNum;
	UInt32 frameCounter;

	LodePNGState pngState;

  bool start;
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/
static Int32 splashAnimator_decodeFrame(SplashAnimator splashAnimator, UInt32 frameIndex, Fvid2_Frame *frame);

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static uint8_t stack[SPLASH_ANIMATOR_TASK_STACK_SIZE];
static struct splash_animator_tag gSplashAnimator;

/******************************************************************************
 * Functions implementation
 *****************************************************************************/
static void splashAnimator_onRequestNewFrameMsg(SplashAnimator splashAnimator)
{
	Int32 retVal = E_OK;
	Fvid2_Frame *frame;

	if (splashAnimator->frameCounter >= splashAnimator->fileHeadersNum)
	{
		/* We reach the end of the animation. we don't need to decode more frames */
		return;
	}

	splashAnimator->isDecoding = TRUE;
	retVal = GfxLayer_dequeueFrame(splashAnimator->gfxLayer, &frame);

  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Error dequeuing GfxLayer frame!\r\n");
    return;
  }

	lodepng_free(PHY_TO_DA_ADDR(frame->addr[0][0]));
	splashAnimator_decodeFrame(splashAnimator, splashAnimator->frameCounter++, frame);

	LOG_PRINT_SVER(DEBUG_SPLASH, "%s() [%d]: frame->addr[0][0] = %p\r\n", __FUNCTION__, __LINE__, frame->addr[0][0]);
	retVal = GfxLayer_queueFrame(splashAnimator->gfxLayer, frame);

  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Error enqueuing GfxLayer frame!\r\n");
    return;
  }

	splashAnimator->isDecoding = FALSE;
}
static void splashAnimator_processMessage(SplashAnimator splashAnimator, SplashAnimatorMessage msg)
{
	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): New Message received with ID %d\r\n", __FUNCTION__, msg.id);

	switch(msg.id)
	{
		case SPLASH_ANIMATOR_MSG_NEW_FRAME_REQ:
			if (splashAnimator->isPlaying)
				splashAnimator_onRequestNewFrameMsg(splashAnimator);
			break;
		case SPLASH_ANIMATOR_MSG_PLAY:
			splashAnimator->isPlaying = TRUE;
			break;
		case SPLASH_ANIMATOR_MSG_STOP:
			splashAnimator->isPlaying = FALSE;
			break;
		default:
			break;
	}
}

static void splashAnimator_processTask(UArg arg0, UArg arg1)
{
  UInt32 exit = FALSE;
  SplashAnimator splashAnimator = (SplashAnimator) arg0;
	SplashAnimatorMessage msg;

  LOG_PRINT_INFO(DEBUG_SPLASH, "Starting Splash Animator task\r\n");

	while(!exit)
	{
		if (Mailbox_pend(splashAnimator->msgMailbox, &msg, BIOS_WAIT_FOREVER))
		{
			splashAnimator_processMessage(splashAnimator, msg);
		}
	}
}

static Int32 splashAnimator_initMailbox(SplashAnimator splashAnimator)
{
	Mailbox_Params mboxParams;
	Error_Block eb;

	Error_init(&eb);

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): Creating message mailbox\r\n", __FUNCTION__);
	Mailbox_Params_init(&mboxParams);
	splashAnimator->msgMailbox = Mailbox_create(sizeof(SplashAnimatorMessage), 10, &mboxParams, &eb);
  if (NULL == splashAnimator->msgMailbox)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to create message mailbox\r\n", __FUNCTION__);
	}

	return E_OK;
}

static Int32 splashAnimator_createProcessTask(SplashAnimator splashAnimator)
{
  Error_Block eb;
  Task_Params taskParams;
  Task_Handle taskHandle;

  Error_init(&eb);

  /* create main thread (interrupts not enabled in main on BIOS) */
  Task_Params_init(&taskParams);
  taskParams.instance->name = "splashAnim";
  taskParams.arg0 = (xdc_UArg) splashAnimator;
  taskParams.stackSize = SPLASH_ANIMATOR_TASK_STACK_SIZE;
  taskParams.stack = stack;
	taskParams.affinity = APP_CORE_NUM;
 
  taskHandle = Task_create(splashAnimator_processTask, &taskParams, &eb);
  if (NULL == taskHandle)
  {
    LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Couldn't create splash animator processing task\r\n", __FUNCTION__);
    return FVID2_EFAIL;
  }
  
  LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): Splash animator processing task created successfully\r\n", __FUNCTION__);
  splashAnimator->procHandle = taskHandle;

  return FVID2_SOK;
}

static Int32 splashAnimtor_readFile(SplashAnimator splashAnimator, JZFileHeader *header, UInt8 *data)
{
	Int32 retVal = E_OK;
	JZFile *f = splashAnimator->zipFile;
	UInt32 offset;
	JZFileHeader localHeader;

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): Reading file at offset %d with size %d bytes\r\n", __FUNCTION__, header->offset, header->uncompressedSize);

	offset = f->tell(f);

	f->seek(f, header->offset, SEEK_SET);

	retVal = jzReadLocalFileHeader(f, &localHeader, NULL, 0);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to read local file header\r\n", __FUNCTION__);
		f->seek(f, offset, SEEK_SET);
    return E_ERROR;
  }

	
	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): compressionMethod = %d, uncompressedSize = %d\r\n", __FUNCTION__, localHeader.compressionMethod, localHeader.uncompressedSize);
		
	retVal = jzReadData(f, &localHeader, data);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Couldn't read file data\r\n", __FUNCTION__);
		retVal = E_ERROR;
	}
	
	f->seek(f, offset, SEEK_SET);

	return retVal;
}

static Int32 splashAnimator_zipRecordCallback(JZFile *zip, Int32 idx, JZFileHeader *header, char *filename, void *user_data)
{
	UInt32 offset;
	SplashAnimator splashAnimator = (SplashAnimator) user_data;

	/* Store current file read position */
	offset = zip->tell(zip);

	/* copy file header object to our internal data space */
	memcpy(splashAnimator->fileHeaders + splashAnimator->fileHeadersNum++, header, sizeof(JZFileHeader));

	LOG_PRINT_SVER(DEBUG_SPLASH, "%s(): filename = \"%s\", offset = %d, uncompressedSize = %d\r\n", 
			__FUNCTION__, filename, header->offset, header->uncompressedSize);

	/* Restore read file position */
	zip->seek(zip, offset, SEEK_SET);

	return 1;
}

static Int32 splashAnimator_readZip(SplashAnimator splashAnimator)
{
	Int32 retVal;
	JZFile *f;
	UInt32 *animBaseAddr, *animSize;

	animBaseAddr = (UInt32 *) (0x90000000 + 4); //(PHY_TO_DA_ADDR(SPLASH_ANIMATOR_SPLASH_ADDR) + 4);
	animSize = (UInt32 *) (0x90000000); // PHY_TO_DA_ADDR(SPLASH_ANIMATOR_SPLASH_ADDR);

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): Animation start addr = %p, size = %d\r\n", __FUNCTION__, animBaseAddr, *animSize);
	
	f = ZipMemoryFile_create(animBaseAddr, *animSize);
	if (NULL == f)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to open zip file\r\n", __FUNCTION__);
		return E_ERROR;
	}

	splashAnimator->zipFile = f;
	
	JZEndRecord endRecord;
	retVal = jzReadEndRecord(f, &endRecord);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to read animation zip end record\r\n", __FUNCTION__);
		f->close(f);
		return E_ERROR;
	}

	/* Allocate space for animation file headers */
	splashAnimator->fileHeaders = (JZFileHeader *) Memory_alloc(NULL, endRecord.numEntries * sizeof(JZFileHeader), 0, NULL);
	if (NULL == splashAnimator->fileHeaders)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to allocate memory for animation file headers\r\n", __FUNCTION__);
		f->close(f);
		return E_ERROR;
	}

	retVal = jzReadCentralDirectory(f, &endRecord, splashAnimator_zipRecordCallback, splashAnimator);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to read animation zip directory\r\n", __FUNCTION__);
	}

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): found %d files\r\n", __FUNCTION__, splashAnimator->fileHeadersNum);

  return retVal;
}

#ifdef SIMPLIFIED_QOI_IMPLEMENTATION
static Int32 splashAnimator_decodeFrame(SplashAnimator splashAnimator, UInt32 frameIndex, Fvid2_Frame *frame)
{
	Int32 retVal = E_OK;
	JZFileHeader *fileHeader;
	UInt8 *encodedData;

	if (frameIndex >= splashAnimator->fileHeadersNum)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Invalid frame index. requested %d, maximum %d\r\n", __FUNCTION__, frameIndex, splashAnimator->fileHeadersNum);
		return E_ERROR;
	}

	fileHeader = &splashAnimator->fileHeaders[frameIndex];

	encodedData = Memory_alloc(NULL, fileHeader->uncompressedSize, 0, NULL);
	if (NULL == encodedData)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to allocate buffer for encoded data\r\n", __FUNCTION__);
		return E_ERROR;
	}

	retVal = splashAnimtor_readFile(splashAnimator, fileHeader, encodedData);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to read encoded file\r\n", __FUNCTION__);
		Memory_free(NULL, encodedData, fileHeader->uncompressedSize);
		return E_ERROR;
	}

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): %d bytes read from file %p\r\n", __FUNCTION__, fileHeader->uncompressedSize, fileHeader);
  //LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): %s\r\n", __FUNCTION__, encodedData);

	qoi_desc_t desc;
	qoi_dec_t dec;
	qoi_pixel_t px;
	size_t rawImageLenght, bufferSize;

	/* Initialize QOI decoder */
	qoi_desc_init(&desc);
	qoi_initalize_pixel(&px);
	qoi_set_pixel_rgba(&px, 0, 0, 0, 255);
	
	if (!read_qoi_header(&desc, encodedData))
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Invalid QOI format!\r\n", __FUNCTION__);
		Memory_free(NULL, encodedData, fileHeader->uncompressedSize);
		return E_ERROR;
	}

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): Image Info: size = %u x %u, %u channels and colorspace %u\r\n", __FUNCTION__, desc.width, desc.height, desc.channels, desc.colorspace);

	qoi_dec_init(&desc, &dec, encodedData, fileHeader->uncompressedSize);

	UInt32 seek = 0;
	UInt8 *ptr = (UInt8 *) PHY_TO_DA_ADDR(frame->addr[0][0]);
	
	UInt32 startTicks, endTicks, deltaTicks;
  startTicks = Clock_getTicks();
	
	while(!qoi_dec_done(&dec))
	{
		px = qoi_decode_chunk(&dec);

		ptr[seek] = px.red;
		ptr[seek + 1] = px.green;
		ptr[seek + 2] = px.blue;

		if (desc.channels > 3)
			ptr[seek + 3] = px.alpha;

		seek += desc.channels;
	}
	endTicks = Clock_getTicks();

	deltaTicks = endTicks - startTicks;
	
	Cache_wbInv(frame->addr[0][0], desc.width * desc.height * 4, Cache_Type_ALL, TRUE);

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): Image of %d x %d decoded in %d ticks\r\n", __FUNCTION__, desc.width, desc.height, deltaTicks);
	
	Memory_free(NULL, encodedData, fileHeader->uncompressedSize);

	return E_OK;
}

#else
static Int32 splashAnimator_decodeFrame(SplashAnimator splashAnimator, UInt32 frameIndex, Fvid2_Frame *frame)
{
	Int32 retVal = E_OK;
	JZFileHeader *fileHeader;
	UInt8 *encodedData;

	if (frameIndex >= splashAnimator->fileHeadersNum)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Invalid frame index. requested %d, maximum %d\r\n", __FUNCTION__, frameIndex, splashAnimator->fileHeadersNum);
		return E_ERROR;
	}

	fileHeader = &splashAnimator->fileHeaders[frameIndex];

	encodedData = Memory_alloc(NULL, fileHeader->uncompressedSize, 0, NULL);
	if (NULL == encodedData)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to allocate buffer for encoded data\r\n", __FUNCTION__);
		return E_ERROR;
	}

	retVal = splashAnimtor_readFile(splashAnimator, fileHeader, encodedData);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to read encoded file\r\n", __FUNCTION__);
		Memory_free(NULL, encodedData, fileHeader->uncompressedSize);
		return E_ERROR;
	}

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): %d bytes read from file %p\r\n", __FUNCTION__, fileHeader->uncompressedSize, fileHeader);
	
	UInt32 startTicks, endTicks, deltaTicks;
	UInt32 width, height;
	startTicks = Clock_getTicks();
	retVal = lodepng_decode((UInt8**)&frame->addr[0][0], &width, &height, &splashAnimator->pngState, encodedData, fileHeader->uncompressedSize);
	endTicks = Clock_getTicks();
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to decode PNG image\r\n", __FUNCTION__);
		Memory_free(NULL, encodedData, fileHeader->uncompressedSize);
		return E_ERROR;
	}

	deltaTicks = endTicks - startTicks;
	
	frame->addr[0][0] = DA_TO_PHY_ADDR((UInt8 *)frame->addr[0][0]);

	Cache_wbInv(frame->addr[0][0], width * height * 4, Cache_Type_ALL, TRUE);

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): Image of %d x %d decoded in %d ticks\r\n", __FUNCTION__, width, height, deltaTicks);
	
	Memory_free(NULL, encodedData, fileHeader->uncompressedSize);

	return E_OK;
}
#endif

static Int32 splashAnimator_onDraw(GfxLayer gfxLayer, Ptr appData)
{
	SplashAnimator splashAnimator = (SplashAnimator) appData;

	if (!splashAnimator->isDecoding)
	{
		SplashAnimatorMessage msg;
		msg.id = SPLASH_ANIMATOR_MSG_NEW_FRAME_REQ;
		msg.appData = splashAnimator;

		Mailbox_post(splashAnimator->msgMailbox, &msg, BIOS_WAIT_FOREVER);
	}

	return E_OK;
}

static Int32 splashAnimator_onFocusChange(GfxLayer gfxLayer, Ptr appData, bool_t newState)
{
	SplashAnimator splashAnimator = (SplashAnimator) appData;

	LOG_PRINT_INFO(DEBUG_SPLASH, "%s(): newState = %d\r\n", __FUNCTION__, newState);

	SplashAnimatorMessage msg;
	msg.id = (newState)? SPLASH_ANIMATOR_MSG_PLAY : SPLASH_ANIMATOR_MSG_STOP;
	msg.appData = splashAnimator;

	Mailbox_post(splashAnimator->msgMailbox, &msg, BIOS_WAIT_FOREVER);

	return E_OK;
}

Int32 SplashAnimator_init(SplashAnimator *splashAnimator)
{
  Int32 retVal = FVID2_EFAIL;
  Int32 i;

  LOG_PRINT_INFO(DEBUG_SPLASH, "%s()\r\n", __FUNCTION__);

  /* Check for input parameter */
  if (NULL == splashAnimator) 
    return FVID2_EBADARGS;

  *splashAnimator = &gSplashAnimator;

  /* Initialize internal variables */
  gSplashAnimator.isInitialized = FALSE;
	gSplashAnimator.isDecoding = FALSE;
	gSplashAnimator.isPlaying = TRUE;
	gSplashAnimator.fileHeaders = NULL;
	gSplashAnimator.fileHeadersNum = 0;
  gSplashAnimator.start = false;
	gSplashAnimator.frameCounter = 0;

	/* Initialize command mailbox */
	retVal = splashAnimator_initMailbox(&gSplashAnimator);
	if (E_OK != retVal)
	{
		return retVal;
	}

	/* Create process task */
	retVal = splashAnimator_createProcessTask(&gSplashAnimator);
	if (E_OK != retVal)
	{
		return retVal;
	}


#ifndef SIMPLIFIED_QOI_IMPLEMENTATION
	lodepng_allocator_init();

	/* Initialize png decoder state */
	LodePNGState *state = &gSplashAnimator.pngState;
	lodepng_state_init(state);

	state->decoder.ignore_crc = TRUE;
	state->decoder.ignore_critical = TRUE;
	state->decoder.zlibsettings.ignore_adler32 = TRUE;
#endif 
	splashAnimator_readZip(*splashAnimator);

	/* Create Graphic Layer */
	GfxLayerParams layerParams;
	GfxLayerParams_init(&layerParams);
	layerParams.name = "splash";
	layerParams.zOrder = 2;
	layerParams.alpha = 0xFF;
	layerParams.width = SPLASH_WIDTH;
	layerParams.height = SPLASH_HEIGHT;
	layerParams.xPos = (DISPLAY_LCD_WIDTH - SPLASH_WIDTH) / 2;
	layerParams.yPos = (DISPLAY_LCD_HEIGHT - SPLASH_HEIGHT) / 2;
	layerParams.onDrawCallback = splashAnimator_onDraw;
	layerParams.onFocusChangeCallback = splashAnimator_onFocusChange;
	layerParams.appData = &gSplashAnimator;
	GfxQueueParams_init(&layerParams.queueParams);
	layerParams.queueParams.maxSize = SPLASH_ANIMATOR_MAX_FRAMES;
	layerParams.queueParams.frameWidth = layerParams.width;
	layerParams.queueParams.frameHeight = layerParams.height;
	layerParams.queueParams.frameBytePerPixel = 4;
#ifdef SIMPLIFIED_QOI_IMPLEMENTATION
	layerParams.queueParams.allocateFrameBuffer = TRUE;
#else
	layerParams.queueParams.allocateFrameBuffer = FALSE;
#endif
	retVal = GfxLayer_create(&gSplashAnimator.gfxLayer, &layerParams, GFX_LAYER_TAG_SPLASH);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_SPLASH, "%s(): Unable to create graphic layer\r\n", __FUNCTION__);
		return retVal;
	}

	/* Enable graphic layer */
	GfxLayer_setEnableState(gSplashAnimator.gfxLayer, TRUE);

	/* Fill layer buffer */
  Fvid2_Frame *frame;
	retVal = GfxLayer_dequeueFrame(gSplashAnimator.gfxLayer, &frame);

	splashAnimator_decodeFrame(*splashAnimator, gSplashAnimator.frameCounter++, frame);
	retVal = GfxLayer_queueFrame(gSplashAnimator.gfxLayer, frame);
	
	/* We are now initialized */
	gSplashAnimator.isInitialized = TRUE;

  return retVal;
}

Int32 SplashAnimator_start(SplashAnimator splashAnimator)
{
  /* Check input parameters */
	if (NULL == splashAnimator)
		return E_ERROR;
  
  splashAnimator->start = true;
}

Int32 SplashAnimator_show(SplashAnimator splashAnimator)
{
	/* Check input parameters */
	if (NULL == splashAnimator)
		return E_ERROR;

	splashAnimator->frameCounter = 0;

	/* Enable graphic layer */
	GfxLayer_setEnableState(gSplashAnimator.gfxLayer, TRUE);

	/* Show layer */
	GfxLayer_show(splashAnimator->gfxLayer, FALSE);
	
	return E_OK;
}

Int32 SplashAnimator_hide(SplashAnimator splashAnimator)
{
	/* Check input parameters */
	if (NULL == splashAnimator)
	{
		return E_ERROR;
	}

	/* Show layer */
	GfxLayer_hide(splashAnimator->gfxLayer, FALSE);

  /* Disable graphic layer */
	GfxLayer_setEnableState(gSplashAnimator.gfxLayer, FALSE);
	
	return E_OK;
}
