/******************************************************************************
 *
 * \file    pdc_view.c
 *
 * \brief   Park Distant Control view source file
 *
 * \author  Esteban Pupillo
 *
 * \date    22 Sep 2022
 *
 *****************************************************************************/

#include <standard.h>

#include "pdc_view.h"

#include <console.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/heaps/HeapMem.h>


#include "gfx_layer.h"
#include "display.h"
#include "renderer.h"
#include "video_dma.h"

/**
 * @addtogroup PdcView
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define PDC_VIEW_BPP    (4)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
struct pdc_view_type {
	bool_t isInitialized;
	/**< flag to know if the view is initialized */
	
	GfxLayer gfxLayer;
	/**< Graphic layer associated with this view */

	Renderer renderer;
	/**< Reference to the renderer engine */

  bool showingView;
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static struct pdc_view_type gPdcView = {
	/* isInitialized */
	FALSE,

	/* gfxLayer */
	NULL,

	/* renderer */
	NULL,
};

/******************************************************************************
 * Functions implementation
 *****************************************************************************/
Int32 pdcView_onFocusChangeCallback(GfxLayer gfxLayer, Ptr appData, bool_t newState)
{
	PdcView pdcView = (PdcView) appData;

	LOG_PRINT_INFO(DEBUG_PDC_VIEW, "%s(): newState = %d\r\n", __FUNCTION__, newState);

	if (!pdcView->isInitialized)
		return E_OK;

	if (newState)
	{
		Renderer_setLayout(pdcView->renderer, Renderer_getPdcOnlyLayout());
		GfxLayer_setEnableState(pdcView->gfxLayer, TRUE);
	}
	else
	{
		GfxLayer_setEnableState(pdcView->gfxLayer, FALSE);
	}
	
	return E_OK;
}

static Int32 pdcView_onDraw(GfxLayer gfxLayer, Ptr appData)
{
	Int32 retVal = E_OK;
	PdcView pdcView = (PdcView) appData;
	RendererFrame rFrame;
	Fvid2_Frame *layerFrame;
  UInt32 gfxLayerWidth, gfxLayerHeight;

	LOG_PRINT_SVER(DEBUG_PDC_VIEW, "%s(): gfxLayer = %p, pdcView = %p\r\n", __FUNCTION__, gfxLayer, pdcView);

	/* acquire a frame from renderer */
	retVal = Renderer_acquireViewFrame(pdcView->renderer, Renderer_getPdcOnlyLayout(), &rFrame);
	if (E_OK != retVal)
	{
		/* nothing to draw */
		LOG_PRINT_ERR(DEBUG_PDC_VIEW, "%s(): Unable to acquire frame from renderer\r\n", __FUNCTION__);
		return E_ERROR;
	}

	/* dequeue a frame from layer */
	retVal = GfxLayer_dequeueFrame(gfxLayer, &layerFrame);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_PDC_VIEW, "%s(): Unable to dequeue frame from layer\r\n", __FUNCTION__);

		/* release frame from renderer */
		retVal = Renderer_releaseViewFrame(pdcView->renderer, Renderer_getPdcOnlyLayout(), &rFrame);

		return E_ERROR;
	}

  if (!GfxLayer_getSize(gfxLayer, &gfxLayerWidth, &gfxLayerHeight))
  {
		LOG_PRINT_ERR(DEBUG_PDC_VIEW, "%s(): Unable to obtain gfx layer size!!\r\n", __FUNCTION__);
    
    /* queue untreated frame to layer */
	  retVal = GfxLayer_queueFrame(gfxLayer, layerFrame);

    /* release frame from renderer */
		retVal = Renderer_releaseViewFrame(pdcView->renderer, Renderer_getPdcOnlyLayout(), &rFrame);

    return E_ERROR;
  }

	/* bitblit renderer frame into layer frame */
	VideoDMA_copyFrame(PHY_TO_DA_ADDR((UInt8 *) layerFrame->addr[0][0]),
                     PDC_VIEW_BPP,
                     gfxLayerWidth * PDC_VIEW_BPP,
				             PHY_TO_DA_ADDR((UInt8 *) rFrame.addr),
                     rFrame.bpp,
                     rFrame.stride,
                     rFrame.width,
                     rFrame.height);

	/* queue filled frame to layer */
	retVal = GfxLayer_queueFrame(gfxLayer, layerFrame);

	/* release frame from renderer */
	retVal = Renderer_releaseViewFrame(pdcView->renderer, Renderer_getPdcOnlyLayout(), &rFrame);

	return E_OK;
}

Int32 PdcView_init(PdcView *pdcView, PdcViewParams *params)
{
	Int32 retVal = E_OK;
	UInt32 width, height;

	/* check input parameters */
	if (NULL == pdcView)
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* retrieve default display resolution */
	Display_getResolution(NULL, &width, &height);

	/* Create Graphic Layer */
	GfxLayerParams layerParams;
	GfxLayerParams_init(&layerParams);
	layerParams.name = "pdc";
	layerParams.zOrder = 4;
	layerParams.alpha = 0x0;
	layerParams.width = width;
	layerParams.height = height;
	layerParams.xPos = 0;
	layerParams.yPos = 0;
	layerParams.onDrawCallback = pdcView_onDraw;
	layerParams.onFocusChangeCallback = pdcView_onFocusChangeCallback;
	layerParams.appData = &gPdcView;
	GfxQueueParams_init(&layerParams.queueParams);
	layerParams.queueParams.maxSize = 3;
	layerParams.queueParams.frameWidth = layerParams.width;
	layerParams.queueParams.frameHeight = layerParams.height;
	layerParams.queueParams.frameBytePerPixel = 4;

	retVal = GfxLayer_create(&gPdcView.gfxLayer, &layerParams, GFX_LAYER_TAG_PDC);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_PDC_VIEW, "%s(): Unable to create graphic layer\r\n", __FUNCTION__);
		return E_ERROR;
	}

	/* Obtain a reference of the renderer engine */
	Renderer_getInstance(&gPdcView.renderer);

  gPdcView.showingView = false;

	/* we are now initialized */
	gPdcView.isInitialized = TRUE;

	/* return instance */
	*pdcView = &gPdcView;

	LOG_PRINT_INFO(DEBUG_PDC_VIEW, "%s(): PdcView initialized at %p\r\n", __FUNCTION__, &gPdcView);

	return E_OK;
}

Int32 PdcView_show(PdcView pdcView)
{
  int retVal;
  UInt32 current_renderer_layout;

	/* Check parameters */
	if (NULL == pdcView)
	{
		return E_ERROR;
	}
	LOG_PRINT_INFO(DEBUG_PDC_VIEW, "%s(): Showing view\r\n", __FUNCTION__);

  retVal = Renderer_getCurrentLayout(pdcView->renderer, &current_renderer_layout);

  if (retVal != E_OK)
  {
    LOG_PRINT_ERR(DEBUG_PDC_VIEW, "(%s) [%d]: Error obtaining current Renderer layout: %d\r\n", __FUNCTION__, __LINE__, retVal);
    return retVal;
  }

  if ((current_renderer_layout == Renderer_getPdcOnlyLayout()) && (pdcView->showingView))
    return E_OK;

	Renderer_setLayout(pdcView->renderer, Renderer_getPdcOnlyLayout());
  pdcView->showingView = true;

	GfxLayer_setEnableState(pdcView->gfxLayer, TRUE);

	return GfxLayer_show(pdcView->gfxLayer, FALSE);
}

Int32 PdcView_hide(PdcView pdcView)
{
	/* Check parameters */
	if (NULL == pdcView)
	{
		return E_ERROR;
	}

  if (!pdcView->showingView)
    return E_OK;

  pdcView->showingView = false;

	LOG_PRINT_INFO(DEBUG_PDC_VIEW, "%s(): Hiding view\r\n", __FUNCTION__);

	GfxLayer_hide(pdcView->gfxLayer, FALSE);

	return GfxLayer_setEnableState(pdcView->gfxLayer, FALSE);
}

/**
 * Close doxygen group
 * @}
 */

