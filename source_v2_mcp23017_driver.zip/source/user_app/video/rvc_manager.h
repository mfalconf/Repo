/******************************************************************************
 *
 * \file    rvc_manager.h
 *
 * \brief   Rear View Camera manager module header file
 *
 * \author  Esteban Pupillo
 *
 * \date    11 Jun 2022
 *
 *****************************************************************************/
#ifndef __RVC_MANAGER_H__
#define __RVC_MANAGER_H__

/**
 * @addtogroup RvcManager
 * @{
 */

#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/** Ouptput frames queue maximun size */
#define RVCMANAGER_OUTPUT_QUEUE_MAX_SIZE  (2)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief VideoCapture data type
 */
typedef struct rvc_manager_tag* RvcManager;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initialize Rear View Camera manager
 *
 * This function has to be called before any other function of the RVC
 * manager module API
 *
 * @param rvcManager pointer to the video capture instance to initialize
 * @param callback callback function used to notify new frames
 * @return #FVID2_SOK on success
 */
Int32 RvcManager_init(RvcManager *rvcManager, Fvid2_CbParams callback);

/**
 * @brief Gets a reference to the RVC manager
 *
 * @param rvcManager pointer to receive the RVC instance
 * @return #FVIDE2_SOK on succes
 */
Int32 RvcManager_getInstance(RvcManager *rvcManager);

/**
 * @brief Queues frame list to driver
 *
 * @param rvcManager RVC manager instance
 * @param frameList list of frames to queue
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 RvcManager_queueBuffer(RvcManager rvcManager, Fvid2_FrameList *frameList);

/**
 * @brief Dequeues frame list from driver
 *
 * @param rvcManager rvcManager instance
 * @param frameList pointer to a list of frames dequeued
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 RvcManager_dequeueBuffer(RvcManager rvcManager, Fvid2_FrameList *frameList);

/**
 * @brief Starts RVC diagnostic task
 * 
 * @param rvcManager rvcManager instance
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 RvcManager_startDiagnostic(RvcManager rvcManager);

/**
 * @brief Starts RVC video playback
 *
 * @param rvcManager rvcManager instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 RvcManager_start(RvcManager rvcManager);

/**
 * @brief Stops RVC diagnostic task
 * 
 * @param rvcManager rvcManager instance
 * @return Int32 #FIVD2_SOK on success, error code otherwise
 */
Int32 RvcManager_stopDiagnostic(RvcManager rvcManager);

/**
 * @brief Stops RVC video playback
 *
 * @param rvcManager rvcManager instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 RvcManager_stop(RvcManager rvcManager);

/**
 * @brief Checks if the RVC is playing
 *
 * @param rvcManager rvcManager instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 RvcManager_isPlaying(RvcManager rvcManager);

/**
 * @brief Registers a new callback to the module
 *
 * @param rvcManager RvcManager instance
 * @param callback new callback to register
 *
 * @return #FVID2_SOK on succes, error code otherwise
 */
Int32 RvcManager_registerCallback(RvcManager rvcManager, Fvid2_CbParams callback);

/**
 * @brief Unegisters a callback from the module
 *
 * @param rvcManager RvcManager instance
 * @param callback callback to unregister
 *
 * @return #FVID2_SOK on succes, error code otherwise
 */
Int32 RvcManager_unregisterCallback(RvcManager rvcManager, Fvid2_CbParams callback);

/** Initialize necessary GPIOs related to the RVC manager */
void RvcManager_initGpios(void);

/**
 * Close doxygen group
 * @}
 */

#endif //__RVC_MANAGER_H__
