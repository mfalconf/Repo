/******************************************************************************
 *
 * \file    gfx_queue.c
 *
 * \brief   Graphic queue module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    13 Sep 2022
 *
 *****************************************************************************/

/* Uncomment the following line enable super verbose debug messages 
 * 
 * WARNING: this could have a huge impact in system performance
 */
//#define LOG_DEBUG_SUPER_VERBOSE

#include <standard.h>

#include "gfx_queue.h"
#include "video_heap.h"

#include <console.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/heaps/HeapMem.h>
#include <ti/sysbios/knl/Queue.h>
#include <ti/sysbios/gates/GateTask.h>
#include <ti/sysbios/gates/GateMutexPri.h>

/**
 * @addtogroup GfxQueue
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DEBUG_GFX_QUEUE  0

#define DONT_REUSE_FRAMES   0

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
struct gfx_queue_type {
	GfxQueueParams params;
	/**< Queue parameters */

	bool_t isEnabled;
	/**< flag used to know if a graphic queue is enabled or disabled */

	GateMutexPri_Handle gateMutex;
	/**< Gate used to protect critical sections */

	Queue_Handle qFree;
	/**< Free Frames queue handler */

	UInt32 freeFrames;
	/**< Number of free frames in the queue */

	Queue_Handle qDequeued;
	/**< dequeued Frames queue handler */

	UInt32 dequeuedFrames;
	/**< Number of dequeued frames in the queue */

	Queue_Handle qQueued;
	/**< Queued Frames queue handler */

	UInt32 queuedFrames;
	/**< Number of queued frames in the queue */

	Queue_Handle qAcquired;
	/**< Acquired Frames queue handler */

	UInt32 acquiredFrames;
	/**< Number of acquired frames in the queue */

	UInt32 allocatedFrames;
	/**< Number of frames allocated for the queue */
};

typedef struct gfx_queue_obj_type {
	Queue_Elem elem;
	/**< The first element of the queue MUST be Queue_Elem */

	UInt32 id;
	/**< Frame Id */

	Fvid2_Frame frame;
	/**< Frame object */

	Ptr frameBuffer;
	/**< Pointer to frame buffer*/

	bool_t acquired;
	/**< Set to TRUE if the frame was acquired */
} GfxQueueObj;

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

void GfxQueue_dump(GfxQueue gfxQueue)
{
	LOG_PRINT_INFO(DEBUG_GFX_QUEUE, "+- GfxQueueStats: instance        = %p\r\n"
			                            "|                 allocatedFrames = %d\r\n"
			                            "|                 freeFrames      = %d\r\n"
																	"|                 dequeuedFrames  = %d\r\n"
																	"|                 queuedFrames    = %d\r\n"
																	"+---------------- acquiredFrames  = %d\r\n",
																	gfxQueue,
																	gfxQueue->allocatedFrames,
																	gfxQueue->freeFrames, 
																	gfxQueue->dequeuedFrames, 
																	gfxQueue->queuedFrames, 
																	gfxQueue->acquiredFrames);
	
}

static Int32 gfxQueue_allocateFrame(GfxQueue gfxQueue)
{
	GfxQueueObj *frmObj;

	/* Check if we can still allocate frames objects */
	if (gfxQueue->params.maxSize <= gfxQueue->allocatedFrames)
	{
		/* we reached the maximum queue size, we cannot allocate a new frame */
		LOG_PRINT_ERR(DEBUG_GFX_QUEUE, "%s(): Unable to allocate new frame. Queue max size limit reached. maxSize=%d\r\n", __FUNCTION__, gfxQueue->params.maxSize);

		return E_ERROR;
	}

	/* Allocate new frame object */
  frmObj = (GfxQueueObj *) Memory_alloc(NULL, sizeof(GfxQueueObj), 0, NULL);
	if (NULL == frmObj)
	{
		LOG_PRINT_ERR(DEBUG_GFX_QUEUE, "%s(): Unable to allocate new frame\r\n", __FUNCTION__);
		return E_ERROR;
	}

	if (gfxQueue->params.allocateFrameBuffer)
	{
		/* Allocate a new frame buffer */
		frmObj->frameBuffer = VideoHeap_allocFrame(gfxQueue->params.frameWidth, 
																						 gfxQueue->params.frameHeight, 
																						 gfxQueue->params.frameBytePerPixel);
		
		/* Associate frame buffer with frame object */
		Fvid2Frame_init(&frmObj->frame);
		frmObj->frame.addr[0][0] = DA_TO_PHY_ADDR((UInt8 *) frmObj->frameBuffer);
	}
	else
	{
		/* it's client responsibility to allocate frame buffer */
		frmObj->frameBuffer = NULL;
		frmObj->frame.addr[0][0] = NULL;
	}

	frmObj->acquired = FALSE;

	LOG_PRINT_INFO(DEBUG_GFX_QUEUE, "%s(): Allocated frame %d at %p for queue %p\r\n", __FUNCTION__, gfxQueue->allocatedFrames, frmObj, gfxQueue);

	/* Added new allocated frame to free queue */
	Queue_put(gfxQueue->qFree, (Queue_Elem *) frmObj);
	
	/* Update allocated frames counter */
	gfxQueue->allocatedFrames++;

	/* Update free frames counter */
	gfxQueue->freeFrames++;

	return E_OK;
}

Int32 GfxQueue_create(GfxQueue *gfxQueue, GfxQueueParams *gfxQueueParams)
{
	Error_Block eb;
	GfxQueue newQueue;

	/* Check input parameters */
	if (NULL == gfxQueue)
	{
		return E_ERROR;
	}

	/* Allocate a new graphic queue object */
	newQueue = (GfxQueue) Memory_alloc(NULL, sizeof(struct gfx_queue_type), 0, &eb);
	if (NULL == newQueue)
	{
		*gfxQueue = NULL;
		return E_ERROR;
	}

	/* Configure queue */
	if (NULL != gfxQueueParams)
	{
		/* Copy parameters to internal object */
		memcpy(&newQueue->params, gfxQueueParams, sizeof(GfxQueueParams));
	}
	else
	{
		/* Configure default values */
		newQueue->params.maxSize = GFX_QUEUE_DEFAULT_MAX_SIZE;
	}

	LOG_PRINT_INFO(DEBUG_GFX_QUEUE, "%s(): Graphic Queue created at %p. maxSize = %d\r\n", __FUNCTION__, newQueue, newQueue->params.maxSize);

	/* Create gate used for synchronization */
	GateMutexPri_Params gateMutexParams;
	GateMutexPri_Params_init(&gateMutexParams);
	newQueue->gateMutex = GateMutexPri_create(&gateMutexParams, &eb);
	if (NULL == newQueue->gateMutex)
	{
		LOG_PRINT_ERR(DEBUG_GFX_QUEUE, "%s(): Unable to create Gate for synchronization\r\n", __FUNCTION__);
		
		/* free allocated Memory */
		Memory_free(NULL, newQueue, sizeof(struct gfx_queue_type));
	
		return E_ERROR;
	}

	/* Create internal queues */
	newQueue->qFree = Queue_create(NULL, NULL);
	newQueue->qDequeued = Queue_create(NULL, NULL);
	newQueue->qQueued = Queue_create(NULL, NULL);
	newQueue->qAcquired = Queue_create(NULL, NULL);

	/* Initialize counters */
	newQueue->freeFrames = 0;
	newQueue->dequeuedFrames = 0;
	newQueue->queuedFrames = 0;
	newQueue->acquiredFrames = 0;
	newQueue->allocatedFrames = 0;

	/* Initialize state */
	newQueue->isEnabled = FALSE;

	LOG_PRINT_INFO(DEBUG_GFX_QUEUE, "%s(): qFree = %p, qDequeued = %p, qQueued = %p, qAcquired = %p\r\n", 
			__FUNCTION__, newQueue->qFree, newQueue->qDequeued, newQueue->qQueued, newQueue->qAcquired);

	GfxQueue_dump(newQueue);

	/* Return graphic queue handler to user */
	*gfxQueue = newQueue;

	return E_OK;
}

Int32 GfxQueue_queue(GfxQueue gfxQueue, Fvid2_Frame *frame)
{
	UInt32 cookie;
	GfxQueueObj *frmObj;

	/* Check input parameters */
	if ((NULL == gfxQueue) || (NULL == frame))
	{
		return E_ERROR;
	}

	cookie = GateMutexPri_enter(gfxQueue->gateMutex);

	/* Check if the queue is currently enabled */
	if (!gfxQueue->isEnabled)
	{
		/* it's not enabled, return error */
		GateMutexPri_leave(gfxQueue->gateMutex, cookie);
		return E_ERROR;
	}

	/* check for monotonic order of the dequeue - queue process */
	if (Queue_empty(gfxQueue->qDequeued))
	{
		/* this is a queue without the corresponding dequeue */

		GateMutexPri_leave(gfxQueue->gateMutex, cookie);
		return E_ERROR;
	}

	frmObj = Queue_get(gfxQueue->qDequeued);
	if (&frmObj->frame != frame)
	{
		/* this is an out-of-order queue */
		/* restore item to original queue and exit */
		
		LOG_PRINT_ERR(DEBUG_GFX_QUEUE, "%s(): Out-of-order queue. frame queued %p, expecting %p\r\n", __FUNCTION__, frame, &frmObj->frame);

		Queue_put(gfxQueue->qDequeued, (Queue_Elem *) frmObj);

		GateMutexPri_leave(gfxQueue->gateMutex, cookie);
		return E_ERROR;
	}

	/* move frane from dequeued to queued */
	Queue_put(gfxQueue->qQueued, (Queue_Elem *) frmObj);

	/* update counters */
  gfxQueue->dequeuedFrames--;
	gfxQueue->queuedFrames++;

	LOG_PRINT_SVER(DEBUG_GFX_QUEUE, "%s(): queue %p frameObj %p queued (frame = %p)\r\n", __FUNCTION__, gfxQueue, frmObj, &frmObj->frame);
	
	GateMutexPri_leave(gfxQueue->gateMutex, cookie);

	return E_OK;
}

Int32 GfxQueue_dequeue(GfxQueue gfxQueue, Fvid2_Frame **frame)
{
	Int32 retVal;
	UInt32 cookie;
	GfxQueueObj *frmObj;

	/* Check input parameters */
	if ((NULL == gfxQueue) || (NULL == frame))
	{
		return E_ERROR;
	}
	
	cookie = GateMutexPri_enter(gfxQueue->gateMutex);

	/* Check if the queue is currently enabled */
	if (!gfxQueue->isEnabled)
	{
		/* it's not enabled, return error */
		GateMutexPri_leave(gfxQueue->gateMutex, cookie);
		return E_ERROR;
	}

	/* if the free queue is empty, we need to allocate a new frame object */
	if (Queue_empty(gfxQueue->qFree))
	{
    /* Allocate new frame object */
		retVal = gfxQueue_allocateFrame(gfxQueue);
		if (E_OK != retVal)
		{
#if DONT_REUSE_FRAMES
      static int flag = 0;

      if (!flag) {
        LOG_PRINT_ERR(DEBUG_GFX_QUEUE, "%s(): Error allocating new frame (%d)\r\n", __FUNCTION__, retVal);
        flag = 1;
      }
		  GateMutexPri_leave(gfxQueue->gateMutex, cookie);
			return retVal;
#else
      /* Take oldest non-acquired frame and use it */
      LOG_PRINT_SVER(DEBUG_GFX_QUEUE, "%s(): Using oldest queued frame since no more allocation is possible\r\n", __FUNCTION__);
      if (!Queue_empty(gfxQueue->qQueued))
      {
        frmObj = Queue_get(gfxQueue->qQueued);
        Queue_put(gfxQueue->qFree, (Queue_Elem *) frmObj);

        /* update frame counters */
				gfxQueue->queuedFrames--;
				gfxQueue->freeFrames++;
      }
      else
      {
        LOG_PRINT_ERR(DEBUG_GFX_QUEUE, "%s(): Cannot allocate new frame and no queued frames are available\r\n", __FUNCTION__);
        GateMutexPri_leave(gfxQueue->gateMutex, cookie);
        return FVID2_EAGAIN;
      }
#endif /* DONT_REUSE_FRAMES */
		}
	}

	/* Get frame from free queue */
	frmObj = Queue_get(gfxQueue->qFree);

	/* Move it to dequeued queue */
	Queue_put(gfxQueue->qDequeued, (Queue_Elem*) frmObj);

	frmObj->acquired = FALSE;

	/* Return dequeued frame to user */
	*frame = &frmObj->frame;

	/* update counters */
	gfxQueue->freeFrames--;
	gfxQueue->dequeuedFrames++;

	LOG_PRINT_SVER(DEBUG_GFX_QUEUE, "%s(): queue %p frameObj %p dequeued (frame = %p)\r\n", __FUNCTION__, gfxQueue, frmObj, *frame);

	GateMutexPri_leave(gfxQueue->gateMutex, cookie);
	
	return E_OK;
}

Int32 GfxQueue_acquire(GfxQueue gfxQueue, Fvid2_Frame **frame)
{
	UInt32 cookie;
	GfxQueueObj *frmObj;

	/* check input parameters */
	if ((NULL == gfxQueue) || (NULL == frame))
	{
		return E_ERROR;
	}

	cookie = GateMutexPri_enter(gfxQueue->gateMutex);

	/* Check if the queue is currently enabled */
	if (!gfxQueue->isEnabled)
	{
		/* it's not enabled, return error */
		GateMutexPri_leave(gfxQueue->gateMutex, cookie);
		LOG_PRINT_ERR(DEBUG_GFX_QUEUE, "%s(): Can't acquire a frame from a disabled queue\r\n", __FUNCTION__);
		return E_ERROR;
	}

	/* Check if we have at least one queued frame */
	if (Queue_empty(gfxQueue->qQueued))
	{
		bool_t previousFrameFound;

		previousFrameFound = FALSE;

		/* There is no queued frame, check if we have a free frame that was previously acquired */
		if (!Queue_empty(gfxQueue->qFree))
    {
      frmObj = Queue_getTail(gfxQueue->qFree);

			/* we have a free frame, we need to check if it was previously acquired */
			if (frmObj->acquired)
			{
				/* it was previously acquired. move it to the queued frame */
				Queue_put(gfxQueue->qQueued, (Queue_Elem *) frmObj);

				/* update frame counters */
				gfxQueue->queuedFrames++;
				gfxQueue->freeFrames--;

				/* we have found a valid previous frame */
				previousFrameFound = TRUE;
				LOG_PRINT_SVER(DEBUG_GFX_QUEUE, "%s(): Reusing previously acquired frame frame.addr[0][0] = %p\r\n", __FUNCTION__, frmObj->frame.addr[0][0]);
			}
			else
			{
				/* restore it back to the queue */
				Queue_put(gfxQueue->qFree, (Queue_Elem *) frmObj);
			}
		}

		/* if we didn't find a previous frame, return error */
		if (!previousFrameFound) 
		{
		  GateMutexPri_leave(gfxQueue->gateMutex, cookie);
			return E_ERROR;
		}
	}

	/* Move queued frame to acquired queue */
	frmObj = Queue_get(gfxQueue->qQueued);
	Queue_put(gfxQueue->qAcquired, (Queue_Elem *) frmObj);

	/* Set frame as acquired */
	frmObj->acquired = TRUE;

	/* return acquired frame to user */
	*frame = &frmObj->frame;

	/* update counters */
	gfxQueue->queuedFrames--;
	gfxQueue->acquiredFrames++;

	LOG_PRINT_SVER(DEBUG_GFX_QUEUE, "%s(): queue %p frameObj %p acquired (frame = %p)\r\n", __FUNCTION__, gfxQueue, frmObj, *frame);

	GateMutexPri_leave(gfxQueue->gateMutex, cookie);
	
	return E_OK;
}

Int32 GfxQueue_release(GfxQueue gfxQueue, Fvid2_Frame *frame)
{
	UInt32 cookie;
	GfxQueueObj *frmObj;

	/* check input parameters */
	if ((NULL == gfxQueue) || (NULL == frame))
	{
		return E_ERROR;
	}

	cookie = GateMutexPri_enter(gfxQueue->gateMutex);

	/* Check if the queue is currently enabled */
	if (!gfxQueue->isEnabled)
	{
		/* it's not enabled, return error */
		GateMutexPri_leave(gfxQueue->gateMutex, cookie);
		return E_ERROR;
	}

	/* check for consistency */
	if (Queue_empty(gfxQueue->qAcquired))
	{
		/* This is release request without a previous acquire request */
		
		GateMutexPri_leave(gfxQueue->gateMutex, cookie);
		return E_ERROR;
	}

	frmObj = Queue_get(gfxQueue->qAcquired);
	if (&frmObj->frame != frame)
	{
		/* This is an out of order release */
		LOG_PRINT_SVER(DEBUG_GFX_QUEUE, "%s(): Out-of-order release. frame released %p, expecting %p\r\n", __FUNCTION__, frame, &frmObj->frame);

		/* place the we just dequeued back to the corresponding queue */
		Queue_put(gfxQueue->qAcquired, (Queue_Elem *) frmObj);

		for(frmObj = Queue_head(gfxQueue->qAcquired); 
		  	frmObj != (GfxQueueObj *) gfxQueue->qAcquired; 
			  frmObj = Queue_next((Queue_Elem *)frmObj))
	  {
			if (&frmObj->frame == frame)
			{
				/* we found it, stop looking */
				break;
			}
		}

		/* if we didn't find the frame object, then return error */
		if (frmObj == (GfxQueueObj *) gfxQueue->qAcquired)
		{
			/* we haven't found the corresponding frame object */
			LOG_PRINT_ERR(DEBUG_GFX_QUEUE, "%s(): Unable to release frame. %p frame is invalid\r\n", __FUNCTION__, frame);
			GateMutexPri_leave(gfxQueue->gateMutex, cookie);
			return E_ERROR;
		}

		/* we have found the corresponding frame object,
		 * we remove it from the queue and continue 
		 */
		Queue_remove((Queue_Elem *) frmObj);
	}

	/* move frame from acquired to idle queue */
	Queue_put(gfxQueue->qFree, (Queue_Elem *) frmObj);

	/* update counters */
  //cookie = BspOsal_disableInterrupt();
	gfxQueue->acquiredFrames--;
	gfxQueue->freeFrames++;
	//BspOsal_restoreInterrupt(cookie);

	LOG_PRINT_SVER(DEBUG_GFX_QUEUE, "%s(): queue %p frameObj %p released (frame = %p)\r\n", __FUNCTION__, gfxQueue, frmObj, &frmObj->frame);

	GateMutexPri_leave(gfxQueue->gateMutex, cookie);
	return E_OK;
}

Int32 GfxQueue_setEnableState(GfxQueue gfxQueue, bool_t newState)
{
  UInt32 cookie;

	/* Check input parameters */
	if (NULL == gfxQueue)
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	cookie = GateMutexPri_enter(gfxQueue->gateMutex);

	/* Update enable state with new value */
	gfxQueue->isEnabled = newState;

	GateMutexPri_leave(gfxQueue->gateMutex, cookie);

	return E_OK;
}

Int32 GfxQueue_freeAll(GfxQueue gfxQueue)
{
	UInt32 cookie;
  GfxQueueObj *frmObj;

	/* Check input parameters */
	if (NULL == gfxQueue)
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* we have to do this inside a critical region because 
	 * while we are reorganizing the queue no other task can
	 * interact with queue
	 */
	cookie = GateMutexPri_enter(gfxQueue->gateMutex);

	/* Check if the queue is currently disabled */
	if (gfxQueue->isEnabled)
	{
		/* it's enabled, return error */
		GateMutexPri_leave(gfxQueue->gateMutex, cookie);

		return E_ERROR;
	}

	/* 1st make sure that we invalidate all the
	 * buffers in the free queue
	 */

	//while(!Queue_empty(gfxQueue->qFree))
	for(frmObj = Queue_head(gfxQueue->qFree); 
			frmObj != (GfxQueueObj *) gfxQueue->qFree; 
			frmObj = Queue_next((Queue_Elem *)frmObj))
	{
		//frmObj = Queue_get(gfxQueue->qFree);

		frmObj->acquired = FALSE;

		/* move frame to idle queue */
		//Queue_put(gfxQueue->qFree, (Queue_Elem *) frmObj);

	}

	/* 2nd move acquired to free queue */
	while(!Queue_empty(gfxQueue->qAcquired))
	{
		frmObj = Queue_get(gfxQueue->qAcquired);

		frmObj->acquired = FALSE;

		/* move frame to idle queue */
		Queue_put(gfxQueue->qFree, (Queue_Elem *) frmObj);

		gfxQueue->acquiredFrames--;
		gfxQueue->freeFrames++;

	}

	/* 3rd move queued to free queue */
  while(!Queue_empty(gfxQueue->qQueued))
	{
		frmObj = Queue_get(gfxQueue->qQueued);

		/* move frame to idle queue */
		Queue_put(gfxQueue->qFree, (Queue_Elem *) frmObj);

		gfxQueue->queuedFrames--;
		gfxQueue->freeFrames++;
	}

	/* 4th move dequeued to free */
	while(!Queue_empty(gfxQueue->qDequeued))
	{
		frmObj = Queue_get(gfxQueue->qDequeued);

		/* move frame to idle queue */
		Queue_put(gfxQueue->qFree, (Queue_Elem *) frmObj);

		gfxQueue->dequeuedFrames--;
		gfxQueue->freeFrames++;

	}

	GfxQueue_dump(gfxQueue);

	GateMutexPri_leave(gfxQueue->gateMutex, cookie);

	return E_OK;
}

/**
 * Close doxygen group
 * @}
 */

