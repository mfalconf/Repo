/******************************************************************************
 *
 * \file    pdc_view.h
 *
 * \brief   Park Distance Control view header file
 *
 * \author  Esteban Pupillo
 *
 * \date    22 Sep 2022
 *
 *****************************************************************************/
#ifndef __PDC_VIEW_H__
#define __PDC_VIEW_H__

/**
 * @addtogroup PdcView
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief PdcView abstract data type
 */
typedef struct pdc_view_type* PdcView;

/**
 * @brief PdcView parameters 
 */
typedef struct pdc_view_params_tag {

} PdcViewParams;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initializes PdcView parameters
 */
void inline PdcViewParams_init(PdcViewParams *params)
{
	if (NULL != params)
	{
		memset(params, 0, sizeof(PdcViewParams));
	}
}

Int32 PdcView_init(PdcView *pdcView, PdcViewParams *params);

Int32 PdcView_show(PdcView pdcView);

Int32 PdcView_hide(PdcView pdcView);



/**
 * Close doxygen group
 * @}
 */

#endif //__PDC_VIEW_H__
