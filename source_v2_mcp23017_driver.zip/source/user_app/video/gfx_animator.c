/******************************************************************************
 *
 * \file    gfx_animator.c
 *
 * \brief   Graphic Animator module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    17 Sep 2022
 *
 *****************************************************************************/

#include <standard.h>

#include "gfx_animator.h"

#include <console.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/heaps/HeapMem.h>


/**
 * @addtogroup GfxAnimator
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define ANIMATION_EASE_OUT_CUBIC      0
#define ANIMATION_EASE_OUT_QUART      1
#define ANIMATION_EASE_OUT_EXPO       2

// Select one of the animations above
#define ANIMATION_CURVE               ANIMATION_EASE_OUT_QUART

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
struct gfx_animator_type {
	bool_t isInitialized;
	/**< flag to know if the animator module is initialized */

	bool_t isStarted;
	/**< flag to know if the animation has started */

	bool_t hasEnded;
	/**< flag to know if the animation has ended */

	Int32 alpha;
	/**< alpha auxiliary coefficient */

	Int32 beta;
	/**< beta auxiliary coefficient */

	UInt32 timer;
	/**< timer used to keep track of the animation */

	Int32 currentValue;
	/**< animation current value parameter */

	GfxAnimatorParams params;
	/**< Animator parameters */
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/
#if   ANIMATION_CURVE == ANIMATION_EASE_OUT_QUBIC
/*
 * Simple python script to regenerate:
   # Put n in the amount of desired samples for the LUT
   n = 100
   arr=[i/n for i in range(n + 1)]
   funct=[int((1 - pow(1 - n, 3)) * 1000) for n in arr]
   print(funct)
 */
static const Int32 OUT_LUT[] = {
  0, 29, 58, 87, 115, 142, 169, 195, 221, 246,
  270, 295, 318, 341, 363, 385, 407, 428, 448, 468,
  487, 506, 525, 543, 561, 578, 594, 610, 626, 642,
  657, 671, 685, 699, 712, 725, 737, 749, 761, 773,
  784, 794, 804, 814, 824, 833, 842, 851, 859, 867,
  875, 882, 889, 896, 902, 908, 914, 920, 925, 931,
  936, 940, 945, 949, 953, 957, 960, 964, 967, 970,
  973, 975, 978, 980, 982, 984, 986, 987, 989, 990,
  992, 993, 994, 995, 995, 996, 997, 997, 998, 998,
  999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 1000};
#elif ANIMATION_CURVE == ANIMATION_EASE_OUT_QUART
/*
 * Simple python script to regenerate:
   # Put n in the amount of desired samples for the LUT
   n = 100
   arr=[i/n for i in range(n + 1)]
   funct=[int((1 - pow(1 - n, 4)) * 1000) for n in arr]
   print(funct)
 */
static const Int32 OUT_LUT[] = {
  0, 39, 77, 114, 150, 185, 219, 251, 283, 314,
  343, 372, 400, 427, 452, 477, 502, 525, 547, 569, 
  590, 610, 629, 648, 666, 683, 700, 716, 731, 745, 
  759, 773, 786, 798, 810, 821, 832, 842, 852, 861, 
  870, 878, 886, 894, 901, 908, 914, 921, 926, 932, 
  937, 942, 946, 951, 955, 958, 962, 965, 968, 971, 
  974, 976, 979, 981, 983, 984, 986, 988, 989, 990, 
  991, 992, 993, 994, 995, 996, 996, 997, 997, 998, 
  998, 998, 998, 999, 999, 999, 999, 999, 999, 999, 
  999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 1000};
#elif ANIMATION_CURVE == ANIMATION_EASE_OUT_EXPO
/*
 * Simple python script to regenerate:
   # Put n in the amount of desired samples for the LUT
   n = 100
   arr=[i/n for i in range(n + 1)]
   funct=[int(1000 if n == 1 else (1 - pow(2, -10 * n)) * 1000) for n in arr]
   print(funct)
 */
static const Int32 OUT_LUT[] = {
  0, 66, 129, 187, 242, 292, 340, 384, 425, 464,
  500, 533, 564, 593, 621, 646, 670, 692, 712, 732, 
  750, 766, 782, 796, 810, 823, 835, 846, 856, 866,
  875, 883, 891, 898, 905, 911, 917, 923, 928, 933,
  937, 941, 945, 949, 952, 955, 958, 961, 964, 966,
  968, 970, 972, 974, 976, 977, 979, 980, 982, 983,
  984, 985, 986, 987, 988, 988, 989, 990, 991, 991,
  992, 992, 993, 993, 994, 994, 994, 995, 995, 995,
  996, 996, 996, 996, 997, 997, 997, 997, 997, 997,
  998, 998, 998, 998, 998, 998, 998, 998, 998, 998, 1000};
#else
#error "Please select an animation curve definition"
#endif

static const UInt32 OUT_LUT_SIZE = sizeof(OUT_LUT) / sizeof(OUT_LUT[0]);

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

static Int32 gfxAnimator_getEasingValue(UInt32 x)
{
	return (x < OUT_LUT_SIZE) ? 
		      OUT_LUT[x] : OUT_LUT[OUT_LUT_SIZE - 1];
}

static Int32 gfxAnimator_calculateValue(GfxAnimator gfxAnimator)
{
	UInt32 time;

	/* if the animation has not yet started return start value */
	if (!gfxAnimator->isStarted)
		return gfxAnimator->params.startValue;

	/* if the animation has ended return the end value */
	if (gfxAnimator->hasEnded)
		return gfxAnimator->params.endValue;

	/* if the animation is running return the calculated value */
	time = gfxAnimator->timer;

	return gfxAnimator->alpha + (gfxAnimator->beta * gfxAnimator_getEasingValue(time)) / 1000;	
}

Int32 GfxAnimator_create(GfxAnimator *gfxAnimator, GfxAnimatorParams *params)
{
	GfxAnimator newAnimator;

	/* Check input parameters */
	if ((NULL == gfxAnimator) || (NULL == params))
	{
		return E_ERROR;
	}

	/* Allocate new animator */
	newAnimator = (GfxAnimator) Memory_alloc(NULL, sizeof(struct gfx_animator_type), 0, NULL);
	if (NULL == newAnimator)
	{
		/* we couldn't allocate a new animator object */
		return E_ERROR;
	}

	/* Initialize internal variables */
	newAnimator->isInitialized = FALSE;
	newAnimator->isStarted = FALSE;
	newAnimator->hasEnded = FALSE;
	newAnimator->timer = 0;

	/* copy parameters */
	memcpy(&newAnimator->params, params, sizeof(GfxAnimatorParams));

	/* validate parameters */
	if (0 == newAnimator->params.timeScaleFactor)
		newAnimator->params.timeScaleFactor = 1;

	/* calculate auxiliary coefficients */
	newAnimator->alpha = params->startValue;
	newAnimator->beta = (params->endValue - params->startValue);

	/* the new animator object is now initialized */
	newAnimator->isInitialized = TRUE;

	/* return newly created animator */
	*gfxAnimator = newAnimator;

	LOG_PRINT_INFO(DEBUG_GFX_ANIMATOR, "%s(): Animator %p created\r\n", __FUNCTION__, newAnimator);

	return E_OK;
}

Int32 GfxAnimator_destroy(GfxAnimator gfxAnimator)
{
	/* check input parameters */
	if (NULL == gfxAnimator)
	{
		return E_ERROR;
	}

	/* free animator memory */
	Memory_free(NULL, gfxAnimator, sizeof(struct gfx_animator_type));

	LOG_PRINT_INFO(DEBUG_GFX_ANIMATOR, "%s(): Animator %p destroyed\r\n", __FUNCTION__, gfxAnimator);

	return E_OK;
}

UInt32 GfxAnimator_getLutSize()
{
  return OUT_LUT_SIZE;
}

Int32 GfxAnimator_update(GfxAnimator gfxAnimator, GfxAnimatorValue *outValue, bool_t *hasEnded)
{
	/* Check input parameters */
	if ((NULL == gfxAnimator) || (!gfxAnimator->isInitialized))
	{
		return E_ERROR;
	}

	/* Check if the animation has ended */
	if (gfxAnimator->timer >= OUT_LUT_SIZE)
	{
		/* the animation has ended */
		gfxAnimator->hasEnded = TRUE;
	}

	/* Update current value */
	gfxAnimator->currentValue = gfxAnimator_calculateValue(gfxAnimator);

	LOG_PRINT_INFO(DEBUG_GFX_ANIMATOR, "%s(): timer = %d, value = %d\r\n", __FUNCTION__, gfxAnimator->timer, gfxAnimator->currentValue);

	/* update animation timer */
	gfxAnimator->timer += gfxAnimator->params.timeScaleFactor;
	
	/* return calculated value */
	outValue->value = gfxAnimator->currentValue;
	outValue->parameterKey = gfxAnimator->params.parameterKey;
	*hasEnded = gfxAnimator->hasEnded;

	return E_OK;
}

Int32 GfxAnimator_start(GfxAnimator gfxAnimator)
{
	/* Check input parameters */
	if ((NULL == gfxAnimator) || (!gfxAnimator->isInitialized))
	{
		return E_ERROR;
	}

	/* if the animation is already started, then do nothing */
	if (gfxAnimator->isStarted)
	{
		return E_OK;
	}

	gfxAnimator->timer = 0;
	gfxAnimator->hasEnded = FALSE;
	gfxAnimator->isStarted = TRUE;

	LOG_PRINT_INFO(DEBUG_GFX_ANIMATOR, "%s(): Animator %p started\r\n", __FUNCTION__, gfxAnimator);

	return E_OK;
}

/**
 * Close doxygen group
 * @}
 */

