/******************************************************************************
 *
 * \file    gfx_layer.h
 *
 * \brief   Graphic layer header file
 *
 * \author  Esteban Pupillo
 *
 * \date    13 Sep 2022
 *
 *****************************************************************************/
#ifndef __GFX_LAYER_H__
#define __GFX_LAYER_H__

/**
 * @addtogroup GfxLayer
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>
#include "gfx_queue.h"

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define GFX_LAYER_NAME_MAX_LENGTH (8)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief GfxLayer abstract data type
 */
typedef struct gfx_layer_type* GfxLayer;

typedef Int32 (*OnDrawCallback)(GfxLayer gfxLayer, Ptr appData);
typedef Int32 (*OnFocusChangeCallback)(GfxLayer gfxLayer, Ptr appData, bool_t newState);

/**
 * @brief Graphic Layer parameters
 */
typedef struct gfx_layer_params_tag {
	char *name;
	UInt32 zOrder;
	UInt32 xPos;
	UInt32 yPos;
	UInt32 width;
	UInt32 height;
	UInt32 alpha;
	GfxQueueParams queueParams;
	OnDrawCallback onDrawCallback;
	OnFocusChangeCallback onFocusChangeCallback;
	Ptr appData;
} GfxLayerParams;

typedef struct gfx_layer_state_tag {
	UInt32 zOrder;
	UInt32 xPos;
	UInt32 yPos;
	UInt32 width;
	UInt32 height;
	UInt32 alpha;
} GfxLayerState;

typedef enum gfx_layer_tag_en {
  GFX_LAYER_TAG_NONE,
  GFX_LAYER_TAG_SPLASH,
  GFX_LAYER_TAG_RVC,
  GFX_LAYER_TAG_PDC,
  GFX_LAYER_TAG_MAX,
} GfxLayerTag;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @briel Initializes Graphic Layer parameters
 */
void inline GfxLayerParams_init(GfxLayerParams *params)
{
	if (NULL != params)
	{
		memset(params, 0, sizeof(GfxLayerParams));
	}
}

/**
 * @brief Creates a graphic layer
 *
 * @param gfxLayer pointer to a graphic layer to create
 * @param gfxLayerParams pointer the graphic layer parameters
 * @param tag Tag for this graphic layer
 * 
 * @return #E_OK on success
 */
Int32 GfxLayer_create(GfxLayer *gfxLayer, GfxLayerParams *gfxLayerParams, GfxLayerTag tag);

void GfxLayer_dump(GfxLayer gfxLayer);

char* GfxLayer_getName(GfxLayer gfxLayer);
UInt32 GfxLayer_getAlpha(GfxLayer gfxLayer);
UInt32 GfxLayer_getLocation(GfxLayer gfxLayer, UInt32 *xPos, UInt32 *yPos);
bool_t GfxLayer_getSize(GfxLayer gfxLayer, UInt32 *width, UInt32 *height);
bool_t GfxLayer_isFullScreen(GfxLayer gfxLayer); 
GfxLayerTag GfxLayer_getTag(GfxLayer gfxLayer);
UInt32 GfxLayer_getDisplayState(GfxLayer gfxLayer, GfxLayerState *state);

Int32 GfxLayer_queueFrame(GfxLayer gfxLayer, Fvid2_Frame *frame);
Int32 GfxLayer_dequeueFrame(GfxLayer gfxLayer, Fvid2_Frame **frame);
Int32 GfxLayer_acquireFrame(GfxLayer gfxLayer, Fvid2_Frame **frame);
Int32 GfxLayer_releaseFrame(GfxLayer gfxLayer, Fvid2_Frame *frame);
Int32 GfxLayer_freeAllFrames(GfxLayer gfxLayer);

Int32 GfxLayer_compareZorder(void *a, void *b);

Int32 GfxLayer_draw(GfxLayer gfxLayer, Fvid2_Frame *displayFrame);

Int32 GfxLayer_show(GfxLayer gfxLayer, bool_t animated);
Int32 GfxLayer_hide(GfxLayer gfxLayer, bool_t animated);

Int32 GfxLayer_setEnableState(GfxLayer gfxLayer, bool_t newState);

Int32 GfxLayer_onFocusChange(GfxLayer gfxLayer, bool_t newState);

/**
 * Close doxygen group
 * @}
 */

#endif //__GFX_LAYER_H__
