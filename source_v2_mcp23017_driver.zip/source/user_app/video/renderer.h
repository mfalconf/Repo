/******************************************************************************
 *
 * \file    renderer.h
 *
 * \brief   Renderer module header file
 *
 * \author  Esteban Pupillo
 *
 * \date    25 Jul 2022
 *
 *****************************************************************************/
#ifndef __RENDERER_H__
#define __RENDERER_H__

/**
 * @addtogroup Renderder
 * @{
 */
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>

#include <common_definitions.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
typedef struct resource_geometry_tag {
	UInt32 xpos;
	UInt32 ypos;
	UInt32 width;
	UInt32 height;
} ResourceGeometry_t;

typedef enum language_tag {
	RENDERER_LANGUAGE_ENGLISH,
	RENDERER_LANGUAGE_SPANISH,
	RENDERER_LANGUAGE_PORTUGUESE,
	RENDERER_LANGUAGE_INVALID,
} Language_en;

/**
 * @brief Renderer data type
 */
typedef struct renderer_tag* Renderer;

/**
 * @brief Renderer callback used to update sensor information
 */
typedef Int32 (*RendererSensorRefreshCb)(void *AppData, UInt32 *frontSensorFlags, UInt32 *rearSensorFlags);

/**
 * @brief Renderer callback parameters structure
 *
 * Use this structure to configure the callback to be used for sensor update
 */
typedef struct renderer_cb_tag {
	RendererSensorRefreshCb sensorRefreshCbFxn;
	Fvid2_CbFxn    frameUpdateCbFxn;
	void *appData;
} RendererCbParam;

typedef struct renderer_frame_tag {
	void *addr;
	UInt32 width;
	UInt32 height;
	UInt32 stride;
	UInt32 bpp;
	//bool_t repeatedFrame;
	Ptr reserved;
} RendererFrame;

typedef Shadow_CarModel_T RendererCar;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initialize Renderer
 *
 * This function has to be called before any other function of this
 * module API
 *
 * @param r pointer to initialize
 * @param callback Callback to be executed
 * @return #FVID2_SOK on success
 */
Int32 Renderer_init(Renderer *r, RendererCbParam callback);

/**
 * @brief Gets a pointer to the renderer module
 *
 * @param r pointer to return the renderer object
 * @return E_OK on success
 */
Int32 Renderer_getInstance(Renderer *r);

/**
 * @brief Starts Renderer
 *
 * @param Renderer instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_start(Renderer r);

/**
 * @brief Stops HMI
 *
 * @param Renderer instance
 *	
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_stop(Renderer r);

/**
 * @brief Sets the layout to render
 *
 * @param LayoutID ID of the layout
 *
 * @return #E_OK on success, error code otherwise
 */
Int32 Renderer_setLayout(Renderer r, UInt32 id);

/**
 * @brief Queues frame list to driver
 *
 * @param Renderer renderer instance
 * @param frameList list of frames to queue
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_queueBuffer(Renderer r, Fvid2_FrameList *frameList);

/**
 * @brief Deueues frame list from driver
 *
 * @param Renderer renderer instance
 * @param frameList pointer to a list of frames dequeued
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_dequeueBuffer(Renderer r, Fvid2_FrameList *frameList);

/**
 * @brief Acquire a new view frame for a particular layout
 * 
 * @param r Renderer instance
 * @param layoutId Desired layout ID to get the view frame
 * @param frame Pointer where to store the view frame
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_acquireViewFrame(Renderer r, UInt32 layoutId, RendererFrame *frame);

/**
 * @brief Release a view frame for a particular layout
 * 
 * @param r Renderer instance
 * @param layoutId Desired layout ID to release the view frame
 * @param frame Pointer of the frame to be released
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_releaseViewFrame(Renderer r, UInt32 layoutId, RendererFrame *frame);

/**
 * @brief Update the parking sensors flags
 * 
 * @param r Renderer instance
 * @param frontSensorFlags Buffer holding the different front parking sensor flags
 * @param rearSensorFlags Buffer holding the different rear parking sensor flags
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_updateSensors(Renderer r, UInt32 *frontSensorFlags, UInt32 *rearSensorFlags);

/**
 * @brief Update if the touch is available or not to update the GUI layout
 * 
 * @param r Renderer instance
 * @param touchAvailable New state of the touch availability
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_updateTouchAvailable(Renderer r, bool_t touchAvailable);

/**
 * @brief Update the current RVC signal status to update the GUI layout
 * 
 * @param r Renderer instance
 * @param rvcStatus New RVC signal status
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_updateRvcStatus(Renderer r, bool_t rvcStatus);

/**
 * @brief Update the current car model to update the GUI layout
 * 
 * @param r Renderer instance
 * @param car New car model detected
 * @param pdcAvailable If PDC is available for this vehicle
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_updateCar(Renderer r, RendererCar car, bool_t pdcAvailable);

/**
 * @brief Update the current language to update the GUI layout
 * 
 * @param r Renderer instance
 * @param language New language detected
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_updateLanguage(Renderer r, Language_en language);

/**
 * @brief Update the current switch ON status to update the GUI layout
 * 
 * @param r Renderer instance
 * @param switchOn New switch ON status
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_updateSwitchOn(Renderer r, bool_t switchOn);

/**
 * @brief Update if the front parking sensors are available or not to update the GUI layout
 * 
 * @param r Renderer instance
 * @param sensorsAvailable New front parking sensors available
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_updateFrontPdcSensorsAvailable(Renderer r, bool_t sensorsAvailable);

/**
 * @brief Update if the rear parking sensors are available or not to update the GUI layout
 * 
 * @param r Renderer instance
 * @param sensorsAvailable New rear parking sensors available
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 Renderer_updateRearPdcSensorsAvailable(Renderer r, bool_t sensorsAvailable);

/**
 * @brief Get the ID that describes the RVC and PDC layout
 * 
 * @return UInt32 RVC and PDC layout
 */
UInt32 Renderer_getRvcAndPdcLayout(void);

/**
 * @brief Get the ID that describes the PDC only layout
 * 
 * @return UInt32 PDC only layout
 */
UInt32 Renderer_getPdcOnlyLayout(void);

/**
 * @brief Get the current layout being shown
 * 
 * @param r Renderer object
 * @param current_layout Placeholder to put the current layout being shown
 * @return int Result of the operation
 */
int Renderer_getCurrentLayout(Renderer r, UInt32 *current_layout);

/**
 * @brief Obtain the geometry of the PDC exit button
 * 
 * @param geometry Pointer to store the desired geometry
 * @return Int32 E_OK on success, E_ERROR otherwise
 */
Int32 Renderer_getPdcExitButtonGeometry(ResourceGeometry_t *geometry);

/**
 * @brief Obtain the geometry of the PDC switch button
 * 
 * @param geometry Pointer to store the desired geometry
 * @return Int32 E_OK on success, E_ERROR otherwise
 */
Int32 Renderer_getPdcSwitchButtonGeometry(ResourceGeometry_t *geometry);

/**
 * @brief Obtain the geometry of the PDC car button
 * 
 * @param geometry Pointer to store the desired geometry
 * @return Int32 E_OK on success, E_ERROR otherwise
 */
Int32 Renderer_getPdcCarButtonGeometry(ResourceGeometry_t *geometry);

/**
 * @brief Obtain the geometry of the RVC exit button
 * 
 * @param geometry Pointer to store the desired geometry
 * @return Int32 E_OK on success, E_ERROR otherwise
 */
Int32 Renderer_getRvcExitButtonGeometry(ResourceGeometry_t *geometry);

/**
 * @brief Obtain the geometry of the RVC switch button
 * 
 * @param geometry Pointer to store the desired geometry
 * @return Int32 E_OK on success, E_ERROR otherwise
 */
Int32 Renderer_getRvcSwitchButtonGeometry(ResourceGeometry_t *geometry);

/**
 * @brief Obtain the geometry of the RVC car button
 * 
 * @param geometry Pointer to store the desired geometry
 * @return Int32 E_OK on success, E_ERROR otherwise
 */
Int32 Renderer_getRvcCarButtonGeometry(ResourceGeometry_t *geometry);

/**
 * @brief Obtain the geometry of the RVC background
 * 
 * @param geometry Pointer to store the desired geometry
 * @return Int32 E_OK on success, E_ERROR otherwise
 */
Int32 Renderer_getRvcBackgroundGeometry(ResourceGeometry_t *geometry);

/**
 * @brief Obtain the geometry of the RVC alert background message
 * 
 * @param geometry Pointer to store the desired geometry
 * @return Int32 E_OK on success, E_ERROR otherwise
 */
Int32 Renderer_getRvcAlertBackgroundGeometry(ResourceGeometry_t *geometry);

/**
 * Close doxygen group
 * @}
 */

#endif //__RENDERER_H__
