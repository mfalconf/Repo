/******************************************************************************
 *
 * \file    pdc_manager.c
 *
 * \brief   Park Distant Control manager source file
 *
 * \author  Esteban Pupillo
 *
 * \date    22 Sep 2022
 *
 *****************************************************************************/

#include <standard.h>

#include "pdc_manager.h"
#include "renderer.h"

#include <console.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Semaphore.h>

/**
 * @addtogroup PdcManager
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
/** Uncomment the following line if want to use simulated simulated sensor 
 * data.
 *
 * In simulated mode, this module creates a tasks that simulates the change
 * in sensors
 */
// #define PDC_MANAGER_SIMULATED_SENSORS

#define DEBUG_PDC_MANAGER 0

#define PDC_MANAGER_TASK_STACK_SIZE (0x1000)

#define SENSOR_INVALID       (0xFF)

#define SENSOR_SIM_INIT_VAL1 (254)
#define SENSOR_SIM_INIT_VAL2 (254)
#define SENSOR_SIM_INIT_VAL3 (254)
#define SENSOR_SIM_INIT_VAL4 (254)
#define SENSOR_SIM_STEP1 (10)
#define SENSOR_SIM_STEP2 (10)
#define SENSOR_SIM_STEP3 (10)
#define SENSOR_SIM_STEP4 (10)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

typedef struct pdc_sensor_map_entry_tag
{
	UInt32 range;
	UInt32 segments;
} PdcSensorMapEntry;

struct pdc_manager_type {
	bool_t isInitialized;
	/**< flag to know if the module is initialized */

	Renderer renderer;
	/**< PDC renderer instance */

#ifdef PDC_MANAGER_SIMULATED_SENSORS
	Task_Handle simulationTaskHandle;
	/**< Task used when simulation mode is active */
#endif

	Uint8 frontSensorsValue[PDC_MANAGER_FRONT_SENSORS_NUM];
	/**< Current value of front sensors in cm */

	Uint8 rearSensorsValue[PDC_MANAGER_REAR_SENSORS_NUM];
	/**< Current value of rear sensors in cm */

	UInt32 frontSensorFlags;
	/**< Current active front sensor segments */

	bool_t frontSensorsAvailable;
	/**< Flag to check if front parking sensors are available */

	UInt32 rearSensorFlags;
	/**< Current active rear sensor segments */

	bool_t rearSensorsAvailable;
	/**< Flag to check if rear parking sensors are available */

	Semaphore_Handle readyLock;
	/**< Semaphore used to know when the renderer is ready */
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/
#undef X
#define X(dist, seg) {dist, seg},
static const PdcSensorMapEntry pdcRearOutsideSensorMap[PDC_OUTSIDE_SEGMENTS_NUM] = {
	PDC_REAR_OUTSIDE_SENSOR_CM_TO_SEG_MAP
};

#undef X
#define X(dist, seg) {dist, seg},
static const PdcSensorMapEntry pdcRearInsideSensorMap[PDC_INSIDE_SEGMENTS_NUM] = {
	PDC_REAR_INSIDE_SENSOR_CM_TO_SEG_MAP
};

#undef X
#define X(dist, seg) {dist, seg},
static const PdcSensorMapEntry pdcFrontOutsideSensorMap[PDC_OUTSIDE_SEGMENTS_NUM] = {
	PDC_FRONT_OUTSIDE_SENSOR_CM_TO_SEG_MAP
};

#undef X
#define X(dist, seg) {dist, seg},
static const PdcSensorMapEntry pdcFrontInsideSensorMap[PDC_INSIDE_SEGMENTS_NUM] = {
	PDC_FRONT_INSIDE_SENSOR_CM_TO_SEG_MAP
};

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static struct pdc_manager_type gPdcManager = {
	/* isInitialized */
	FALSE,
};

#ifdef PDC_MANAGER_SIMULATED_SENSORS
static UInt8 stack[PDC_MANAGER_TASK_STACK_SIZE];
#endif

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

#ifdef PDC_MANAGER_SIMULATED_SENSORS
static void pdcManager_simulateSensors(Int8 frontSensor[], Int8 rearSensor[])
{
	static Int32 value1 = SENSOR_SIM_INIT_VAL1;
	static Int32 value2 = SENSOR_SIM_INIT_VAL2;
	static Int32 value3 = SENSOR_SIM_INIT_VAL3;
	static Int32 value4 = SENSOR_SIM_INIT_VAL4;
	static Int32 step1 = -SENSOR_SIM_STEP1;
	static Int32 step2 = -SENSOR_SIM_STEP2;
	static Int32 step3 = -SENSOR_SIM_STEP3;
	static Int32 step4 = -SENSOR_SIM_STEP4;

	frontSensor[0] = value1;
	frontSensor[1] = value2;
	frontSensor[2] = value3;
	frontSensor[3] = value4;

	rearSensor[0] = value4;
	rearSensor[1] = value3;
	rearSensor[2] = value2;
	rearSensor[3] = value1;


	value1 += step1;
	value2 += step2;
	value3 += step3;
	value4 += step4;

	if (0 >= value1)
	{
		value1 = 0;
		step1 = SENSOR_SIM_STEP1;
	}
	else if (SENSOR_SIM_INIT_VAL1 < value1)
	{
		value1 = SENSOR_SIM_INIT_VAL1;
		step1 = -SENSOR_SIM_STEP1;
	}

	if (0 >= value2)
	{
		value2 = 0;
		step2 = SENSOR_SIM_STEP2;
	}
	else if (SENSOR_SIM_INIT_VAL2 < value2)
	{
		value2 = SENSOR_SIM_INIT_VAL2;
		step2 = -SENSOR_SIM_STEP2;
	}

	if (0 >= value3)
	{
		value3 = 0;
		step3 = SENSOR_SIM_STEP3;
	}
	else if (SENSOR_SIM_INIT_VAL3 < value3)
	{
		value3 = SENSOR_SIM_INIT_VAL3;
		step3 = -SENSOR_SIM_STEP3;
	}

	if (0 >= value4)
	{
		value4 = 0;
		step4 = SENSOR_SIM_STEP4;
	}
	else if (SENSOR_SIM_INIT_VAL4 < value4)
	{
		value4 = SENSOR_SIM_INIT_VAL4;
		step4 = -SENSOR_SIM_STEP4;
	}

	LOG_PRINT_SVER(DEBUG_PDC_MANAGER, "%s(): sensor[0] = %d, sensor[1] = %d, "
																		"sensor[2] = %d, sensor[3] = %d\r\n", 
																		__FUNCTION__, 
																		frontSensor[0], frontSensor[1], 
																		frontSensor[2], frontSensor[3]);
}

static void pdcManager_simulationTask(UArg arg0, UArg arg1)
{
  UInt32 exit = FALSE;
  PdcManager pdcManager = (PdcManager) arg0;

	while(!exit)
	{
		Task_sleep_ms(100);

		/* generate sensors values */
		pdcManager_simulateSensors(pdcManager->frontSensorsValue, 
															 pdcManager->rearSensorsValue);


		/* update values */
		PdcManager_updateFrontSensors(pdcManager, pdcManager->frontSensorsValue);
		PdcManager_updateRearSensors(pdcManager, pdcManager->rearSensorsValue);
	}
}

static Int32 pdcManager_createSimulationTask(PdcManager pdcManager)
{
  Error_Block eb;
  Task_Params taskParams;
  Task_Handle taskHandle;

  Error_init(&eb);

  /* create main thread (interrupts not enabled in main on BIOS) */
  Task_Params_init(&taskParams);
  taskParams.instance->name = "PdcSimulation";
  taskParams.arg0 = (xdc_UArg) pdcManager;
  taskParams.stackSize = PDC_MANAGER_TASK_STACK_SIZE;
  taskParams.stack = stack;
  taskParams.affinity = VIDEO_CORE_NUM;
 
  taskHandle = Task_create(pdcManager_simulationTask, &taskParams, &eb);
  if (NULL == taskHandle)
  {
    LOG_PRINT_ERR(DEBUG_PDC_MANAGER, "Couldn't create PDC simulation task\n");
    return E_ERROR;
  }
  
  LOG_PRINT_INFO(DEBUG_PDC_MANAGER, "PDC simulation task created successfully\n");
  pdcManager->simulationTaskHandle = taskHandle;

  return E_OK;
}
#endif

static Int32 pdcManager_onNewRenderFrame(Fvid2_Handle handle, Ptr appData, Ptr reserved)
{
	PdcManager pdcManager = (PdcManager) appData;

	/* post ready semaphore */
	Semaphore_post(pdcManager->readyLock);

  return E_OK;
}

static Int32 pdcManager_updateFrontSensorsFlag(PdcManager pdcManager)
{
	UInt32 i;

	/* Clear sensor flags */
	pdcManager->frontSensorFlags = 0;

	for (i = 0; i < PDC_OUTSIDE_SEGMENTS_NUM; i++)
	{
		if ((0 == (pdcManager->frontSensorFlags & 0x000000FF)) && 
				(pdcFrontOutsideSensorMap[i].range >= pdcManager->frontSensorsValue[0]))
			pdcManager->frontSensorFlags |= pdcFrontOutsideSensorMap[i].segments << (8 * 0);
		
		if ((0 == (pdcManager->frontSensorFlags & 0xFF000000)) && 
				(pdcFrontOutsideSensorMap[i].range >= pdcManager->frontSensorsValue[3]))
			pdcManager->frontSensorFlags |= pdcFrontOutsideSensorMap[i].segments << (8 * 3);
	}

	for (i = 0; i < PDC_INSIDE_SEGMENTS_NUM; i++)
	{
		if ((0 == (pdcManager->frontSensorFlags & 0x0000FF00)) && 
				(pdcFrontInsideSensorMap[i].range >= pdcManager->frontSensorsValue[1]))
			pdcManager->frontSensorFlags |= pdcFrontInsideSensorMap[i].segments << (8 * 1);
		
		if ((0 == (pdcManager->frontSensorFlags & 0x00FF0000)) && 
				(pdcFrontInsideSensorMap[i].range >= pdcManager->frontSensorsValue[2]))
			pdcManager->frontSensorFlags |= pdcFrontInsideSensorMap[i].segments << (8 * 2);
	}

	LOG_PRINT_SVER(DEBUG_PDC_MANAGER, "%s(): frontSensorFlags = 0x%08x, rearSensorFlags = 0x%08x\r\n", 
			                              __FUNCTION__, pdcManager->frontSensorFlags, pdcManager->rearSensorFlags);

	return E_OK;
}

static Int32 pdcManager_updateRearSensorsFlag(PdcManager pdcManager)
{
	UInt32 i;

	/* Clear sensor flags */
	pdcManager->rearSensorFlags = 0;

	for (i = 0; i < PDC_OUTSIDE_SEGMENTS_NUM; i++)
	{
		if ((0 == (pdcManager->rearSensorFlags & 0x000000FF)) && 
				(pdcRearOutsideSensorMap[i].range >= pdcManager->rearSensorsValue[0]))
			pdcManager->rearSensorFlags |= pdcRearOutsideSensorMap[i].segments << (8 * 0);
		
		if ((0 == (pdcManager->rearSensorFlags & 0xFF000000)) && 
				(pdcRearOutsideSensorMap[i].range >= pdcManager->rearSensorsValue[3]))
			pdcManager->rearSensorFlags |= pdcRearOutsideSensorMap[i].segments << (8 * 3);
	}

	for (i = 0; i < PDC_INSIDE_SEGMENTS_NUM; i++)
	{
		if ((0 == (pdcManager->rearSensorFlags & 0x0000FF00)) && 
				(pdcRearInsideSensorMap[i].range >= pdcManager->rearSensorsValue[1]))
			pdcManager->rearSensorFlags |= pdcRearInsideSensorMap[i].segments << (8 * 1);
		
		if ((0 == (pdcManager->rearSensorFlags & 0x00FF0000)) && 
				(pdcRearInsideSensorMap[i].range >= pdcManager->rearSensorsValue[2]))
			pdcManager->rearSensorFlags |= pdcRearInsideSensorMap[i].segments << (8 * 2);
	}

	LOG_PRINT_SVER(DEBUG_PDC_MANAGER, "%s(): frontSensorFlags = 0x%08x, rearSensorFlags = 0x%08x\r\n", 
			                              __FUNCTION__, pdcManager->frontSensorFlags, pdcManager->rearSensorFlags);

	return E_OK;
}

Int32 PdcManager_init(PdcManager *pdcManager, PdcManagerParams *params)
{
	Int32 retVal = E_OK;

	/* check input parameters */
	if (NULL == pdcManager)
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* enforce that we are not yet initialized */
	gPdcManager.isInitialized = FALSE;
	gPdcManager.frontSensorsAvailable = FALSE;

	/* create ready Semaphore */
	Semaphore_Params semParams;
	Semaphore_Params_init(&semParams);
	gPdcManager.readyLock = Semaphore_create(0, &semParams, NULL);
  if (NULL == gPdcManager.readyLock)
  {
    LOG_PRINT_ERR(DEBUG_PDC_MANAGER, "%s(): ready lock semaphore creation failed!!\r\n", __FUNCTION__);
    return E_ERROR;
  }

	/* Initialize PDC Renderer */
	RendererCbParam rendererCbParams;
	rendererCbParams.frameUpdateCbFxn = pdcManager_onNewRenderFrame;
	rendererCbParams.sensorRefreshCbFxn = NULL;
	rendererCbParams.appData = &gPdcManager;
  retVal = Renderer_init(&gPdcManager.renderer, rendererCbParams);
	if (FVID2_SOK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_PDC_MANAGER, "%s(): PDC Render engine initialization failed!!\r\n", __FUNCTION__);
		return retVal;
	}

	retVal = Renderer_start(gPdcManager.renderer);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_PDC_MANAGER, "%s(): Unable to start PDC render engine\r\n", __FUNCTION__);
		return retVal;
	}

#ifdef PDC_MANAGER_SIMULATED_SENSORS
	pdcManager_createSimulationTask(&gPdcManager);
	
#endif

	/* now we are correctly initialized */
	gPdcManager.isInitialized = TRUE;

	/* return instance */
	*pdcManager = &gPdcManager;
	
	LOG_PRINT_INFO(DEBUG_PDC_MANAGER, "%s(): PdcManager initialized at %p\r\n", __FUNCTION__, &gPdcManager);

	Semaphore_pend(gPdcManager.readyLock, BIOS_WAIT_FOREVER);

	LOG_PRINT_INFO(DEBUG_PDC_MANAGER, "%s(): PdcManager Ready\r\n", __FUNCTION__, &gPdcManager);


	return E_OK;
}

Int32 PdcManager_getInstance(PdcManager *pdcManager)
{
	/* Check if the module is initialized */
	if (!gPdcManager.isInitialized)
	{
		/* The module is not initialized. Can't return instance */
		*pdcManager = NULL;
		return E_ERROR;
	}

	/* return current instance */
	*pdcManager = &gPdcManager;

	return E_OK;
}

Int32 PdcManager_updateFrontSensors(PdcManager pdcManager, Uint8 *frontSensor)
{
	Int32 retVal = E_OK;
  UInt32 i;

	/* Check input parameters */
	if ((NULL == pdcManager) || (NULL == frontSensor))
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* Check if the module is initialized */
	if (!pdcManager->isInitialized)
	{
		return E_ERROR;
	}

	if (!pdcManager->frontSensorsAvailable)
	{
		pdcManager->frontSensorsAvailable = TRUE;
		Renderer_updateFrontPdcSensorsAvailable(pdcManager->renderer, TRUE);
	}

	for (i = 0; i < PDC_MANAGER_FRONT_SENSORS_NUM; i++)
	{
		pdcManager->frontSensorsValue[i] = frontSensor[i];
	}

	/* update sensor flags based on new sensor values */
	retVal = pdcManager_updateFrontSensorsFlag(pdcManager);

	/* update renderer flags */
	retVal = Renderer_updateSensors(pdcManager->renderer, 
																	&pdcManager->frontSensorFlags, 
																	&pdcManager->rearSensorFlags);

	return retVal;
}

Int32 PdcManager_updateRearSensors(PdcManager pdcManager, Uint8 *rearSensor)
{
	Int32 retVal = E_OK;
  UInt32 i;

	/* Check input parameters */
	if ((NULL == pdcManager) || (NULL == rearSensor))
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* Check if the module is initialized */
	if (!pdcManager->isInitialized)
	{
		return E_ERROR;
	}

	if (!pdcManager->rearSensorsAvailable)
	{
		pdcManager->rearSensorsAvailable = TRUE;
		Renderer_updateRearPdcSensorsAvailable(pdcManager->renderer, TRUE);
	}

	for (i = 0; i < PDC_MANAGER_REAR_SENSORS_NUM; i++)
	{
		pdcManager->rearSensorsValue[i] = rearSensor[i];
	}

	/* update sensor flags based on new sensor values */
	retVal = pdcManager_updateRearSensorsFlag(pdcManager);
	
	/* update renderer flags */
	retVal = Renderer_updateSensors(pdcManager->renderer, 
																	&pdcManager->frontSensorFlags, 
																	&pdcManager->rearSensorFlags);

	return retVal;
}

Int32 PdcManager_updateTouchAvailable(PdcManager pdcManager, bool_t touchAvailable)
{
	if (NULL == pdcManager)
		return E_ERROR;
	
	return Renderer_updateTouchAvailable(pdcManager->renderer, touchAvailable);
}

Int32 PdcManager_updateRvcStatus(PdcManager pdcManager, bool_t rvcStatus)
{
	if (NULL == pdcManager)
		return E_ERROR;
	
	return Renderer_updateRvcStatus(pdcManager->renderer, rvcStatus);
}

Int32 PdcManager_updateCar(PdcManager pdcManager, RendererCar car, bool_t pdcAvailable)
{
	if (NULL == pdcManager)
		return E_ERROR;
	
	return Renderer_updateCar(pdcManager->renderer, car, pdcAvailable);
}

Int32 PdcManager_updateLanguage(PdcManager pdcManager, Language_en language)
{
	if (NULL == pdcManager)
		return E_ERROR;
	
	return Renderer_updateLanguage(pdcManager->renderer, language);
}

Int32 PdcManager_updateSwitchOn(PdcManager pdcManager, bool_t switchOn)
{
	if (NULL == pdcManager)
		return E_ERROR;
	
	return Renderer_updateSwitchOn(pdcManager->renderer, switchOn);
}

/**
 * Close doxygen group
 * @}
 */
