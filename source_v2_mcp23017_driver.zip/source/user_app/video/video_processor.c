// #define TRACE_ENABLE
// #define LOG_DEBUG_SUPER_VERBOSE
#include <standard.h>
#include "video_processor.h"
#include "video_heap.h"
#include "video_capture.h"
#include "display.h"

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>
#include <ti/csl/cslr_dss.h>
#include "clock_utils.h"

#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>
#include <ti/drv/vps/include/vpe/vps_cfgDei.h>
#include <ti/drv/vps/include/vpe/vps_m2mVpe.h>
#include <ti/drv/vps/include/vpe/vps_m2m.h>

#include <ti/drv/vps/include/common/bsp_utilsQue.h>

#include <displays/9inches_4D_display_cfg.h>

#include <../poc/poc_config.h>

#define DEBUG_VIDEO_PROC 0

#define VIDEOPROCESSOR_TASK_STACK_SIZE      (0x1000)

#define VIDEOPROCESSOR_MAX_IN_BUFFERS       (8U)
#define VIDEOPROCESSOR_MAX_OUT_BUFFERS  		(6U)
#define VIDEOPROCESSOR_OUTPUT_FORMAT    		(FVID2_DF_ABGR32_8888) //(FVID2_DF_RGB24_888)

#if VIDEOPROCESSOR_OUTPUT_FORMAT == FVID2_DF_ABGR32_8888
#define VIDEOPROCESSOR_OUTPUT_FRAME_BPP     (4)
#endif

//#undef ENABLE_VPE
#define ENABLE_VPE

struct video_processor_tag {
  bool_t isInitialized;
  /**< Tells if the driver is initialized */

	bool_t isPlaying;

  Task_Handle vprocHandle;
  /**< Video processor task hander */

  Semaphore_Handle reqCompleteSem;
  /**< Video processor request complete semaphore */

  VideoCapture videoCapture;
  /**< Video Capture instance */

  Fvid2_CbParams userCbPrms;
  /**< User callback parameters */

  UInt32 instId;
  /**< Driver instance ID */

  Vps_M2mCreateParams createPrms;
  /**< Driver create parameters */

  Vps_M2mCreateStatus createStatus;
  /**< Driver create status */

  Vps_M2mVpeParams vpePrms;
  /**< Video processor parameters */

  Fvid2_Handle drvHandle;
  /**< Video processor driver handle */

  Fvid2_CbParams cbPrms;
  /**< Video processor callback registration */
  
  Fvid2_ProcessList processList;
  /**< Video processor process list */

  Fvid2_ProcessList errProcessList;
  /**< Error process list */

  Fvid2_FrameList inFrameList;
  Fvid2_FrameList outFrameList;

	//Vps_CaptRtParams captureFramesParams[VIDEOPROCESSOR_MAX_IN_BUFFERS];
  //Vps_M2mVpeRtParams inRtParams[VIDEOPROCESSOR_MAX_IN_BUFFERS];
	//Vps_FrameParams inFrameParams[VIDEOPROCESSOR_MAX_IN_BUFFERS];
  Fvid2_Frame captureFrames[VIDEOPROCESSOR_MAX_IN_BUFFERS];
  //Vps_M2mVpeRtParams outRtParams[VIDEOPROCESSOR_MAX_OUT_BUFFERS];
	//Vps_FrameParams outFrameParams[VIDEOPROCESSOR_MAX_OUT_BUFFERS];
  Fvid2_Frame outputFrames[VIDEOPROCESSOR_MAX_OUT_BUFFERS];
  Fvid2_Frame inFrame;
  Fvid2_Frame outFrame;
  Fvid2_Frame queueFrame;

  /* Buffers information */
  UInt8 *inBuffersPool;
  /**< Input buffers memory pool start address */
  UInt8 *outBuffersPool;
  /**< Output buffers memory pool start address */

  UInt8 *inBufY[VIDEOPROCESSOR_MAX_IN_BUFFERS];
  /**< Input lumma buffers */

  UInt8 *inBufCbCr[VIDEOPROCESSOR_MAX_IN_BUFFERS];
  /**< Input chroma buffers */

  UInt8 *outBufY[VIDEOPROCESSOR_MAX_OUT_BUFFERS];
  /**< Output lumma buffers */

  UInt8 *outBufCbCr[VIDEOPROCESSOR_MAX_OUT_BUFFERS];
  /**< Output chroma buffers */

  UInt32 inBufIdx;
  /**< Current input buffer index */

  UInt32 outBufDoneIdx;
  /**< Current output done buffer index */

  UInt32 outBufEmptyIdx;
  /**< Current output empty buffer index */

  UInt32 outBufDoneCnt;
  /**< Done frames at output buffer */

  UInt32 outBufReadIdx;
  /**< Output buffer read index */
  
	UInt32 inFid;

	Ptr processQueueData[VIDEOPROCESSOR_MAX_OUT_BUFFERS];
	BspUtils_QueHandle processQueue;
	Ptr inQueueData[VIDEOPROCESSOR_MAX_IN_BUFFERS];
	BspUtils_QueHandle inQueue;

	Ptr doneQueueData[VIDEOPROCESSOR_MAX_OUT_BUFFERS];
  BspUtils_QueHandle doneQueue;

	Uint32 outputFrameWidth;
  Uint32 outputFrameHeight;

  UInt32 inWidth;
  UInt32 inHeight;

  UInt32 videoLeftOffset;
  UInt32 videoBottomOffset;

  Semaphore_Handle stopSignalsSem;
  bool_t canRun;
  bool_t processingFrame;
};

static struct video_processor_tag gVideoProcessor;
/* Task stack size */
static uint8_t stack[VIDEOPROCESSOR_TASK_STACK_SIZE];

/**
 * @brief Get the output size of the video processor
 * 
 * @param videoProcessor Video processor object
 * @param outputSizeWidth Output width
 * @param outputSizeHeight Output height
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
static Int32 videoProcessor_getOutputSize(VideoProcessor videoProcessor, Uint32 *outputSizeWidth, Uint32 *outputSizeHeight)
{
  Int32 retVal = FVID2_SOK;

  if ((outputSizeWidth != NULL) && (outputSizeHeight != NULL))
  {
    *outputSizeWidth = videoProcessor->outputFrameWidth - videoProcessor->videoLeftOffset;
    *outputSizeHeight = videoProcessor->outputFrameHeight - videoProcessor->videoBottomOffset;
  }
  else
  {
    retVal = FVID2_EBADARGS;
  }

  return retVal;
}

static Int32 videoProcessor_processFrame(VideoProcessor videoProcessor)
{
  Int32 retVal;
  Fvid2_FrameList *inFrmList, *outFrmList;
  Fvid2_ProcessList *pList;
  bool_t can_run;
 
	pList = &videoProcessor->processList;
  pList->inFrameList[0] = &videoProcessor->inFrameList;
  pList->outFrameList[0] = &videoProcessor->outFrameList;
  pList->numInLists = 1;
  pList->numOutLists = 1;

  inFrmList = pList->inFrameList[0];
  outFrmList = pList->outFrameList[0];

  do
  {
    Semaphore_pend(videoProcessor->stopSignalsSem, BIOS_WAIT_FOREVER);
    can_run = videoProcessor->canRun;
    Semaphore_post(videoProcessor->stopSignalsSem);

    if (!can_run)
    {
      Semaphore_pend(videoProcessor->stopSignalsSem, BIOS_WAIT_FOREVER);
      videoProcessor->processingFrame = false;
      Semaphore_post(videoProcessor->stopSignalsSem);
      Task_sleep_ms(20);
    }
  } while (!can_run);

  Semaphore_pend(videoProcessor->stopSignalsSem, BIOS_WAIT_FOREVER);
  videoProcessor->processingFrame = true;
  Semaphore_post(videoProcessor->stopSignalsSem);

  /* get a frame from the in queue */
	retVal = BspUtils_queGet(&videoProcessor->inQueue, (Ptr*) &inFrmList->frames[0], 1, BIOS_WAIT_FOREVER);
	if (BSP_SOK != retVal)
	{
		/* we don't have any frame available to process */
		inFrmList->frames[0] = NULL;
		inFrmList->numFrames = 0;
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s [%d](): BspUtils_queGet returned with error %d\r\n", __FUNCTION__, __LINE__, retVal);
	} 
	else
	{
    LOG_PRINT_SVER(DEBUG_VIDEO_PROC, "%s [%d]: Dequeued frame from inQueue @ %p, chNum=%d, status=%d\r\n", __FUNCTION__, __LINE__, inFrmList->frames[0], inFrmList->frames[0]->chNum, inFrmList->frames[0]->status);
		inFrmList->numFrames = 1;

#if _POC_USE_90_DEG_ROTATION_    
    Video_AutoTurn90_YUV422I(PHY_TO_DA_ADDR((UInt8 *) inFrmList->frames[0]->addr[0][0]), 720, 240, 720 * 2, 240 * 2);    
#endif

  }

	if (NULL == outFrmList)
	{
		LOG_PRINT_ERR(DEBUG_VIDEO_PROC,"%s(): outFrmList is null\r\n",__FUNCTION__);
	}

	/* get a frame from the process queue */
	retVal = BspUtils_queGet(&videoProcessor->processQueue, (Ptr*) &outFrmList->frames[0], 1, BIOS_WAIT_FOREVER);
	if (BSP_SOK != retVal)
	{
		/* we don't have any frame ready for processing */
		outFrmList->frames[0] = NULL;
		outFrmList->numFrames = 0;
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): BspUtils_queGet returned with error %d\r\n", __FUNCTION__, retVal);
	} 
	else
	{
		/* offset the frame start address to at the specified x position */
		outFrmList->frames[0]->addr[0][0] += (videoProcessor->videoLeftOffset * VIDEOPROCESSOR_OUTPUT_FRAME_BPP);
		outFrmList->numFrames = 1;
	}

  /* CAUTION: this call will reset all the values of the process list passed as argument */
  LOG_PRINT_SVER(DEBUG_VIDEO_PROC, "%s [%d]: Pushing in frame to driver @ %p, chNum=%d, status=%d\r\n", __FUNCTION__, __LINE__, inFrmList->frames[0], inFrmList->frames[0]->chNum, inFrmList->frames[0]->status);
  retVal = Fvid2_processFrames(gVideoProcessor.drvHandle, &gVideoProcessor.processList);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Processing failed!!\r\n", __FUNCTION__);
  }

  return retVal;
}

static Int32 videoProcessor_newInputFrmCallback(Fvid2_Handle handle, Ptr appData, Ptr reserved)
{
  Int32 retVal = FVID2_SOK;
  VideoProcessor videoProcessor = (VideoProcessor) appData;
  Fvid2_FrameList frmList;
  UInt32 cookie = BspOsal_disableInterrupt();

  retVal = VideoCapture_dequeueBuffer(videoProcessor->videoCapture, &frmList);
  if (FVID2_SOK == retVal)
  {
    if (frmList.frames[0]->chNum == 0U)
    {
      /* Weird case where this buffer is currently being used but the driver gives it anyway */
      LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s [%d]: WARNING!!! Frame dequeued from VideoCapture with WEIRD channel number @ %p, chNum=%d, status=%d\r\n", __FUNCTION__, __LINE__, frmList.frames[0], frmList.frames[0]->chNum, frmList.frames[0]->status);
    }
    
    /* Add frame to in queue */
    LOG_PRINT_SVER(DEBUG_VIDEO_PROC, "%s [%d]: Frame dequeued from VideoCapture @ %p, chNum=%d, status=%d\r\n", __FUNCTION__, __LINE__, frmList.frames[0], frmList.frames[0]->chNum, frmList.frames[0]->status);
    frmList.frames[0]->chNum = 0U;
    retVal = BspUtils_quePut(&videoProcessor->inQueue, frmList.frames[0], BIOS_NO_WAIT);
    if (BSP_SOK != retVal)
    {
      LOG_PRINT_ERR(DEBUG_VIDEO_PROC,"%s(): Unable to queue frame into in queue\r\n", __FUNCTION__);
      /* Skip the frame */
      retVal = VideoCapture_queueBuffer(videoProcessor->videoCapture, &frmList);
      if (FVID2_SOK != retVal)
      {
        LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Capture queue failed!!\r\n", __FUNCTION__);
      }
    }
  }
  else
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Capture dequeue failed!!(%d)\r\n", __FUNCTION__, retVal); 
  }

  BspOsal_restoreInterrupt(cookie);

  return retVal;
}

static Int32 videoProcessor_callback(Fvid2_Handle handle, Ptr appData, Ptr reserved)
{
  static UInt32 dummy = 0;
  Int32 retVal = FVID2_SOK;
  VideoProcessor videoProcessor = (VideoProcessor) appData;

  LOG_PRINT_SVER(DEBUG_VIDEO_PROC, "%s(): frame %d\r\n", __FUNCTION__, dummy);
  /* Transfer complete. Signal it */
  Semaphore_post(videoProcessor->reqCompleteSem);

  return retVal;
}

static Int32 videoProcessor_error_callback(Fvid2_Handle handle, Ptr appData, void *errList, Ptr reverved)
{
  Int32 retVal = FVID2_SOK;

  LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Video processor error callback...\r\n", __FUNCTION__);
  
  return retVal;
}

static Int32 videoProcessor_allocBuffers(VideoProcessor videoProcessor)
{
  Int32 retVal = FVID2_SOK;
  Vps_M2mVpeParams *vpePrms;
  Fvid2_Format *fmt;
  UInt32 cnt;
  UInt32 inBufSizeY = 0, inBufSizeCbCr = 0;
  UInt32 outBufSizeY = 0, outBufSizeCbCr = 0;
  UInt8 *tmpPtr;

  /* Initialize buffers data */
  videoProcessor->inBuffersPool = NULL;
  videoProcessor->outBuffersPool = NULL;
  for(cnt = 0; cnt < VIDEOPROCESSOR_MAX_IN_BUFFERS; cnt++)
  {
    videoProcessor->inBufY[cnt] = NULL;
    videoProcessor->inBufCbCr[cnt] = NULL;
  }
  for(cnt = 0; cnt < VIDEOPROCESSOR_MAX_OUT_BUFFERS; cnt++)
  {
    videoProcessor->outBufY[cnt] = NULL;
    videoProcessor->outBufCbCr[cnt] = NULL;
  }

  /* Get current VPE parameters */
  vpePrms = &videoProcessor->vpePrms;
  /* Retrieve input format */
  fmt = &vpePrms->inFmt;
  /* Calculate input buffer size based on pixel format */
  if (Fvid2_isDataFmtYuv422I(fmt->dataFormat))
  {
    inBufSizeY = VpsUtils_align(fmt->width * 2U, VPS_BUFFER_ALIGNMENT) * fmt->height;
    /* Interleaved format does not use a separate chroma buffer */
    inBufSizeCbCr = 0U;
  }
  else
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s: Input format not supported!!\r\n", __FUNCTION__);
    return FVID2_EBADARGS;
  }

  /* Retrieve output format */
  fmt = &vpePrms->outFmt;
  /* Calculate output buffer size based on pixel format */
	if (Fvid2_isDataFmtSemiPlanar(fmt->dataFormat))
  {
    outBufSizeY = VpsUtils_align(videoProcessor->outputFrameWidth, VPS_BUFFER_ALIGNMENT) * videoProcessor->outputFrameHeight;
    if (Fvid2_isDataFmtYuv420Sp(fmt->dataFormat))
    {
      outBufSizeCbCr = outBufSizeY / 2U;
    }
    else
    {
      outBufSizeCbCr = outBufSizeY;
    }
  }
	else if (FVID2_DF_RGB24_888 == fmt->dataFormat)
	{
		outBufSizeY = VpsUtils_align(videoProcessor->outputFrameWidth, VPS_BUFFER_ALIGNMENT) * videoProcessor->outputFrameHeight * 3U;
	}
	else if (FVID2_DF_ABGR32_8888 == fmt->dataFormat)
	{
		outBufSizeY = VpsUtils_align(videoProcessor->outputFrameWidth, VPS_BUFFER_ALIGNMENT) * videoProcessor->outputFrameHeight * 4U;
	}
	else
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s: Output format not supported!!\r\n", __FUNCTION__);
    return FVID2_EBADARGS; 
  }

  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s: Input buffer size: %d Y + %d CbCr = %d\r\n", __FUNCTION__, 
      inBufSizeY, inBufSizeCbCr, (inBufSizeY + inBufSizeCbCr));

  /* Allocate all input buffers at once so that memory is allocated contiguously */
  videoProcessor->inBuffersPool = (Uint8 *) VideoHeap_alloc(
                  (VIDEOPROCESSOR_MAX_IN_BUFFERS * (inBufSizeY + inBufSizeCbCr)), 
                  VPS_BUFFER_ALIGNMENT);
  if (NULL == videoProcessor->inBuffersPool)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Unable to allocate input buffers!!\r\n", __FUNCTION__);
    return FVID2_EALLOC;
  }

  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s: Output buffer size: %d Y + %d CbCr = %d\r\n", __FUNCTION__, 
      outBufSizeY, outBufSizeCbCr, (outBufSizeY + outBufSizeCbCr));
  
  /* Assign pointers from pool to each input buffer */
  tmpPtr = videoProcessor->inBuffersPool;
  for (cnt = 0; cnt < VIDEOPROCESSOR_MAX_IN_BUFFERS; cnt++)
  {
    /* Assign luma buffer */
    videoProcessor->inBufY[cnt] = tmpPtr;
    tmpPtr += inBufSizeY;

    /* Assign chroma buffer is needed */
    if (inBufSizeCbCr > 0)
    {
      videoProcessor->inBufCbCr[cnt] = tmpPtr;
      tmpPtr += inBufSizeCbCr;
    }
  }

  return retVal;
}

static Int32 videoProcessor_queueVideoCaptureBuffers(VideoProcessor videoProcessor)
{
  Int32 retVal;
  Fvid2_FrameList frmList;
  Fvid2_Frame *frm;
	UInt32 cnt;

  /* Initialize frame list */
  Fvid2FrameList_init(&frmList);

  /* add frames information to frame list */
  for (cnt = 0; cnt < VIDEOPROCESSOR_MAX_IN_BUFFERS; cnt++)
  {
    frm = &videoProcessor->captureFrames[cnt];

    Fvid2Frame_init(frm);
    frm->chNum = 0U;
    frm->addr[0][0] = DA_TO_PHY_ADDR(videoProcessor->inBufY[cnt]);
    frm->addr[0][1] = (NULL != videoProcessor->inBufCbCr[cnt])? DA_TO_PHY_ADDR(videoProcessor->inBufCbCr[cnt]) : NULL;
    frm->appData = &videoProcessor->inBufY[cnt];

    frmList.frames[cnt] = frm;
  }

  /* set number of frames added to the frame list */
  frmList.numFrames = VIDEOPROCESSOR_MAX_IN_BUFFERS;

  /* push frames to capture driver */
  retVal = VideoCapture_queueBuffer(videoProcessor->videoCapture, &frmList);

  return retVal;
}

static Int32 videoProcessor_setScCoeff(VideoProcessor videoProcessor)
{
  Int32 retVal = FVID2_SOK;
  Vps_ScCoeffParams coeffPrms;

  VpsScCoeffParams_init(&coeffPrms);
  coeffPrms.scalerId = VPS_M2M_VPE_SCALER_ID_SC0;
  coeffPrms.hScalingSet = VPS_SC_DS_SET_8_16;
  coeffPrms.vScalingSet = VPS_SC_DS_SET_8_16;

  retVal = Fvid2_control(videoProcessor->drvHandle, 
                         IOCTL_VPS_SET_COEFFS, 
                         &coeffPrms, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Set scaler coefficients IOCTL failed!!\r\n", __FUNCTION__);
    return retVal;
  }
  
  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s(): Scaler coefficients programmed OK\r\n", __FUNCTION__);
  return retVal;
}

static void videoProcessor_initParams(VideoProcessor videoProcessor)
{
  Vps_M2mCreateParams *createPrms;
  Vps_M2mVpeParams *vpePrms;
  Fvid2_Format *fmt;
  Fvid2_ProcessList *pList;
  Fvid2_FrameList *fList;

  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s()\r\n", __FUNCTION__);

  /* Initially not runnable */
  videoProcessor->canRun = false;
  videoProcessor->processingFrame = false;

  /* Init buffers variables */
  videoProcessor->inBufIdx = 0;
  videoProcessor->outBufEmptyIdx = 0;
  videoProcessor->outBufDoneIdx = 0;
  videoProcessor->outBufDoneCnt = 0;
  videoProcessor->outBufReadIdx = 0;

  /* Init process list */
  pList = &videoProcessor->processList;
  Fvid2ProcessList_init(pList);
  pList->inFrameList[0] = &videoProcessor->inFrameList;
  pList->outFrameList[0] = &videoProcessor->outFrameList;
  pList->numInLists = 1;
  pList->numOutLists = 1;

  /* Init input frame list */
  fList = &videoProcessor->inFrameList;
  Fvid2FrameList_init(fList);
  fList->numFrames = 1U;
  fList->frames[0] = &videoProcessor->inFrame;
  Fvid2Frame_init(&videoProcessor->inFrame);
  videoProcessor->inFrame.chNum = 0U;

  /* Init output frame list */
  fList = &videoProcessor->outFrameList;
  Fvid2FrameList_init(fList);
  fList->numFrames = 1U;
  fList->frames[0] = &videoProcessor->outFrame;
  Fvid2Frame_init(&videoProcessor->outFrame);
  videoProcessor->outFrame.chNum = 0U;

  /* Init error process list */
  memset(&videoProcessor->errProcessList, 0, sizeof(videoProcessor->errProcessList));
  
  /* Init callbacks object */
  Fvid2CbParams_init(&videoProcessor->cbPrms);
  videoProcessor->cbPrms.cbFxn = &videoProcessor_callback;
  videoProcessor->cbPrms.errCbFxn = &videoProcessor_error_callback;
  videoProcessor->cbPrms.errList = &videoProcessor->errProcessList;
  videoProcessor->cbPrms.appData = videoProcessor;

  /* Init VPE creation parameters */
  createPrms = &videoProcessor->createPrms;
  VpsM2mCreateParams_init(createPrms);
  createPrms->numCh = 1U;
  createPrms->chInQueueLength = VPS_M2M_DEF_QUEUE_LEN_PER_CH;
  createPrms->isDeiFmdEnable = FALSE;

  /* Init VPE parameters */
  vpePrms = &videoProcessor->vpePrms;
  VpsM2mVpeParams_init(vpePrms);
  vpePrms->chNum = 0U;
  vpePrms->inMemType = VPS_VPDMA_MT_NONTILEDMEM;
  vpePrms->outMemType = VPS_VPDMA_MT_NONTILEDMEM;
  
	/* VPE input parameters*/
  fmt = &vpePrms->inFmt;
  Fvid2Format_init(fmt);
  fmt->chNum = 0U;
  
#if _POC_USE_90_DEG_ROTATION_ 
  fmt->width = videoProcessor->inHeight;
  fmt->height = videoProcessor->inWidth;
#else 
  fmt->width = videoProcessor->inWidth;
  fmt->height = videoProcessor->inHeight;
#endif
  
  fmt->dataFormat = FVID2_DF_YUV422I_YUYV;
  fmt->scanFormat = FVID2_SF_INTERLACED;
  fmt->pitch[FVID2_YUV_INT_ADDR_IDX] = fmt->width * 2U;
  fmt->fieldMerged[FVID2_YUV_INT_ADDR_IDX] = FALSE;
  fmt->bpp = FVID2_BPP_BITS16;
  
	/* VPE output parameters */
  fmt = &vpePrms->outFmt;
  Fvid2Format_init(fmt);
  fmt->chNum = 0U;

#if _POC_USE_90_DEG_ROTATION_  
  fmt->width = DISPLAY_LCD_WIDTH;
  fmt->height = DISPLAY_LCD_HEIGHT;
#else
  Int32 ret = videoProcessor_getOutputSize(videoProcessor, &fmt->width, &fmt->height);

  if (FVID2_SOK != ret)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s: Failed to get output size. Error code = %d\r\n", __FUNCTION__, ret);
    return;
  }
#endif

  fmt->dataFormat = VIDEOPROCESSOR_OUTPUT_FORMAT; //FVID2_DF_RGB24_888; //FVID2_DF_YUV420SP_UV;
  fmt->scanFormat = FVID2_SF_PROGRESSIVE;
  if (Fvid2_isDataFmtSemiPlanar(fmt->dataFormat))
  {
		fmt->pitch[FVID2_YUV_SP_Y_ADDR_IDX] = videoProcessor->outputFrameWidth;
    fmt->pitch[FVID2_YUV_SP_CBCR_ADDR_IDX] = videoProcessor->outputFrameWidth;
  }
  else if (FVID2_DF_RGB24_888 == fmt->dataFormat)
	{
		fmt->pitch[FVID2_RGB_ADDR_IDX] = videoProcessor->outputFrameWidth * 3U; 
	}
  else if (FVID2_DF_ABGR32_8888 == fmt->dataFormat)
	{
		fmt->pitch[FVID2_RGB_ADDR_IDX] = videoProcessor->outputFrameWidth * 4U; 
	}
	else
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s: Output format not supported!!\r\n", __FUNCTION__);
    return;
  }
  fmt->bpp = FVID2_BPP_BITS16;
  
	/* VPE deinterlacer parameters */
  vpePrms->deiCfg.bypass = FALSE;
  
	/* VPE scaler parameters */
  vpePrms->scCfg.bypass = FALSE;
  vpePrms->scCfg.nonLinear = FALSE;
  vpePrms->scCfg.stripSize = 0U;
  vpePrms->scCfg.enablePeaking = TRUE;
  vpePrms->scCfg.enableEdgeDetect = TRUE;
  vpePrms->scCfg.advCfg = NULL;
  vpePrms->scCropCfg.cropStartX = 0U;
  vpePrms->scCropCfg.cropStartY = 0U;
  vpePrms->scCropCfg.cropWidth = vpePrms->inFmt.width;
  vpePrms->scCropCfg.cropHeight = vpePrms->inFmt.height * 2;

}

static Int32 videoProcessor_allocDeiCtxBuffer(VideoProcessor videoProcessor)
{
  Int32 retVal;
  Vps_DeiCtxInfo deiCtxInfo;
  Vps_DeiCtxBuf deiCtxBuf;
  UInt32 bCnt;

  deiCtxInfo.chNum = 0U;
  retVal = Fvid2_control(videoProcessor->drvHandle, 
                         IOCTL_VPS_GET_DEI_CTX_INFO, 
                         &deiCtxInfo, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Get DEI context info IOCTL failed!!\r\n",__FUNCTION__);
    return retVal;
  }

  for (bCnt = 0; bCnt < deiCtxInfo.numFld; bCnt++)
  {
    deiCtxBuf.fldBuf[bCnt] = (void *) VideoHeap_alloc(deiCtxInfo.fldBufSize, VPS_BUFFER_ALIGNMENT_RECOMMENDED);
    if (NULL == deiCtxBuf.fldBuf[bCnt])
    {
      LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Video Memory alloc failed!!\r\n", __FUNCTION__);
      retVal = FVID2_EALLOC;
      break;
    }
    deiCtxBuf.fldBuf[bCnt] = DA_TO_PHY_ADDR((UInt8 *) deiCtxBuf.fldBuf[bCnt]);
  }

  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Deinterlacer field buffers allocation failed!!\r\n", __FUNCTION__);
    return retVal;
  }
  
  for (bCnt = 0; bCnt < deiCtxInfo.numMv; bCnt++)
  {
    deiCtxBuf.mvBuf[bCnt] = (void *) VideoHeap_alloc(deiCtxInfo.mvBufSize, VPS_BUFFER_ALIGNMENT_RECOMMENDED);
    if (NULL == deiCtxBuf.mvBuf[bCnt])
    {
      LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Video Memory alloc failed!!\r\n", __FUNCTION__);
      retVal = FVID2_EALLOC;
      break;
    }

    deiCtxBuf.mvBuf[bCnt] = DA_TO_PHY_ADDR((UInt8 *) deiCtxBuf.mvBuf[bCnt]);
  }

  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Deinterlacer mv buffers allocation failed!!\r\n", __FUNCTION__);
    return retVal;
  }

  for (bCnt = 0; bCnt < deiCtxInfo.numMvstm; bCnt++)
  {
    deiCtxBuf.mvstmBuf[bCnt] = (void *) VideoHeap_alloc(deiCtxInfo.mvstmBufSize, VPS_BUFFER_ALIGNMENT_RECOMMENDED);
    if (NULL == deiCtxBuf.mvstmBuf[bCnt])
    {
      LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Video Memory alloc failed!!\r\n", __FUNCTION__);
      retVal = FVID2_EALLOC;
      break;
    }

    deiCtxBuf.mvstmBuf[bCnt] = DA_TO_PHY_ADDR((UInt8 *) deiCtxBuf.mvstmBuf[bCnt]);
  }

  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Deinterlacer mvstm buffers allocation failed!!\r\n", __FUNCTION__);
    return retVal;
  }

  deiCtxBuf.chNum = 0U;
  retVal = Fvid2_control(videoProcessor->drvHandle, 
                         IOCTL_VPS_SET_DEI_CTX_BUF, 
                         &deiCtxBuf,
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Set DEI context buffer IOCTL failed!!\r\n", __FUNCTION__);
  }

  return retVal;
}

static Int32 videoProcessor_create(VideoProcessor videoProcessor)
{
  Int32 retVal = FVID2_SOK;
  
  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s()\r\n", __FUNCTION__);
  
  videoProcessor_initParams(videoProcessor);

  videoProcessor->drvHandle = Fvid2_create(FVID2_VPS_M2M_DRV,
                                         videoProcessor->instId,
                                         &videoProcessor->createPrms,
                                         &videoProcessor->createStatus,
                                         &videoProcessor->cbPrms);
  if ((NULL == videoProcessor->drvHandle) ||
      (FVID2_SOK != videoProcessor->createStatus.retVal))
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): M2M driver create failed!!\r\n", __FUNCTION__);
    retVal = videoProcessor->createStatus.retVal;
    return retVal;
  }

  retVal = Fvid2_control(videoProcessor->drvHandle, 
                         IOCTL_VPS_M2M_SET_VPE_PARAMS, 
                         &videoProcessor->vpePrms,
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): VPE Set Params IOCTL failed!!\r\n", __FUNCTION__);
    Fvid2_delete(videoProcessor->drvHandle, NULL);
    return retVal;
  }

	/* Create process queue */
  retVal = BspUtils_queCreate(&videoProcessor->processQueue, 
                              VIDEOPROCESSOR_MAX_OUT_BUFFERS, 
                              videoProcessor->processQueueData, 
                              BSPUTILS_QUE_FLAG_BLOCK_QUE_GET);
  if (BSP_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Process queue creation failed!!\r\n", __FUNCTION__);
    return retVal;
  }

  /* Create in queue */
  retVal = BspUtils_queCreate(&videoProcessor->inQueue, 
                              VIDEOPROCESSOR_MAX_IN_BUFFERS, 
                              videoProcessor->inQueueData, 
                              BSPUTILS_QUE_FLAG_BLOCK_QUE_GET);
  if (BSP_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): In queue creation failed!!\r\n", __FUNCTION__);
    return retVal;
  }

	/* Create done queue */
  retVal = BspUtils_queCreate(&videoProcessor->doneQueue, 
                              VIDEOPROCESSOR_MAX_OUT_BUFFERS, 
                              videoProcessor->doneQueueData, 
                              BSPUTILS_QUE_FLAG_BLOCK_QUE_GET);
  if (BSP_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Done queue creation failed!!\r\n", __FUNCTION__);
    return retVal;
  }

  retVal = videoProcessor_allocBuffers(videoProcessor);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Video processor buffers allocation failed!!\r\n", __FUNCTION__);
    return retVal;
  }

  retVal = videoProcessor_setScCoeff(videoProcessor);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Scaler coefficients programming failed!!\r\n", __FUNCTION__);
    return retVal;
  }

  retVal = videoProcessor_allocDeiCtxBuffer(videoProcessor);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Deinterlacer context buffers allocation failed!!\r\n", __FUNCTION__);
    return retVal;
  }  

  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s(): Creation done\r\n", __FUNCTION__);
  return retVal;
}

static Int32 videoProcessor_initVideoCapture()
{
  Int32 retVal;
  UInt32 videoCapInstId;
  Fvid2_CbParams videoCapCb;

  /* Set video capture callback */
  Fvid2CbParams_init(&videoCapCb);
  videoCapCb.cbFxn = &videoProcessor_newInputFrmCallback;
  videoCapCb.appData = &gVideoProcessor;

  /* Set video capture instance id */
  videoCapInstId = VPS_CAPT_VIP_MAKE_INST_ID(VPS_VIP1, VPS_VIP_S0, VPS_VIP_PORTB);

  /* Initialize video capture */
  retVal = VideoCapture_init(&gVideoProcessor.videoCapture,
                             videoCapInstId,
                             gVideoProcessor.inWidth,
                             gVideoProcessor.inHeight,
                             videoCapCb);

  return retVal;
}

static void videoProcessor_processTask(UArg arg0, UArg arg1)
{
  Int32 retVal;
  UInt32 exit = FALSE;
  Fvid2_ProcessList doneProcessList;
  VideoProcessor videoProcessor = (VideoProcessor) arg0;

  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s(): Starting video processor task. inst = %p\r\n", __FUNCTION__, videoProcessor);

  while(!exit)
  {
    retVal = videoProcessor_processFrame(videoProcessor);
    if (FVID2_SOK != retVal)
    {
      LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s [%d]: Process frame failed (%d)\r\n", __FUNCTION__, __LINE__, retVal);
      continue;
    }

    /* Wait till frames get processed */
    Semaphore_pend(videoProcessor->reqCompleteSem, BIOS_WAIT_FOREVER);

    LOG_PRINT_SVER(DEBUG_VIDEO_PROC, "%s(): New Frame available...\r\n", __FUNCTION__);
    retVal = Fvid2_getProcessedFrames(videoProcessor->drvHandle, &doneProcessList, FVID2_TIMEOUT_NONE);
    if (FVID2_SOK != retVal)
    {
      LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Get processed frames request failed!!\r\n", __FUNCTION__);
      continue;
    }

		/* Check if we have a valid output frame */
		if ((NULL != doneProcessList.outFrameList[0]) && 
				(0 < doneProcessList.outFrameList[0]->numFrames))
		{
			/* reset frame start address */
			doneProcessList.outFrameList[0]->frames[0]->addr[0][0] -= videoProcessor->videoLeftOffset * VIDEOPROCESSOR_OUTPUT_FRAME_BPP;

			Vps_M2mVpeRtParams *rtParams = doneProcessList.outFrameList[0]->frames[0]->perFrameCfg;
			if (NULL != rtParams)
			{
				LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s(): output frame: width: %d, height: %d\r\n", __FUNCTION__, rtParams->outFrmPrms->width, rtParams->outFrmPrms->height);
			}

			/* add frame to done queue */
			retVal = BspUtils_quePut(&videoProcessor->doneQueue, doneProcessList.outFrameList[0]->frames[0], BIOS_NO_WAIT);
			if (BSP_SOK != retVal)
			{
				LOG_PRINT_ERR(DEBUG_VIDEO_PROC,"%s(): Unable to queue frame into done queue\r\n", __FUNCTION__);
			}
		
			/* call user callback to notify that a new frame is available */
			if (NULL != videoProcessor->userCbPrms.cbFxn)
    	{
       	(*videoProcessor->userCbPrms.cbFxn)(NULL, videoProcessor->userCbPrms.appData, NULL);
    	}
		}
    else
    {
      LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Output frame not valid\r\n", __FUNCTION__);
    }

		/* Check if we have a valid input frame to release */
    if ((NULL != doneProcessList.inFrameList[0]) &&
        (NULL != doneProcessList.inFrameList[0]->frames[0]))
    {
      /* we have to release this input frame */
			doneProcessList.inFrameList[0]->frames[0]->perFrameCfg = NULL;

      LOG_PRINT_SVER(DEBUG_VIDEO_PROC, "%s [%d]: Queueing buffer to vcap @ %p, chNum=%d, status=%d\r\n", __FUNCTION__, __LINE__, doneProcessList.inFrameList[0]->frames[0], doneProcessList.inFrameList[0]->frames[0]->chNum, doneProcessList.inFrameList[0]->frames[0]->status);

      retVal = VideoCapture_queueBuffer(videoProcessor->videoCapture, doneProcessList.inFrameList[0]);
      if (FVID2_SOK != retVal)
      {
        LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Capture queue failed!!\r\n", __FUNCTION__);
      }
    }
    else
    {
      LOG_PRINT_SVER(DEBUG_VIDEO_PROC, "%s(): input buffer held by driver\r\n", __FUNCTION__);
    }
  }
}

static Int32 videoProcessor_createProcessTask(VideoProcessor videoProcessor)
{
  Error_Block eb;
  Task_Params taskParams;
  Task_Handle taskHandle;

  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s()\r\n", __FUNCTION__);

  Error_init(&eb);

  /* create main thread (interrupts not enabled in main on BIOS) */
  Task_Params_init(&taskParams);
  taskParams.instance->name = "vproc";
  taskParams.arg0 = (xdc_UArg) videoProcessor;
  taskParams.stackSize = VIDEOPROCESSOR_TASK_STACK_SIZE;
  taskParams.stack = stack;
  taskParams.affinity = VIDEO_CORE_NUM;
 
  taskHandle = Task_create(videoProcessor_processTask, &taskParams, &eb);
  if (NULL == taskHandle)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "Couldn't create video processor task\n");
    return FVID2_EFAIL;
  }
  
  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "Video processor task created successfully\n");
  videoProcessor->vprocHandle = taskHandle;

  return FVID2_SOK;
}

Int32 VideoProcessor_init(VideoProcessor *videoProcessor, UInt32 inWidth, UInt32 inHeight, UInt32 videoLeftOffset, UInt32 videoBottomOffset, Fvid2_CbParams callback)
{
  Int32 retVal;
  Semaphore_Params semPrms;

  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s()\r\n", __FUNCTION__);

  /* Check for input parameter */
  if (NULL == videoProcessor) 
    return FVID2_EBADARGS;

  *videoProcessor = &gVideoProcessor;

  /* Initialize internal variables */
  gVideoProcessor.isInitialized = FALSE;

  /* Initialize video video processor instance id */
  gVideoProcessor.instId = VPS_M2M_INST_VPE1;

  /* Initialize input width and height */
  gVideoProcessor.inWidth = inWidth;
  gVideoProcessor.inHeight = inHeight;

  gVideoProcessor.videoLeftOffset = videoLeftOffset;
  gVideoProcessor.videoBottomOffset = videoBottomOffset;

  /* Initialize output sizes */
  Display_getResolution(NULL, &gVideoProcessor.outputFrameWidth, &gVideoProcessor.outputFrameHeight);
  
  /* Create a local copy of user callback object */
  memcpy(&gVideoProcessor.userCbPrms, &callback, sizeof(callback));

  /* Initialize video capture */
  retVal = videoProcessor_initVideoCapture();
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Video Capture initialization failed! Error code = %d\r\n", __FUNCTION__, retVal);
    return retVal;
  }

  /* Create video processor instance */
  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "videoProcessor->instId = %d\r\n", gVideoProcessor.instId);
  retVal = videoProcessor_create(&gVideoProcessor);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Video processor creation failed! Error code = %d\r\n", __FUNCTION__, retVal);
    return retVal;
  }

  /* Create request complete semaphore */
  Semaphore_Params_init(&semPrms);
  gVideoProcessor.reqCompleteSem = Semaphore_create(0, &semPrms, NULL);
  if (NULL == gVideoProcessor.reqCompleteSem)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Request done semaphore create failed!!\r\n", __FUNCTION__);
    return FVID2_EFAIL;
  }

  /* Create task stoppable semaphore */
  Semaphore_Params_init(&semPrms);
  semPrms.mode = Semaphore_Mode_BINARY;
  gVideoProcessor.stopSignalsSem = Semaphore_create(0, &semPrms, NULL);
  if (NULL == gVideoProcessor.stopSignalsSem)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Task stoppable semaphore create failed!!\r\n", __FUNCTION__);
    return FVID2_EFAIL;
  }
  Semaphore_post(gVideoProcessor.stopSignalsSem);

  /* Create processing task */
  retVal = videoProcessor_createProcessTask(&gVideoProcessor);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): video processor task creation failed!!\r\n", __FUNCTION__);
    return retVal;
  }

	gVideoProcessor.isPlaying = FALSE;

  /* We have now initialized our module */
  gVideoProcessor.isInitialized = TRUE;

  return retVal;
}

Int32 VideoProcessor_startDiagnostic(VideoProcessor videoProcessor)
{
  Int32 retVal;

  /* Check input parameters */
  if (NULL == videoProcessor)
    return FVID2_EBADARGS;
  
  retVal = VideoCapture_startDiagnostic(videoProcessor->videoCapture);

  return retVal;
}

Int32 VideoProcessor_start(VideoProcessor videoProcessor)
{
  Int32 retVal;
	
  /* Check input parameters */
  if (NULL == videoProcessor)
    return FVID2_EBADARGS;

  /* Check if the module is initialized */
  if (!videoProcessor->isInitialized)
    return FVID2_EFAIL;

  retVal = videoProcessor_queueVideoCaptureBuffers(videoProcessor);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Queue buffers to video capture failed!!\r\n", __FUNCTION__);
    return retVal;
  }

  Semaphore_pend(videoProcessor->stopSignalsSem, BIOS_WAIT_FOREVER);
  videoProcessor->canRun = true;
  Semaphore_post(videoProcessor->stopSignalsSem);

  /* In order to start the video processor it's only 
   * required to start the video capture
   */
  retVal = VideoCapture_start(gVideoProcessor.videoCapture);

	if (FVID2_SOK == retVal)
	{
		videoProcessor->isPlaying = TRUE;
	}
  
  return retVal;
}

Int32 VideoProcessor_stopDiagnostic(VideoProcessor videoProcessor)
{
  Int32 retVal;

  /* Check input arguments */
  if (NULL == videoProcessor)
    return FVID2_EBADARGS;

  retVal = VideoCapture_stopDiagnostic(videoProcessor->videoCapture);

  return retVal;
}

Int32 VideoProcessor_stop(VideoProcessor videoProcessor)
{
  Int32 retVal;
	Fvid2_FrameList frameList;
	Fvid2_ProcessList procList;
	Fvid2_Frame frm;
  bool_t is_processing;

  /* Check input parameters */
  if (NULL == videoProcessor)
    return FVID2_EBADARGS;

  /* Check if the module is initialized */
  if (!videoProcessor->isInitialized)
    return FVID2_EFAIL;

  Semaphore_pend(videoProcessor->stopSignalsSem, BIOS_WAIT_FOREVER);
  videoProcessor->canRun = false;
  Semaphore_post(videoProcessor->stopSignalsSem);

  do
  {
    Semaphore_pend(videoProcessor->stopSignalsSem, BIOS_WAIT_FOREVER);
    is_processing = videoProcessor->processingFrame;
    Semaphore_post(videoProcessor->stopSignalsSem);

    if (is_processing)
      Task_sleep_ms(20);
  } while (is_processing);

  /* In order to stop the video processor it's only 
   * required to stop the video capture
   */
  retVal = VideoCapture_stop(gVideoProcessor.videoCapture);

	/* retrieve all buffers from capture driver */
	while(retVal != FVID2_ENO_MORE_BUFFERS)
	{
		retVal = VideoCapture_dequeueBuffer(videoProcessor->videoCapture, &frameList);
		LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s(): dequeued %d buffers from capture device\r\n", __FUNCTION__, frameList.numFrames);
	}

  retVal = Fvid2_stop(videoProcessor->drvHandle, NULL);
  if (retVal != FVID2_SOK)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s [%d]: Error stopping VPE (%d)\r\n", __FUNCTION__, __LINE__, retVal);
  }
  
	/* retrieve all buffers from vpe driver */
	Fvid2ProcessList_init(&procList);
	retVal = FVID2_SOK;
	while(retVal != FVID2_ENO_MORE_BUFFERS)
	{
		retVal = Fvid2_getProcessedFrames(videoProcessor->drvHandle, &procList, FVID2_TIMEOUT_NONE);
		LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s(): dequeued %d, %d buffers from processing device\r\n", 
				__FUNCTION__, 
				(procList.inFrameList[0] != NULL)? procList.inFrameList[0]->numFrames : 0, 
				(procList.outFrameList[0] != NULL)? procList.outFrameList[0]->numFrames : 0);
	}

	LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s(): Freeing process queue\r\n", __FUNCTION__);
	while(!BspUtils_queIsEmpty(&videoProcessor->processQueue))
		retVal = BspUtils_queGet(&videoProcessor->processQueue, (Ptr*) &frm, 1, BIOS_NO_WAIT);

  LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s(): Freeing in queue\r\n", __FUNCTION__);
  while(!BspUtils_queIsEmpty(&videoProcessor->inQueue))
		retVal = BspUtils_queGet(&videoProcessor->inQueue, (Ptr*) &frm, 1, BIOS_NO_WAIT);
 	
	LOG_PRINT_INFO(DEBUG_VIDEO_PROC, "%s(): Freeing done queue\r\n", __FUNCTION__);
	while(!BspUtils_queIsEmpty(&videoProcessor->doneQueue))
		retVal = BspUtils_queGet(&videoProcessor->doneQueue, (Ptr*) &frm, 1, BIOS_NO_WAIT);

	videoProcessor->isPlaying = FALSE;
 
	LOG_PRINT_INFO(DEBUG_VIDEO_PROC,"%s(): done!\r\n", __FUNCTION__);

  return FVID2_SOK;
}

void VideoProcessor_initGpios(void)
{
  VideoCapture_initGpios();
}


Int32 VideoProcessor_queueBuffer(VideoProcessor videoProcessor, Fvid2_FrameList *frameList)
{
  Int32 retVal;

  /* Check input parameters */
  if ((NULL == videoProcessor) || (NULL == frameList))
  {
    return FVID2_EBADARGS;
  }

  /* Check if the module is initialized */
  if (!videoProcessor->isInitialized)
  {
    return FVID2_EFAIL;
  }

	/* Check for a valid frame to queue */
	if ((1 == frameList->numFrames) &&
			(NULL != frameList->frames[0]))
	{
		/* set the corresponding channel number */
		frameList->frames[0]->chNum = 0;
		/* add released frame to the process queue */
		retVal = BspUtils_quePut(&videoProcessor->processQueue, frameList->frames[0], BIOS_NO_WAIT);
		if (BSP_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Unable to push frame to process queue\r\n", __FUNCTION__);
		}
	}
  else
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Condition not met! frameList->numFrames=%d\r\n", __FUNCTION__, frameList->numFrames);
  }

  return retVal;
}

Int32 VideoProcessor_dequeueBuffer(VideoProcessor videoProcessor, Fvid2_FrameList *frameList)
{
  Int32 retVal;
  Fvid2_Frame *frm;

  /* Check input parameters */
  if ((NULL == videoProcessor) || (NULL == frameList))
  {
    return FVID2_EBADARGS;
  }

  /* Check if the module is initialized */
  if (!videoProcessor->isInitialized)
  {
    return FVID2_EFAIL;
  }

	if (!videoProcessor->isPlaying)
	{
		return FVID2_EFAIL;
	}

	/* dequeue frame from done queue */
	retVal = BspUtils_queGet(&videoProcessor->doneQueue, (Ptr*) &frm, 1, BIOS_NO_WAIT);
	if (BSP_SOK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_VIDEO_PROC, "%s(): Unable to get a frame from done queue\r\n", __FUNCTION__);
		return retVal;
	}

	frameList->numFrames = 1;
	frameList->frames[0] = frm;

  return FVID2_SOK;
}
