/******************************************************************************
 *
 * \file    hmi_manager.c
 *
 * \brief   HMI manager module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    25 Jun 2022
 *
 *****************************************************************************/

#include <standard.h>
#include "console.h"
#include <xdc/std.h>
#include "display.h"
#include "project_def.h"
#include "hmi_manager.h"
#include "ti/drv/vps/include/osal/bsp_osal.h"
#include "video_heap.h"
#include "fsm.h"
#include "gfx_composer.h"
#include "splash_animator.h"
#include "rvc_manager.h"
#include "pdc_manager.h"
#include "pdc_view.h"
#include "rvc_view.h"
#include "shadow_storage.h"
#include <sar_ram.h>
#include <pdc_manager.h>
#include <famp_pm.h>
#include "renderer.h"
#include <video_capture.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Event.h>

#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>
#include <ti/csl/cslr_dss.h>

#include <ti/drv/vps/include/vps.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/devices/bsp_lcdController.h>
#include <ti/drv/vps/include/platforms/bsp_platform.h>

#include <external_signals.h>

/**
 * @addtogroup HmiManager
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DEBUG_HMI                               1

#define HMI_MANAGER_INVALID_SPEED               (UINT16_MAX)

#define HMI_MANAGER_TASK_STACK_SIZE             (0x1000)

#define HMI_MANAGER_LOOP_TIME_US                (10 * 1000)

#define HMI_MANAGER_RVC_DEBOUNCE_TIME_US        (500 * 1000)
#define HMI_MANAGER_RVC_DEBOUNCE_COUNTS         (HMI_MANAGER_RVC_DEBOUNCE_TIME_US / HMI_MANAGER_LOOP_TIME_US)

#define HMI_MANAGER_TOUCH_DEINHIBIT_TIMEOUT_US  (5000 * 1000)
#define HMI_MANAGER_TOUCH_DEINHIBIT_COUNTS      (HMI_MANAGER_TOUCH_DEINHIBIT_TIMEOUT_US / HMI_MANAGER_LOOP_TIME_US)

#define HMI_MANAGER_TOUCH_INHIBIT_TIMEOUT_US    (1000 * 1000)
#define HMI_MANAGER_TOUCH_INHIBIT_COUNTS        (HMI_MANAGER_TOUCH_INHIBIT_TIMEOUT_US / HMI_MANAGER_LOOP_TIME_US)

#define HMI_MANAGER_DELAY_BTWN_VIEWS_TIMEOUT_US (500 * 1000)
#define HMI_MANAGER_DELAY_BTWN_VIEWS_COUNTS     (HMI_MANAGER_DELAY_BTWN_VIEWS_TIMEOUT_US / HMI_MANAGER_LOOP_TIME_US)

#define HMI_MANAGER_SCREEN_MANAGER_LOOP_TIME_US (10 * 1000)

#define HMI_MANAGER_DELAY_SCREEN_ON_TIMEOUT_US  (250 * 1000)
#define HMI_MANAGER_DELAY_SCREEN_ON_COUNTS      (HMI_MANAGER_DELAY_SCREEN_ON_TIMEOUT_US / HMI_MANAGER_SCREEN_MANAGER_LOOP_TIME_US)

#define HMI_MANAGER_COORD_IN_GEOMETRY(x, y, g)  (((x > g.xpos) && (x < (g.xpos + g.width))) && ((y > g.ypos) && (y < (g.ypos + g.height))))

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
typedef enum {
  HMI_STATE_STARTING,
  HMI_STATE_IDLE,
  HMI_STATE_SHOWING_SPLASH,
  HMI_STATE_SHOWING_RVC,
  HMI_STATE_SHOWING_PDC,
  HMI_STATE_DEBOUNCING_PDC,
  HMI_STATE_WAITING_TOUCH_DEINHIBITED,
  HMI_STATE_WAITING_TOUCH_INHIBITED,
  HMI_STATE_WAITING_FOR_START,
  HMI_STATE_ERROR,
  HMI_STATE_DELAY_BETWEEN_VIEWS,
  HMI_STATE_CHECKING_CAMERA,
  HMI_STATE_PDC_AND_RVC_NOT_AVAILABLE,
  HMI_STATE_NUM,
} HmiManager_StateId;

typedef enum {
  HMI_EVENT_RVC_STATE_CHANGE = FSM_USER_SIG,
  HMI_EVENT_BOOT_COMPLETE,
  HMI_EVENT_VEHICLE_SPEED_CHANGE,
  HMI_EVENT_PDC_KEY_STATE_CHANGE,
  HMI_EVENT_PDC_AND_RVC_KEY_STATE_CHANGE,
  HMI_EVENT_TRANSPORT_MODE_CHANGE,
  HMI_EVENT_NUM,
} HmiManager_EventId;

typedef struct hmi_manager_fsm_tag {
  FSM_FIELDS;
  HmiManager hmiManager;
} HmiManager_Fsm;

typedef enum {
  HMI_MANAGER_PRESSED_BUTTON_NONE = 0,
  HMI_MANAGER_PRESSED_BUTTON_PDC_EXIT,
  HMI_MANAGER_PRESSED_BUTTON_PDC_SWITCH,
  HMI_MANAGER_PRESSED_BUTTON_RVC_EXIT,
  HMI_MANAGER_PRESSED_BUTTON_RVC_SWITCH,
} HmiManager_PressedButton;

typedef enum {
  HMI_MANAGER_CAMERA_STATUS_UNKNOWN = 0,
  HMI_MANAGER_CAMERA_STATUS_OK,
  HMI_MANAGER_CAMERA_STATUS_NOK,
  HMI_MANAGER_CAMERA_STATUS_MAX,
} HmiManager_CameraStatus;

typedef struct hmi_manager_evt_tag {
  FSM_EVENT_FIELDS;
  union EvtParam {
    UInt32 paramUint;
    Int32 paramInt;
    bool_t paramBool;
    Ptr paramPtr;
  } param;
} HmiManager_Evt;

struct hmi_manager_tag {
  bool_t isInitialized;
  Task_Handle procHandle;
  HmiManager_Fsm hmiFsm;

  GfxComposer gfxComposer;
  SplashAnimator splashAnim;
  PdcManager pdcManager;
  RvcManager rvcManager;
  PdcView pdcView;
  RvcView rvcView;

  Semaphore_Handle signalsSem;

  bool_t canRvcStatus;
  bool_t canPdcKey;
  bool_t canTransportMode;
  bool_t stopSplash;
  bool_t rvcStatus;
  bool_t pdcStatus;
  HmiManager_CameraStatus cameraStatus;
  UInt16 vehicleSpeed;
  bool_t transportMode;
  bool_t reflashingState;
  bool_t splashStarted;
  bool_t desiredScreenState;
  bool_t screenState;
  GfxLayer currentOnFocusLayer;
  bool_t guiExit;
  bool_t guiSwitchToRvc;
  bool_t guiSwitchToPdc;
  RendererCar guiNewCar;
  RendererCar guiCurrentCar;
  Language_en newLanguage;
  Language_en currentLanguage;
  bool_t newSwitchOn;
  bool_t currentSwitchOn;

  Int32 pdcDebounces;
  Int32 rvcDebounces;
  Int32 waitingTouchDeinhibitDebounces;
  Int32 waitingTouchInhibitDebounces;
  Int32 delayBetweenViewsDebounces;

  bool_t start;
  bool_t created;
};

static Int32 hmiManager_startingHandler(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_idleHandler(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_splashModeHandler(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_rvcModeHandler(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_pdcModeHandler(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_debouncingPdcHandler(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_waitingTouchDeinhibited(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_waitingTouchInhibited(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_waitingForStart(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_error(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_delayBetweenViews(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_checkingCamera(Fsm *fsm, FsmEvent const *evt);
static Int32 hmiManager_pdcAndRvcNotAvailable(Fsm *fsm, FsmEvent const *evt);

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/
static const FsmState hmiStates[] = {
  {HMI_STATE_STARTING, hmiManager_startingHandler},
  {HMI_STATE_IDLE, hmiManager_idleHandler},
  {HMI_STATE_SHOWING_SPLASH, hmiManager_splashModeHandler},
  {HMI_STATE_SHOWING_RVC, hmiManager_rvcModeHandler},
  {HMI_STATE_SHOWING_PDC, hmiManager_pdcModeHandler},
  {HMI_STATE_DEBOUNCING_PDC, hmiManager_debouncingPdcHandler},
  {HMI_STATE_WAITING_TOUCH_DEINHIBITED, hmiManager_waitingTouchDeinhibited},
  {HMI_STATE_WAITING_TOUCH_INHIBITED, hmiManager_waitingTouchInhibited},
  {HMI_STATE_WAITING_FOR_START, hmiManager_waitingForStart},
  {HMI_STATE_ERROR, hmiManager_error},
  {HMI_STATE_DELAY_BETWEEN_VIEWS, hmiManager_delayBetweenViews},
  {HMI_STATE_CHECKING_CAMERA, hmiManager_checkingCamera},
  {HMI_STATE_PDC_AND_RVC_NOT_AVAILABLE, hmiManager_pdcAndRvcNotAvailable},
};

/**
 * @brief Perform the handshake of the touch click communication method
 * with the A15 core
 * 
 * @param x Pointer to place the resulting x-axis value of the coordinate
 * @param y Pointer to place the resulting y-axis value of the coordinate
 * @return Int32 E_OK if everything ok, error code otherwise
 */
static Int32 hmiManager_handshakeTouchClick(uint16_t *x, uint16_t *y);

/**
 * @brief Analyze a touch click event to obtain which button was pressed
 * 
 * @param hmiManager HMI Manager instance
 * @param x x-axis coordinate to analyze
 * @param y y-axis coordinate to analyze
 * @return HmiManager_PressedButton Resulting button pressed from the analysis
 */
static HmiManager_PressedButton hmiManager_analyzeTouchClick(HmiManager hmiManager, uint16_t x, uint16_t y);

/**
 * @brief Chech if the current vehicle has the PDC module available
 * 
 * @param car Current vehicle
 * @return true PDC is available
 * @return false PDC is not available
 */
static bool hmiManager_pdcAvailableByCar(RendererCar car);

/**
 * @brief Check if the current vehicle has the PDC module available
 * 
 * @param hmiManager HMI Manager instance
 * @return true PDC is available
 * @return false PDC is not available
 */
static bool hmiManager_pdcAvailable(HmiManager hmiManager);

/**
 * @brief Check if the ADAS trigger is active
 * @note This will tell if RVC or PDC view should be shown, only based on the vehicle,
 * RVC and PDC signals (not paying attention to GUI buttons)
 * 
 * @param car Vehicle to base the analysis
 * @param pdc PDC status
 * @param rvc RVC status
 * @return true ADAS trigger is active
 * @return false ADAS trigger is inactive
 */
static bool hmiManager_adasTriggerByParams(RendererCar car, bool pdc, bool rvc);

/**
 * @brief Check if the ADAS trigger is active
 * @note This will tell if RVC or PDC view should be shown, only based on the
 * RVC and PDC signals (not paying attention to GUI buttons)
 * 
 * @param hmiManager HMI Manager instance
 * @return true ADAS trigger is active
 * @return false ADAS trigger is inactive
 */
static bool hmiManager_adasTrigger(HmiManager hmiManager);

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static struct hmi_manager_tag gHmiManager = {
  .isInitialized = false,
  .created = false,
};

static uint8_t stack[HMI_MANAGER_TASK_STACK_SIZE];
static uint8_t screen_manager_stack[HMI_MANAGER_TASK_STACK_SIZE];

/******************************************************************************
 * Functions implementation
 *****************************************************************************/
static bool_t hmiManager_getTransportMode(void)
{
  bool_t aux;

  Semaphore_pend(gHmiManager.signalsSem, BIOS_WAIT_FOREVER);
  aux = gHmiManager.canTransportMode;
  Semaphore_post(gHmiManager.signalsSem);

  return aux;
}

static bool_t hmiManager_getReverseState(void)
{
  return true;
}

static bool_t hmiManager_getStopSplash(void)
{
  return sar_ram_get_stop_splash();
}

static bool_t hmiManager_getPdcKeyState(void)
{
  return true;
}

static bool_t hmiManager_blockUi(HmiManager hmiManager)
{
  return (hmiManager->transportMode) || (hmiManager->reflashingState);
}

static void hmiManager_focusGainedCallback(GfxLayer layer, void *context)
{
  HmiManager hmiManager = (HmiManager) context;
  Semaphore_pend(gHmiManager.signalsSem, BIOS_WAIT_FOREVER);
  hmiManager->currentOnFocusLayer = layer;
  Semaphore_post(gHmiManager.signalsSem);
}

static void hmiManager_generateEvents(HmiManager hmiManager)
{
  static bool using_simulated_parking_sensors = false;
  static bool rvc_service_started = false;

  bool new_rvc, new_pdc, new_transport_mode, stop_splash;

  if (!rvc_service_started)
  {
    rvc_service_started = sar_ram_get_rvc_service_started();

    if (rvc_service_started)
      PdcManager_updateTouchAvailable(hmiManager->pdcManager, true);
  }

  /*
   * NOTE:
   * Given the nature of the FSM framework, the order in which this event analysis
   * appears is extremely important since there is an implicit first-more-important nature
   * caused due to the internals of how this FSM framework is developed
   * 
   * In our case, the PDC key state is what really ends up driving the more important aspects
   * of our FSM, hence it needs to be the first event analysed
   */

  new_transport_mode = hmiManager_getTransportMode();

  if (new_transport_mode != hmiManager->transportMode)
  {
    LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Transport mode changed. oldTm = %d, newTm = %d\r\n", __FUNCTION__, __LINE__, hmiManager->transportMode, new_transport_mode);

    hmiManager->transportMode = new_transport_mode;
  }

  /*
   * NOTE 2:
   * If the PDC and RVC signal arrive somehow at the same time (this should only be achieved using
   * the SAR RAM debug feature) then we should check if both PDC and RVC events are set/unset at the same time,
   * in which cases we shall inform a different event
   */
  new_rvc = hmiManager_getReverseState();
  new_pdc = hmiManager_getPdcKeyState();

  if ((new_rvc != hmiManager->rvcStatus) && (new_pdc != hmiManager->pdcStatus) && (new_rvc == new_pdc))
  {
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): Both PdcKey and ReverseGear State changed. oldPdc = %d, newPdc = %d, oldRvc = %d, newRvc = %d\r\n", __FUNCTION__, hmiManager->pdcStatus, new_pdc, hmiManager->rvcStatus, new_rvc);
    
    hmiManager->pdcStatus = new_pdc;
    hmiManager->rvcStatus = new_rvc;
  }
  else
  {
    if (new_pdc != hmiManager->pdcStatus)
    {
      LOG_PRINT_INFO(DEBUG_HMI, "%s(): PdcKey State changed. old state = %d, new state = %d\r\n", __FUNCTION__, hmiManager->pdcStatus, new_pdc);
      hmiManager->pdcStatus = new_pdc;
    }

    if (new_rvc != hmiManager->rvcStatus)
    {
      LOG_PRINT_INFO(DEBUG_HMI, "%s(): ReverseGear State changed. old state = %d, new state = %d\r\n", __FUNCTION__, hmiManager->rvcStatus, new_rvc);
      hmiManager->rvcStatus = new_rvc;
    }
  }

  stop_splash = hmiManager_getStopSplash();
  if (stop_splash != hmiManager->stopSplash)
  {
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): stopSplash State changed. old state = %d, new state = %d\r\n", __FUNCTION__, hmiManager->stopSplash, stop_splash);
    hmiManager->stopSplash = stop_splash;
  }

  if (sar_ram_dbg_get_simulated_parking_sensors())
  {
    if (!using_simulated_parking_sensors)
    {
      LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Switching to use simulated parking sensors!\r\n", __FUNCTION__, __LINE__);
      using_simulated_parking_sensors = true;
    }

    int retVal;
    PdcManager pdcManager;
    UInt8 front_sensors[4], rear_sensors[4];

    retVal = PdcManager_getInstance(&pdcManager);

    if (E_OK == retVal)
    {
      sar_ram_dbg_get_parking_sensors(front_sensors, rear_sensors);
      PdcManager_updateFrontSensors(pdcManager, front_sensors);
      PdcManager_updateRearSensors(pdcManager, rear_sensors);
    }
    else
    {
      LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: Cannot update PDC sensors at the moment. Error code: %d\r\n", __FUNCTION__, __LINE__, retVal);
    }
  }
  else if (using_simulated_parking_sensors)
  {
    LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Switching to use real parking sensors!\r\n", __FUNCTION__, __LINE__);
    using_simulated_parking_sensors = false;
  }
}

static void hmiManager_checkInitializations(HmiManager hmiManager, HmiManager_Fsm *hmiFsm)
{
  int retVal = E_OK;

  /* If the initialization was done before, skip it */
  if (hmiManager->isInitialized)
  {
    /* Already initialized */
    LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: HMI Manager is already initialized!\r\n", __FUNCTION__, __LINE__);
    return;
  }

  /* Initialize PDC manager */
  PdcManagerParams pdcManagerParams;
  PdcManagerParams_init(&pdcManagerParams);
  retVal = PdcManager_init(&hmiManager->pdcManager, &pdcManagerParams); 
  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_HMI, "%s(): Unable to initialize PDC manager\r\n", __FUNCTION__);

    /* Transition to ERROR state */
    FsmTran(hmiFsm, &hmiStates[HMI_STATE_ERROR]);

    return;
  }

  /* Initialize Rvc manager */
  Fvid2_CbParams rvcManagerCb;
  Fvid2CbParams_init(&rvcManagerCb);
  rvcManagerCb.cbFxn = NULL;
  rvcManagerCb.appData = NULL;
  retVal = RvcManager_init(&hmiManager->rvcManager, rvcManagerCb);
  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_HMI, "%s(): Unable to initialize RVC manager\r\n", __FUNCTION__);

    /* Transition to ERROR state */
    FsmTran(hmiFsm, &hmiStates[HMI_STATE_ERROR]);

    return;
  }

  /* Initialize Rvc view */
  RvcViewParams rvcViewParams;
  RvcViewParams_init(&rvcViewParams);
  retVal = RvcView_init(&hmiManager->rvcView, &rvcViewParams);
  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_HMI, "%s(): Unable to initialize RVC view\r\n", __FUNCTION__);

    /* Transition to ERROR state */
    FsmTran(hmiFsm, &hmiStates[HMI_STATE_ERROR]);

    return;
  }

  /* Initialize PDC view */
  PdcViewParams pdcViewParams;
  PdcViewParams_init(&pdcViewParams);
  retVal = PdcView_init(&hmiManager->pdcView, &pdcViewParams);
  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_HMI, "%s(): Unable to initialize PDC view\r\n", __FUNCTION__);

    /* Transition to ERROR state */
    FsmTran(hmiFsm, &hmiStates[HMI_STATE_ERROR]);

    return;
  }
  /* now that we have everything in place
  * update the initialization flag
  */
  gHmiManager.isInitialized = TRUE;
}

static void hmiManager_stopComposer(HmiManager hmiManager)
{
  RvcManager_stop(hmiManager->rvcManager);

  /* Check if the GfxComposer is started */
  if (GfxComposer_isStarted(hmiManager->gfxComposer))
  {
    int res;
    /* Stop graphic composer to stop sending frames to the display */
    res = GfxComposer_stop(hmiManager->gfxComposer);

    if (res != E_OK)
    {
      LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: Error stopping GFX composer: %d\r\n", __FUNCTION__, __LINE__, res);
    }
  }

  while(GfxComposer_isStarted(hmiManager->gfxComposer))
  {
    Task_sleep_ms(500);
    
    if (GfxComposer_isStarted(hmiManager->gfxComposer))
      LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Waiting for GfxComposer to stop...\r\n", __FUNCTION__, __LINE__);
  }
  
  SplashAnimator_hide(hmiManager->splashAnim);
  PdcView_hide(hmiManager->pdcView);
  RvcView_hide(hmiManager->rvcView);
}

static Int32 hmiManager_startingHandler(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  
  /* In this state we only care about the ENTRY event */
  if (FSM_ENTRY_SIG != hmiEvt->sig)
    return retVal;

  /* IMPORTANT: WE ARE GOING TO MAKE THE MINIMUM INITIALIZATION REQUIRED TO SHOW THE 
   * SPLASH ANIMATION. THE COMPLETE INITIALIZATION IS DONE WHILE SHOWING THE SPLASH
   * ANIMATION
   *
   * HAVE IN MIND THAT WHATEVER DELAY TO ADD HERE YOU ARE DELAYING THE SPLASH SCREEN
   */

  /* Initialize Splash animator */
  retVal = SplashAnimator_init(&hmiManager->splashAnim);
  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_HMI, "%s(): Unable to initialize splash animator\r\n", __FUNCTION__);
  
    /* Transition to ERROR state */
    FsmTran(hmiFsm, &hmiStates[HMI_STATE_ERROR]);
    
    return E_ERROR;
  }

  GfxComposer_start(hmiManager->gfxComposer, false);

  SplashAnimator_show(hmiManager->splashAnim);

  /* Transition to waiting for start */
  FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_FOR_START]);
  
  return retVal;
}

static int32_t hmiManager_idleHandler(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);

  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Entering Idle mode\r\n", __FUNCTION__, __LINE__);
        hmiManager_stopComposer(hmiManager);
        break;
      }
    case FSM_TICK_SIG:
      {
        if (!hmiManager_blockUi(hmiManager))
        {
          if (hmiManager_adasTrigger(hmiManager) && !hmiManager->guiExit)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_DEBOUNCING_PDC]);
          }
          else if (!hmiManager->stopSplash)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_SPLASH]);
          }
        }
        
        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static int32_t hmiManager_splashModeHandler(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);

  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Entering Splash mode\r\n", __FUNCTION__, __LINE__);

        if (!hmiManager->splashStarted)
        {
          LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Starting splash animator!\r\n", __FUNCTION__, __LINE__);
          hmiManager->splashStarted = true;
          SplashAnimator_start(hmiManager->splashAnim);
        }

        SplashAnimator_show(hmiManager->splashAnim);
        PdcView_hide(hmiManager->pdcView);
        RvcView_hide(hmiManager->rvcView);

        GfxComposer_start(hmiManager->gfxComposer, false);

        break;
      }
    case FSM_TICK_SIG:
      {
        if ((hmiManager->stopSplash) || (hmiManager_blockUi(hmiManager)))
        {
          FsmTran(hmiFsm, &hmiStates[HMI_STATE_IDLE]);
        }
        else if (hmiManager_adasTrigger(hmiManager) && (!hmiManager->guiExit))
        {
          FsmTran(hmiFsm, &hmiStates[HMI_STATE_DEBOUNCING_PDC]);
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;

}

static int32_t hmiManager_rvcModeHandler(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);

  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Entering RVC mode\r\n", __FUNCTION__, __LINE__);

        if (!hmiManager->rvcStatus)
        {
          /* This is a weird case, try to encause the FSM quickly */
          LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: In RVC mode but RVC is inactive!\r\n", __FUNCTION__, __LINE__);
          FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_TOUCH_INHIBITED]);
        }
        else
        {
          PdcManager_updateRvcStatus(hmiManager->pdcManager, true);
          RvcManager_start(hmiManager->rvcManager);
          RvcView_show(hmiManager->rvcView);
        }

        break;
      }
    case FSM_TICK_SIG:
      {
        if ((!hmiManager_adasTrigger(hmiManager)) ||
            (hmiManager_blockUi(hmiManager)) ||
            (hmiManager->guiExit))
        {
          sar_ram_set_pdc_key_state(false);
          sar_ram_set_rvc_active(false);
          
          if (!hmiManager->start)
          {
            RvcManager_stop(hmiManager->rvcManager);
            RvcView_hide(hmiManager->rvcView);
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_FOR_START]);
          }
          else if ((!sar_ram_get_touch_inhibited()) && (hmiManager->stopSplash))
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_TOUCH_INHIBITED]);
          }
          else
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_TOUCH_DEINHIBITED]);
          }
        }
        else if (((!hmiManager->rvcStatus) || (hmiManager->guiSwitchToPdc)) &&
                 (hmiManager_pdcAvailable(hmiManager)))
        {
          if (hmiManager->guiSwitchToPdc)
          {
            RvcManager_stop(hmiManager->rvcManager);
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_PDC]);
          }
          else
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_DELAY_BETWEEN_VIEWS]);
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static int32_t hmiManager_pdcModeHandler(Fsm *fsm, FsmEvent const *evt)
{
  static bool_t previousRvcStatus;
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);

  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Entering PDC mode\r\n", __FUNCTION__, __LINE__);
        hmiManager->rvcDebounces = HMI_MANAGER_RVC_DEBOUNCE_COUNTS;
        previousRvcStatus = hmiManager->rvcStatus;
        PdcManager_updateRvcStatus(hmiManager->pdcManager, hmiManager->rvcStatus && (hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_OK));
        PdcView_show(hmiManager->pdcView);
        break;
      }
    case FSM_TICK_SIG:
      {
        if (hmiManager->rvcStatus)
          hmiManager->rvcDebounces--;
        else
          hmiManager->rvcDebounces = HMI_MANAGER_RVC_DEBOUNCE_COUNTS;

        if (!hmiManager_pdcAvailable(hmiManager))
        {
          LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: In PDC state but no PDC available!\r\n", __FUNCTION__, __LINE__);

          /* This is a weird case, try to encause the FSM quickly */
          if (hmiManager->rvcStatus)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_RVC]);
          }
          else
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_TOUCH_INHIBITED]);
          }
        }
        else if ((!hmiManager_adasTrigger(hmiManager)) ||
                 (hmiManager_blockUi(hmiManager)) ||
                 (hmiManager->guiExit) ||
                 (!hmiManager_pdcAvailable(hmiManager)))
        {
          sar_ram_set_pdc_key_state(false);
          sar_ram_set_rvc_active(false);

          if (!hmiManager->start)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_FOR_START]);
          }
          else if ((!sar_ram_get_touch_inhibited()) && (hmiManager->stopSplash))
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_TOUCH_INHIBITED]);
          }
          else
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_TOUCH_DEINHIBITED]);
          }
        }
        else if ((hmiManager->rvcStatus && !hmiManager->guiSwitchToPdc) ||
                 (hmiManager->guiSwitchToRvc && hmiManager->rvcStatus))
        {
          if (hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_UNKNOWN)
          {
            /* Always ensure that the minimum time with RVC status ON was met */
            if (0 >= hmiManager->rvcDebounces)
            {
              LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Debouncing RVC completed!\r\n", __FUNCTION__, __LINE__);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_CHECKING_CAMERA]);
            }
          }
          else if (hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_OK)
          {
            if (hmiManager->guiSwitchToRvc)
            {
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_RVC]);
            }
            else
            {
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_DELAY_BETWEEN_VIEWS]);
            }
          }
        }

        if ((previousRvcStatus != hmiManager->rvcStatus) && (!hmiManager->rvcStatus))
        {
          /* We only care when RVC switches to off from here, because if RVC switches to on, we go to that view */
          PdcManager_updateRvcStatus(hmiManager->pdcManager, false);
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }

    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static Int32 hmiManager_debouncingPdcHandler(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);

  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Starting PDC/RVC signal debounce process...\r\n", __FUNCTION__, __LINE__);

        /* Prepare the "debounced time" counts */
        hmiManager->rvcDebounces = HMI_MANAGER_RVC_DEBOUNCE_COUNTS;
        hmiManager->pdcDebounces = HMI_MANAGER_RVC_DEBOUNCE_COUNTS;
        /* Set the camera status to unknown, as the FSM will always go through here before RVC/PDC */
        hmiManager->cameraStatus = HMI_MANAGER_CAMERA_STATUS_UNKNOWN;
        break;
      }
    case FSM_TICK_SIG:
      {
        if (hmiManager_blockUi(hmiManager))
        {
          FsmTran(hmiFsm, &hmiStates[HMI_STATE_IDLE]);
        }
        else if (!hmiManager_adasTrigger(hmiManager))
        {
          if (!hmiManager->start)
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_FOR_START]);
          else if (hmiManager->stopSplash)
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_IDLE]);
          else
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_SPLASH]);
        }
        else
        {
          if (hmiManager->rvcStatus)
            hmiManager->rvcDebounces--;
          else
            hmiManager->rvcDebounces = HMI_MANAGER_RVC_DEBOUNCE_COUNTS;

          hmiManager->pdcDebounces--;
          
          if (0 >= hmiManager->pdcDebounces)
          {
            hmiManager->pdcDebounces = 0;

            if (hmiManager->rvcStatus)
            {
              /* Always ensure that the minimum time with RVC status ON was met */
              if (0 >= hmiManager->rvcDebounces)
              {
                LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Debouncing RVC completed!\r\n", __FUNCTION__, __LINE__);
                FsmTran(hmiFsm, &hmiStates[HMI_STATE_CHECKING_CAMERA]);
              }
            }
            else if (hmiManager_pdcAvailable(hmiManager))
            {
              LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Debouncing PDC completed!\r\n", __FUNCTION__, __LINE__);
              sar_ram_set_pdc_key_state(true);
              sar_ram_set_rvc_active(false);
              GfxComposer_start(hmiManager->gfxComposer, false);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_PDC]);
            }
            else
            {
              sar_ram_set_pdc_key_state(false);
              sar_ram_set_rvc_active(false);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_PDC_AND_RVC_NOT_AVAILABLE]);
            }
          }
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static Int32 hmiManager_waitingTouchDeinhibited(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);

  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Waiting for A15 core to deinhibit touch...\r\n", __FUNCTION__, __LINE__);

        /* Prepare the safety timeout counts */
        hmiManager->waitingTouchDeinhibitDebounces = HMI_MANAGER_TOUCH_DEINHIBIT_COUNTS;
        break;
      }
    case FSM_TICK_SIG:
      {
        if ((hmiManager_adasTrigger(hmiManager)) &&
            (!hmiManager_blockUi(hmiManager)) &&
            (!hmiManager->guiExit))
        {
          if (hmiManager->rvcStatus && (hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_OK))
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_RVC]);
          }
          else if (hmiManager_pdcAvailable(hmiManager))
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_PDC]);
          }
          else
          {
            sar_ram_set_pdc_key_state(false);
            sar_ram_set_rvc_active(false);
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_PDC_AND_RVC_NOT_AVAILABLE]);
          }
        }
        else if (0 < hmiManager->waitingTouchDeinhibitDebounces)
        {
          hmiManager->waitingTouchDeinhibitDebounces--;
          
          if (!hmiManager->start)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_FOR_START]);
          }
          else if (hmiManager_blockUi(hmiManager))
          {
            LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Transport mode ON. Proceeding to idle\r\n", __FUNCTION__, __LINE__);
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_IDLE]);
          }
          else if ((0 >= hmiManager->waitingTouchDeinhibitDebounces) || (!sar_ram_get_touch_inhibited()))
          {
            if (0 >= hmiManager->waitingTouchDeinhibitDebounces)
              LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: Waited too long for touch to be deinhibited! Continuing anyway...\r\n", __FUNCTION__, __LINE__);
            
            LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Proceeding to idle/splash\r\n", __FUNCTION__, __LINE__);

            if (hmiManager->stopSplash)
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_IDLE]);
            else
            {
              RvcManager_stop(hmiManager->rvcManager);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_SPLASH]);
            }
          }
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static Int32 hmiManager_waitingTouchInhibited(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);

  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Waiting for A15 core to inhibit touch...\r\n", __FUNCTION__, __LINE__);

        /* Prepare the safety timeout counts */
        hmiManager->waitingTouchInhibitDebounces = HMI_MANAGER_TOUCH_INHIBIT_COUNTS;
        break;
      }
    case FSM_TICK_SIG:
      {
        if ((hmiManager_adasTrigger(hmiManager)) &&
            (!hmiManager_blockUi(hmiManager)) &&
            (!hmiManager->guiExit))
        {
          if (hmiManager->rvcStatus && (hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_OK))
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_RVC]);
          }
          else if (hmiManager_pdcAvailable(hmiManager))
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_PDC]);
          }
          else
          {
            sar_ram_set_pdc_key_state(false);
            sar_ram_set_rvc_active(false);
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_PDC_AND_RVC_NOT_AVAILABLE]);
          }
        }
        else if (0 < hmiManager->waitingTouchInhibitDebounces)
        {
          hmiManager->waitingTouchInhibitDebounces--;
          
          if (!hmiManager->start)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_FOR_START]);
          }
          else if (hmiManager_blockUi(hmiManager))
          {
            LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Transport mode ON. Proceeding to idle\r\n", __FUNCTION__, __LINE__);
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_IDLE]);
          }
          else if ((0 >= hmiManager->waitingTouchInhibitDebounces) || (sar_ram_get_touch_inhibited()))
          {
            if (0 >= hmiManager->waitingTouchInhibitDebounces)
              LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: Waited too long for touch to be inhibited! Continuing anyway...\r\n", __FUNCTION__, __LINE__);
            
            LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Proceeding to wait for touch deinhibited\r\n", __FUNCTION__, __LINE__);
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_TOUCH_DEINHIBITED]);
          }
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static Int32 hmiManager_waitingForStart(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);

  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Initializing things...\r\n", __FUNCTION__, __LINE__);
        hmiManager_checkInitializations(hmiManager, hmiFsm);
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Waiting for start signal to start the splash...\r\n", __FUNCTION__, __LINE__);
        break;
      }
    case FSM_TICK_SIG:
      {
        if (hmiManager->start)
        {
          if (hmiManager->stopSplash)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_IDLE]);
          }
          else
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_SPLASH]);
          }
        }
        else if (hmiManager_adasTrigger(hmiManager) && (!hmiManager->guiExit))
        {
          FsmTran(hmiFsm, &hmiStates[HMI_STATE_DEBOUNCING_PDC]);
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static Int32 hmiManager_error(Fsm *fsm, FsmEvent const *evt)
{
  static bool informed = false;

  if (!informed)
  {
    LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: In error state.\r\n", __FUNCTION__, __LINE__);
    informed = true;
  }
  
  return E_OK;
}

static Int32 hmiManager_delayBetweenViews(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);
  
  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Performing delay between views...\r\n", __FUNCTION__, __LINE__);

        /* Prepare the safety timeout counts */
        hmiManager->delayBetweenViewsDebounces = HMI_MANAGER_DELAY_BTWN_VIEWS_COUNTS;
        break;
      }
    case FSM_TICK_SIG:
      {
        if (0 < hmiManager->delayBetweenViewsDebounces)
        {
          hmiManager->delayBetweenViewsDebounces--;
        }

        if (0 >= hmiManager->delayBetweenViewsDebounces)
        {
          if (hmiManager_adasTrigger(hmiManager))
          {
            if (hmiManager->rvcStatus && (hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_OK))
            {
              sar_ram_set_pdc_key_state(true);
              sar_ram_set_rvc_active(true);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_RVC]);
            }
            else if (hmiManager_pdcAvailable(hmiManager))
            {
              sar_ram_set_pdc_key_state(true);
              sar_ram_set_rvc_active(false);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_PDC]);
            }
            else
            {
              sar_ram_set_pdc_key_state(false);
              sar_ram_set_rvc_active(false);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_PDC_AND_RVC_NOT_AVAILABLE]);
            }
          }
          else
          {
            sar_ram_set_pdc_key_state(false);
            sar_ram_set_rvc_active(false);

            if (!sar_ram_get_touch_inhibited())
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_TOUCH_INHIBITED]);
            else
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_TOUCH_DEINHIBITED]);
          }
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static Int32 hmiManager_checkingCamera(Fsm *fsm, FsmEvent const *evt)
{
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);
  
  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Checking camera state...\r\n", __FUNCTION__, __LINE__);
        RvcManager_startDiagnostic(hmiManager->rvcManager);
        break;
      }
    case FSM_TICK_SIG:
      {
        bool camera_ok = false;

        if (!hmiManager_adasTrigger(hmiManager))
        {
          RvcManager_stopDiagnostic(hmiManager->rvcManager);
          
          if (!hmiManager->start)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_FOR_START]);
          }
          else if (hmiManager->stopSplash)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_IDLE]);
          }
          else
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_SPLASH]);
          }
        }
        else if ((hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_UNKNOWN) ||
                 (hmiManager->cameraStatus >= HMI_MANAGER_CAMERA_STATUS_MAX)) /* Handling this weird case just in case */
        {
          if (VideoCapture_cameraOk(&camera_ok) != E_INVALID_CONDITION)
          {
            RvcManager_stopDiagnostic(hmiManager->rvcManager);
            hmiManager->cameraStatus = camera_ok ? HMI_MANAGER_CAMERA_STATUS_OK : HMI_MANAGER_CAMERA_STATUS_NOK;
          }
        }

        if ((hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_OK) || (hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_NOK))
        {
          /* Here we have a valid camera status, either it is ok or not ok*/
          if (hmiManager->cameraStatus == HMI_MANAGER_CAMERA_STATUS_OK)
          {
            if (hmiManager->rvcStatus)
            {
              LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Camera ok, going into RVC state\r\n", __FUNCTION__, __LINE__);
              sar_ram_set_pdc_key_state(true);
              sar_ram_set_rvc_active(true);
              GfxComposer_start(hmiManager->gfxComposer, false);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_RVC]);
            }
            else if (hmiManager_pdcAvailable(hmiManager))
            {
              LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Camera ok, going into PDC state\r\n", __FUNCTION__, __LINE__);
              sar_ram_set_pdc_key_state(true);
              sar_ram_set_rvc_active(false);
              GfxComposer_start(hmiManager->gfxComposer, false);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_PDC]);
            }
            else
            {
              LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Camera nok, but PDC module is not available and RVC signal is off!\r\n", __FUNCTION__, __LINE__);
              FsmTran(hmiFsm, &hmiStates[HMI_STATE_PDC_AND_RVC_NOT_AVAILABLE]);
            }
          }
          else if (hmiManager_pdcAvailable(hmiManager))
          {
            LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Camera nok, going into PDC state\r\n", __FUNCTION__, __LINE__);
            sar_ram_set_pdc_key_state(true);
            sar_ram_set_rvc_active(false);
            GfxComposer_start(hmiManager->gfxComposer, false);
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_PDC]);
          }
          else
          {
            LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Camera nok, but PDC module is not available\r\n", __FUNCTION__, __LINE__);
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_PDC_AND_RVC_NOT_AVAILABLE]);
          }
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static Int32 hmiManager_pdcAndRvcNotAvailable(Fsm *fsm, FsmEvent const *evt)
{
  static bool stopSplashStateOnEnter = false;
  Int32 retVal = E_OK;
  HmiManager_Fsm *hmiFsm = (HmiManager_Fsm*) fsm;
  HmiManager hmiManager = (HmiManager) hmiFsm->hmiManager;
  HmiManager_Evt *hmiEvt = (HmiManager_Evt*) evt;

  if (FSM_TICK_SIG != hmiEvt->sig)
    LOG_PRINT_INFO(DEBUG_HMI, "%s(): event = %d\r\n", __FUNCTION__, hmiEvt->sig);
  
  switch (hmiEvt->sig) {
    case FSM_ENTRY_SIG:
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: PDC and RVC modules aren't available. Waiting for trigger signal to go off...\r\n", __FUNCTION__, __LINE__);
        stopSplashStateOnEnter = hmiManager->stopSplash;
        break;
      }
    case FSM_TICK_SIG:
      {
        if (!hmiManager_adasTrigger(hmiManager))
        {
          if (!hmiManager->start)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_WAITING_FOR_START]);
          }
          else if (hmiManager->stopSplash)
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_IDLE]);
          }
          else
          {
            FsmTran(hmiFsm, &hmiStates[HMI_STATE_SHOWING_SPLASH]);
          }
        }
        else if ((!stopSplashStateOnEnter) && (hmiManager->stopSplash))
        {
          stopSplashStateOnEnter = false;
          hmiManager_stopComposer(hmiManager);
        }

        break;
      }
    case FSM_EXIT_SIG:
      {
        break;
      }
    default:
      {
        /* Ignoring event */
      }
  }

  return retVal;
}

static Int32 hmiManager_handshakeTouchClick(uint16_t *x, uint16_t *y)
{
  if (NULL == x)
    return E_ERROR;
  
  if (NULL == y) 
    return E_ERROR;
  
  sar_ram_get_touch_press(x, y);

  if (SAR_RAM_IS_TOUCH_VALID(*x, *y))
    sar_ram_set_touch_press(SAR_RAM_INVALID_TOUCH_PRESS_X, SAR_RAM_INVALID_TOUCH_PRESS_Y);

  return E_OK;
}

static HmiManager_PressedButton hmiManager_analyzeTouchClick(HmiManager hmiManager, uint16_t x, uint16_t y)
{
  HmiManager_PressedButton ret = HMI_MANAGER_PRESSED_BUTTON_NONE;

  if (SAR_RAM_IS_TOUCH_VALID(x, y) && hmiManager_adasTrigger(hmiManager))
  {
    ResourceGeometry_t geometry;
    LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Read touch at (%d, %d) while ADAS trigger is active! RVC Status: %d\r\n", __FUNCTION__, __LINE__, x, y, hmiManager->rvcStatus);
    
    if ((hmiManager->rvcStatus) && (!hmiManager->guiSwitchToPdc))
    {
      Renderer_getRvcExitButtonGeometry(&geometry);
      if (HMI_MANAGER_COORD_IN_GEOMETRY(x, y, geometry))
        ret = HMI_MANAGER_PRESSED_BUTTON_RVC_EXIT;
      
      Renderer_getRvcSwitchButtonGeometry(&geometry);
      if (HMI_MANAGER_COORD_IN_GEOMETRY(x, y, geometry))
        ret = HMI_MANAGER_PRESSED_BUTTON_RVC_SWITCH;
      
      Renderer_getRvcCarButtonGeometry(&geometry);
      if (HMI_MANAGER_COORD_IN_GEOMETRY(x, y, geometry))
        ret = HMI_MANAGER_PRESSED_BUTTON_RVC_SWITCH;
    }
    else
    {
      Renderer_getPdcExitButtonGeometry(&geometry);
      if (HMI_MANAGER_COORD_IN_GEOMETRY(x, y, geometry))
        ret = HMI_MANAGER_PRESSED_BUTTON_PDC_EXIT;
      
      Renderer_getPdcSwitchButtonGeometry(&geometry);
      if (HMI_MANAGER_COORD_IN_GEOMETRY(x, y, geometry))
        ret = HMI_MANAGER_PRESSED_BUTTON_PDC_SWITCH;
      
      Renderer_getPdcCarButtonGeometry(&geometry);
      if (HMI_MANAGER_COORD_IN_GEOMETRY(x, y, geometry))
        ret = HMI_MANAGER_PRESSED_BUTTON_PDC_SWITCH;
    }
  }

  if ((!hmiManager_pdcAvailable(hmiManager)) && (ret == HMI_MANAGER_PRESSED_BUTTON_RVC_SWITCH))
  {
    /* We don't care for the switch button in the RVC view if the PDC module is not available */
    LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Discarding button (%d) as PDC module is not active\r\n", __FUNCTION__, __LINE__, ret);
    ret = HMI_MANAGER_PRESSED_BUTTON_NONE;
  }

  if (ret != HMI_MANAGER_PRESSED_BUTTON_NONE)
    LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Button pressed! Button=%d\r\n", __FUNCTION__, __LINE__, ret);

  return ret;
}

static bool hmiManager_pdcAvailableByCar(RendererCar car)
{
  return (car != CAR_MODEL_VW_POLO) && (car != CAR_MODEL_INVALID);
}

static bool hmiManager_pdcAvailable(HmiManager hmiManager)
{
  return hmiManager_pdcAvailableByCar(hmiManager->guiCurrentCar);
}

static bool hmiManager_adasTriggerByParams(RendererCar car, bool pdc, bool rvc)
{
  /* Simplified:
     PDC Available -> The trigger is the pdcStatus signal
     PDC Not Available -> The trigger is the rvcStatus signal */
  return (hmiManager_pdcAvailableByCar(car) && pdc) || (!hmiManager_pdcAvailableByCar(car) && rvc);
}

static bool hmiManager_adasTrigger(HmiManager hmiManager)
{
  return hmiManager_adasTriggerByParams(hmiManager->guiCurrentCar, hmiManager->pdcStatus, hmiManager->rvcStatus);
}

static void hmiManager_processTask(UArg arg0, UArg arg1)
{
  UInt32 exit = FALSE;
  HmiManager hmiManager = (HmiManager) arg0;
  uint16_t x, y;
  bool_t lastPdcStatus = false;
  bool_t lastRvcStatus = false;

  LOG_PRINT_INFO(DEBUG_HMI, "Starting HMI manager task\r\n");

  /* Initialize state machine object */
  gHmiManager.hmiFsm.hmiManager = &gHmiManager;

  /* Create hmi state machine */
  FsmCtor((Fsm*)&gHmiManager.hmiFsm, &hmiStates[HMI_STATE_STARTING]);

  /* Start state machine */
  FsmInit((Fsm*)&gHmiManager.hmiFsm, &FsmEvtEntry);

  while (!exit) 
  {
    /* Check and generate events */
    hmiManager_generateEvents(hmiManager);

    hmiManager_handshakeTouchClick(&x, &y);
    HmiManager_PressedButton button = hmiManager_analyzeTouchClick(hmiManager, x, y);

    switch (button)
    {
      case HMI_MANAGER_PRESSED_BUTTON_NONE:
      {
        /* Ignore */
        break;
      }

      case HMI_MANAGER_PRESSED_BUTTON_PDC_EXIT:
      case HMI_MANAGER_PRESSED_BUTTON_RVC_EXIT:
      {
        hmiManager->guiExit = hmiManager->currentSwitchOn;
        break;
      }

      case HMI_MANAGER_PRESSED_BUTTON_PDC_SWITCH:
      {
        hmiManager->guiSwitchToPdc = false;
        hmiManager->guiSwitchToRvc = true;
        break;
      }

      case HMI_MANAGER_PRESSED_BUTTON_RVC_SWITCH:
      {
        hmiManager->guiSwitchToRvc = false;
        hmiManager->guiSwitchToPdc = true;
        break;
      }

      default:
      {
        LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: Weird case with button %d not handled!", __FUNCTION__, __LINE__, button);
      }
    }

    /* We check if needed to clear GUI switch status whenever PDC and/or RVC state changes */
    if ((lastPdcStatus != hmiManager->pdcStatus) || (lastRvcStatus != hmiManager->rvcStatus))
    {
      /* Clear GUI exit status whenever ADAS trigger is off */
      if (!hmiManager_adasTrigger(hmiManager))
      {
        hmiManager->guiExit = false;
      }

      hmiManager->guiSwitchToPdc = false;
      hmiManager->guiSwitchToRvc = false;

      /* Also, clear GUI exit status when RVC goes from OFF to ON to re-enable RVC */
      /* This is only relevant when the PDC module is available */
      if (hmiManager_pdcAvailable(hmiManager) && (hmiManager->rvcStatus && !lastRvcStatus))
      {
        hmiManager->guiExit = false;
      }

      lastPdcStatus = hmiManager->pdcStatus;
      lastRvcStatus = hmiManager->rvcStatus;
    }

    if (hmiManager->guiNewCar != hmiManager->guiCurrentCar)
    {
      hmiManager->guiCurrentCar = hmiManager->guiNewCar;
      PdcManager_updateCar(hmiManager->pdcManager, hmiManager->guiCurrentCar, hmiManager_pdcAvailableByCar(hmiManager->guiCurrentCar));
    }

    if ((hmiManager->newLanguage != hmiManager->currentLanguage) && (hmiManager->newLanguage != RENDERER_LANGUAGE_INVALID))
    {
      hmiManager->currentLanguage = hmiManager->newLanguage;
      PdcManager_updateLanguage(hmiManager->pdcManager, hmiManager->currentLanguage);
    }

    if (hmiManager->newSwitchOn != hmiManager->currentSwitchOn)
    {
      hmiManager->currentSwitchOn = hmiManager->newSwitchOn;
      PdcManager_updateSwitchOn(hmiManager->pdcManager, hmiManager->currentSwitchOn);
    }

    FsmDispatch(&hmiManager->hmiFsm, &FsmEvtTick);
    Task_sleep(HMI_MANAGER_LOOP_TIME_US / Clock_tickPeriod);
  }
}

static void hmiManager_screenManagerTask(UArg arg0, UArg arg1)
{
  HmiManager hmiManager = (HmiManager) arg0;
  UInt32 turn_on_screen_counter = 0;

  LOG_PRINT_INFO(DEBUG_HMI, "Starting HMI screen manager task\r\n");

  /* Initialize state machine object */
  gHmiManager.hmiFsm.hmiManager = &gHmiManager;

  while (1)
  {
    bool_t this_desired_screen_state;
    HmiManager_StateId this_fsm_state;
    bool_t this_pdc_state;

    Task_sleep(HMI_MANAGER_SCREEN_MANAGER_LOOP_TIME_US / Clock_tickPeriod);

    this_desired_screen_state = hmiManager->desiredScreenState;
    this_fsm_state = FsmGetCurrStateId(&hmiManager->hmiFsm);
    this_pdc_state = hmiManager->pdcStatus;

    if (this_desired_screen_state != hmiManager->screenState)
    {
      if (!this_desired_screen_state)
      {
        LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Switching screen state to OFF\r\n", __FUNCTION__, __LINE__);
        FAMP_PM_Turn_Off_Screen();
        hmiManager->screenState = false;
      }
      else
      {
        bool_t turn_on_screen = false;

        if (hmiManager->currentOnFocusLayer != NULL)
        {
          GfxLayer layer = hmiManager->currentOnFocusLayer;
          switch (this_fsm_state)
          {
            case HMI_STATE_SHOWING_SPLASH:
            {
              if (GfxLayer_getTag(layer) == GFX_LAYER_TAG_SPLASH)
                turn_on_screen_counter++;
              else
                turn_on_screen_counter = 0;

              break;
            }

            case HMI_STATE_IDLE:
            case HMI_STATE_PDC_AND_RVC_NOT_AVAILABLE:
            {
              /* Always turn on screen in IDLE (HMI manager in IDLE...) state */
              turn_on_screen = true;
              break;
            }

            case HMI_STATE_SHOWING_PDC:
            {
              GfxLayerState state;

              GfxLayer_getDisplayState(layer, &state);

              if ((GfxLayer_getTag(layer) == GFX_LAYER_TAG_PDC) &&
                  (this_pdc_state) &&
                  (state.xPos == 0 && state.yPos == 0) &&
                  (state.alpha == 0xFF))
                turn_on_screen_counter++;
              else
                turn_on_screen_counter = 0;

              break;
            }

            case HMI_STATE_SHOWING_RVC:
            {
              GfxLayerState state;

              GfxLayer_getDisplayState(layer, &state);

              if ((GfxLayer_getTag(layer) == GFX_LAYER_TAG_RVC) &&
                  (this_pdc_state) &&
                  (state.xPos == 0 && state.yPos == 0) &&
                  (state.alpha == 0xFF))
                turn_on_screen_counter++;
              else
                turn_on_screen_counter = 0;

              break;
            }

            default:
            {
              /* Ignoring event */
            }
          }
        }

        if (turn_on_screen || (turn_on_screen_counter >= HMI_MANAGER_DELAY_SCREEN_ON_COUNTS))
        {
          LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Switching screen state to ON\r\n", __FUNCTION__, __LINE__);
          hmiManager->screenState = true;
          turn_on_screen_counter = 0;
          FAMP_PM_Turn_On_Screen();
        }
      }
    }
    else
    {
      /* Refresh desired screen state */
      hmiManager->screenState ? FAMP_PM_Turn_On_Screen() : FAMP_PM_Turn_Off_Screen();
      turn_on_screen_counter = 0;
    }
  }
}

static Int32 hmiManager_createProcessTask(HmiManager hmiManager)
{
  Error_Block eb;
  Task_Params taskParams;
  Task_Params screenTaskParams;
  Task_Handle taskHandle;

  Error_init(&eb);

  /* create processing task */
  Task_Params_init(&taskParams);
  taskParams.instance->name = "hmiproc";
  taskParams.arg0 = (xdc_UArg) hmiManager;
  taskParams.stackSize = HMI_MANAGER_TASK_STACK_SIZE;
  taskParams.stack = stack;
  taskParams.affinity = VIDEO_CORE_NUM;
 
  taskHandle = Task_create(hmiManager_processTask, &taskParams, &eb);
  if (NULL == taskHandle)
  {
    LOG_PRINT_ERR(DEBUG_HMI, "Couldn't create HMI manager processing task\n");
    return E_ERROR;
  }

  Task_Params_init(&screenTaskParams);
  screenTaskParams.instance->name = "hmiscrproc";
  screenTaskParams.arg0 = (xdc_UArg) hmiManager;
  screenTaskParams.stackSize = HMI_MANAGER_TASK_STACK_SIZE;
  screenTaskParams.stack = screen_manager_stack;
  screenTaskParams.affinity = VIDEO_CORE_NUM;

  Task_create(hmiManager_screenManagerTask, &screenTaskParams, &eb);
  
  LOG_PRINT_INFO(DEBUG_HMI, "HMI manager processing task created successfully\n");
  hmiManager->procHandle = taskHandle;

  return E_OK;
}

Int32 HmiManager_init(void)
{
  Int32 retVal = E_ERROR;

  LOG_PRINT_INFO(DEBUG_HMI, "%s()\r\n", __FUNCTION__);

  /* Initialize internal variables */
  gHmiManager.isInitialized = false;
  gHmiManager.canRvcStatus = false;
  gHmiManager.rvcStatus = false;
  gHmiManager.stopSplash = false;
  gHmiManager.canPdcKey = false;
  gHmiManager.pdcStatus = false;
  gHmiManager.canTransportMode = false;
  gHmiManager.transportMode = false;
  gHmiManager.reflashingState = false;
  gHmiManager.splashStarted = false;
  gHmiManager.desiredScreenState = false;
  gHmiManager.screenState = false;
  gHmiManager.currentOnFocusLayer = NULL;
  gHmiManager.vehicleSpeed = HMI_MANAGER_INVALID_SPEED;
  gHmiManager.pdcDebounces = 0;
  gHmiManager.waitingTouchDeinhibitDebounces = 0;
  gHmiManager.waitingTouchInhibitDebounces = 0;
  gHmiManager.delayBetweenViewsDebounces = 0;
  gHmiManager.guiExit = false;
  gHmiManager.guiSwitchToRvc = false;
  gHmiManager.guiSwitchToPdc = false;
  gHmiManager.guiCurrentCar = CAR_MODEL_INVALID;
  gHmiManager.guiNewCar = CAR_MODEL_INVALID;
  gHmiManager.newLanguage = RENDERER_LANGUAGE_INVALID;
  gHmiManager.currentLanguage = RENDERER_LANGUAGE_INVALID;
  gHmiManager.newSwitchOn = false;
  gHmiManager.currentSwitchOn = false;
  gHmiManager.start = false;

  gHmiManager.signalsSem = Semaphore_create(1, NULL, NULL);

  /* Create HMI task */
  retVal = hmiManager_createProcessTask(&gHmiManager);
  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_HMI, "%s():HMI Task initialization failed!!\r\n", __FUNCTION__);
    return retVal;
  }

  /* Initialize graphic composer */
  retVal = GfxComposer_init(&gHmiManager.gfxComposer, hmiManager_focusGainedCallback, &gHmiManager);
  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_HMI, "%s(): Unable to initialize Graphic composer\r\n", __FUNCTION__);
    return retVal;
  }
  
  gHmiManager.created = true;

  return retVal;
}

void HmiManager_start(void)
{
  if (!gHmiManager.created)
    return;

  if (gHmiManager.start)
    return;

  LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: HMI manager is being started!\r\n", __FUNCTION__, __LINE__);

  Semaphore_pend(gHmiManager.signalsSem, BIOS_WAIT_FOREVER);
  gHmiManager.start = true;
  Semaphore_post(gHmiManager.signalsSem);
}

void HmiManager_set_rvc_state(bool_t rvc_state)
{
  if (!gHmiManager.created)
    return;

  Semaphore_pend(gHmiManager.signalsSem, BIOS_WAIT_FOREVER);
  LOG_PRINT_SVER(DEBUG_HMI, "(%s) [%d]: Setting new RVC state from CAN: %d\r\n", __FUNCTION__, __LINE__, rvc_state);
  gHmiManager.canRvcStatus = rvc_state;
  Semaphore_post(gHmiManager.signalsSem);
}

void HmiManager_set_pdc_key_state(bool_t pdc_key_state)
{
  if (!gHmiManager.created)
    return;

  Semaphore_pend(gHmiManager.signalsSem, BIOS_WAIT_FOREVER);
  LOG_PRINT_SVER(DEBUG_HMI, "(%s) [%d]: Setting new PDC state from CAN: %d\r\n", __FUNCTION__, __LINE__, pdc_key_state);
  gHmiManager.canPdcKey = pdc_key_state;
  Semaphore_post(gHmiManager.signalsSem);
}

void HmiManager_update_front_parking_sensors(Uint8 *front_sensors)
{
  int retVal;
  PdcManager pdcManager;
  bool pdc_key_status;

  if (!gHmiManager.isInitialized)
    return;

  if (sar_ram_dbg_get_simulated_parking_sensors())
    return;

  Semaphore_pend(gHmiManager.signalsSem, BIOS_WAIT_FOREVER);
  pdc_key_status = gHmiManager.canPdcKey;
  Semaphore_post(gHmiManager.signalsSem);

  if (!pdc_key_status)
    return;

  retVal = PdcManager_getInstance(&pdcManager);

  if (E_OK == retVal)
  {
    PdcManager_updateFrontSensors(pdcManager, front_sensors);
  }
  else
  {
    LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: Cannot update PDC sensors at the moment. Error code: %d\r\n", __FUNCTION__, __LINE__, retVal);
  }
}

void HmiManager_update_rear_parking_sensors(Uint8 *rear_sensors)
{
  int retVal;
  PdcManager pdcManager;
  bool pdc_key_status;

  if (!gHmiManager.isInitialized)
    return;

  if (sar_ram_dbg_get_simulated_parking_sensors())
    return;

  Semaphore_pend(gHmiManager.signalsSem, BIOS_WAIT_FOREVER);
  pdc_key_status = gHmiManager.canPdcKey;
  Semaphore_post(gHmiManager.signalsSem);

  if (!pdc_key_status)
    return;

  retVal = PdcManager_getInstance(&pdcManager);

  if (E_OK == retVal)
  {
    PdcManager_updateRearSensors(pdcManager, rear_sensors);
  }
  else
  {
    LOG_PRINT_ERR(DEBUG_HMI, "(%s) [%d]: Cannot update PDC sensors at the moment. Error code: %d\r\n", __FUNCTION__, __LINE__, retVal);
  }
}

void HmiManager_update_transport_mode(bool_t transport_mode_active)
{
  if (!gHmiManager.created)
    return;

  Semaphore_pend(gHmiManager.signalsSem, BIOS_WAIT_FOREVER);
  LOG_PRINT_SVER(DEBUG_HMI, "(%s) [%d]: Setting new Transport Mode state from CAN: %d\r\n", __FUNCTION__, __LINE__, transport_mode_active);
  gHmiManager.canTransportMode = transport_mode_active;
  Semaphore_post(gHmiManager.signalsSem);
}

void HmiManager_update_reflashing_state(bool_t reflashing_state)
{
  if (!gHmiManager.created)
    return;

  Semaphore_pend(gHmiManager.signalsSem, BIOS_WAIT_FOREVER);
  LOG_PRINT_SVER(DEBUG_HMI, "(%s) [%d]: Setting new reflashing state: %d\r\n", __FUNCTION__, __LINE__, reflashing_state);
  gHmiManager.reflashingState = reflashing_state;
  Semaphore_post(gHmiManager.signalsSem);
}

void HmiManager_set_desired_screen_state(bool screen_state)
{
  if (!gHmiManager.created)
    return;

  LOG_PRINT_SVER(DEBUG_HMI, "(%s) [%d]: Setting new screen state state: %d\r\n", __FUNCTION__, __LINE__, screen_state);
  gHmiManager.desiredScreenState = screen_state;
}

void HmiManager_set_car(RendererCar car)
{
  if (!gHmiManager.created)
    return;
  
  LOG_PRINT_INFO(DEBUG_HMI, "(%s) [%d]: Updated car model to = %d\r\n", __FUNCTION__, __LINE__, car);
  gHmiManager.guiNewCar = car;
}

void HmiManager_set_language(Language_en language)
{
  if (!gHmiManager.created)
    return;
  
  if (language != RENDERER_LANGUAGE_INVALID)
  {
    LOG_PRINT_SVER(DEBUG_HMI, "(%s) [%d]: Setting new language: %d\r\n", __FUNCTION__, __LINE__, lanuage);
    gHmiManager.newLanguage = language;
  }
}

void HmiManager_set_switch_on(bool_t switch_on_state)
{
  if (!gHmiManager.created)
    return;
  
  LOG_PRINT_SVER(DEBUG_HMI, "(%s) [%d]: Setting new switch on state: %d\r\n", __FUNCTION__, __LINE__, switch_on_state);
  gHmiManager.newSwitchOn = switch_on_state;
}

bool HmiManager_get_adas_view_on(RendererCar car, bool pdc, bool rvc)
{
  return hmiManager_adasTriggerByParams(car, pdc, rvc);
}
