/******************************************************************************
 *
 * \file    gfx_blender.h
 *
 * \brief   Graphic blender header file
 *
 * \author  Esteban Pupillo
 *
 * \date    17 Sep 2022
 *
 *****************************************************************************/
#ifndef __GFX_BLENDER_H__
#define __GFX_BLENDER_H__

/**
 * @addtogroup GfxBlender
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief GfxBlender abstract data type
 */
typedef struct gfx_blender_type* GfxBlender;

typedef struct gfx_blender_frame_buf_tag {
	UInt32 width;
	/**< frame buffer width in pixels */

	UInt32 height;
	/**< frame buffer height in pixels */
	
	UInt32 bpp;
	/**< frame buffer bytes per pixel */

	UInt32 stride;
	/**< frame buffer stride in bytes */

} GfxBlenderBufferParam;

typedef struct gfx_bitblit_param_tag {
	GfxBlenderBufferParam inFrameParams;
	/**< input frame buffer parameters */

	UInt32 xPos;
	/**< X position in display frame pixels where the bitblit shall start */

	UInt32 yPos;
	/**< Y position in display frame pixels where the bitblit shall start */

	UInt32 width;
	/**< Width in input frame pixels */

	UInt32 height;
	/**< Height in input frame pixels */

} GfxBitblitParams;

/**
 * @brief GfxBlender parameters 
 */
typedef struct gfx_blender_params_tag {
	GfxBlenderBufferParam displayFrameParams;

} GfxBlenderParams;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initializes Graphic Blender parameters
 */
void inline GfxBlenderParams_init(GfxBlenderParams *params)
{
	if (NULL != params)
	{
		memset(params, 0, sizeof(GfxBlenderParams));
	}
}

/**
 * @brief Creates a graphic blender
 *
 * @param gfxBlender pointer to a graphic blender to create
 * @param gfxBlenderParams pointer the graphic blender parameters
 * 
 * @return #E_OK on success
 */
Int32 GfxBlender_create(GfxBlender *gfxBlender, GfxBlenderParams *gfxBlenderParams);

Int32 GfxBlender_bitblit(GfxBlender gfxBlender, Fvid2_Frame *outFrame, Fvid2_Frame *inFrame, GfxBitblitParams *params);


/**
 * Close doxygen group
 * @}
 */

#endif //__GFX_BLENDER_H__
