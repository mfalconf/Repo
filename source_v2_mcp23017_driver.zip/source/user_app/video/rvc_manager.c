/******************************************************************************
 *
 * \file    rvc_manager.c
 *
 * \brief   Rear View Camera manager module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    11 Jun 2022
 *
 *****************************************************************************/
#include <standard.h>
#include "console.h"
#include "rvc_manager.h"
#include <xdc/std.h>
#include "video_processor.h"
#include "gfx_layer.h"
#include "display.h"

#include <ti/drv/vps/include/common/bsp_utilsQue.h>

#include "renderer.h"
#include "video_dma.h"

/**
 * @addtogroup RvcManager
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DEBUG_RVC_MANAGER           0

#define RVC_MANAGER_MAX_CALLBACKS   (4)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

struct rvc_manager_tag {
  bool_t isInitialized;
  bool_t isPlaying;

  Fvid2_CbParams userCbPrms[RVC_MANAGER_MAX_CALLBACKS];
  /**< User callback parameters */

	UInt32 userCbCount;
	/**< Number of registered callbacks */

  VideoProcessor videoProcessor;
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static struct rvc_manager_tag gRvcManager;

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

static Int32 rvcManager_addCallback(RvcManager rvcManager, Fvid2_CbParams cbParams)
{
	/* Check if we have room to add it */
	if (RVC_MANAGER_MAX_CALLBACKS <= rvcManager->userCbCount)
	{
		/* We don't have room to add the new callback */
		return FVID2_EFAIL;
	}

	/* Add new callback */
	rvcManager->userCbPrms[rvcManager->userCbCount] = cbParams;
	rvcManager->userCbCount++;

	return FVID2_SOK;
}

static Int32 rvcManager_removeCallback(RvcManager rvcManager, Fvid2_CbParams cbParams)
{
	UInt32 i;

	if (0 == rvcManager->userCbCount)
	{
		/* We don't have any callback registered; nothing to do here */
		return FVID2_SOK;
	}

	for (i=0; i < rvcManager->userCbCount; i++)
	{
		if (rvcManager->userCbPrms[i].cbFxn == cbParams.cbFxn)
		{
			/* we found a match */
			break;
		}
	}

	/* Check if we found the callback to remove */
	if (i == rvcManager->userCbCount)
	{
		/* we couldn't find the callback; return error */
		return FVID2_EFAIL;
	}

	/* remove callback from array */
	for (; i < rvcManager->userCbCount - 1; i++)
	{
		rvcManager->userCbPrms[i] = rvcManager->userCbPrms[i+1];
	}

	/* update counter */
	rvcManager->userCbCount--;

	return E_OK;
}

static void rvcManager_executeCallbacks(RvcManager rvcManager)
{
	Uint32 i;

	/* Go thru all the registered callbacks*/
	for(i = 0; i < rvcManager->userCbCount; i++)
	{
		/* if we have a valid callback Function then invoke it */
		if (NULL != rvcManager->userCbPrms[i].cbFxn)
		{
			(*rvcManager->userCbPrms[i].cbFxn)(NULL, rvcManager->userCbPrms[i].appData, NULL);
		}
	}
}

static Int32 rvcManager_videoProcessorCallback(Fvid2_Handle handle, Ptr appData, Ptr reserved)
{
  Int32 retVal = FVID2_SOK;
  RvcManager rvcManager = (RvcManager) appData;

  LOG_PRINT_SVER(DEBUG_RVC_MANAGER, "%s()\r\n", __FUNCTION__);

	/* Inform user that we have a new filled frame */
	rvcManager_executeCallbacks(rvcManager);

  return retVal;
}

Int32 RvcManager_init(RvcManager *rvcManager, Fvid2_CbParams callback)
{
  Int32 retVal;
  Fvid2_CbParams videoProcessorCb;
	ResourceGeometry_t backgroundGeometry;
	ResourceGeometry_t alertGeometry;

  LOG_PRINT_INFO(DEBUG_RVC_MANAGER, "%s()\r\n", __FUNCTION__);

  /* Check for input parameter */
  if (NULL == rvcManager) 
    return FVID2_EBADARGS;

  *rvcManager = &gRvcManager;

  /* Initialize internal variables */
  gRvcManager.isInitialized = FALSE;
	gRvcManager.userCbCount = 0;
	memset(&gRvcManager.userCbPrms, 0, sizeof(gRvcManager.userCbPrms));

	/* If we have a valid callback then add it */
	if (NULL != callback.cbFxn)
	{
		rvcManager_addCallback(&gRvcManager, callback);
	}

  /* Init callbacks object */
  Fvid2CbParams_init(&videoProcessorCb);
  videoProcessorCb.cbFxn = &rvcManager_videoProcessorCallback;
  videoProcessorCb.appData = &gRvcManager;

	Renderer_getRvcBackgroundGeometry(&backgroundGeometry);
	Renderer_getRvcAlertBackgroundGeometry(&alertGeometry);

	backgroundGeometry.width = 0;
	backgroundGeometry.height = 0;
	
	alertGeometry.width = 0;
	alertGeometry.height = 0;


  // TODO: AJS refactor the IN dimensions to get them from the video serializer when available
  retVal = VideoProcessor_init(&gRvcManager.videoProcessor,
                               720U,
                               240U,
															 backgroundGeometry.width,
															 alertGeometry.height,
                               videoProcessorCb);

  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_RVC_MANAGER, "%s(): Video processor initialization failed!!\r\n", __FUNCTION__);
    return retVal;
  }

  gRvcManager.isPlaying = FALSE;
  gRvcManager.isInitialized = TRUE;

  return retVal;
}

Int32 RvcManager_getInstance(RvcManager *rvcManager)
{
	Int retVal = FVID2_SOK;

	/* Check input parameters */
	if (NULL == rvcManager)
	{
		return FVID2_EBADARGS;
	}

	/* Check if module is initialized */
	if (!gRvcManager.isInitialized)
	{
		return FVID2_EAGAIN;
	}

	/* return current instance */
	*rvcManager = &gRvcManager;

	return retVal;
}

Int32 RvcManager_queueBuffer(RvcManager rvcManager, Fvid2_FrameList *frameList)
{
  Int32 retVal = FVID2_SOK;

  if ((NULL == rvcManager) || (NULL == frameList))
    return FVID2_EBADARGS;

	if (NULL != frameList->frames[0])
	{
		LOG_PRINT_SVER(DEBUG_RVC_MANAGER, "%s(): queueing buffer\r\n", __FUNCTION__);
  	retVal = VideoProcessor_queueBuffer(rvcManager->videoProcessor, frameList);
	}

  return retVal;
}

Int32 RvcManager_dequeueBuffer(RvcManager rvcManager, Fvid2_FrameList *frameList)
{
  Int32 retVal;

  if ((NULL == rvcManager) || (NULL == frameList))
    return FVID2_EBADARGS;

	retVal = VideoProcessor_dequeueBuffer(rvcManager->videoProcessor, frameList);

	return retVal;
}

Int32 RvcManager_startDiagnostic(RvcManager rvcManager)
{
	Int32 retVal = FVID2_SOK;

	/* Check input arguments */
  if (NULL == rvcManager)
    return FVID2_EBADARGS;

	retVal = VideoProcessor_startDiagnostic(rvcManager->videoProcessor);

	return retVal;
}

Int32 RvcManager_start(RvcManager rvcManager)
{
  Int32 retVal = FVID2_SOK;

  /* Check input arguments */
  if (NULL == rvcManager)
    return FVID2_EBADARGS;

  /* Check if the module is initialized */
  if (!rvcManager->isInitialized)
    return FVID2_EFAIL;

	if (!rvcManager->isPlaying)
	{
  	/* Start video processor */
  	retVal = VideoProcessor_start(rvcManager->videoProcessor);
	}

  /* Update playback state */
  if (FVID2_SOK == retVal)
	{
    rvcManager->isPlaying = TRUE;
	}

  return retVal;
}

Int32 RvcManager_stopDiagnostic(RvcManager rvcManager)
{
	Int32 retVal = FVID2_SOK;

	/* Check input arguments */
  if (NULL == rvcManager)
    return FVID2_EBADARGS;

	retVal = VideoProcessor_stopDiagnostic(rvcManager->videoProcessor);

	return retVal;
}

Int32 RvcManager_stop(RvcManager rvcManager)
{
  Int32 retVal;

  /* Check input arguments */
  if (NULL == rvcManager)
    return FVID2_EBADARGS;

  /* Check if the module is initialized */
  if (!rvcManager->isInitialized)
    return FVID2_EFAIL;

	if (!rvcManager->isPlaying)
		return FVID2_SOK;

  /* Stop video processor */
	retVal = VideoProcessor_stop(rvcManager->videoProcessor);

  /* Update playback state */
  if (FVID2_SOK == retVal)
	{
    rvcManager->isPlaying = FALSE;
	}

  return retVal;
}

Int32 RvcManager_isPlaying(RvcManager rvcManager)
{
  /* Check input arguments */
  if (NULL == rvcManager)
    return FALSE;

  /* Check if the module is initialized */
  if (!rvcManager->isInitialized)
    return FALSE;

  return rvcManager->isPlaying;
}

Int32 RvcManager_registerCallback(RvcManager rvcManager, Fvid2_CbParams callback)
{
	/* Check input parameters */
	if ((NULL == rvcManager) || (NULL == callback.cbFxn))
	{
		return FVID2_EBADARGS;
	}

	return rvcManager_addCallback(rvcManager, callback);
}

Int32 RvcManager_unregisterCallback(RvcManager rvcManager, Fvid2_CbParams callback)
{
	/* Check input parameters */
	if ((NULL == rvcManager) || (NULL == callback.cbFxn))
	{
		return FVID2_EBADARGS;
	}

	return rvcManager_removeCallback(rvcManager, callback);
}

void RvcManager_initGpios(void)
{
	VideoProcessor_initGpios();
}
