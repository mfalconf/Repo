/******************************************************************************
 *
 * \file    video_capture.h
 *
 * \brief   Video Capture module header file
 *
 * \author  Esteban Pupillo
 *
 * \date    11 Jun 2022
 *
 *****************************************************************************/
#ifndef __VIDEO_PROCESSOR_H__
#define __VIDEO_PROCESSOR_H__

/**
 * @addtogroup VideoProcessor
 * @{
 */

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

#include <standard.h>

#include "console.h"

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief VideoProcessor data type
 */
typedef struct video_processor_tag* VideoProcessor;


/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initialize video processor module
 *
 * This function has to be called before any other function of the video
 * processor module API
 * 
 * @note This initialization assumes certain constraints in the layout as it is
 * designed mainly for the VW Amarok/Polo/Saveiro style. This will initialize the
 * processor to put the RVC video feed in the top right section of the display
 *
 * @param videoProcessor pointer to the video processor instance to initialize
 * @param inWidth Input width for the processor
 * @param inHeight Input height for the processor
 * @param videoLeftOffset Left offset for the video
 * @param videoBottomOffset Bottom offset for the video
 * @param callback callback function to receive events from video capture
 * @return #FVID2_SOK on success
 */
Int32 VideoProcessor_init(VideoProcessor *videoProcessor, UInt32 inWidth, UInt32 inHeight, UInt32 videoLeftOffset, UInt32 videoBottomOffset, Fvid2_CbParams callback);

/**
 * @brief Queues frame list to driver
 *
 * @param videoProcessor video processor instance
 * @param frameList list of frames to queue
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 VideoProcessor_queueBuffer(VideoProcessor videoProcessor, Fvid2_FrameList *frameList);

/**
 * @brief Deueues frame list from driver
 *
 * @param videoProcessor video processor instance
 * @param frameList pointer to a list of frames dequeued
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 VideoProcessor_dequeueBuffer(VideoProcessor videoProcessor, Fvid2_FrameList *frameList);

/**
 * @brief Starts video processor diagnostic
 * 
 * @param videoProcessor video processor instance
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 VideoProcessor_startDiagnostic(VideoProcessor videoProcessor);

/**
 * @brief Starts video processor pipeline
 *
 * @param videoProcessor video processor instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 VideoProcessor_start(VideoProcessor videoProcessor);

/**
 * @brief Stops video processor diagnostic
 * 
 * @param videoProcessor video processor instance
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 VideoProcessor_stopDiagnostic(VideoProcessor videoProcessor);

/**
 * @brief Stops video processor pipeline
 *
 * @param videoProcessor video processor instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 VideoProcessor_stop(VideoProcessor videoProcessor);

/** Initialize necessary GPIOs related to the video processor */
void VideoProcessor_initGpios(void);

/**
 * Close doxygen group
 * @}
 */

#endif //__VIDEO_PROCESSOR_H__
