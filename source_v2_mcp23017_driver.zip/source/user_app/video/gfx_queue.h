/******************************************************************************
 *
 * \file    gfx_queue.h
 *
 * \brief   Graphic queue header file
 *
 * \author  Esteban Pupillo
 *
 * \date    13 Sep 2022
 *
 *****************************************************************************/
#ifndef __GFX_QUEUE_H__
#define __GFX_QUEUE_H__

/**
 * @addtogroup GfxQueue
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/** Minimum number of frames that must kept in queue after the first enqueue 
 */
#define GFX_QUEUE_MIN_UNDEQUEUED_FRAMES			(1)

/** Default queue maximum size
 * This value is valid if the maxSize parameter is not specified when
 * creating the queue
 */
#define GFX_QUEUE_DEFAULT_MAX_SIZE          (4)


/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief GfxQueue abstract data type
 */
typedef struct gfx_queue_type* GfxQueue;

typedef struct gfx_queue_params_tag {
	UInt32 maxSize;
	/**< queue maximum size */

	UInt32 frameWidth;
	/**< frame width in pixels */

	UInt32 frameHeight;
	/**< frame height in pixels */

	UInt32 frameBytePerPixel;
	/**< frame bytes per pixel */

	bool_t allocateFrameBuffer;
	/**< flag to control if the graphic queue allocates the corresponding 
	 * frame buffer.
	 * The default value is TRUE 
	 */

} GfxQueueParams;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

void inline GfxQueueParams_init(GfxQueueParams *params)
{
	if (NULL != params)
	{
		params->maxSize = GFX_QUEUE_DEFAULT_MAX_SIZE;
		params->frameWidth = 0;
		params->frameHeight = 0;
		params->frameBytePerPixel = 0;
		params->allocateFrameBuffer = TRUE;
	}
}

/**
 * @brief Creates a graphic queue
 *
 * @param gfxQueue pointer to a graphic queue to create
 * @param gfxQueueParams pointer the graphic queue parameters
 * 
 * @return #E_OK on success
 */
Int32 GfxQueue_create(GfxQueue *gfxQueue, GfxQueueParams *gfxQueueParams);
void GfxQueue_dump(GfxQueue gfxQueue);
Int32 GfxQueue_setEnableState(GfxQueue gfxQueue, bool_t newState);
Int32 GfxQueue_queue(GfxQueue gfxQueue, Fvid2_Frame *frame);
Int32 GfxQueue_dequeue(GfxQueue gfxQueue, Fvid2_Frame **frame);
Int32 GfxQueue_acquire(GfxQueue gfxQueue, Fvid2_Frame **frame);
Int32 GfxQueue_release(GfxQueue gfxQueue, Fvid2_Frame *frame);
Int32 GfxQueue_freeAll(GfxQueue gfxQueue);

/**
 * Close doxygen group
 * @}
 */

#endif //__GFX_QUEUE_H__
