/******************************************************************************
 *
 * \file    9inches_4D_display.h
 *
 * \brief   Display configuration file for the 9 inches 4D display
 *
 * \author  Augusto Santini
 *
 * \date    7 Dic 2022
 *
 *****************************************************************************/
#ifndef _9INCHES_4D_DISPLAY_H__
#define _9INCHES_4D_DISPLAY_H__

/**
 * @addtogroup DisplayConfig4D9 4D 9-Inches Display Configuration
 *
 * This is the display configuration for the 9 inches 4D display
 *
 * @{
 */

#include <ti/drv/vps/include/vps.h>
#include <ti/drv/vps/include/dss/vps_cfgDss.h>
#include <ti/drv/vps/include/vps_display.h>
#include <ti/drv/vps/include/vps_displayCtrl.h>

#include <standard.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/** Display horizontal resolution in pixels */
#define DISPLAY_LCD_WIDTH       1024U

/** Display vertical resolution in pixels */
#define DISPLAY_LCD_HEIGHT      600U

/** Display interface clock frequency in KHz */
// Note that changing this value also affects the time that takes the
// IPU 1 core to correctly set up the display frequency and hence it
// "takes longer" to start the HMI stuff. Empirically, with values that
// end with two zeros (are multiple of 100) the time is the lowest
#define DISPLAY_PIXEL_CLK       55100U // 65 fps

/** Display frame rate in frame per seconds */
#define DISPLAY_FRAME_RATE      65U

/** Display interface timings configuration */
#define DISPLAY_H_FRONT_PORCH   160U

/** Display interface timings configuration */
#define DISPLAY_H_BACK_PORCH    160U

/** Display interface timings configuration */
#define DISPLAY_H_SYNC_LENGTH   1U

/** Display interface timings configuration */
#define DISPLAY_V_FRONT_PORCH   12U

/** Display interface timings configuration */
#define DISPLAY_V_BACK_PORCH    23U

/** Display interface timings configuration */
#define DISPLAY_V_SYNC_LENGTH   1U

/** Display interface scan format
 * 
 * Valid options are: 
 *  FVID2_SF_PROGRESSIVE 
 *  FVID2_SF_INTERLACED
 */
#define DISPLAY_SCAN_FORMAT     FVID2_SF_PROGRESSIVE

/** Display interface configuration
 *
 * Valid options are:
 *   FVID2_VIFM_SCH_ES
 */
#define DISPLAY_MODE            FVID2_VIFM_SCH_DS_HSYNC_VSYNC

/** Display interface pixel clock polarity */
#define DISPLAY_CLK_POLARITY    FVID2_POL_LOW

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/


/** Display gamma table */
static const Vps_DssDispcGammaEntry gGammaEntries[] = {
    { .red = 0,     .green = 0,     .blue = 0,      }, 
    { .red = 139,   .green = 139,   .blue = 139,    }, 
    { .red = 301,   .green = 301,   .blue = 301,    }, 
    { .red = 472,   .green = 472,   .blue = 472,    }, 
    { .red = 650,   .green = 650,   .blue = 650,    }, 
    { .red = 833,   .green = 833,   .blue = 833,    }, 
    { .red = 1020,  .green = 1020,  .blue = 1020,   }, 
    { .red = 1211,  .green = 1211,  .blue = 1211,   }, 
    { .red = 1404,  .green = 1404,  .blue = 1404,   }, 
    { .red = 1601,  .green = 1601,  .blue = 1601,   }, 
    { .red = 1799,  .green = 1799,  .blue = 1799,   }, 
    { .red = 2000,  .green = 2000,  .blue = 2000,   }, 
    { .red = 2203,  .green = 2203,  .blue = 2203,   }, 
    { .red = 2408,  .green = 2408,  .blue = 2408,   }, 
    { .red = 2614,  .green = 2614,  .blue = 2614,   }, 
    { .red = 2822,  .green = 2822,  .blue = 2822,   }, 
    { .red = 3032,  .green = 3032,  .blue = 3032,   }, 
    { .red = 3243,  .green = 3243,  .blue = 3243,   }, 
    { .red = 3455,  .green = 3455,  .blue = 3455,   }, 
    { .red = 3669,  .green = 3669,  .blue = 3669,   }, 
    { .red = 3884,  .green = 3884,  .blue = 3884,   }, 
    { .red = 4100,  .green = 4100,  .blue = 4100,   }, 
    { .red = 4318,  .green = 4318,  .blue = 4318,   }, 
    { .red = 4536,  .green = 4536,  .blue = 4536,   }, 
    { .red = 4756,  .green = 4756,  .blue = 4756,   }, 
    { .red = 4976,  .green = 4976,  .blue = 4976,   }, 
    { .red = 5197,  .green = 5197,  .blue = 5197,   }, 
    { .red = 5420,  .green = 5420,  .blue = 5420,   }, 
    { .red = 5643,  .green = 5643,  .blue = 5643,   }, 
    { .red = 5867,  .green = 5867,  .blue = 5867,   }, 
    { .red = 6092,  .green = 6092,  .blue = 6092,   }, 
    { .red = 6318,  .green = 6318,  .blue = 6318,   }, 
    { .red = 6545,  .green = 6545,  .blue = 6545,   }, 
    { .red = 6772,  .green = 6772,  .blue = 6772,   }, 
    { .red = 7000,  .green = 7000,  .blue = 7000,   }, 
    { .red = 7229,  .green = 7229,  .blue = 7229,   }, 
    { .red = 7459,  .green = 7459,  .blue = 7459,   }, 
    { .red = 7689,  .green = 7689,  .blue = 7689,   }, 
    { .red = 7920,  .green = 7920,  .blue = 7920,   }, 
    { .red = 8152,  .green = 8152,  .blue = 8152,   }, 
    { .red = 8384,  .green = 8384,  .blue = 8384,   }, 
    { .red = 8617,  .green = 8617,  .blue = 8617,   }, 
    { .red = 8851,  .green = 8851,  .blue = 8851,   }, 
    { .red = 9085,  .green = 9085,  .blue = 9085,   }, 
    { .red = 9320,  .green = 9320,  .blue = 9320,   }, 
    { .red = 9556,  .green = 9556,  .blue = 9556,   }, 
    { .red = 9792,  .green = 9792,  .blue = 9792,   }, 
    { .red = 10028, .green = 10028, .blue = 10028,  }, 
    { .red = 10265, .green = 10265, .blue = 10265,  }, 
    { .red = 10503, .green = 10503, .blue = 10503,  }, 
    { .red = 10741, .green = 10741, .blue = 10741,  }, 
    { .red = 10980, .green = 10980, .blue = 10980,  }, 
    { .red = 11219, .green = 11219, .blue = 11219,  }, 
    { .red = 11459, .green = 11459, .blue = 11459,  }, 
    { .red = 11699, .green = 11699, .blue = 11699,  }, 
    { .red = 11940, .green = 11940, .blue = 11940,  }, 
    { .red = 12181, .green = 12181, .blue = 12181,  }, 
    { .red = 12423, .green = 12423, .blue = 12423,  }, 
    { .red = 12665, .green = 12665, .blue = 12665,  }, 
    { .red = 12908, .green = 12908, .blue = 12908,  }, 
    { .red = 13151, .green = 13151, .blue = 13151,  }, 
    { .red = 13394, .green = 13394, .blue = 13394,  }, 
    { .red = 13638, .green = 13638, .blue = 13638,  }, 
    { .red = 13882, .green = 13882, .blue = 13882,  }, 
    { .red = 14127, .green = 14127, .blue = 14127,  }, 
    { .red = 14373, .green = 14373, .blue = 14373,  }, 
    { .red = 14618, .green = 14618, .blue = 14618,  }, 
    { .red = 14864, .green = 14864, .blue = 14864,  }, 
    { .red = 15111, .green = 15111, .blue = 15111,  }, 
    { .red = 15358, .green = 15358, .blue = 15358,  }, 
    { .red = 15605, .green = 15605, .blue = 15605,  }, 
    { .red = 15852, .green = 15852, .blue = 15852,  }, 
    { .red = 16100, .green = 16100, .blue = 16100,  }, 
    { .red = 16349, .green = 16349, .blue = 16349,  }, 
    { .red = 16598, .green = 16598, .blue = 16598,  }, 
    { .red = 16847, .green = 16847, .blue = 16847,  }, 
    { .red = 17096, .green = 17096, .blue = 17096,  }, 
    { .red = 17346, .green = 17346, .blue = 17346,  }, 
    { .red = 17597, .green = 17597, .blue = 17597,  }, 
    { .red = 17847, .green = 17847, .blue = 17847,  }, 
    { .red = 18098, .green = 18098, .blue = 18098,  }, 
    { .red = 18349, .green = 18349, .blue = 18349,  }, 
    { .red = 18601, .green = 18601, .blue = 18601,  }, 
    { .red = 18853, .green = 18853, .blue = 18853,  }, 
    { .red = 19105, .green = 19105, .blue = 19105,  }, 
    { .red = 19358, .green = 19358, .blue = 19358,  }, 
    { .red = 19611, .green = 19611, .blue = 19611,  }, 
    { .red = 19864, .green = 19864, .blue = 19864,  }, 
    { .red = 20118, .green = 20118, .blue = 20118,  }, 
    { .red = 20372, .green = 20372, .blue = 20372,  }, 
    { .red = 20626, .green = 20626, .blue = 20626,  }, 
    { .red = 20880, .green = 20880, .blue = 20880,  }, 
    { .red = 21135, .green = 21135, .blue = 21135,  }, 
    { .red = 21390, .green = 21390, .blue = 21390,  }, 
    { .red = 21646, .green = 21646, .blue = 21646,  }, 
    { .red = 21902, .green = 21902, .blue = 21902,  }, 
    { .red = 22158, .green = 22158, .blue = 22158,  }, 
    { .red = 22414, .green = 22414, .blue = 22414,  }, 
    { .red = 22671, .green = 22671, .blue = 22671,  }, 
    { .red = 22928, .green = 22928, .blue = 22928,  }, 
    { .red = 23185, .green = 23185, .blue = 23185,  }, 
    { .red = 23442, .green = 23442, .blue = 23442,  }, 
    { .red = 23700, .green = 23700, .blue = 23700,  }, 
    { .red = 23958, .green = 23958, .blue = 23958,  }, 
    { .red = 24217, .green = 24217, .blue = 24217,  }, 
    { .red = 24475, .green = 24475, .blue = 24475,  }, 
    { .red = 24734, .green = 24734, .blue = 24734,  }, 
    { .red = 24993, .green = 24993, .blue = 24993,  }, 
    { .red = 25253, .green = 25253, .blue = 25253,  }, 
    { .red = 25512, .green = 25512, .blue = 25512,  }, 
    { .red = 25772, .green = 25772, .blue = 25772,  }, 
    { .red = 26032, .green = 26032, .blue = 26032,  }, 
    { .red = 26293, .green = 26293, .blue = 26293,  }, 
    { .red = 26554, .green = 26554, .blue = 26554,  }, 
    { .red = 26815, .green = 26815, .blue = 26815,  }, 
    { .red = 27076, .green = 27076, .blue = 27076,  }, 
    { .red = 27337, .green = 27337, .blue = 27337,  }, 
    { .red = 27599, .green = 27599, .blue = 27599,  }, 
    { .red = 27861, .green = 27861, .blue = 27861,  }, 
    { .red = 28123, .green = 28123, .blue = 28123,  }, 
    { .red = 28386, .green = 28386, .blue = 28386,  }, 
    { .red = 28648, .green = 28648, .blue = 28648,  }, 
    { .red = 28911, .green = 28911, .blue = 28911,  }, 
    { .red = 29174, .green = 29174, .blue = 29174,  }, 
    { .red = 29438, .green = 29438, .blue = 29438,  }, 
    { .red = 29701, .green = 29701, .blue = 29701,  }, 
    { .red = 29965, .green = 29965, .blue = 29965,  }, 
    { .red = 30229, .green = 30229, .blue = 30229,  }, 
    { .red = 30494, .green = 30494, .blue = 30494,  }, 
    { .red = 30758, .green = 30758, .blue = 30758,  }, 
    { .red = 31023, .green = 31023, .blue = 31023,  }, 
    { .red = 31288, .green = 31288, .blue = 31288,  }, 
    { .red = 31553, .green = 31553, .blue = 31553,  }, 
    { .red = 31819, .green = 31819, .blue = 31819,  }, 
    { .red = 32084, .green = 32084, .blue = 32084,  }, 
    { .red = 32350, .green = 32350, .blue = 32350,  }, 
    { .red = 32616, .green = 32616, .blue = 32616,  }, 
    { .red = 32883, .green = 32883, .blue = 32883,  }, 
    { .red = 33149, .green = 33149, .blue = 33149,  }, 
    { .red = 33416, .green = 33416, .blue = 33416,  }, 
    { .red = 33683, .green = 33683, .blue = 33683,  }, 
    { .red = 33950, .green = 33950, .blue = 33950,  }, 
    { .red = 34217, .green = 34217, .blue = 34217,  }, 
    { .red = 34485, .green = 34485, .blue = 34485,  }, 
    { .red = 34753, .green = 34753, .blue = 34753,  }, 
    { .red = 35021, .green = 35021, .blue = 35021,  }, 
    { .red = 35289, .green = 35289, .blue = 35289,  }, 
    { .red = 35557, .green = 35557, .blue = 35557,  }, 
    { .red = 35826, .green = 35826, .blue = 35826,  }, 
    { .red = 36095, .green = 36095, .blue = 36095,  }, 
    { .red = 36364, .green = 36364, .blue = 36364,  }, 
    { .red = 36633, .green = 36633, .blue = 36633,  }, 
    { .red = 36902, .green = 36902, .blue = 36902,  }, 
    { .red = 37172, .green = 37172, .blue = 37172,  }, 
    { .red = 37442, .green = 37442, .blue = 37442,  }, 
    { .red = 37712, .green = 37712, .blue = 37712,  }, 
    { .red = 37982, .green = 37982, .blue = 37982,  }, 
    { .red = 38252, .green = 38252, .blue = 38252,  }, 
    { .red = 38523, .green = 38523, .blue = 38523,  }, 
    { .red = 38793, .green = 38793, .blue = 38793,  }, 
    { .red = 39064, .green = 39064, .blue = 39064,  }, 
    { .red = 39336, .green = 39336, .blue = 39336,  }, 
    { .red = 39607, .green = 39607, .blue = 39607,  }, 
    { .red = 39878, .green = 39878, .blue = 39878,  }, 
    { .red = 40150, .green = 40150, .blue = 40150,  }, 
    { .red = 40422, .green = 40422, .blue = 40422,  }, 
    { .red = 40694, .green = 40694, .blue = 40694,  }, 
    { .red = 40966, .green = 40966, .blue = 40966,  }, 
    { .red = 41238, .green = 41238, .blue = 41238,  }, 
    { .red = 41511, .green = 41511, .blue = 41511,  }, 
    { .red = 41784, .green = 41784, .blue = 41784,  }, 
    { .red = 42057, .green = 42057, .blue = 42057,  }, 
    { .red = 42330, .green = 42330, .blue = 42330,  }, 
    { .red = 42603, .green = 42603, .blue = 42603,  }, 
    { .red = 42876, .green = 42876, .blue = 42876,  }, 
    { .red = 43150, .green = 43150, .blue = 43150,  }, 
    { .red = 43424, .green = 43424, .blue = 43424,  }, 
    { .red = 43698, .green = 43698, .blue = 43698,  }, 
    { .red = 43972, .green = 43972, .blue = 43972,  }, 
    { .red = 44246, .green = 44246, .blue = 44246,  }, 
    { .red = 44521, .green = 44521, .blue = 44521,  }, 
    { .red = 44795, .green = 44795, .blue = 44795,  }, 
    { .red = 45070, .green = 45070, .blue = 45070,  }, 
    { .red = 45345, .green = 45345, .blue = 45345,  }, 
    { .red = 45620, .green = 45620, .blue = 45620,  }, 
    { .red = 45895, .green = 45895, .blue = 45895,  }, 
    { .red = 46171, .green = 46171, .blue = 46171,  }, 
    { .red = 46447, .green = 46447, .blue = 46447,  }, 
    { .red = 46722, .green = 46722, .blue = 46722,  }, 
    { .red = 46998, .green = 46998, .blue = 46998,  }, 
    { .red = 47274, .green = 47274, .blue = 47274,  }, 
    { .red = 47551, .green = 47551, .blue = 47551,  }, 
    { .red = 47827, .green = 47827, .blue = 47827,  }, 
    { .red = 48104, .green = 48104, .blue = 48104,  }, 
    { .red = 48380, .green = 48380, .blue = 48380,  }, 
    { .red = 48657, .green = 48657, .blue = 48657,  }, 
    { .red = 48934, .green = 48934, .blue = 48934,  }, 
    { .red = 49212, .green = 49212, .blue = 49212,  }, 
    { .red = 49489, .green = 49489, .blue = 49489,  }, 
    { .red = 49766, .green = 49766, .blue = 49766,  }, 
    { .red = 50044, .green = 50044, .blue = 50044,  }, 
    { .red = 50322, .green = 50322, .blue = 50322,  }, 
    { .red = 50600, .green = 50600, .blue = 50600,  }, 
    { .red = 50878, .green = 50878, .blue = 50878,  }, 
    { .red = 51156, .green = 51156, .blue = 51156,  }, 
    { .red = 51435, .green = 51435, .blue = 51435,  }, 
    { .red = 51713, .green = 51713, .blue = 51713,  }, 
    { .red = 51992, .green = 51992, .blue = 51992,  }, 
    { .red = 52271, .green = 52271, .blue = 52271,  }, 
    { .red = 52550, .green = 52550, .blue = 52550,  }, 
    { .red = 52829, .green = 52829, .blue = 52829,  }, 
    { .red = 53108, .green = 53108, .blue = 53108,  }, 
    { .red = 53388, .green = 53388, .blue = 53388,  }, 
    { .red = 53667, .green = 53667, .blue = 53667,  }, 
    { .red = 53947, .green = 53947, .blue = 53947,  }, 
    { .red = 54227, .green = 54227, .blue = 54227,  }, 
    { .red = 54507, .green = 54507, .blue = 54507,  }, 
    { .red = 54787, .green = 54787, .blue = 54787,  }, 
    { .red = 55068, .green = 55068, .blue = 55068,  }, 
    { .red = 55348, .green = 55348, .blue = 55348,  }, 
    { .red = 55629, .green = 55629, .blue = 55629,  }, 
    { .red = 55909, .green = 55909, .blue = 55909,  }, 
    { .red = 56190, .green = 56190, .blue = 56190,  }, 
    { .red = 56471, .green = 56471, .blue = 56471,  }, 
    { .red = 56753, .green = 56753, .blue = 56753,  }, 
    { .red = 57034, .green = 57034, .blue = 57034,  }, 
    { .red = 57315, .green = 57315, .blue = 57315,  }, 
    { .red = 57597, .green = 57597, .blue = 57597,  }, 
    { .red = 57879, .green = 57879, .blue = 57879,  }, 
    { .red = 58160, .green = 58160, .blue = 58160,  }, 
    { .red = 58442, .green = 58442, .blue = 58442,  }, 
    { .red = 58725, .green = 58725, .blue = 58725,  }, 
    { .red = 59007, .green = 59007, .blue = 59007,  }, 
    { .red = 59289, .green = 59289, .blue = 59289,  }, 
    { .red = 59572, .green = 59572, .blue = 59572,  }, 
    { .red = 59854, .green = 59854, .blue = 59854,  }, 
    { .red = 60137, .green = 60137, .blue = 60137,  }, 
    { .red = 60420, .green = 60420, .blue = 60420,  }, 
    { .red = 60703, .green = 60703, .blue = 60703,  }, 
    { .red = 60986, .green = 60986, .blue = 60986,  }, 
    { .red = 61270, .green = 61270, .blue = 61270,  }, 
    { .red = 61553, .green = 61553, .blue = 61553,  }, 
    { .red = 61837, .green = 61837, .blue = 61837,  }, 
    { .red = 62120, .green = 62120, .blue = 62120,  }, 
    { .red = 62404, .green = 62404, .blue = 62404,  }, 
    { .red = 62688, .green = 62688, .blue = 62688,  }, 
    { .red = 62972, .green = 62972, .blue = 62972,  }, 
    { .red = 63256, .green = 63256, .blue = 63256,  }, 
    { .red = 63541, .green = 63541, .blue = 63541,  }, 
    { .red = 63825, .green = 63825, .blue = 63825,  }, 
    { .red = 64110, .green = 64110, .blue = 64110,  }, 
    { .red = 64394, .green = 64394, .blue = 64394,  }, 
    { .red = 64679, .green = 64679, .blue = 64679,  }, 
    { .red = 64964, .green = 64964, .blue = 64964,  }, 
    { .red = 65249, .green = 65249, .blue = 65249,  },
    { .red = 65535, .green = 65535, .blue = 65535,  }, 
};

/**
 * Close doxygen group
 * @}
 */

#endif /* _7INCHES4D_DISPLAY_H__ */
