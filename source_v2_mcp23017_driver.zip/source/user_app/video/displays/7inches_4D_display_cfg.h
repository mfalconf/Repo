/******************************************************************************
 *
 * \file    7inches_4D_display.h
 *
 * \brief   Display configuration file for the 7 inches 4D display
 *
 * \author  Esteban Pupillo
 *
 * \date    27 Jun 2022
 *
 *****************************************************************************/
#ifndef _7INCHES_4D_DISPLAY_H__
#define _7INCHES_4D_DISPLAY_H__

/**
 * @addtogroup DisplayConfig4D7 4D 7-Inches Display Configuration
 *
 * This is the display configuration for the 7 inches 4D display
 *
 * @{
 */

#include <ti/drv/vps/include/vps.h>
#include <ti/drv/vps/include/dss/vps_cfgDss.h>
#include <ti/drv/vps/include/vps_display.h>
#include <ti/drv/vps/include/vps_displayCtrl.h>

#include <standard.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/** Display horizontal resolution in pixels */
#define DISPLAY_LCD_WIDTH       800U

/** Display vertical resolution in pixels */
#define DISPLAY_LCD_HEIGHT      480U

/** Display interface clock frequency in KHz */
#define DISPLAY_PIXEL_CLK       29250U

/** Display frame rate in frame per seconds */
#define DISPLAY_FRAME_RATE      60U

/** Display interface timings configuration */
#define DISPLAY_H_FRONT_PORCH   40U

/** Display interface timings configuration */
#define DISPLAY_H_BACK_PORCH    40U

/** Display interface timings configuration */
#define DISPLAY_H_SYNC_LENGTH   48U

/** Display interface timings configuration */
#define DISPLAY_V_FRONT_PORCH   13U

/** Display interface timings configuration */
#define DISPLAY_V_BACK_PORCH    31U

/** Display interface timings configuration */
#define DISPLAY_V_SYNC_LENGTH   1U

/** Display interface scan format
 * 
 * Valid options are: 
 *  FVID2_SF_PROGRESSIVE 
 *  FVID2_SF_INTERLACED
 */
#define DISPLAY_SCAN_FORMAT     FVID2_SF_PROGRESSIVE

/** Display interface configuration
 *
 * Valid options are:
 *   FVID2_VIFM_SCH_ES
 */
#define DISPLAY_MODE            FVID2_VIFM_SCH_DS_HSYNC_VSYNC

/** Display interface pixel clock polarity */
#define DISPLAY_CLK_POLARITY    FVID2_POL_LOW

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/


/** Display gamma table */
static const Vps_DssDispcGammaEntry gGammaEntries[] = {
    { .red = 0, .green = 0, .blue = 0, },
    { .red = 21, .green = 21, .blue = 4, },
    { .red = 58, .green = 58, .blue = 14, },
    { .red = 104, .green = 104, .blue = 28, },
    { .red = 158, .green = 158, .blue = 47, },
    { .red = 219, .green = 219, .blue = 70, },
    { .red = 285, .green = 285, .blue = 96, },
    { .red = 356, .green = 356, .blue = 125, },
    { .red = 432, .green = 432, .blue = 158, },
    { .red = 513, .green = 513, .blue = 194, },
    { .red = 598, .green = 598, .blue = 233, },
    { .red = 687, .green = 687, .blue = 276, },
    { .red = 779, .green = 779, .blue = 321, },
    { .red = 875, .green = 875, .blue = 369, },
    { .red = 974, .green = 974, .blue = 420, },
    { .red = 1077, .green = 1077, .blue = 473, },
    { .red = 1182, .green = 1182, .blue = 529, },
    { .red = 1291, .green = 1291, .blue = 588, },
    { .red = 1403, .green = 1403, .blue = 650, },
    { .red = 1517, .green = 1517, .blue = 714, },
    { .red = 1634, .green = 1634, .blue = 781, },
    { .red = 1754, .green = 1754, .blue = 850, },
    { .red = 1877, .green = 1877, .blue = 922, },
    { .red = 2002, .green = 2002, .blue = 996, },
    { .red = 2129, .green = 2129, .blue = 1073, },
    { .red = 2259, .green = 2259, .blue = 1152, },
    { .red = 2391, .green = 2391, .blue = 1233, },
    { .red = 2526, .green = 2526, .blue = 1317, },
    { .red = 2662, .green = 2662, .blue = 1403, },
    { .red = 2801, .green = 2801, .blue = 1491, },
    { .red = 2943, .green = 2943, .blue = 1582, },
    { .red = 3086, .green = 3086, .blue = 1675, },
    { .red = 3231, .green = 3231, .blue = 1770, },
    { .red = 3379, .green = 3379, .blue = 1867, },
    { .red = 3528, .green = 3528, .blue = 1967, },
    { .red = 3680, .green = 3680, .blue = 2069, },
    { .red = 3833, .green = 3833, .blue = 2173, },
    { .red = 3989, .green = 3989, .blue = 2279, },
    { .red = 4146, .green = 4146, .blue = 2387, },
    { .red = 4305, .green = 4305, .blue = 2497, },
    { .red = 4466, .green = 4466, .blue = 2610, },
    { .red = 4629, .green = 4629, .blue = 2724, },
    { .red = 4794, .green = 4794, .blue = 2841, },
    { .red = 4960, .green = 4960, .blue = 2960, },
    { .red = 5128, .green = 5128, .blue = 3081, },
    { .red = 5298, .green = 5298, .blue = 3203, },
    { .red = 5470, .green = 5470, .blue = 3328, },
    { .red = 5643, .green = 5643, .blue = 3455, },
    { .red = 5818, .green = 5818, .blue = 3584, },
    { .red = 5994, .green = 5994, .blue = 3715, },
    { .red = 6173, .green = 6173, .blue = 3848, },
    { .red = 6352, .green = 6352, .blue = 3983, },
    { .red = 6534, .green = 6534, .blue = 4120, },
    { .red = 6717, .green = 6717, .blue = 4259, },
    { .red = 6901, .green = 6901, .blue = 4400, },
    { .red = 7087, .green = 7087, .blue = 4542, },
    { .red = 7275, .green = 7275, .blue = 4687, },
    { .red = 7464, .green = 7464, .blue = 4834, },
    { .red = 7655, .green = 7655, .blue = 4982, },
    { .red = 7847, .green = 7847, .blue = 5133, },
    { .red = 8040, .green = 8040, .blue = 5285, },
    { .red = 8236, .green = 8236, .blue = 5439, },
    { .red = 8432, .green = 8432, .blue = 5595, },
    { .red = 8630, .green = 8630, .blue = 5753, },
    { .red = 8829, .green = 8829, .blue = 5913, },
    { .red = 9030, .green = 9030, .blue = 6075, },
    { .red = 9232, .green = 9232, .blue = 6238, },
    { .red = 9436, .green = 9436, .blue = 6404, },
    { .red = 9641, .green = 9641, .blue = 6571, },
    { .red = 9847, .green = 9847, .blue = 6740, },
    { .red = 10055, .green = 10055, .blue = 6911, },
    { .red = 10263, .green = 10263, .blue = 7084, },
    { .red = 10474, .green = 10474, .blue = 7258, },
    { .red = 10685, .green = 10685, .blue = 7434, },
    { .red = 10898, .green = 10898, .blue = 7613, },
    { .red = 11112, .green = 11112, .blue = 7792, },
    { .red = 11328, .green = 11328, .blue = 7974, },
    { .red = 11545, .green = 11545, .blue = 8158, },
    { .red = 11763, .green = 11763, .blue = 8343, },
    { .red = 11982, .green = 11982, .blue = 8530, },
    { .red = 12203, .green = 12203, .blue = 8719, },
    { .red = 12424, .green = 12424, .blue = 8909, },
    { .red = 12647, .green = 12647, .blue = 9101, },
    { .red = 12872, .green = 12872, .blue = 9295, },
    { .red = 13097, .green = 13097, .blue = 9491, },
    { .red = 13324, .green = 13324, .blue = 9689, },
    { .red = 13552, .green = 13552, .blue = 9888, },
    { .red = 13781, .green = 13781, .blue = 10089, },
    { .red = 14011, .green = 14011, .blue = 10291, },
    { .red = 14243, .green = 14243, .blue = 10496, },
    { .red = 14475, .green = 14475, .blue = 10702, },
    { .red = 14709, .green = 14709, .blue = 10910, },
    { .red = 14944, .green = 14944, .blue = 11119, },
    { .red = 15180, .green = 15180, .blue = 11330, },
    { .red = 15417, .green = 15417, .blue = 11543, },
    { .red = 15656, .green = 15656, .blue = 11757, },
    { .red = 15895, .green = 15895, .blue = 11974, },
    { .red = 16136, .green = 16136, .blue = 12192, },
    { .red = 16378, .green = 16378, .blue = 12411, },
    { .red = 16621, .green = 16621, .blue = 12632, },
    { .red = 16865, .green = 16865, .blue = 12855, },
    { .red = 17110, .green = 17110, .blue = 13080, },
    { .red = 17356, .green = 17356, .blue = 13306, },
    { .red = 17603, .green = 17603, .blue = 13534, },
    { .red = 17852, .green = 17852, .blue = 13763, },
    { .red = 18101, .green = 18101, .blue = 13994, },
    { .red = 18352, .green = 18352, .blue = 14227, },
    { .red = 18603, .green = 18603, .blue = 14461, },
    { .red = 18856, .green = 18856, .blue = 14697, },
    { .red = 19109, .green = 19109, .blue = 14935, },
    { .red = 19364, .green = 19364, .blue = 15174, },
    { .red = 19620, .green = 19620, .blue = 15415, },
    { .red = 19877, .green = 19877, .blue = 15657, },
    { .red = 20135, .green = 20135, .blue = 15901, },
    { .red = 20393, .green = 20393, .blue = 16147, },
    { .red = 20653, .green = 20653, .blue = 16394, },
    { .red = 20914, .green = 20914, .blue = 16643, },
    { .red = 21176, .green = 21176, .blue = 16894, },
    { .red = 21439, .green = 21439, .blue = 17146, },
    { .red = 21703, .green = 21703, .blue = 17399, },
    { .red = 21968, .green = 21968, .blue = 17655, },
    { .red = 22234, .green = 22234, .blue = 17911, },
    { .red = 22501, .green = 22501, .blue = 18170, },
    { .red = 22769, .green = 22769, .blue = 18430, },
    { .red = 23038, .green = 23038, .blue = 18691, },
    { .red = 23308, .green = 23308, .blue = 18954, },
    { .red = 23579, .green = 23579, .blue = 19219, },
    { .red = 23850, .green = 23850, .blue = 19485, },
    { .red = 24123, .green = 24123, .blue = 19753, },
    { .red = 24397, .green = 24397, .blue = 20022, },
    { .red = 24672, .green = 24672, .blue = 20293, },
    { .red = 24947, .green = 24947, .blue = 20565, },
    { .red = 25224, .green = 25224, .blue = 20839, },
    { .red = 25502, .green = 25502, .blue = 21115, },
    { .red = 25780, .green = 25780, .blue = 21392, },
    { .red = 26059, .green = 26059, .blue = 21670, },
    { .red = 26340, .green = 26340, .blue = 21950, },
    { .red = 26621, .green = 26621, .blue = 22232, },
    { .red = 26903, .green = 26903, .blue = 22515, },
    { .red = 27187, .green = 27187, .blue = 22800, },
    { .red = 27471, .green = 27471, .blue = 23086, },
    { .red = 27756, .green = 27756, .blue = 23374, },
    { .red = 28041, .green = 28041, .blue = 23663, },
    { .red = 28328, .green = 28328, .blue = 23954, },
    { .red = 28616, .green = 28616, .blue = 24246, },
    { .red = 28905, .green = 28905, .blue = 24539, },
    { .red = 29194, .green = 29194, .blue = 24835, },
    { .red = 29484, .green = 29484, .blue = 25131, },
    { .red = 29776, .green = 29776, .blue = 25430, },
    { .red = 30068, .green = 30068, .blue = 25729, },
    { .red = 30361, .green = 30361, .blue = 26031, },
    { .red = 30655, .green = 30655, .blue = 26333, },
    { .red = 30950, .green = 30950, .blue = 26637, },
    { .red = 31245, .green = 31245, .blue = 26943, },
    { .red = 31542, .green = 31542, .blue = 27250, },
    { .red = 31839, .green = 31839, .blue = 27559, },
    { .red = 32138, .green = 32138, .blue = 27869, },
    { .red = 32437, .green = 32437, .blue = 28181, },
    { .red = 32737, .green = 32737, .blue = 28494, },
    { .red = 33038, .green = 33038, .blue = 28808, },
    { .red = 33339, .green = 33339, .blue = 29124, },
    { .red = 33642, .green = 33642, .blue = 29442, },
    { .red = 33945, .green = 33945, .blue = 29761, },
    { .red = 34250, .green = 34250, .blue = 30081, },
    { .red = 34555, .green = 34555, .blue = 30403, },
    { .red = 34861, .green = 34861, .blue = 30726, },
    { .red = 35167, .green = 35167, .blue = 31051, },
    { .red = 35475, .green = 35475, .blue = 31377, },
    { .red = 35783, .green = 35783, .blue = 31705, },
    { .red = 36093, .green = 36093, .blue = 32034, },
    { .red = 36403, .green = 36403, .blue = 32364, },
    { .red = 36714, .green = 36714, .blue = 32696, },
    { .red = 37025, .green = 37025, .blue = 33030, },
    { .red = 37338, .green = 37338, .blue = 33365, },
    { .red = 37651, .green = 37651, .blue = 33701, },
    { .red = 37966, .green = 37966, .blue = 34039, },
    { .red = 38281, .green = 38281, .blue = 34378, },
    { .red = 38596, .green = 38596, .blue = 34718, },
    { .red = 38913, .green = 38913, .blue = 35060, },
    { .red = 39230, .green = 39230, .blue = 35404, },
    { .red = 39548, .green = 39548, .blue = 35749, },
    { .red = 39867, .green = 39867, .blue = 36095, },
    { .red = 40187, .green = 40187, .blue = 36443, },
    { .red = 40508, .green = 40508, .blue = 36792, },
    { .red = 40829, .green = 40829, .blue = 37142, },
    { .red = 41151, .green = 41151, .blue = 37494, },
    { .red = 41474, .green = 41474, .blue = 37848, },
    { .red = 41798, .green = 41798, .blue = 38203, },
    { .red = 42122, .green = 42122, .blue = 38559, },
    { .red = 42448, .green = 42448, .blue = 38916, },
    { .red = 42774, .green = 42774, .blue = 39275, },
    { .red = 43101, .green = 43101, .blue = 39636, },
    { .red = 43428, .green = 43428, .blue = 39997, },
    { .red = 43757, .green = 43757, .blue = 40361, },
    { .red = 44086, .green = 44086, .blue = 40725, },
    { .red = 44416, .green = 44416, .blue = 41091, },
    { .red = 44746, .green = 44746, .blue = 41459, },
    { .red = 45078, .green = 45078, .blue = 41827, },
    { .red = 45410, .green = 45410, .blue = 42197, },
    { .red = 45743, .green = 45743, .blue = 42569, },
    { .red = 46076, .green = 46076, .blue = 42942, },
    { .red = 46411, .green = 46411, .blue = 43316, },
    { .red = 46746, .green = 46746, .blue = 43692, },
    { .red = 47082, .green = 47082, .blue = 44069, },
    { .red = 47419, .green = 47419, .blue = 44447, },
    { .red = 47756, .green = 47756, .blue = 44827, },
    { .red = 48094, .green = 48094, .blue = 45208, },
    { .red = 48433, .green = 48433, .blue = 45591, },
    { .red = 48773, .green = 48773, .blue = 45975, },
    { .red = 49113, .green = 49113, .blue = 46360, },
    { .red = 49454, .green = 49454, .blue = 46747, },
    { .red = 49796, .green = 49796, .blue = 47135, },
    { .red = 50139, .green = 50139, .blue = 47524, },
    { .red = 50482, .green = 50482, .blue = 47915, },
    { .red = 50826, .green = 50826, .blue = 48307, },
    { .red = 51171, .green = 51171, .blue = 48700, },
    { .red = 51516, .green = 51516, .blue = 49095, },
    { .red = 51862, .green = 51862, .blue = 49491, },
    { .red = 52209, .green = 52209, .blue = 49889, },
    { .red = 52557, .green = 52557, .blue = 50288, },
    { .red = 52905, .green = 52905, .blue = 50688, },
    { .red = 53254, .green = 53254, .blue = 51090, },
    { .red = 53604, .green = 53604, .blue = 51492, },
    { .red = 53955, .green = 53955, .blue = 51897, },
    { .red = 54306, .green = 54306, .blue = 52302, },
    { .red = 54658, .green = 54658, .blue = 52709, },
    { .red = 55010, .green = 55010, .blue = 53118, },
    { .red = 55364, .green = 55364, .blue = 53527, },
    { .red = 55718, .green = 55718, .blue = 53938, },
    { .red = 56072, .green = 56072, .blue = 54350, },
    { .red = 56428, .green = 56428, .blue = 54764, },
    { .red = 56784, .green = 56784, .blue = 55179, },
    { .red = 57140, .green = 57140, .blue = 55595, },
    { .red = 57498, .green = 57498, .blue = 56013, },
    { .red = 57856, .green = 57856, .blue = 56432, },
    { .red = 58215, .green = 58215, .blue = 56852, },
    { .red = 58575, .green = 58575, .blue = 57274, },
    { .red = 58935, .green = 58935, .blue = 57697, },
    { .red = 59296, .green = 59296, .blue = 58121, },
    { .red = 59657, .green = 59657, .blue = 58547, },
    { .red = 60020, .green = 60020, .blue = 58974, },
    { .red = 60383, .green = 60383, .blue = 59402, },
    { .red = 60746, .green = 60746, .blue = 59831, },
    { .red = 61110, .green = 61110, .blue = 60262, },
    { .red = 61475, .green = 61475, .blue = 60694, },
    { .red = 61841, .green = 61841, .blue = 61128, },
    { .red = 62207, .green = 62207, .blue = 61563, },
    { .red = 62574, .green = 62574, .blue = 61999, },
    { .red = 62942, .green = 62942, .blue = 62436, },
    { .red = 63310, .green = 63310, .blue = 62875, },
    { .red = 63680, .green = 63680, .blue = 63315, },
    { .red = 64049, .green = 64049, .blue = 63756, },
    { .red = 64420, .green = 64420, .blue = 64199, },
    { .red = 64791, .green = 64791, .blue = 64643, },
    { .red = 65162, .green = 65162, .blue = 65088, },
    { .red = 65535, .green = 65535, .blue = 65535, },
};

/**
 * Close doxygen group
 * @}
 */

#endif /* _7INCHES4D_DISPLAY_H__ */
