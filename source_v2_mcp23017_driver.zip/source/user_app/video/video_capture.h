/******************************************************************************
 *
 * \file    video_capture.h
 *
 * \brief   Video Capture module header file
 *
 * \author  Esteban Pupillo
 *
 * \date    11 Jun 2022
 *
 *****************************************************************************/
#ifndef __VIDEO_CAPTURE_H__
#define __VIDEO_CAPTURE_H__

/**
 * @addtogroup VideoCapture
 * @{
 */

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>
#include <ti/drv/vps/include/dss/vps_cfgDss.h>
#include <ti/drv/vps/include/vps_display.h>
#include <ti/drv/vps/include/vps_displayCtrl.h>
#include <ti/drv/vps/include/vps_capture.h>

#include <standard.h>
#include "console.h"

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief VideoCapture data type
 */
typedef struct video_capture_tag* VideoCapture;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initialize video capture module
 *
 * This function has to be called before any other function of the video
 * capture module API
 *
 * @param videoCapture pointer to the video capture instance to initialize
 * @param instId instance id to initialize
 * @param inWidth Width input size
 * @param inHeight Height input size
 * @param callback callback function to receive events from video capture
 * @return #FVID2_SOK on success
 */
Int32 VideoCapture_init(VideoCapture *videoCapture, UInt32 instId, UInt32 inWidth, UInt32 inHeight, Fvid2_CbParams callback);

/**
 * @brief Queues frame list to driver
 *
 * @param videoCapture video capture instance
 * @param frameList list of frames to queue
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 VideoCapture_queueBuffer(VideoCapture videoCapture, Fvid2_FrameList *frameList);

/**
 * @brief Deueues frame list from driver
 *
 * @param videoCapture video capture instance
 * @param frameList pointer to a list of frames dequeued
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 VideoCapture_dequeueBuffer(VideoCapture videoCapture, Fvid2_FrameList *frameList);

/**
 * @brief Starts video capture camera diagnostic
 * 
 * @param videoCapture video capture instance
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 VideoCapture_startDiagnostic(VideoCapture videoCapture);

/**
 * @brief Starts capturing frames
 *
 * @param videoCapture video capture instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 VideoCapture_start(VideoCapture videoCapture);

/**
 * @brief Stops video capture camera diagnostic
 * 
 * @param videoCapture video capture instance
 * @return Int32 #FVID2_SOK on success, error code otherwise
 */
Int32 VideoCapture_stopDiagnostic(VideoCapture videoCapture);

/**
 * @brief Starts capturing frames
 *
 * @param videoCapture video capture instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 VideoCapture_stop(VideoCapture videoCapture);

/**
 * @brief Dumps video capture module statistics
 *
 * This function will print the video capture statistics to the standard 
 * console configured on the system
 *
 * @param videoCapture Video capture instance
 */
Int32 VideoCapture_dumpStats(VideoCapture videoCapture);

/**
 * @brief Check if the camera status is ok
 * 
 * @param ok[out] Pointer where the result of the diagnostic will be stored
 * @note If the return value is @a false, then the passed pointer as argument
 * is left unmodified and has no usefull meaning
 * @return int There are three possible cases. If the pointer passed is invalid,
 * then @a E_ERROR is returned. If the diagnostic was not yet performed, then
 * @a E_INVALID_CONDITION is returned. In both of this cases, the value pointed
 * by @a ok is left unmodified. Else, everything is good and the diagnostic hass
 * been performed, so the result of the diagnostic is stored in the value pointed
 * by @a ok
 */
int VideoCapture_cameraOk(bool *ok);

/**
 * @brief This method is necessary in order to avoid spurious voltages in the i2c
 * lines. When the video decoder is in power-down mode, it drives the i2c lines
 * and sets the clock to strong high and the data to strong low, potentially causing
 * the MSP Main's i2c FSM to fail and leave it in an unrecoverable state
 * 
 * This method MUST be called early in the initializing stages of the IPU in order to
 * avoid this spurious voltages and avoid sporadic reboots
 */
void VideoCapture_initGpios(void);

/**
 * Close doxygen group
 * @}
 */

#endif //__VIDEO_CAPTURE_H__
