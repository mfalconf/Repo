/******************************************************************************
 *
 * \file    video_dma.c
 *
 * \brief   Video DMA module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    19 Jul 2022
 *
 *****************************************************************************/

#include <standard.h>

#include "video_dma.h"
#include <console.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/csl/soc.h>
#include <ti/csl/csl_edma.h>
#include <ti/csl/hw_types.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/hal/Hwi.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <ti/sysbios/hal/Cache.h>



/**
 * @addtogroup VideoDma
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DEBUG_VIDEO_DMA  0

#define VIDEO_DMA_EDMA_BASE_ADDR    (SOC_EDMA_TPCC_BASE + L4_REGISTER_ADDRESS_OFFSET)
#define VIDEO_DMA_IRQ_NUM           (34)
#define VIDEO_DMA_REGION            (1)
#define VIDEO_DMA_QUEUE_NUM         (1)
#define VIDEO_DMA_CHANNEL_NUM       (58)
#define VIDEO_DMA_TCC_NUM           (0)

#define _UPDATE_EVERY_X_FRAMES_     (2)
/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static Bool videoDMAInitialized = FALSE;
static Hwi_Handle intrHandle;
static volatile Bool videoDmaTxOk = FALSE;
Semaphore_Handle videoDMATxCmpSem;
Semaphore_Handle videoDMABusySem;

/******************************************************************************
 * Functions implementation
 *****************************************************************************/
static void videoDma_isr(UInt32 arg)
{
  LOG_PRINT_SVER(DEBUG_VIDEO_DMA, "%s(): Intr status = %x %x \r\n", __FUNCTION__, EDMA3IntrStatusHighGet(VIDEO_DMA_EDMA_BASE_ADDR), EDMA3GetIntrStatus(VIDEO_DMA_EDMA_BASE_ADDR));

  if (VIDEO_DMA_CHANNEL_NUM >= 32)
  {
    if (EDMA3IntrStatusHighGet(VIDEO_DMA_EDMA_BASE_ADDR) & ((uint32_t) 1U << (VIDEO_DMA_CHANNEL_NUM - 32)))
    {
      EDMA3ClrIntr(VIDEO_DMA_EDMA_BASE_ADDR, VIDEO_DMA_CHANNEL_NUM); 
      videoDmaTxOk = TRUE;
      Semaphore_post(videoDMATxCmpSem);
    }
  }
  else
  {
    if (EDMA3GetIntrStatus(VIDEO_DMA_EDMA_BASE_ADDR) & ((uint32_t) 1U << (VIDEO_DMA_CHANNEL_NUM)))
    {
      EDMA3ClrIntr(VIDEO_DMA_EDMA_BASE_ADDR, VIDEO_DMA_CHANNEL_NUM);
      videoDmaTxOk = TRUE;
      Semaphore_post(videoDMATxCmpSem);
    }
  }
}

static void videoDma_error_isr(UInt32 arg)
{
  LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "%s():\r\n", __FUNCTION__);
  uint32_t intrErr = EDMA3GetErrIntrStatus(VIDEO_DMA_EDMA_BASE_ADDR);
  uint32_t intrErrHigh = EDMA3ErrIntrHighStatusGet(VIDEO_DMA_EDMA_BASE_ADDR);
  uint32_t ccErr = EDMA3GetCCErrStatus(VIDEO_DMA_EDMA_BASE_ADDR);

  if (intrErr || ccErr || intrErrHigh)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "(%s) [%d]: intrErrHigh=%d ; intrErr=%d ; ccErr=%d\r\n", __FUNCTION__, __LINE__, intrErrHigh, intrErr, ccErr);
  }
  else
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "(%s) [%d]: Error ISR called without errors!\r\n", __FUNCTION__, __LINE__);
  }

  Semaphore_post(videoDMATxCmpSem);
}

Int32 VideoDMA_init(void)
{
  int i;
	Semaphore_Params semPrms;

  LOG_PRINT_INFO(DEBUG_VIDEO_DMA, "%s(): Id = 0x%x\r\n", __FUNCTION__, *((UInt32*) VIDEO_DMA_EDMA_BASE_ADDR));
  /* Check if the module was previously initialized */
  if (videoDMAInitialized)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "%s(): Module already initialized!!\r\n", __FUNCTION__);
    return E_ERROR;
  }

  /* create DMA completion semaphore */
  Semaphore_Params_init(&semPrms);
  videoDMATxCmpSem = Semaphore_create(0, &semPrms, NULL);
  if (NULL == videoDMATxCmpSem)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "%s(): TX complete semaphore creation failed!!\r\n", __FUNCTION__);
    return E_ERROR;
  }

	/* create DMA busy semaphore */
  Semaphore_Params_init(&semPrms);
  videoDMABusySem = Semaphore_create(1, &semPrms, NULL);
  if (NULL == videoDMABusySem)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "%s(): TX complete semaphore creation failed!!\r\n", __FUNCTION__);
    return E_ERROR;
  }

  /* Wake up module */
  HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_CM_CORE_BASE + CM_L3MAIN1_TPTC1_CLKCTRL , 0x01U);
  HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CORE_CM_CORE_BASE + CM_L3MAIN1_TPTC2_CLKCTRL , 0x01U);

  LOG_PRINT_INFO(DEBUG_VIDEO_DMA, "%s(): Registering EDMA ISR\r\n", __FUNCTION__);
 
  /* Register EDMA interrupt */
  Error_Block eb;
  Error_init(&eb);
  intrHandle = Hwi_create(VIDEO_DMA_IRQ_NUM, videoDma_isr, NULL, &eb);
  if (NULL == intrHandle)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "%s: Cannot Register IRQ\r\n", __FUNCTION__);
    return E_ERROR;      
  }

  Error_init(&eb);
  intrHandle = Hwi_create(VIDEO_DMA_IRQ_NUM + 1, videoDma_error_isr, NULL, &eb);
  if (NULL == intrHandle)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "%s: Cannot Register IRQ\r\n", __FUNCTION__);
    return E_ERROR;      
  }

  /* Initialize low level driver */
  LOG_PRINT_INFO(DEBUG_VIDEO_DMA, "%s(): Initializing EDMA driver\r\n", __FUNCTION__);
  EDMAsetRegion(VIDEO_DMA_REGION);
  EDMA3Init(VIDEO_DMA_EDMA_BASE_ADDR, VIDEO_DMA_QUEUE_NUM);

  /* Disable all events */
  for (i = 0; i < 64; i++)
  {
    EDMA3DisableChInShadowReg(VIDEO_DMA_EDMA_BASE_ADDR, EDMA3_CHANNEL_TYPE_DMA, i);
  }

  for (i = 0; i < 8; i++)
  {
    EDMA3DisableChInShadowReg(VIDEO_DMA_EDMA_BASE_ADDR, EDMA3_CHANNEL_TYPE_QDMA, i);
  }

  /* Enable only used channel */
  EDMA3EnableDmaEvt(VIDEO_DMA_EDMA_BASE_ADDR, VIDEO_DMA_CHANNEL_NUM);
  EDMA3EnableChInShadowReg(VIDEO_DMA_EDMA_BASE_ADDR, EDMA3_CHANNEL_TYPE_DMA, VIDEO_DMA_CHANNEL_NUM);

  videoDMAInitialized = TRUE;

  return E_OK;
}

Int32 VideoDMA_deinit(void)
{
  /* Check if the module was previously initialized */
  if (!videoDMAInitialized)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "%s(): Module already deinitialized!!\r\n", __FUNCTION__);
    return E_ERROR;
  }

  /* deinitialize low level driver */
  EDMA3Deinit(VIDEO_DMA_EDMA_BASE_ADDR, VIDEO_DMA_QUEUE_NUM);
  videoDMAInitialized = FALSE;

  return E_OK;
}

static Int32 VideoDMA_copyFrame_dma(void *dstFrame, UInt32 dstBpp, UInt32 dstStride, 
                         void *srcFrame, UInt32 srcBpp, UInt32 srcStride,
                         UInt32 width, UInt32 height)
{
  Int32 retVal;
  EDMA3CCPaRAMEntry edmaParam;
  int ticks_start, ticks_end;

  if (!videoDMAInitialized)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "%s(): EDMA module not initialized!!\r\n", __FUNCTION__);
    return E_ERROR;
  }

	LOG_PRINT_SVER(DEBUG_VIDEO_DMA, "%s(): Preparing DMA copy. srcAddr = %x, dstAddr = %x\r\n", 
                 __FUNCTION__, (UInt32) DA_TO_PHY_ADDR((UInt8 *) srcFrame), 
                (UInt32) DA_TO_PHY_ADDR((UInt8 *) dstFrame));

  if (!VideoHeap_isValidPtr(srcFrame) || !VideoHeap_isValidPtr(dstFrame))
  {
    LOG_PRINT_ERR(DEBUG_MIF, "(%s) [%d]: Invalid Source or Destination address. scrAddr = %p, dstAddr = %p\r\n", __FUNCTION__, __LINE__, srcFrame, dstFrame);
    return E_ERROR;
  }

  /* if we are busy, we wait here */
  Semaphore_pend(videoDMABusySem, BIOS_WAIT_FOREVER);

  retVal = EDMA3RequestChannel(VIDEO_DMA_EDMA_BASE_ADDR, EDMA3_CHANNEL_TYPE_DMA, VIDEO_DMA_CHANNEL_NUM, VIDEO_DMA_CHANNEL_NUM, VIDEO_DMA_QUEUE_NUM);

  if (TRUE != retVal)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "(%s) [%d]: Error requesting DMA channel = %d\r\n", __FUNCTION__, __LINE__);
    return retVal;
  }
	
  edmaParam.srcAddr = (UInt32) DA_TO_PHY_ADDR((UInt8 *) srcFrame);
  edmaParam.destAddr = (UInt32) DA_TO_PHY_ADDR((UInt8 *) dstFrame);
  edmaParam.aCnt = width * srcBpp;
  edmaParam.bCnt = height;
  edmaParam.cCnt = 1;
  edmaParam.srcBIdx = srcStride;
  edmaParam.destBIdx = dstStride;
  edmaParam.srcCIdx = 0;
  edmaParam.destCIdx = 0;
  edmaParam.linkAddr = 0xFFFFU;
  edmaParam.opt = (EDMA3_OPT_SYNCDIM_MASK | EDMA3_OPT_TCINTEN_MASK | 
                  ((VIDEO_DMA_CHANNEL_NUM << EDMA3_OPT_TCC_SHIFT) & EDMA3_OPT_TCC_MASK));

  EDMA3SetPaRAM(VIDEO_DMA_EDMA_BASE_ADDR, VIDEO_DMA_CHANNEL_NUM, &edmaParam);

  LOG_PRINT_SVER(DEBUG_VIDEO_DMA, "%s(): Enabling Transfer\r\n", __FUNCTION__);
  videoDmaTxOk = FALSE;

  retVal = EDMA3EnableTransfer(VIDEO_DMA_EDMA_BASE_ADDR, VIDEO_DMA_CHANNEL_NUM, EDMA3_TRIG_MODE_MANUAL);
  LOG_PRINT_SVER(DEBUG_VIDEO_DMA, "%s(): EDMA3EnableTransfer() returned %d\r\n", __FUNCTION__, retVal);

  ticks_start = Clock_getTicks();
  Semaphore_pend(videoDMATxCmpSem, BIOS_WAIT_FOREVER);
  ticks_end = Clock_getTicks();

  if ((ticks_end - ticks_start) > MS_TO_TICKS(3) )
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "(%s) [%d]: DMA transfer took too long!!! (%d msecs). w=%d, h=%d, bpp=%d, copySize=%d\r\n", __FUNCTION__, __LINE__, (ticks_end - ticks_start), width, height, srcBpp, width*height*srcBpp);

  if (videoDmaTxOk == FALSE)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_DMA, "(%s) [%d]: Error in DMA transfer!\r\n", __FUNCTION__, __LINE__);
  }

  EDMA3DisableTransfer(VIDEO_DMA_EDMA_BASE_ADDR, VIDEO_DMA_CHANNEL_NUM, EDMA3_TRIG_MODE_MANUAL);

  LOG_PRINT_SVER(DEBUG_VIDEO_DMA, "%s(): Copy DONE!!\r\n", __FUNCTION__, retVal);

	/* Update busy flag */
	Semaphore_post(videoDMABusySem);

  return E_OK;
}

Int32 VideoDMA_copyFrame(void *dstFrame, UInt32 dstBpp, UInt32 dstStride, 
                         void *srcFrame, UInt32 srcBpp, UInt32 srcStride,
                         UInt32 width, UInt32 height)
{
  return VideoDMA_copyFrame_dma(dstFrame, dstBpp, dstStride, srcFrame, srcBpp, srcStride, width, height);
}

Int32 VideoDMA_copyFrame_RVC(void *dstFrame, UInt32 dstBpp, UInt32 dstStride, 
                         void *srcFrame, UInt32 srcBpp, UInt32 srcStride,
                         UInt32 width, UInt32 height)
{
  static bool firts_time = true;
  if(firts_time) 
  {
    LOG_PRINT_INFO(DEBUG_MIF,"%s - dstStride = %d, srcStride = %d, \r\nsrcWidth= %d, srcHeight = %d\r\ndstBpp= %d, srcBpp = %d\r\n",
                              __FUNCTION__, dstStride, srcStride, width, height, dstBpp, srcBpp);
    firts_time = false;                              
  } 
  
#if _USE_DMA_
  return VideoDMA_copyFrame_dma(dstFrame, dstBpp, dstStride, srcFrame, srcBpp, srcStride, width, height);
#else
  for(int y = 0; y < height; y++)
  {
    memcpy((void *)((UInt8*)dstFrame + y * dstStride), (void *)((UInt8*)srcFrame + y * srcStride), width * srcBpp); 
  }
  return E_OK;	
#endif
}


void memcpy_YUV422I_dma(uint8_t *dstFrame, UInt32 dstBpp, UInt32 dstStride, uint8_t *srcFrame, UInt32 srcBpp, UInt32 srcStride,
                         UInt32 width, UInt32 height) 
{
  Cache_wbInv(srcFrame, width * height * srcBpp, Cache_Type_ALL, TRUE);

  VideoDMA_copyFrame_dma((void *)dstFrame, dstBpp, dstStride, (void *)srcFrame, srcBpp, srcStride, width, height);
}

void testDmaHeap();

void Video_AutoTurn90_YUV422I(uint8_t *srcp, int width, int height, int src_stride, int dst_stride)
{	
	static uint8_t *dstp = NULL;
  
  if(dstp == NULL)
  {
    //dstp = (uint8_t *) malloc(src_stride * height);
    dstp = (uint8_t *) VideoHeap_allocFrame(width, height, 2);
    if(dstp == NULL) 
    {
      LOG_PRINT_ERR(DEBUG_MIF,"%s - MALLOC COULD NOT RESERVE MEMORY!!!\n", __FUNCTION__);
      return;
    } 
  }

  #if _UPDATE_EVERY_X_FRAMES_ > 0
  static int update_counter = _UPDATE_EVERY_X_FRAMES_ - 1;
  
  update_counter++;
  if((update_counter % _UPDATE_EVERY_X_FRAMES_) != 0) 
  {
    //memcpy((uint8_t *)srcp, (uint8_t *)dstp, src_stride * height);
    memcpy_YUV422I_dma((UInt8 *) srcp, 2, dst_stride, (UInt8 *) dstp, 2, dst_stride, height, width);
    return;
  }
  #endif
  
  int bytes_per_row = width * 2; //Every pixel use 2 bytes.
  
  for (int y = 0; y < height; y += 2)
	{
		uint8_t *src_p = srcp + (y * src_stride);
    uint8_t *dstp_current_row = dstp + ((height - 2 - y) << 1);
    
		for (int x = 0; x < bytes_per_row; x += 4)
		{
      uint8_t *srcp_current_row = src_p + x;
      uint8_t *srcp_next_row = srcp_current_row + src_stride;

			uint8_t u = (srcp_current_row[1] + srcp_next_row[1]) >> 1;
			uint8_t v = (srcp_current_row[3] + srcp_next_row[3]) >> 1;
			
      dstp_current_row[0] = srcp_next_row[0];
			dstp_current_row[1] = u;
			dstp_current_row[2] = srcp_current_row[0];
			dstp_current_row[3] = v;
			
      uint8_t* dstp_next_row = dstp_current_row + dst_stride;
			
      dstp_next_row[0] = srcp_next_row[2];
			dstp_next_row[1] = u;
			dstp_next_row[2] = srcp_current_row[2];
			dstp_next_row[3] = v;
			dstp_current_row += dst_stride << 1;
		}
	}
  
	//memcpy((unsigned char *)srcp, (unsigned char *)dstp, src_stride * height);
  
  memcpy_YUV422I_dma((UInt8 *) srcp, 2, dst_stride, (UInt8 *) dstp, 2, dst_stride, height, width);
  
  //testDmaHeap();
}

void testPrintDma(uint8_t * buf, int w, int h) {
  LOG_PRINT_INFO(DEBUG_MIF, "\n");

  for(int i = 0; i < h; i++) {
    for(int j = 0; j < w; j++) {
      LOG_PRINT_INFO(DEBUG_MIF, "%c ", buf[j]);
    }
    LOG_PRINT_INFO(DEBUG_MIF, "\n");
  }
}

void testDmaHeap() {
  static bool first_time = true;
  static uint8_t *dst_p = NULL;
  static uint8_t *orig_p = NULL;

  #define TEST_WIDTH (5)
  #define TEST_HEIGHT (3)
  #define TEST_BPP (2)
  #define TEST_STRIDE ((TEST_WIDTH * TEST_BPP))

  if(!first_time) {
    return;
  }
  first_time = false;
  
  if(orig_p == NULL) {
    orig_p = (uint8_t *) VideoHeap_allocFrame(TEST_WIDTH, TEST_HEIGHT, TEST_BPP);
    if(orig_p == NULL) {
      LOG_PRINT_ERR(DEBUG_MIF,"%s - MALLOC COULD NOT RESERVE MEMORY!!!\n", __FUNCTION__);
      return;
    } 
  }

  if(dst_p == NULL) {
    dst_p = (uint8_t *) VideoHeap_allocFrame(TEST_WIDTH, TEST_HEIGHT, TEST_BPP);
    if(dst_p == NULL) {
      LOG_PRINT_ERR(DEBUG_MIF,"%s - MALLOC COULD NOT RESERVE MEMORY!!!\n", __FUNCTION__);
      return;
    } 
  }

  memset(orig_p, 'x', TEST_STRIDE * TEST_HEIGHT);
  memset(dst_p, 'B', TEST_STRIDE * TEST_HEIGHT);
  
  for(int x = 0; x < TEST_HEIGHT; x++) {
    memset(orig_p + (x * TEST_STRIDE), 'A', TEST_WIDTH);
  }

  testPrintDma(orig_p, TEST_STRIDE, TEST_HEIGHT); 
  testPrintDma(dst_p, TEST_STRIDE, TEST_HEIGHT); 

/*
  for(int y = 0; y < TEST_HEIGHT; y++) {
    memcpy((void *)((UInt8*)dst_p + y * TEST_STRIDE), (void *)((UInt8*)orig_p + y * TEST_STRIDE), TEST_WIDTH * TEST_BPP); 
  } 
*/

  memcpy_YUV422I_dma(dst_p, TEST_BPP, TEST_STRIDE, orig_p, TEST_BPP, TEST_STRIDE, TEST_WIDTH, TEST_HEIGHT);
  
  testPrintDma(dst_p, TEST_STRIDE, TEST_HEIGHT);
}

/**
 * Close doxygen group
 * @}
 */
