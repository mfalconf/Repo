/******************************************************************************
 *
 * \file    pdc_manager.h
 *
 * \brief   Park Distance Control manager header file
 *
 * \author  Esteban Pupillo
 *
 * \date    22 Sep 2022
 *
 *****************************************************************************/
#ifndef __PDC_MANAGER_H__
#define __PDC_MANAGER_H__

/**
 * @addtogroup PdcManager
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

#include "renderer.h"

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define PDC_MANAGER_FRONT_SENSORS_NUM 	(4)
#define PDC_MANAGER_REAR_SENSORS_NUM 		(4)

#define	PDC_OUTSIDE_SEGMENTS_NUM				(4)
#define	PDC_INSIDE_SEGMENTS_NUM					(8)

#undef X
#define PDC_REAR_OUTSIDE_SENSOR_CM_TO_SEG_MAP \
	/* distance in cm, segment */ \
	X(  15,   1) \
	X(  30,   2) \
	X(  95,   3) \
	X( 160,   4)

#undef X
#define PDC_REAR_INSIDE_SENSOR_CM_TO_SEG_MAP \
	/* distance in cm, segment */ \
	X(  15,   1) \
	X(  30,   2) \
	X(  60,   3) \
	X(  80,   4) \
	X( 100,   5) \
	X( 120,   6) \
	X( 140,   7) \
	X( 160,   8)

#undef X
#define PDC_FRONT_OUTSIDE_SENSOR_CM_TO_SEG_MAP \
	/* distance in cm, segment */ \
	X(  10,   1) \
	X(  20,   2) \
	X(  45,   3) \
	X(  60,   4)

#undef X
#define PDC_FRONT_INSIDE_SENSOR_CM_TO_SEG_MAP \
	/* distance in cm, segment */ \
	X(  12,   1) \
	X(  25,   2) \
	X(  45,   3) \
	X(  60,   4) \
	X(  75,   5) \
	X(  90,   6) \
	X( 105,   7) \
	X( 120,   8)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief PdcManager abstract data type
 */
typedef struct pdc_manager_type* PdcManager;

/**
 * @brief PdcManager parameters 
 */
typedef struct pdc_manager_params_tag {

} PdcManagerParams;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initializes PdcManager parameters
 */
void inline PdcManagerParams_init(PdcManagerParams *params)
{
	if (NULL != params)
	{
		memset(params, 0, sizeof(PdcManagerParams));
	}
}

Int32 PdcManager_init(PdcManager *pdcManager, PdcManagerParams *params);
Int32 PdcManager_getInstance(PdcManager *pdcManager);
Int32 PdcManager_updateFrontSensors(PdcManager pdcManager, Uint8 *frontSensor);
Int32 PdcManager_updateRearSensors(PdcManager pdcManager, Uint8 *rearSensor);
Int32 PdcManager_updateSensors(PdcManager pdcManager, Uint8 *frontSensor, Uint8 *rearSensor);
Int32 PdcManager_updateTouchAvailable(PdcManager pdcManager, bool_t touchAvailable);
Int32 PdcManager_updateRvcStatus(PdcManager pdcManager, bool_t rvcStatus);
Int32 PdcManager_updateCar(PdcManager pdcManager, RendererCar car, bool_t pdcAvailable);
Int32 PdcManager_updateLanguage(PdcManager pdcManager, Language_en language);
Int32 PdcManager_updateSwitchOn(PdcManager pdcManager, bool_t switchOn);

/**
 * Close doxygen group
 * @}
 */

#endif //__PDC_MANAGER_H__
