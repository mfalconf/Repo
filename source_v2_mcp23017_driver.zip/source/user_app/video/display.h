/******************************************************************************
 *
 * \file    display.h
 *
 * \brief   Display module header file
 *
 * \author  Esteban Pupillo
 *
 * \date    27 Jun 2022
 *
 *****************************************************************************/
#ifndef __DISPLAY_H__
#define __DISPLAY_H__

/**
 * @addtogroup Display
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/** Configure the LCD ouptut port that will be used */
#define DISPLAY_BSP_OUTPUT_PORT (BSP_PLATFORM_VENC_LCD3)
#define DISPLAY_OUTPUT_PORT     (VPS_DCTRL_DSS_VENC_LCD3)

/** Selects the DSS plane that will be used by IPU */
#define DISPLAY_IPU_PLANE       (VPS_DISP_INST_DSS_VID3)

/** Defines the plane horizontal position */
#define DISPLAY_PLANE_XPOS      (0U)

/** Defines the plane vertical position */
#define DISPLAY_PLANE_YPOS      (0U)

/** Defines the plane data format */ 
#define DISPLAY_PLANE_DATA_FORMAT   (FVID2_DF_BGRA32_8888) //(FVID2_DF_BGR24_888)//(FVID2_DF_BGRA32_8888)//(FVID2_DF_ARGB32_8888) //(FVID2_DF_YUV420SP_UV)

/** Defines the plane scan format */
#define DISPLAY_PLANE_SCAN_FORMAT   (FVID2_SF_PROGRESSIVE)

/** Defines the number of frames used by the display pipeline */
#define DISPLAY_MAX_FRAMES       (3U)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief VideoCapture data type
 */
typedef struct display_tag* Display;


/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initialize Display subsystem
 *
 * This function has to be called before any other function of this
 * module API
 *
 * @param Display pointer to the Display instance to initialize
 * @param Fvid2_CbParams frame ready callback
 * @return #FVID2_SOK on success
 */
Int32 Display_init(Display *display, Fvid2_CbParams callback);

/**
 * @brief Starts display pipeline
 *
 * @param display display instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 Display_start(Display display);

/**
 * @brief Stops display pipeline
 *
 * @param display display instance
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 Display_stop(Display display);

/**
 * @brief Queues frame list to driver
 *
 * @param Display display instance
 * @param frameList list of frames to queue
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 Display_queueBuffer(Display display, Fvid2_FrameList *frameList);

/**
 * @brief Dequeues frame list from driver
 *
 * @param Display display instance
 * @param frameList pointer to a list of frames dequeued
 *
 * @return #FVID2_SOK on success, error code otherwise
 */
Int32 Display_dequeueBuffer(Display display, Fvid2_FrameList *frameList);

bool_t Display_isStarted(Display display);

bool_t Display_canStart(Display display);

Int32 Display_getResolution(Display display, UInt32 *width, UInt32 *height);

Int32 Display_getGlobalAlpha(Display display, UInt8 *alpha);

Int32 Display_setGlobalAlpha(Display display, UInt8 alpha);

/**
 * Close doxygen group
 * @}
 */

#endif //__DISPLAY_H__
