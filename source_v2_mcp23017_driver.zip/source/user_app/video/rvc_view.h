/******************************************************************************
 *
 * \file    pdc_view.h
 *
 * \brief   Rear Camera view header file
 *
 * \author  Esteban Pupillo
 *
 * \date    22 Sep 2022
 *
 *****************************************************************************/
#ifndef __RVC_VIEW_H__
#define __RVC_VIEW_H__

/**
 * @addtogroup RvcView
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <ti/drv/vps/include/fvid2/fvid2.h>
#include <ti/drv/vps/include/vps.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/**
 * @brief RvcView abstract data type
 */
typedef struct rvc_view_type* RvcView;

/**
 * @brief RvcView parameters 
 */
typedef struct rvc_view_params_tag {

} RvcViewParams;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Initializes RvcView parameters
 */
void inline RvcViewParams_init(RvcViewParams *params)
{
	if (NULL != params)
	{
		memset(params, 0, sizeof(RvcViewParams));
	}
}

Int32 RvcView_init(RvcView *rvcView, RvcViewParams *params);

Int32 RvcView_show(RvcView rvcView);

Int32 RvcView_hide(RvcView rvcView);



/**
 * Close doxygen group
 * @}
 */

#endif //__RVC_VIEW_H__
