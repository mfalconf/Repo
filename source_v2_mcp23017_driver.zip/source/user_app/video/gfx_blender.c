/******************************************************************************
 *
 * \file    gfx_blender.c
 *
 * \brief   Graphic blender module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    17 Sep 2022
 *
 *****************************************************************************/

#include <standard.h>

#include "gfx_blender.h"

#include <console.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/heaps/HeapMem.h>

#include "video_dma.h"

#include <ti/sysbios/hal/Cache.h>

/**
 * @addtogroup GfxBlender
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define GFX_BLENDER_USE_DMA    (1)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
struct gfx_blender_type {
	bool_t isInitialized;
	/**< flag to know if the blender module is initialized */

	GfxBlenderParams params;
	/**< blender parameters */
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

Int32 GfxBlender_create(GfxBlender *gfxBlender, GfxBlenderParams *gfxBlenderParams)
{
	GfxBlender newBlender;

	/* Check input parameters */
	if ((NULL == gfxBlender) || (NULL == gfxBlenderParams))
	{
		return E_ERROR;
	}

	/* Allocate new blender */
	newBlender = (GfxBlender) Memory_alloc(NULL, sizeof(struct gfx_blender_type), 0, NULL);
	if (NULL == newBlender)
	{
		/* we couldn't allocate a new blender object */
		return E_ERROR;
	}

	/* Initialize internal variables */
	newBlender->isInitialized = FALSE;

	/* copy parameters */
	memcpy(&newBlender->params, gfxBlenderParams, sizeof(GfxBlenderParams));

	/* the new blender object is now initialized */
	newBlender->isInitialized = TRUE;

	/* return newly created blender */
	*gfxBlender = newBlender;

	LOG_PRINT_INFO(DEBUG_GFX_BLENDER, "%s(): Blender %p created\r\n", __FUNCTION__, newBlender);

	return E_OK;
}

Int32 GfxBlender_bitblit(GfxBlender gfxBlender, Fvid2_Frame *outFrame, Fvid2_Frame *inFrame, GfxBitblitParams *params)
{
	Int32 retVal = E_OK;
  UInt8 *outStartAddr;
	Int32 width, height;

	/* Check input parameters */
	if ((NULL == gfxBlender) || (NULL == outFrame) || 
			(NULL == inFrame) || (NULL == params))
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* Check if the blender object is initialized */
	if (!gfxBlender->isInitialized)
	{
		return E_ERROR;
	}

	/* calculate where we have to start blitting */
	outStartAddr = (UInt8*)outFrame->addr[0][0];
	outStartAddr += params->yPos * gfxBlender->params.displayFrameParams.stride;
	outStartAddr += params->xPos * gfxBlender->params.displayFrameParams.bpp;

	/* make sure we are inside the frame buffer memory area */
  width = (gfxBlender->params.displayFrameParams.width - params->xPos) < params->width ? gfxBlender->params.displayFrameParams.width - params->xPos : params->width;
  height = (gfxBlender->params.displayFrameParams.height - params->yPos) < params->height ? gfxBlender->params.displayFrameParams.height - params->yPos : params->height;

	if ((0 <= width) && (0 <= height))
	{
    UInt32 y;
#if GFX_BLENDER_USE_DMA == 1
	/* do bitblit using dma */
	retVal = VideoDMA_copyFrame(PHY_TO_DA_ADDR(outStartAddr), 
	  					               gfxBlender->params.displayFrameParams.bpp, 
					        					 gfxBlender->params.displayFrameParams.stride,
					                   PHY_TO_DA_ADDR((UInt8 *) inFrame->addr[0][0]), 
										         params->inFrameParams.bpp, 
										         params->inFrameParams.stride, 
										         width,
										         height);
#else
  for (y = 0; y < height; y++)
  {
    memcpy((void *)((UInt8*)PHY_TO_DA_ADDR(outStartAddr) + y * gfxBlender->params.displayFrameParams.stride), 
				   PHY_TO_DA_ADDR((UInt8 *) inFrame->addr[0][0]) + y * params->inFrameParams.stride, 
					 width * params->inFrameParams.bpp);
  }

	Cache_wbInv(PHY_TO_DA_ADDR(outStartAddr), width * height * params->inFrameParams.bpp, Cache_Type_ALL, TRUE);
#endif
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_GFX_BLENDER, "%s(): Error while doing bitblit\r\n", __FUNCTION__);
	}
	}

	return retVal;
}



/**
 * Close doxygen group
 * @}
 */

