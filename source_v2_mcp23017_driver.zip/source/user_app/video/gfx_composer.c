/******************************************************************************
 *
 * \file    gfx_composer.c
 *
 * \brief   Graphic composer module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    10 Ago 2022
 *
 *****************************************************************************/
// #define LOG_DEBUG_SUPER_VERBOSE 1

#include <standard.h>
#include "console.h"
#include <xdc/std.h>
#include "gfx_blender.h"
#include "gfx_composer.h"
#include "project_def.h"
#include "video_heap.h"
#include "video_dma.h"
#include "display.h"
#include "rvc_manager.h"
#include "renderer.h"
#include "splash_animator.h"
#include "gfx_animator.h"
#include "fsm.h"
#include <board.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/hal/Cache.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Mailbox.h>
#include <ti/sysbios/knl/Event.h>

#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>
#include <ti/csl/cslr_dss.h>
#include <ti/csl/hw_types.h>
#include <ti/csl/csl_gpio.h>

#include <ti/drv/vps/include/devices/bsp_lcdController.h>
#include <ti/drv/vps/include/platforms/bsp_platform.h>
#include <ti/drv/vps/include/common/bsp_utilsQue.h>

#include "gfx_layer.h"

/**
 * @addtogroup GfxComposer
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DEBUG_GFX_COMP   0

#define GFX_COMPOSER_TASK_STACK_SIZE   (0x1000)
#define GFX_STREAM_QUEUE_SIZE          (2)
#define GFX_MAX_FRAMES								 (20)
#define GFX_COMPOSER_MAX_FRAMES        (5)
#define GFX_COMPOSER_MAX_LAYERS        (4)
#define GFX_COMPOSER_DISPLAY_ALPHA     1

#define GFX_COMPOSER_EVENT_NEW_MSG     (Event_Id_00)
#define GFX_COMPOSER_EVENT_VSYNC       (Event_Id_01)

#define GFX_INVALID_LAYER {PRODUCER_NUM, -1, -1, -1, -1}
#define GFX_COMPOSER_INVALID_SLOT     (-1)

// The time scaling factor will affect the fade out transition time
// The relation (lutSize/timeScaleFactor) will set the amount of steps in the transition
// So, with a desired amount of steps (the steps will be executed at each frame updated by the gfxComposer)
// you can define this as: timeScaleFactor = lutSize / desiredSteps
#define GFX_COMPOSER_DESIRED_STEPS_AMOUNT   (20)
#define GFX_COMPOSER_TIME_SCALE_FACTOR      (GfxAnimator_getLutSize() / GFX_COMPOSER_DESIRED_STEPS_AMOUNT)

#undef MODE
#undef LAYER
#define GFX_COMPOSER_MODES \
	MODE(SPLASH) \
	MODE(RVC) \
	MODE(PDC) \
	MODE(OFF)

#define GFX_COMPOSER_SPLASH_COMPOSITION \
	LAYER(PRODUCER_SPLASH, 0, 0, 800, 480)\

#define GFX_COMPOSER_RVC_COMPOSITION \
	LAYER(PRODUCER_GRAPHICS, 0, 0, 192, 480)\
	LAYER(PRODUCER_RVC, 0, 0, 800, 480)

#define GFX_COMPOSER_PDC_COMPOSITION \
	LAYER(PRODUCER_GRAPHICS, 0, 0, 800, 480)

#define GFX_COMPOSER_VIEW \
	LAYER(SPLASH, PRODUCER_SPLASH,       1, 0, 0, 800, 480) \
	LAYER(SMALL_PDC, PRODUCER_GRAPHICS,  0, 0, 0, 192, 480) \
	LAYER(RVC, PRODUCER_RVC,             0, 0, 0, 800, 480) \
	LAYER(FULL_PDC, PRODUCER_GRAPHICS,   0, 0, 0, 800, 480)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
typedef enum gfx_composer_state_tag
{
	GFX_COMPOSER_STOPPED,
	GFX_COMPOSER_STOPPING,
	GFX_COMPOSER_STARTED,
	GFX_COMPOSER_STARTING,

} GfxComposerState;

typedef enum gfx_queue_id_tag {
	Q_RVC_IN,
	Q_RVC_DONE,
	Q_GFX_IN,
	Q_GFX_DONE,
	Q_COMP_OUT,
	Q_COMP_DONE,

	GFX_COMP_QUEUE_NUM,
} GfxQueueId;

typedef enum gfx_producer_id_tag {
	PRODUCER_SPLASH,
	PRODUCER_RVC,
	PRODUCER_GRAPHICS,

	/* Number of producers */
	PRODUCER_NUM,
} ProducerId;

typedef struct gfx_frame_info_tag {
	Fvid2_Frame frame;
	Fvid2_Frame *producerFrame;
	Ptr producer;
	UInt32 credit;
} GfxFrame;

typedef struct gfx_composer_frame_tag {
	Fvid2_Frame frame;
	GfxFrame *relatedFrames[5];
	UInt32 numRelatedFrames;
} GfxComposerFrame;

typedef enum gfx_composer_message_id_tag {
	GFX_COMPOSER_MSG_NONE,
	GFX_COMPOSER_MSG_CHANGE_MODE,
	GFX_COMPOSER_MSG_SET_LAYER_TOP,
	GFX_COMPOSER_MSG_START,
	GFX_COMPOSER_MSG_STOP,

	GFX_COMPOSER_MSG_NUM,
} GfxComposerMessageId;

typedef struct gfx_composer_msg_tag {
	GfxComposerMessageId id;
	UInt32 param1;
	UInt32 param2;
	Ptr appData;
} GfxComposerMessage;

struct gfx_composer_tag {
  bool_t isInitialized;
  /**< Module initialization flag */

	Display displayInst;
	RvcManager rvcInst;
	Renderer renderInst;
	SplashAnimator splashInst;

	bool_t isStarted;
	
	Task_Handle procHandle;

	GfxComposerFrame composedFrames[GFX_COMPOSER_MAX_FRAMES];
	Ptr qDataComposedFrames[GFX_COMPOSER_MAX_FRAMES];
	BspUtils_QueHandle qComposedFrames;

	GfxFrame gfxFrames[GFX_MAX_FRAMES];
	Ptr qDataGfxFrames[GFX_MAX_FRAMES];
	BspUtils_QueHandle qGfxFrames;

	Ptr qData[GFX_COMP_QUEUE_NUM][GFX_STREAM_QUEUE_SIZE];
	BspUtils_QueHandle qHandle[GFX_COMP_QUEUE_NUM];

	Semaphore_Handle vSyncSem;

	Fvid2_Frame compFrm;
	GfxFrame compGfxFrm;

	GfxFrame *curRvcFrm;
	GfxFrame *curGfxFrm;
	GfxFrame *curCompFrm;
	GfxFrame *curSplashFrm;

	Mailbox_Handle msgMailbox;
	Event_Handle vSyncEvent;

	GfxLayer layers[GFX_COMPOSER_MAX_LAYERS];
	UInt32 numLayers;

	GfxBlender blender;
	Int32 currentFocusSlot;

	GfxAnimator gfxAnimator;

	GfxComposerState currentState;

  Fvid2_Frame opaqueFrame;

	gfx_composer_focus_gained_callback focusGainedCb;
	void *focusGainedContext;
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/
static uint8_t gfxComposer_isSlotValid(Int32 slot);

static Int32 gfxComposer_resetQueues(GfxComposer gfxComp);

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static uint8_t stack[GFX_COMPOSER_TASK_STACK_SIZE];
static struct gfx_composer_tag gGfxComposer;

/******************************************************************************
 * Functions implementation
 *****************************************************************************/
/**
 * @brief Set the LVDS enable state
 * 
 * @param state Desired enable state. i.e. If this is true, the LVDS
 * will be enabled
 */
static void gfxComposer_SetLvdsEnable(bool_t state)
{
  LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): state=%d\r\n", __FUNCTION__);
  state ? GPIOPinWrite(VIDEO_LVDS_EN_GPIO_ADDR, VIDEO_LVDS_EN_GPIO_PIN, 1) : GPIOPinWrite(VIDEO_LVDS_EN_GPIO_ADDR, VIDEO_LVDS_EN_GPIO_PIN, 0);
}

static void gfxComposer_dumpLayerStack(GfxComposer gfxComp)
{
	Int32 slot;

	LOG_PRINT_INFO(DEBUG_GFX_COMP,   "%s(): v------+---------+-----------+-------+------------v\r\n", __FUNCTION__);
	LOG_PRINT_INFO(DEBUG_GFX_COMP,   "%s(): | slot |   name  |   addr    | alpha | fullscreen |\r\n", __FUNCTION__);
	LOG_PRINT_INFO(DEBUG_GFX_COMP,   "%s(): +------+---------+-----------+-------+------------+\r\n", __FUNCTION__);
	for (slot = gfxComp->numLayers - 1; slot >= 0; slot--)
	{
		GfxLayer layer = gfxComp->layers[slot];
		LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): | %c %2d | %7s | %p | %5d |     %2d     |\r\n", __FUNCTION__, 
				(slot == gfxComp->currentFocusSlot)? '*': ' ', slot, GfxLayer_getName(layer), layer, GfxLayer_getAlpha(layer), GfxLayer_isFullScreen(layer));
	}

	LOG_PRINT_INFO(DEBUG_GFX_COMP,   "%s(): ^------+---------+-----------+-------+------------^\r\n", __FUNCTION__);
}

static Int32 gfxComposer_getLayerSlot(GfxComposer gfxComp, GfxLayer layer, UInt32 *layerSlot)
{
	UInt32 slot;

  /* Check if the layer was already registered */
  for (slot = 0; slot < gfxComp->numLayers; slot++)
	{
		if (gfxComp->layers[slot] == layer)
		{
			/* layer found */
			break;
		}
	}
	if (slot == gfxComp->numLayers)
	{
		/* We didn't find the layer */
		return E_ERROR;
	}

	/* we found it, return corresponding slot */
	*layerSlot = slot;

	return E_OK;
}

static Int32 gfxComposer_changeLayerToTopSlot(GfxComposer gfxComp, UInt32 currentSlot)
{
	UInt32 slotCounter;
	GfxLayer currentLayer;

	/* Check if current slot is out of bounds */
	if (currentSlot >= gfxComp->numLayers)
	{
		return E_ERROR;
	}

	/* Fist save current slot layer */
	currentLayer = gfxComp->layers[currentSlot];
	
	/* Calculate how many slots we have after the currentSlot */
	slotCounter = (gfxComp->numLayers - 1) - currentSlot;

	/* if current slot is the last one there is no need to shift all the layers */
	if ( 0 != slotCounter)
	{
		/* remove current slot from the array */
		memmove(&gfxComp->layers[currentSlot], 
				    &gfxComp->layers[currentSlot + 1], 
						slotCounter * sizeof(GfxLayer));
	
		/* Place current layer into top most slot */
		gfxComp->layers[gfxComp->numLayers - 1] = currentLayer;

		/* Update current slot focus */
		if (gfxComp->currentFocusSlot > currentSlot)
		{
			gfxComp->currentFocusSlot -= 1;
		}
		else if (gfxComp->currentFocusSlot == currentSlot)
		{	
      gfxComp->currentFocusSlot = gfxComp->numLayers - 1;
		}
		else
		{
			/* nothing to do here */
		}
	}

	return E_OK;
}

static void gfxComposer_updateAnimation(GfxComposer gfxComp)
{
	Int32 retVal;
	GfxAnimatorValue newValue;
	bool_t hasEnded;

	/* check if there is an animation started */
	if (NULL == gfxComp->gfxAnimator)
	{
		/* There is no animation active. Nothing to do here */
		return;
	}

	retVal = GfxAnimator_update(gfxComp->gfxAnimator, &newValue, &hasEnded);
	if (E_OK != retVal)
	{
		/* Something went wrong with the animator, we can't do anything here */
		return;
	}

	/* Check if the display alpha is being animated */
	if (GFX_COMPOSER_DISPLAY_ALPHA == newValue.parameterKey)
	{
		/* Set display alpha */
		Display_setGlobalAlpha(gfxComp->displayInst, newValue.value);
	}

	/* Check if the animation has ended */
	if (hasEnded)
	{
		/* The animation ended, free animator resources */
		GfxAnimator_destroy(gfxComp->gfxAnimator);
		gfxComp->gfxAnimator = NULL;
		
		if (GFX_COMPOSER_STARTING == gfxComp->currentState)
		{
			gfxComp->currentState = GFX_COMPOSER_STARTED;
			LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Graphic composer started\r\n", __FUNCTION__);
		}
		else if (GFX_COMPOSER_STOPPING == gfxComp->currentState)
		{
			gfxComp->currentState = GFX_COMPOSER_STOPPED;
			LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Graphic composer stopped\r\n", __FUNCTION__);
		}
	}

}

static void gfxComposer_updateLayerStack(GfxComposer gfxComp)
{
	Int32 slot;

	LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s()\r\n", __FUNCTION__);

  if (0 == gfxComp->numLayers)
    return;

	for (slot = gfxComp->numLayers - 1; slot >= 0; slot--)
	{
		if ((0 != GfxLayer_getAlpha(gfxComp->layers[slot])))
			break;
	}

	if ((0 <= slot) && (slot != gfxComp->currentFocusSlot))
	{

		LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): new focus slot = %d, current slot = %d\r\n", __FUNCTION__, slot, gfxComp->currentFocusSlot);
		/* Notify layer that is on top */
	  GfxLayer_onFocusChange(gfxComp->layers[slot], TRUE);
		LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Layer '%s' (%p) has gained focus\r\n", __FUNCTION__, GfxLayer_getName(gfxComp->layers[slot]), gfxComp->layers[slot]);

		if (gfxComp->focusGainedCb != NULL)
		{
			LOG_PRINT_INFO(DEBUG_GFX_COMP, "(%s) [%d]: Executing registered callback\r\n", __FUNCTION__, __LINE__);
			gfxComp->focusGainedCb(gfxComp->layers[slot], gfxComp->focusGainedContext);
		}

		if (gfxComposer_isSlotValid(gfxComp->currentFocusSlot))
		{
			/* Notify that to the current topmost layer that it's about to change */
			GfxLayer_onFocusChange(gfxComp->layers[gfxComp->currentFocusSlot], FALSE);
			LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Layer '%s' (%p) has lost focus\r\n", __FUNCTION__, GfxLayer_getName(gfxComp->layers[gfxComp->currentFocusSlot]), gfxComp->layers[gfxComp->currentFocusSlot]);
		}

		/* Update current focus slot */
		gfxComp->currentFocusSlot = slot;

		gfxComposer_dumpLayerStack(gfxComp);
	}
}

static Int32 gfxComposer_composeFrame(GfxComposer gfxComp, GfxComposerFrame *newFrame)
{
	Int32 retVal = E_OK;
	UInt32 layerCnt;

  if (0 == gfxComp->numLayers)
    return retVal;

  if (GfxLayer_getTag(gfxComp->layers[gfxComp->numLayers - 1]) != GFX_LAYER_TAG_SPLASH)
  {
    /* First draw the bottom layers */
    for (layerCnt = 0; layerCnt < gfxComp->numLayers - 1; layerCnt++)
    {
      /* if the upper layer is fullscreen we don't draw this layer
      * because it will fully cover with the upper layer
      */
      if ((0 != GfxLayer_getAlpha(gfxComp->layers[layerCnt])) && (!GfxLayer_isFullScreen(gfxComp->layers[layerCnt + 1])))
      {
        LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): Drawing layer '%s' at slot %d\r\n", __FUNCTION__, GfxLayer_getName(gfxComp->layers[layerCnt]), layerCnt);
        GfxLayer_draw(gfxComp->layers[layerCnt], (Fvid2_Frame *) newFrame);
      }
    }
  }
  else
  {
    layerCnt = gfxComp->numLayers - 1;
  }

  // The strategy of drawing opaque frames is only used if this layer is associated to splash view
  if (GfxLayer_getTag(gfxComp->layers[layerCnt]) == GFX_LAYER_TAG_SPLASH)
  {
    UInt32 displayWidth, displayHeight, i;

    /* Initialize this frame with a full opaque frame */
    Display_getResolution(gfxComp->displayInst, &displayWidth, &displayHeight);
    VideoDMA_copyFrame(PHY_TO_DA_ADDR(newFrame->frame.addr[0][0]),
                        4,
                        4 * displayWidth,
                        PHY_TO_DA_ADDR(gfxComp->opaqueFrame.addr[0][0]),
                        4,
                        4 * displayWidth,
                        displayWidth,
                        displayHeight);

    Cache_wbInv(newFrame->frame.addr[0][0], displayWidth * displayHeight * 4, Cache_Type_ALL, TRUE);
  }

	/* Finally render the topmost layer */
	LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): Drawing layer '%s' at slot %d\r\n", __FUNCTION__, GfxLayer_getName(gfxComp->layers[layerCnt]), layerCnt);
	GfxLayer_draw(gfxComp->layers[layerCnt], (Fvid2_Frame *) newFrame);

	return retVal;
}

static void gfxComposer_processVsync(GfxComposer gfxComp)
{
	Int32 retVal;
  GfxFrame *frm;
	GfxComposerFrame *doneFrm, *newComposeFrm;
	Fvid2_FrameList frmList;
	static UInt32 frameCounter = 0;

	LOG_PRINT_SVER(DEBUG_GFX_COMP, "---------------------\r\n%s(): VSync Found!\r\n", __FUNCTION__);

	/* get a free compose frame */
	retVal = BspUtils_queGet(&gfxComp->qComposedFrames, (Ptr*) &newComposeFrm, 1, BIOS_NO_WAIT);
	if (BSP_SOK != retVal)
	{
    LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to get a new compose frame\r\n", __FUNCTION__);
	}
	else
	{
		/* update animation (if active) */
		gfxComposer_updateAnimation(gfxComp);

		gfxComposer_updateLayerStack(gfxComp);
		gfxComposer_composeFrame(gfxComp, newComposeFrm);

		/* send new frame to display */
		LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): Sending frame %p to display. qSize = %d\r\n", __FUNCTION__, newComposeFrm, gfxComp->qComposedFrames.count);
		retVal = BspUtils_quePut(&gfxComp->qHandle[Q_COMP_OUT], newComposeFrm, BIOS_NO_WAIT);
		if (BSP_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to push frame to Composer done queue\r\n", __FUNCTION__);
		}
	}

	/* Get last displayed frame */
	retVal = BspUtils_queGet(&gfxComp->qHandle[Q_COMP_DONE], (Ptr*) &doneFrm, 1, BIOS_NO_WAIT);
	if (BSP_SOK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): failed to get frame from Composer done frame\r\n", __FUNCTION__);
	}
  else
	{
		/* we got a valid frame */
		LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): Got frame at %p, numRelatedFrames = %d, relatedFrames[0] = %p, relatedFrames[1] = %p\r\n", 
				__FUNCTION__, doneFrm, doneFrm->numRelatedFrames, doneFrm->relatedFrames[0], doneFrm->relatedFrames[1]);

		/* return composed frame */
		retVal = BspUtils_quePut(&gfxComp->qComposedFrames, doneFrm, BIOS_NO_WAIT);
		if (BSP_SOK != retVal)
		{
      LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to free compose frame\r\n", __FUNCTION__);
		}
		else
		{
			LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): Frame %p returned to queue. qSize = %d\r\n", __FUNCTION__, doneFrm, gfxComp->qComposedFrames.count);
		}
	}

	/* Get new frame to send to the display (if any)*/
	if (!BspUtils_queIsEmpty(&gfxComp->qHandle[Q_COMP_OUT]))
	{
		retVal = BspUtils_queGet(&gfxComp->qHandle[Q_COMP_OUT], (Ptr*) &frm, 1, BIOS_NO_WAIT);
    
		if (BSP_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to get frame from composer out queue\r\n", __FUNCTION__);
		}
    else
    {
      frmList.frames[0] = (Fvid2_Frame *) frm;
      frmList.numFrames = 1;

      /* Send frame to display */
      retVal = Display_queueBuffer(gfxComp->displayInst, &frmList);
      if (FVID2_SOK != retVal)
      {
        LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to push new frame to display\r\n", __FUNCTION__);
      }
    }
	}

	/* Get a done frame to send back to RVC manager (if any)*/
	if (!BspUtils_queIsEmpty(&gfxComp->qHandle[Q_RVC_DONE]))
	{
		retVal = BspUtils_queGet(&gfxComp->qHandle[Q_RVC_DONE], (Ptr*) &frm, 1, BIOS_NO_WAIT);
		if (BSP_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to get frame from RVC done queue\r\n", __FUNCTION__);
		}
		frmList.frames[0] = frm->producerFrame;
		frmList.numFrames = 1;
		LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): Returning frame at %p\r\n", __FUNCTION__, frmList.frames[0]);

		/* Send frame back to RVC manager */
		retVal = RvcManager_queueBuffer(gfxComp->rvcInst, &frmList);
		if (FVID2_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to push back RVC done frame to RVC manager\r\n", __FUNCTION__);
		}

		/* Return gfx frame object */
		retVal = BspUtils_quePut(&gfxComp->qGfxFrames, frm, BIOS_NO_WAIT);
		if (BSP_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable return GFX frame to GFX frames queue\r\n", __FUNCTION__);
		}

	}

	/* Get a done frame to send back to renderer (if any)*/
	if (!BspUtils_queIsEmpty(&gfxComp->qHandle[Q_GFX_DONE]))
	{
		retVal = BspUtils_queGet(&gfxComp->qHandle[Q_GFX_DONE], (Ptr*) &frm, 1, BIOS_NO_WAIT);
		if (BSP_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to get frame from GFX done queue\r\n", __FUNCTION__);
		}
		frmList.frames[0] = frm->producerFrame;
		frmList.numFrames = 1;
		LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): Returning frame at %p\r\n", __FUNCTION__, frmList.frames[0]);

		/* Send frame back to renderer */
		retVal = Renderer_queueBuffer(gfxComp->renderInst, &frmList);
		if (FVID2_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to push back GFX done frame to Renderer\r\n", __FUNCTION__);
		}

		/* Return gfx frame object */
		retVal = BspUtils_quePut(&gfxComp->qGfxFrames, frm, BIOS_NO_WAIT);
		if (BSP_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable return GFX frame to GFX frames queue\r\n", __FUNCTION__);
		}

	}
	LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): frameCounter = %d\r\n", __FUNCTION__, frameCounter);
	frameCounter++;
	
	LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): -------------------------------------------------------------\r\n", __FUNCTION__);
}

static void gfxComposer_onStart(GfxComposer gfxComp, bool_t fade_in)
{
	if (gfxComp->isStarted)
	{
		/* We are already started, nothing to do here */
		return;
	}

	/* Check if the animator is in use */
	if (NULL != gfxComp->gfxAnimator)
	{
		/* The animator is in use. We have do destroy it */
		GfxAnimator_destroy(gfxComp->gfxAnimator);
		gfxComp->gfxAnimator = NULL;
	}

	/* Create a new animator to animate the alpha channel to simulate a fade in effect */
	GfxAnimatorParams animParams;

	GfxAnimatorParams_init(&animParams);
  if (fade_in)
	  animParams.startValue = 0;   // 100% transparent
  else
	  animParams.startValue = 0xFF;  // 100% opaque
  
  animParams.endValue = 0xFF;  // 100% opaque
	animParams.parameterKey = GFX_COMPOSER_DISPLAY_ALPHA;
	animParams.timeScaleFactor = 2;

	GfxAnimator_create(&gfxComp->gfxAnimator, &animParams);
	GfxAnimator_start(gfxComp->gfxAnimator);

	gfxComp->currentState = GFX_COMPOSER_STARTING;

	LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Starting composer\r\n", __FUNCTION__);
}

static void gfxComposer_onStop(GfxComposer gfxComp)
{
	if (GFX_COMPOSER_STOPPED == gfxComp->currentState)
	{
		/* We are already stopped, nothing to do here */
		return;
	}

	/* Check if the animator is in use */
	if (NULL != gfxComp->gfxAnimator)
	{
		/* The animator is in use. We have do destroy it */
		GfxAnimator_destroy(gfxComp->gfxAnimator);
		gfxComp->gfxAnimator = NULL;
	}

	/* Create a new animator to animate the alpha channel to simulate a fade out effect */
	GfxAnimatorParams animParams;

	GfxAnimatorParams_init(&animParams);
	animParams.startValue = 0xFF;   // 100% opaque
	animParams.endValue = 0x00;  // 100% transparent
	animParams.parameterKey = GFX_COMPOSER_DISPLAY_ALPHA;
	animParams.timeScaleFactor = GFX_COMPOSER_TIME_SCALE_FACTOR;

	GfxAnimator_create(&gfxComp->gfxAnimator, &animParams);
	GfxAnimator_start(gfxComp->gfxAnimator);

	gfxComp->currentState = GFX_COMPOSER_STOPPING;
	LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Stopping composer\r\n", __FUNCTION__);
}

static void gfxComposer_onSetLayerTopMsg(GfxComposer gfxComp, GfxLayer layer)
{
	Int32 retVal = E_OK;
	UInt32 slot;

	/* Check input parameters */
	if ((NULL == gfxComp) || (NULL == layer))
	{
		/* Invalid parameters */
		return;
	}

	/* Find the corresponding layer slot */
	retVal = gfxComposer_getLayerSlot(gfxComp, layer, &slot);
	if (E_OK != retVal)
	{
		/* The layer was not previously registered */
		return;
	}

	/* if layer is already the topmost do nothing */
	if (slot != (gfxComp->numLayers - 1))
	{
		/* Move layer to top */
		gfxComposer_changeLayerToTopSlot(gfxComp, slot);

		LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): layer '%s' (%p) moved to top\r\n", __FUNCTION__, GfxLayer_getName(layer), layer);

		gfxComposer_dumpLayerStack(gfxComp);
	}

	return;
}

static void gfxComposer_processMessage(GfxComposer gfxComp)
{
	GfxComposerMessage msg;
  LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s()\r\n", __FUNCTION__);
	
  if (Mailbox_pend(gfxComp->msgMailbox, &msg, BIOS_NO_WAIT))
	{
		LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): New Message received with ID %d\r\n", __FUNCTION__, msg.id);
		switch(msg.id)
		{
			case GFX_COMPOSER_MSG_START:
				gfxComposer_onStart(gfxComp, msg.param1);
				break;
			case GFX_COMPOSER_MSG_STOP:
				gfxComposer_onStop(gfxComp);
				break;
			case GFX_COMPOSER_MSG_SET_LAYER_TOP:
				gfxComposer_onSetLayerTopMsg(gfxComp, (GfxLayer) msg.appData);
				break;
			default:
				break;
		}
	}
}

static void gfxComposer_processTask(UArg arg0, UArg arg1)
{
	UInt32 exit = FALSE;
  GfxComposer gfxComp = (GfxComposer) arg0;
	UInt32 events;

  LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Starting Graphic Composer task\r\n", __FUNCTION__);

  while (!exit) 
  {
		/* check if the display is started */
		if ((GFX_COMPOSER_STOPPED != gfxComp->currentState) &&
				!Display_isStarted(gfxComp->displayInst))
		{
			/* The display module is not started, we need to generate
			 * software vsync until we reach the minimum number of priming buffers
			 */

			/* Simulate a vsync interval */
			Task_sleep_ms(16);

			/* Post a SW vsync event */
			Event_post(gfxComp->vSyncEvent, GFX_COMPOSER_EVENT_VSYNC);
		}

		/* wait for vsync */
		events = Event_pend(gfxComp->vSyncEvent,
												Event_Id_NONE, 
												GFX_COMPOSER_EVENT_NEW_MSG + GFX_COMPOSER_EVENT_VSYNC, 
												BIOS_WAIT_FOREVER);
	
		/* Check if we got a vsync event */
		if (events & GFX_COMPOSER_EVENT_VSYNC)
		{
			/* process vsync event */
			gfxComposer_processVsync(gfxComp);
		}

		/* Check if we got a new message */
		if (events & GFX_COMPOSER_EVENT_NEW_MSG)
		{
			/* Process new message */
			gfxComposer_processMessage(gfxComp);
		}

		/* Check if we can start the display */
		if (!Display_isStarted(gfxComp->displayInst) && 
				Display_canStart(gfxComp->displayInst))
		{
			/* Start display */
			Display_start(gfxComp->displayInst);
			LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Display started\r\n", __FUNCTION__);
		}

		/* Check if we need to stop the display */
		if ((GFX_COMPOSER_STOPPED == gfxComp->currentState) && 
				Display_isStarted(gfxComp->displayInst))
		{
			UInt8 globalAlpha;

			Display_getGlobalAlpha(gfxComp->displayInst, &globalAlpha);
			if (0 == globalAlpha)
			{
				/* We reach the end of the fade out animation
			 	* We can stop the display */
				Display_stop(gfxComp->displayInst);

				/* reset graphic queue */
				gfxComposer_resetQueues(gfxComp);

				gfxComp->isStarted = FALSE;
				LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Display stopped\r\n", __FUNCTION__);
			}
		}
	}
}

static Int32 gfxComposer_displayCallback(Fvid2_Handle handle, Ptr appData, Ptr reserved)
{
	Int32 retVal = FVID2_SOK;
  GfxComposer gfxComp = (GfxComposer) appData;
	Fvid2_FrameList frmList;

	LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s()\r\n", __FUNCTION__);
	
	Fvid2FrameList_init(&frmList);
	/* get displayed frame from display */
	retVal = Display_dequeueBuffer(gfxComp->displayInst, &frmList);
	if (FVID2_SOK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to get frame from display (%d)\r\n", __FUNCTION__, retVal);
	}
	else if (frmList.numFrames)
	{
		/* we got a valid frame */
		LOG_PRINT_SVER(DEBUG_GFX_COMP, "%s(): Got frame at %p\r\n", __FUNCTION__, frmList.frames[0]);

		/* push frame to composer done queue */
		retVal = BspUtils_quePut(&gfxComp->qHandle[Q_COMP_DONE], (Ptr) frmList.frames[0], BIOS_WAIT_FOREVER);
		if (BSP_SOK != retVal)
		{
			LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to push frame to composer done queue\r\n", __FUNCTION__);
		}
	}
  else
  {
    LOG_PRINT_ERR(DEBUG_GFX_COMP, "(%s) [%d]: Display_dequeueBuffer() returned but frmList.numFrames == 0 !\r\n", __FUNCTION__, __LINE__);
  }

	Event_post(gfxComp->vSyncEvent, GFX_COMPOSER_EVENT_VSYNC);

	return retVal;
}

static uint8_t gfxComposer_isSlotValid(Int32 slot)
{
  return slot > GFX_COMPOSER_INVALID_SLOT;
}

static Int32 gfxComposer_initModules(GfxComposer gfxComp)
{
	Int32 retVal;
	Fvid2_CbParams cbParams;

  /* Initialize display driver */
	Fvid2CbParams_init(&cbParams);
  cbParams.cbFxn = &gfxComposer_displayCallback;
  cbParams.appData = gfxComp;
  retVal = Display_init(&gfxComp->displayInst, cbParams);
	if (FVID2_SOK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Display driver initialization failed!!\r\n", __FUNCTION__);
		return retVal;	
	}
	Display_setGlobalAlpha(gfxComp->displayInst, 0x0);

	return E_OK;
}

static Int32 gfxComposer_initVideoDrivers(GfxComposer gfxComp)
{
	Int32 retVal = E_ERROR;
	UInt32 reg;
	BspOsal_InitParams_t bspOsalInitPrms = {0};
	Vps_InitParams vpsInitPrms;

	/** Initialize video heap manager module */
	retVal = VideoHeap_init();
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Video Heap Initialization failed!!\r\n", __FUNCTION__);
		return retVal;
	}

	/** Initialize video dma module */
  retVal = VideoDMA_init();
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Video DMA Initialization failed!!\r\n", __FUNCTION__);
		return retVal;
	}

  /* Wake up VIP module */
  HW_WR_REG32(0x6A009000, 0x02U);
  HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CAM_CM_CORE_BASE + CM_CAM_VIP1_CLKCTRL, 0x01U);
  
  /* Wake up VPE module */
  HW_WR_REG32(0x6A005760, 0x02U);
  HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_VPE_CM_CORE_AON_BASE  + CM_VPE_VPE_CLKCTRL, 0x01U);

  /* Wakeup DSS module */
  HW_WR_REG32(0x6A009100, 0x02U);
  LOG_PRINT_INFO(DEBUG_GFX_COMP, "CM_DSS_CLKSTCTRL = 0x%x\n", reg);

  reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE + CTRL_CORE_CONTROL_IO_2);
  HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_CTRL_MODULE_CORE_CORE_REGISTERS_BASE + CTRL_CORE_CONTROL_IO_2 , (reg | 0x01U));

  reg = HW_RD_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_DSS_CM_CORE_BASE + CM_DSS_DSS_CLKCTRL);
  HW_WR_REG32(L4_REGISTER_ADDRESS_OFFSET + SOC_DSS_CM_CORE_BASE + CM_DSS_DSS_CLKCTRL, ((reg & ~0x00000003) | 0x00003F00 | 0x02));

	/* Initialize BspOsal */
  LOG_PRINT_INFO(DEBUG_GFX_COMP, "Initializing BspOsal...\n");
  BspOsal_Init(&bspOsalInitPrms);

	/* Initialize Fvid2 framework */
  LOG_PRINT_INFO(DEBUG_GFX_COMP, "Initializing Fvid2...\n");
  retVal = Fvid2_init(NULL);
  if (BSP_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_GFX_COMP, "Error: FVID2 Init failed!!(%d)\r\n", retVal);
		return retVal;
  }

	/* Initialize VPS driver */
	LOG_PRINT_INFO(DEBUG_GFX_COMP, "Initializing VPS...\n");
  VpsInitParams_init(&vpsInitPrms);
  /* Map virtual addresses to physical addresses */
	vpsInitPrms.isAddrTransReq = TRUE;
  vpsInitPrms.virtBaseAddr   = IPU_RAM_BASE_ADDR;
  vpsInitPrms.physBaseAddr   = PHY_RAM_BASE_ADDR;
  retVal = Vps_init(&vpsInitPrms);
  if (BSP_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_GFX_COMP, "Error: VPS Init failed!!\r\n");
		return retVal;
  }

	return E_OK;
}


static Int32 gfxComposer_createProcessTask(GfxComposer gfxComp)
{
  Error_Block eb;
  Task_Params taskParams;
  Task_Handle taskHandle;

  Error_init(&eb);

  /* create main thread (interrupts not enabled in main on BIOS) */
  Task_Params_init(&taskParams);
  taskParams.instance->name = "gfxComp";
  taskParams.arg0 = (xdc_UArg) gfxComp;
  taskParams.stackSize = GFX_COMPOSER_TASK_STACK_SIZE;
  taskParams.stack = stack;
  taskParams.affinity = VIDEO_CORE_NUM;
 
  taskHandle = Task_create(gfxComposer_processTask, &taskParams, &eb);
  if (NULL == taskHandle)
  {
    LOG_PRINT_ERR(DEBUG_GFX_COMP, "Couldn't create graphic composer processing task\n");
    return FVID2_EFAIL;
  }
  
  LOG_PRINT_INFO(DEBUG_GFX_COMP, "Graphic composer processing task created successfully\n");
  gfxComp->procHandle = taskHandle;

  return FVID2_SOK;
}

static Int32 gfxComposer_initMailbox(GfxComposer gfxComp)
{
	Mailbox_Params mboxParams;
	Error_Block eb;

	Error_init(&eb);
	LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Creating Event object\r\n", __FUNCTION__);
	gfxComp->vSyncEvent = Event_create(NULL, &eb);
	if (NULL == gfxComp->vSyncEvent)
	{
		LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to create vsync event\r\n", __FUNCTION__);
		System_abort("GfxComposer vsync event creation failed\r\n");
	}

	LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): Creating message mailbox\r\n", __FUNCTION__);
	Mailbox_Params_init(&mboxParams);
	mboxParams.readerEvent = gfxComp->vSyncEvent;
	mboxParams.readerEventId = GFX_COMPOSER_EVENT_NEW_MSG;
	gfxComp->msgMailbox = Mailbox_create(sizeof(GfxComposerMessage), 10, &mboxParams, &eb);
  if (NULL == gfxComp->msgMailbox)
	{
		LOG_PRINT_ERR(DEBUG_GFX_COMP, "%s(): Unable to create message mailbox\r\n", __FUNCTION__);
		System_abort("GfxComposer message mailbox creation failed");
	}

	return E_OK;
}

static Int32 gfxComposer_initQueues(GfxComposer gfxComp)
{
	Int32 retVal = E_OK;
	UInt32 i, j;
  UInt32 displayWidth, displayHeight;

  Display_getResolution(gfxComp->displayInst,
                        &displayWidth,
                        &displayHeight);

	/* Create composed frame queue */
	retVal = BspUtils_queCreate(&gfxComp->qComposedFrames, 
			                        GFX_COMPOSER_MAX_FRAMES, 
															gfxComp->qDataComposedFrames, 
															BSPUTILS_QUE_FLAG_NO_BLOCK_QUE); 

	/* Initialize composed frame queue */
	for(i = 0; i < sizeof(gfxComp->composedFrames) / sizeof(gfxComp->composedFrames[0]); i++)
	{
    Fvid2Frame_init((Fvid2_Frame*)&gfxComp->composedFrames[i].frame);
		gfxComp->composedFrames[i].frame.addr[0][0] = DA_TO_PHY_ADDR((UInt8 *) VideoHeap_allocFrame(displayWidth, displayHeight, 4));
    for (j = 0; j < displayWidth * displayHeight; j++)
    {
      *((UInt32 *) (PHY_TO_DA_ADDR(gfxComp->composedFrames[i].frame.addr[0][0]) + (j * 4))) = 0xFF000000;
    }
    Cache_wbInv(gfxComp->composedFrames[i].frame.addr[0][0], displayWidth * displayHeight * 4, Cache_Type_ALL, TRUE);
		gfxComp->composedFrames[i].numRelatedFrames = 0;
    LOG_PRINT_INFO(DEBUG_GFX_COMP, "(%s) [%d]: Queueing qComposedFrame  @ %p \r\n", __FUNCTION__, __LINE__, &gfxComp->composedFrames[i]);
		BspUtils_quePut(&gfxComp->qComposedFrames, &gfxComp->composedFrames[i], BIOS_NO_WAIT);
	}

	/* Create frame info queue */
	retVal = BspUtils_queCreate(&gfxComp->qGfxFrames, 
			                        GFX_MAX_FRAMES, 
															gfxComp->qDataGfxFrames, 
															BSPUTILS_QUE_FLAG_NO_BLOCK_QUE); 

	/* Initialize frame info queue */
	for(i = 0; i < sizeof(gfxComp->gfxFrames) / sizeof(gfxComp->gfxFrames[0]); i++)
	{
		Fvid2Frame_init((Fvid2_Frame*)&gfxComp->gfxFrames[i].frame);
		gfxComp->gfxFrames[i].producer = NULL;
		gfxComp->gfxFrames[i].credit = 0;

		BspUtils_quePut(&gfxComp->qGfxFrames, &gfxComp->gfxFrames[i], BIOS_NO_WAIT);
	}

	/* Create streams queues */
	for(i = 0; i < GFX_COMP_QUEUE_NUM; i++)
	{
		UInt32 flags;

		// flags = BSPUTILS_QUE_FLAG_NO_BLOCK_QUE;
    flags = BSPUTILS_QUE_FLAG_BLOCK_QUE;
		
		/* Create Queue */
  	retVal = BspUtils_queCreate(&gGfxComposer.qHandle[i], 
                              GFX_STREAM_QUEUE_SIZE, 
                              gGfxComposer.qData[i], 
                              flags);
  	if (BSP_SOK != retVal)
  	{
    	LOG_PRINT_ERR(DEBUG_GFX_COMP, "Queue ID %d creation failed!!\r\n", i);
    	break;
  	}
	}

	return retVal;
}

static Int32 gfxComposer_resetQueues(GfxComposer gfxComp)
{
	UInt32 i;
	Ptr tmp;

	/* Empty queue */
	while(!BspUtils_queGet(&gfxComp->qComposedFrames, &tmp, 1, BIOS_NO_WAIT))
		;
	
	/* Initialize composed frame queue */
	for(i = 0; i < sizeof(gfxComp->composedFrames) / sizeof(gfxComp->composedFrames[0]); i++)
	{
    UInt32 displayWidth, displayHeight;

    Display_getResolution(gfxComp->displayInst, &displayWidth, &displayHeight);

		gfxComp->composedFrames[i].numRelatedFrames = 0;
		memset(PHY_TO_DA_ADDR((UInt8 *) gfxComp->composedFrames[i].frame.addr[0][0]), 0, displayWidth * displayHeight * 4);
		BspUtils_quePut(&gfxComp->qComposedFrames, &gfxComp->composedFrames[i], BIOS_NO_WAIT);
	}

	return E_OK;
}

Int32 GfxComposer_init(GfxComposer *gfxComp, gfx_composer_focus_gained_callback callback, void *context)
{
  UInt32 displayWidth, displayHeight;
  UInt32 i;
  Int32 retVal = E_ERROR;
	Semaphore_Params semPrms;

  LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s()\r\n", __FUNCTION__);

  /* Check for input parameter */
  if (NULL == gfxComp) 
    return retVal;

  /* return current object instance */
  *gfxComp = &gGfxComposer;

  /* Initialize LVDS */
  GPIOModuleEnable(VIDEO_LVDS_EN_GPIO_ADDR);
  GPIODirModeSet(VIDEO_LVDS_EN_GPIO_ADDR, VIDEO_LVDS_EN_GPIO_PIN, GPIO_DIR_OUTPUT);

  gfxComposer_SetLvdsEnable(true);
	RvcManager_initGpios();

  /* Initialize internal variables */
  gGfxComposer.isInitialized = FALSE;
	gGfxComposer.isStarted = FALSE;
	gGfxComposer.currentState = GFX_COMPOSER_STOPPED;
  gGfxComposer.numLayers = 0;
	gGfxComposer.currentFocusSlot = GFX_COMPOSER_INVALID_SLOT;
	gGfxComposer.focusGainedCb = callback;
	gGfxComposer.focusGainedContext = context;

  /* Initialize video low level drivers and framework */
	retVal = gfxComposer_initVideoDrivers(*gfxComp);
	if (E_OK != retVal)
	{
		return retVal;
	}

	/* Initialize messages mailbox */
	retVal = gfxComposer_initMailbox(*gfxComp);

	/* Initialize streams queues */
	retVal = gfxComposer_initQueues(*gfxComp);
	if (E_OK != retVal)
	{
		return retVal;
	}

	/* Initialize video and graphic modules */
	retVal = gfxComposer_initModules(*gfxComp);
	if (E_OK != retVal)
	{
		return retVal;
	}

	/* Create blender used for composition */
	GfxBlenderParams blenderParams;
	GfxBlenderParams_init(&blenderParams);
	
	Display_getResolution((*gfxComp)->displayInst, 
				                &blenderParams.displayFrameParams.width,
												&blenderParams.displayFrameParams.height);

	blenderParams.displayFrameParams.bpp = 4;
	blenderParams.displayFrameParams.stride = blenderParams.displayFrameParams.width * blenderParams.displayFrameParams.bpp;
	retVal = GfxBlender_create(&(*gfxComp)->blender, &blenderParams);

  /* Initialize full opaque frame */
  Display_getResolution((*gfxComp)->displayInst,
                        &displayWidth,
                        &displayHeight);

  Fvid2Frame_init((Fvid2_Frame*)&gGfxComposer.opaqueFrame);
	gGfxComposer.opaqueFrame.addr[0][0] = DA_TO_PHY_ADDR((UInt8 *) VideoHeap_allocFrame(displayWidth, displayHeight, 4));
  for (i = 0; i < displayWidth * displayHeight; i++)
  {
    *((UInt32 *) (PHY_TO_DA_ADDR(gGfxComposer.opaqueFrame.addr[0][0]) + (i * 4))) = 0xFF000000;

  }

	gGfxComposer.curRvcFrm = NULL;
	
	/* Create semaphore */
	Semaphore_Params_init(&semPrms);
	gGfxComposer.vSyncSem = Semaphore_create(0, &semPrms, NULL);

	/* Create process task */
	gfxComposer_createProcessTask(*gfxComp);

  /* now that we have everything in place
   * update the initialization flag
   */
  gGfxComposer.isInitialized = TRUE;

  return retVal;
}

Int32 GfxComposer_start(GfxComposer gfxComp, bool_t fade_in)
{
  Int32 retVal = E_OK;

  /* Check input parameters */
  if (NULL == gfxComp)
    return E_ERROR;

  /* Check if the module is initialized */
  if (!gfxComp->isInitialized)
    return E_ERROR;

	GfxComposerMessage msg;
	msg.id = GFX_COMPOSER_MSG_START;
	msg.appData = gfxComp;
  msg.param1 = fade_in;

	retVal = Mailbox_post(gfxComp->msgMailbox, &msg, BIOS_WAIT_FOREVER);

  return retVal;
}

Int32 GfxComposer_stop(GfxComposer gfxComp)
{
  Int32 retVal = E_OK;

  /* Check input parameters */
  if (NULL == gfxComp)
    return E_OK;

  /* Check if the module is initialized */
  if (!gfxComp->isInitialized)
    return E_ERROR;

	GfxComposerMessage msg;
	msg.id = GFX_COMPOSER_MSG_STOP;
	msg.appData = gfxComp;

	retVal = Mailbox_post(gfxComp->msgMailbox, &msg, BIOS_WAIT_FOREVER) ? E_OK : E_ERROR;

  return retVal;
}

Int32 GfxComposer_getInstance(GfxComposer *gfxComposer)
{
	/* Check if the module is initialized */
	if (!gGfxComposer.isInitialized)
	{
		/* The module is not initialized. Can't return instance */
		return E_ERROR;
	}

	/* return current instance */
	*gfxComposer = &gGfxComposer;

	return E_OK;
}

Int32 GfxComposer_addLayer(GfxComposer gfxComposer, GfxLayer layer)
{
	UInt32 slot;

	/* Check input parameters */
	if ((NULL == gfxComposer) || (NULL == layer))
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* Check if the module is initialized */
	if (!gGfxComposer.isInitialized)
	{
		/* The module is not initialized. Can't add a layer */
		return E_ERROR;
	}

	/* Check if we have room for the new layer*/
	if (GFX_COMPOSER_MAX_LAYERS <= gfxComposer->numLayers)
	{
		/* there is no more room for layers */
		return E_ERROR;
	}

	/* Add new layer */
	slot = gfxComposer->numLayers;
	gfxComposer->layers[slot] = layer;
	gfxComposer->numLayers++;

	LOG_PRINT_INFO(DEBUG_GFX_COMP, "%s(): layer %p added to slot %d\r\n", __FUNCTION__, layer, slot);

	return E_OK;
}

Int32 GfxComposer_getBlender(GfxComposer gfxComposer, GfxBlender *gfxBlender)
{
	Int32 retVal = E_OK;

	/* Check input parameters */
	if ((NULL == gfxComposer) || (NULL == gfxBlender))
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* Check if the module is initialized */
	if (!gGfxComposer.isInitialized)
	{
		/* The module is not initialized. Can't add a layer */
		return E_ERROR;
	}

	*gfxBlender = gfxComposer->blender;

	return retVal;
}

Int32 GfxComposer_setTopMostLayer(GfxComposer gfxComposer, GfxLayer layer)
{
	/* Check input parameters */
	if ((NULL == gfxComposer) || (NULL == layer))
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* Check if the module is initialized */
	if (!gGfxComposer.isInitialized)
	{
		/* The module is not initialized. Can't add a layer */
		return E_ERROR;
	}

	GfxComposerMessage msg;
	msg.id = GFX_COMPOSER_MSG_SET_LAYER_TOP;
	msg.appData = layer;

	Mailbox_post(gfxComposer->msgMailbox, &msg, BIOS_WAIT_FOREVER);

	return E_OK;
}

bool_t GfxComposer_isStarted(GfxComposer gfxComposer)
{
	/* Check input parameters */
	if (NULL == gfxComposer)
	{
		return FALSE;
	}

	return (GFX_COMPOSER_STOPPED != gfxComposer->currentState);
}

bool_t GfxComposer_isStarting(GfxComposer gfxComposer)
{
  /* Check input parameters */
	if (NULL == gfxComposer)
	{
		return FALSE;
	}

	return (GFX_COMPOSER_STARTING == gfxComposer->currentState);
}
