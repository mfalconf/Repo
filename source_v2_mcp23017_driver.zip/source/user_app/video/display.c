/******************************************************************************
 *
 * \file    display.c
 *
 * \brief   Display module source file
 *
 * \author  Esteban Pupillo
 * \author  Augusto Santini
 *
 * \date    27 Jun 2022
 *
 *****************************************************************************/
#include <standard.h>
#include <xdc/std.h>
#include "display.h"
#include "console.h"

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <ti/drv/vps/include/devices/bsp_lcdController.h>
#include <ti/drv/vps/include/platforms/bsp_platform.h>

#if defined PRODUCT_VOLKSWAGEN
#include <displays/9inches_4D_display_cfg.h>
// Place other display definitions here depending on the product
// #elif defined PRODUCT_OTHER
// #include <displays/...>
#else
#error  "No product is defined!"
#endif

/**
 * @addtogroup Display
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DISPLAY_TASK_STACK_SIZE   (0x1000)

#define DEBUG_DISPLAY    0

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

typedef struct plane_cfg_tag {
  UInt32 planeId;
  UInt32 width;
  UInt32 height;
  UInt32 posX;
  UInt32 posY;
  UInt32 dataFormat;
  UInt32 scanFormat;
} PlaneCfg;

struct display_tag {
  bool_t isInitialized;
	bool_t isStarted;
	UInt8 globalAlpha;
	UInt32 framesInQueue;
  Fvid2_Handle dispCtrlHandle;
  Fvid2_Handle dispHandle;
  UInt32 dispOutputPort;
  Bsp_LcdCtrlPanelInfo lcdCtrlPanelInfo;
  Vps_DssDispcGammaConfig gammaCfg;
  PlaneCfg planeCfg; 
  Semaphore_Handle newFrameSem;
  Task_Handle procHandle;
  Fvid2_Frame frames[DISPLAY_MAX_FRAMES];
  Fvid2_CbParams userCbPrms;
	Semaphore_Handle lockSem;
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static struct display_tag gDisplay = {
  /* isInitialized */
  FALSE,

	/* isStarted */
	FALSE,

	/* globalAlpha */
	0x0,

	/* framesInQueue */
	0,

  /* discpCtrlHandle */
  NULL,

  /* dispHandle */
  NULL,

  /* dispOutputPort */
  DISPLAY_OUTPUT_PORT,

  /* lcdCtrlPanelInfo */
  {
    /* modeInfo */
    {
      /* standard */
      FVID2_STD_CUSTOM,

      /* width */
      DISPLAY_LCD_WIDTH,

      /* height */
      DISPLAY_LCD_HEIGHT,

      /* scanFormat */
      DISPLAY_SCAN_FORMAT,

      /* pixelClk */
      DISPLAY_PIXEL_CLK,

      /* fps */
      DISPLAY_FRAME_RATE,

      /* hFrontPorch */
      DISPLAY_H_FRONT_PORCH,

      /* hBackPorch */
      DISPLAY_H_BACK_PORCH,

      /* hSyncLen */
      DISPLAY_H_SYNC_LENGTH,

      /* vFrontPorch */
      DISPLAY_V_FRONT_PORCH,

      /* vBackPorch */
      DISPLAY_V_BACK_PORCH,

      /* vSyncLen */
      DISPLAY_V_SYNC_LENGTH
    },

    /* videoIfWidth */
    FVID2_VIFW_24BIT,

    /* videoDataFormat */
    FVID2_DF_RGB24_888,

    /* videoIfMode */
    DISPLAY_MODE,

    /* vsPolarity */
    FVID2_POL_LOW,

    /* hsPolarity */
    FVID2_POL_LOW,

    /* actVidPolarity */
    FVID2_POL_HIGH,

    /* fidPolarity */
    FVID2_POL_HIGH,

    /* pixelClkPolarity */
    DISPLAY_CLK_POLARITY
  },

  /* gammaCfg */
  {
    /* vencId */
    DISPLAY_OUTPUT_PORT,

    /* enableGammaCorrection */
    TRUE,

    /* size */
    sizeof(gGammaEntries) / sizeof(gGammaEntries[0]),

    /* table entries */
    gGammaEntries
  },

  /* planeCfg */
  {
    /* planeId */
    DISPLAY_IPU_PLANE,

    /* width */
    DISPLAY_LCD_WIDTH,

    /* height */
    DISPLAY_LCD_HEIGHT,

    /* posX */
    DISPLAY_PLANE_XPOS,

    /* posY */
    DISPLAY_PLANE_YPOS,

    /* dataFormat */
    DISPLAY_PLANE_DATA_FORMAT,

    /* scanFormat */
    DISPLAY_PLANE_SCAN_FORMAT
  }
};

static uint8_t stack[DISPLAY_TASK_STACK_SIZE];

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

static Int32 display_callback(Fvid2_Handle handle, Ptr appData, Ptr reserved)
{
  Display display = (Display) appData;

  /* New frame request. Unblock procesing task */
  Semaphore_post(display->newFrameSem);

  return FVID2_SOK;
}

static Int32 display_updatePipelineParams(Display display)
{
	Int32 retVal;

	LOG_PRINT_INFO(DEBUG_DISPLAY, "%s(): Updating pipeline alpha to %d\r\n", __FUNCTION__, display->globalAlpha);

	/* Configure DSS pipes */
  Vps_DssDispcOvlyPipeConfig ovlPipeCfg;
  ovlPipeCfg.pipeLine = display->planeCfg.planeId;
  ovlPipeCfg.globalAlpha = display->globalAlpha;
  ovlPipeCfg.zorder = 3;
  ovlPipeCfg.zorderEnable = 1;
  ovlPipeCfg.preMultiplyAlpha = 0;
  retVal = Fvid2_control(display->dispCtrlHandle, 
                         IOCTL_VPS_DCTRL_SET_PIPELINE_PARAMS, 
                         &ovlPipeCfg, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: DCTRL Set Pipeline Parameters IOCTL failed!!\r\n");
  }

	return retVal;
}


static Int32 display_configDctrl(Display display)
{
  Int32 retVal;
  Vps_DctrlConfig dctrlCfg;
  Vps_DssDispcOvlyPanelConfig panelCfg;
  Fvid2_ModeInfo *mInfo;
  Vps_DctrlVencDivisorInfo vencDivisors;
  Vps_DctrlOutputInfo vencOutput;
  Bsp_PlatformSetPllFreq vPllCfg;
  Bsp_PlatformVencSrc vencClkCfg;

  /* Configure video encoder ouptput */
  vencOutput.vencId = display->dispOutputPort;
  vencOutput.actVidPolarity = display->lcdCtrlPanelInfo.actVidPolarity;
  vencOutput.pixelClkPolarity = display->lcdCtrlPanelInfo.pixelClkPolarity;
  vencOutput.dvoFormat = VPS_DCTRL_DVOFMT_GENERIC_DISCSYNC;
  vencOutput.hsPolarity = display->lcdCtrlPanelInfo.hsPolarity;
  vencOutput.vsPolarity = display->lcdCtrlPanelInfo.vsPolarity;
  vencOutput.dataFormat = display->lcdCtrlPanelInfo.videoDataFormat;
  vencOutput.videoIfWidth = display->lcdCtrlPanelInfo.videoIfWidth;

  retVal = Fvid2_control(display->dispCtrlHandle, 
                         IOCTL_VPS_DCTRL_SET_VENC_OUTPUT, 
                         &vencOutput, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: DCTRL set Venc Ouptput IOCTL failed!!\r\n");
  }

	/* Configure pixel clock polarity */
	Bsp_platformSetLcdClkPolarity(DISPLAY_BSP_OUTPUT_PORT, display->lcdCtrlPanelInfo.pixelClkPolarity);

  /* Configure disp ctrl */
  VpsDctrlConfig_init(&dctrlCfg);
  dctrlCfg.useCase = VPS_DCTRL_USERSETTINGS;
  dctrlCfg.numEdges = 0U;

  /* we are only support LCD3 output */
  if (VPS_DCTRL_DSS_VENC_LCD3 != display->dispOutputPort)
  {
    return FVID2_EBADARGS;
  }
  
  /* connect pane input path with corresponding blender */
  dctrlCfg.edgeInfo[dctrlCfg.numEdges].startNode = VPS_DCTRL_DSS_VID3_INPUT_PATH;
  dctrlCfg.edgeInfo[dctrlCfg.numEdges].endNode = VPS_DCTRL_DSS_LCD3_BLENDER;
  dctrlCfg.numEdges++;

  /* connect blender output with the corresponding parallel display port */
  dctrlCfg.edgeInfo[dctrlCfg.numEdges].startNode = VPS_DCTRL_DSS_LCD3_BLENDER;
  dctrlCfg.edgeInfo[dctrlCfg.numEdges].endNode = VPS_DCTRL_DSS_DPI3_OUTPUT;
  dctrlCfg.numEdges++;

  /* we are using just one output encoder */
  dctrlCfg.vencInfo.numVencs = 1U;

  /* configure operational mode */
  dctrlCfg.vencInfo.modeInfo[0U].vencId = VPS_DCTRL_DSS_VENC_LCD3;
  dctrlCfg.vencInfo.modeInfo[0U].mInfo.standard = display->lcdCtrlPanelInfo.modeInfo.standard;
 
  /* copy custom LCD configurations */
  mInfo = &dctrlCfg.vencInfo.modeInfo[0U].mInfo;
  if (FVID2_STD_CUSTOM == display->lcdCtrlPanelInfo.modeInfo.standard)
  {
    memcpy(mInfo, &display->lcdCtrlPanelInfo.modeInfo, sizeof(Fvid2_ModeInfo));
  }
  
  dctrlCfg.vencInfo.tiedVencs = 0U;

  /* configure display control module */
  retVal = Fvid2_control(display->dispCtrlHandle, 
                         IOCTL_VPS_DCTRL_SET_CONFIG, 
                         &dctrlCfg, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: DCTRL set Config IOCTL failed!!\r\n");
  }


  /* Configure Overlay Manager */
  panelCfg.vencId = display->dispOutputPort;
  panelCfg.colorKeyEnable = 0;
  panelCfg.colorKeySel = 0;
  panelCfg.deltaLinesPerPanel = 0;
  panelCfg.transColorKey = 0;
  panelCfg.backGroundColor = 0x0; //0x0000FF00U;
  panelCfg.alphaBlenderEnable = 0;
  panelCfg.ovlyOptimization = 0;

  retVal = Fvid2_control(display->dispCtrlHandle, 
                         IOCTL_VPS_DCTRL_SET_OVLY_PARAMS, 
                         &panelCfg, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: DCTRL Set Overlay Parameters IOCTL failed!!\r\n");
  }

  /* Configure DSS pipes */
  Vps_DssDispcOvlyPipeConfig ovlPipeCfg;
  ovlPipeCfg.pipeLine = display->planeCfg.planeId;
  ovlPipeCfg.globalAlpha = display->globalAlpha;
  ovlPipeCfg.zorder = 3;
  ovlPipeCfg.zorderEnable = 1;
  ovlPipeCfg.preMultiplyAlpha = 0;
  retVal = Fvid2_control(display->dispCtrlHandle, 
                         IOCTL_VPS_DCTRL_SET_PIPELINE_PARAMS, 
                         &ovlPipeCfg, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: DCTRL Set Pipeline Parameters IOCTL failed!!\r\n");
  }

  /* Configure PLLs and clocks */
  vencDivisors.vencId = display->dispOutputPort;
  vencDivisors.divisorLCD = 1;
  vencDivisors.divisorPCD = 3;
  retVal = Fvid2_control(display->dispCtrlHandle, 
                         IOCTL_VPS_DCTRL_SET_VENC_PCLK_DIVISORS, 
                         &vencDivisors, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: DCTRL Set venc Clock divisors IOCTL failed!!\r\n");
  }
 

  /* configure video1 pll */
  vPllCfg.videoPll = BSP_PLATFORM_PLL_VIDEO1;
  vPllCfg.pixelClk = display->lcdCtrlPanelInfo.modeInfo.pixelClock * vencDivisors.divisorPCD;
  vPllCfg.chooseMaxorMinMN = (UInt32) BSP_PLATFORM_VIDEO_PLL_CALC_MAX_MN;
  
  do {
 
    vPllCfg.pixelClk = display->lcdCtrlPanelInfo.modeInfo.pixelClock * vencDivisors.divisorPCD;

  LOG_PRINT_INFO(DEBUG_DISPLAY, "Trying pixelClk = %d, dispClk=%d\r\n", vPllCfg.pixelClk, display->lcdCtrlPanelInfo.modeInfo.pixelClock);
  retVal = Bsp_platformSetPllFreq(&vPllCfg);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: Video PLL configuration failed(%d)!!\r\n", retVal);
    display->lcdCtrlPanelInfo.modeInfo.pixelClock++; 
  }
  } while(FVID2_SOK != retVal);


  if (VPS_DCTRL_DSS_VENC_LCD3 == display->dispOutputPort)
  {
    vencClkCfg.outputVenc = BSP_PLATFORM_VENC_LCD3;
    vencClkCfg.vencClkSrc = BSP_PLATFORM_CLKSRC_DPLL_VIDEO1_CLKOUT3;
  }
  retVal = Bsp_platformSetVencClkSrc(&vencClkCfg);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: Setting Venc clock source failed!!\r\n");
  }

  /* Configure Gamma table */
  retVal = Fvid2_control(display->dispCtrlHandle, 
                         IOCTL_VPS_DCTRL_SET_GAMMA_PARAM, 
                         &display->gammaCfg, NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: Setting gamma table failed!!\r\n");
  }
  
  return retVal;
}


static Int32 display_configDss(Display display)
{
  Int32 retVal;
  Vps_DispCreateParams createParams;
  Vps_DispCreateStatus createStatus;
  Fvid2_CbParams cbParams;

  Vps_DispDssParams dssParams;
  Vps_DssDispcVidConfig dssDispcVidConfig;

  Vps_DssDispcAdvDmaConfig dssDispcAdvDmaConfig;

  VpsDssDispcAdvDmaConfig_init(&dssDispcAdvDmaConfig);
  dssDispcAdvDmaConfig.arbitration = 1; // High priority for this video plane
  
  VpsDssDispcVidConfig_init(&dssDispcVidConfig);

  dssDispcVidConfig.advDmaCfg = &dssDispcAdvDmaConfig;

  /* initialize dss parameters */
  VpsDispDssParams_init(&dssParams);

  /* we are using just one channel */
  dssParams.inFmt.chNum = 0U;
  dssParams.vidCfg = &dssDispcVidConfig;

  /* we are not scaling the output so
   * input and output sizes are equal
   */
  dssParams.inFmt.width = display->planeCfg.width;
  dssParams.inFmt.height = display->planeCfg.height;

  /* we are only supporting semiplaner data format */
  if (Fvid2_isDataFmtSemiPlanar(display->planeCfg.dataFormat))
  {
    /* for semiplanar formats configure buffer pitch */
    dssParams.inFmt.pitch[FVID2_YUV_SP_Y_ADDR_IDX] = VpsUtils_align(
                      display->planeCfg.width, VPS_BUFFER_ALIGNMENT);
    dssParams.inFmt.pitch[FVID2_YUV_SP_CBCR_ADDR_IDX] = 
                      dssParams.inFmt.pitch[FVID2_YUV_SP_Y_ADDR_IDX];
  }
  else if ((FVID2_DF_ARGB32_8888 == display->planeCfg.dataFormat) ||
           (FVID2_DF_BGRA32_8888 == display->planeCfg.dataFormat))
  {
    /* for 32bit ARGB formats configure buffer pitch */
    dssParams.inFmt.pitch[FVID2_RGB_ADDR_IDX] = VpsUtils_align(
                      display->planeCfg.width * 4, VPS_BUFFER_ALIGNMENT);
  }
	else if (FVID2_DF_BGR24_888 == display->planeCfg.dataFormat)
	{
		/* for 24bit RGB formats configure buffer pitch */
    dssParams.inFmt.pitch[FVID2_RGB_ADDR_IDX] = VpsUtils_align(
                      display->planeCfg.width * 3, VPS_BUFFER_ALIGNMENT);
	}
  else 
  {
    return FVID2_EBADARGS;
  }

 
  /* we are not merging any field */
  dssParams.inFmt.fieldMerged[0U] = FALSE;
  dssParams.inFmt.fieldMerged[1U] = FALSE;
  dssParams.inFmt.fieldMerged[2U] = FALSE;

  /* configure data and scan format */
  dssParams.inFmt.dataFormat = display->planeCfg.dataFormat;
  dssParams.inFmt.scanFormat = display->planeCfg.scanFormat;
  
  /* we are using only 32bits per pixel */
  dssParams.inFmt.bpp = FVID2_BPP_BITS32;

  /* since we are not doing any scaling, 
   * target size is equal to input size
   */
  dssParams.tarWidth = display->planeCfg.width;
  dssParams.tarHeight = display->planeCfg.height;

  /* configure plane position for overlaying */
  dssParams.posX = display->planeCfg.posX;
  dssParams.posY = display->planeCfg.posY;

  /* initialize dss creation parameters */
  VpsDispCreateParams_init(&createParams);
	// createParams.periodicCbEnable = FALSE;

  /* initialize dss callback parameters */
  Fvid2CbParams_init(&cbParams);
  cbParams.cbFxn = display_callback;
  cbParams.appData = display;

  /* create dss driver instance */
  display->dispHandle = Fvid2_create(FVID2_VPS_DISP_DRV,
                        display->planeCfg.planeId,
                        &createParams,
                        &createStatus,
                        &cbParams);
  if ((NULL == display->dispHandle) || (FVID2_SOK != createStatus.retVal))
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: Display creation failed!!\r\n");
    return createStatus.retVal;
  }

  /* set dss parameters */
  retVal = Fvid2_control(display->dispHandle, 
                         IOCTL_VPS_DISP_SET_DSS_PARAMS, 
                         &dssParams, 
                         NULL);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: DSS set Params IOCTL failed!!\r\n");
  }
  
  return retVal;
}

static void display_processTask(UArg arg0, UArg arg1)
{
  UInt32 exit = FALSE;
  Display display = (Display) arg0;
  Fvid2_FrameList frameList;

  LOG_PRINT_INFO(DEBUG_DISPLAY, "Starting display taks\r\n");

  while (!exit) 
  {
    /* Wait till Vsync or frame ready interrupt */
    Semaphore_pend(display->newFrameSem, BIOS_WAIT_FOREVER);

		/* Take object lock */
		Semaphore_pend(display->lockSem, BIOS_WAIT_FOREVER);

		/* Update frame counter */
		if (display->framesInQueue)
			display->framesInQueue--;

		/* Release lock */
		Semaphore_post(display->lockSem);
	
    /* Notify user about ready frames */
    if (NULL != display->userCbPrms.cbFxn)
    {
      (*display->userCbPrms.cbFxn)(NULL, display->userCbPrms.appData, &frameList);
    }
  }
}


static Int32 display_createProcessTask(Display display)
{
  Error_Block eb;
  Task_Params taskParams;
  Task_Handle taskHandle;

  Error_init(&eb);

  /* create main thread (interrupts not enabled in main on BIOS) */
  Task_Params_init(&taskParams);
  taskParams.instance->name = "dispproc";
  taskParams.arg0 = (xdc_UArg) display;
  taskParams.stackSize = DISPLAY_TASK_STACK_SIZE;
  taskParams.stack = stack;
  taskParams.affinity = VIDEO_CORE_NUM;
 
  taskHandle = Task_create(display_processTask, &taskParams, &eb);
  if (NULL == taskHandle)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Couldn't create display processing task\n");
    return FVID2_EFAIL;
  }
  
  LOG_PRINT_INFO(DEBUG_DISPLAY, "display processing task created successfully\n");
  display->procHandle = taskHandle;

  return FVID2_SOK;
}

static Int32 display_create(Display display)
{
  Int32 retVal;
  Semaphore_Params semPrms;

  /* create an intance of the display control driver */
  display->dispCtrlHandle = Fvid2_create(FVID2_VPS_DCTRL_DRV,
                                         VPS_DCTRL_INST_0,
                                         NULL,
                                         NULL,
                                         NULL);
  if (NULL == display->dispCtrlHandle)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "DCTRL Create Failed!!\n");
    return FVID2_EFAIL;
  }

  LOG_PRINT_INFO(DEBUG_DISPLAY, "DISP_CONTROL handler created\n");

  /* configure display control module */
  retVal = display_configDctrl(display); 
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "DCTRL configuration failed!!\n");
    return retVal;
  }

  /* configure dss module */
  retVal = display_configDss(display);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "DSS configuration failed!!\n");
    return retVal;
  }

  /* create new frame request semaphore */
  Semaphore_Params_init(&semPrms);
  display->newFrameSem = Semaphore_create(0, &semPrms, NULL);
  if (NULL == display->newFrameSem)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "New frame request semaphore creation failed!!\r\n");
    return FVID2_EFAIL;
  }

	display->lockSem = Semaphore_create(1, &semPrms, NULL);
	if (NULL == display->lockSem)
	{
		LOG_PRINT_ERR(DEBUG_DISPLAY, "lock semaphore creation failed\r\n");
	}

  /* create processing task */
  retVal = display_createProcessTask(display);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "display processing task creation failed!!\r\n");
    return retVal;
  }
 
  return retVal;
}

/** Public API functions **/

Int32 Display_init(Display *display, Fvid2_CbParams callback)
{
  Int32 retVal = FVID2_EFAIL;

  LOG_PRINT_INFO(DEBUG_DISPLAY, "%s()\r\n", __FUNCTION__);

  /* Check for input parameter */
  if (NULL == display) 
    return FVID2_EBADARGS;

  /* return current object instance */
  *display = &gDisplay;

  /* Initialize internal variables */
  gDisplay.isInitialized = FALSE;
	gDisplay.isStarted = FALSE;
	gDisplay.framesInQueue = 0;

  /* Create a local copy of user callback object */
  memcpy(&gDisplay.userCbPrms, &callback, sizeof(callback));

  /* Create display control driver instance */
  retVal = display_create(*display);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Display driver creation failed!!\r\n");
    return retVal;
  }

  /* now that we have everything in place
   * update the initialization flag
   */
  gDisplay.isInitialized = TRUE;

  return retVal;
}

Int32 Display_start(Display display)
{
  Int32 retVal = FVID2_SOK;

  /* Check input parameters */
  if (NULL == display)
    return FVID2_EBADARGS;

	/* Take object lock */
	Semaphore_pend(display->lockSem, BIOS_WAIT_FOREVER);

  /* Check if the module is initialized */
  if (!display->isInitialized)
    return FVID2_EFAIL;

	if (!display->isStarted)
	{
  	/* Send start command to driver */
  	retVal = Fvid2_start(display->dispHandle, NULL);
  	if (FVID2_SOK != retVal)
  	{
    	LOG_PRINT_ERR(DEBUG_DISPLAY, "Unable to start display pipeline\r\n");
			return retVal;
  	}
		display->isStarted = TRUE;
	}

	/* Release lock */
	Semaphore_post(display->lockSem);

   return retVal;
}

Int32 Display_stop(Display display)
{
  Int32 retVal = FVID2_SOK;
	Fvid2_FrameList frameList;

  /* Check input parameters */
  if (NULL == display)
    return FVID2_EBADARGS;

	/* Take object lock */
	Semaphore_pend(display->lockSem, BIOS_WAIT_FOREVER);

  /* Check if the module is initialized */
  if (!display->isInitialized)
    return FVID2_EFAIL;

	if (display->isStarted)
	{
  	/* Send stop command to driver */
  	retVal = Fvid2_stop(display->dispHandle, NULL);
  	if (FVID2_SOK != retVal)
  	{
    	LOG_PRINT_ERR(DEBUG_DISPLAY, "Unable to stop display pipeline\r\n");
  		return retVal;
		}

		/* dequeue all buffers from driver */
		while(retVal != FVID2_ENO_MORE_BUFFERS)
		{
			retVal = Fvid2_dequeue(display->dispHandle, &frameList, 0, FVID2_TIMEOUT_NONE);
			LOG_PRINT_INFO(DEBUG_DISPLAY, "%s(): dequeued %d buffers from display device\r\n", __FUNCTION__, frameList.numFrames);
		}
  
		display->framesInQueue = 0;
		display->isStarted = FALSE;
	}

	/* Release lock */
	Semaphore_post(display->lockSem);

  return retVal;
}

Int32 Display_queueBuffer(Display display, Fvid2_FrameList *frameList)
{
	Int32 retVal;

  /* Check input parameters */
  if (NULL == display)
    return FVID2_EBADARGS;

	/* Take object lock */
	Semaphore_pend(display->lockSem, BIOS_WAIT_FOREVER);

  /* Check if the module is initialized */
  if (!display->isInitialized)
    return FVID2_EFAIL;

	/* Queue frames to driver */
	retVal = Fvid2_queue(display->dispHandle, frameList, 0);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "Error: Unable to queue frame(%d)!!\r\n", retVal);
  	return retVal;
	}

	/* Update frame counter */
	display->framesInQueue++;

	/* Release lock */
	Semaphore_post(display->lockSem);
	
	return retVal;
}

Int32 Display_dequeueBuffer(Display display, Fvid2_FrameList *frameList)
{
	Int32 retVal;

  /* Check input parameters */
  if (NULL == display)
    return FVID2_EBADARGS;

	/* Take object lock */
	Semaphore_pend(display->lockSem, BIOS_WAIT_FOREVER);

  /* Check if the module is initialized */
  if (!display->isInitialized)
    return FVID2_EFAIL;

	/* Dequeue frames from driver */
  retVal = Fvid2_dequeue(display->dispHandle, frameList, 0, FVID2_TIMEOUT_FOREVER /*FVID2_TIMEOUT_NONE*/);
  if (FVID2_SOK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_DISPLAY, "%s(): Error: Unable to dequeue frame(%d)!!\r\n", __FUNCTION__, retVal);
  }

	/* Release lock */
	Semaphore_post(display->lockSem);

	return retVal;
}

bool_t Display_isStarted(Display display)
{
	/* Check input parameters */
  if (NULL == display)
    return FALSE;

  /* Check if the module is initialized */
  if (!display->isInitialized)
    return FALSE;

	return display->isStarted;
}

bool_t Display_canStart(Display display)
{
	/* Check input parameters */
  if (NULL == display)
    return FALSE;

  /* Check if the module is initialized */
  if (!display->isInitialized)
    return FALSE;

	if (display->isStarted)
		return FALSE;

	return (DISPLAY_MAX_FRAMES <= display->framesInQueue)? TRUE : FALSE; 
}

Int32 Display_getResolution(Display display, UInt32 *width, UInt32 *height)
{
	/* Check input parameters */
  if ((NULL == width) || (NULL == height))
    return FVID2_EBADARGS;

	/* Use default display if not specified */
	if (NULL == display)
	{
		display = &gDisplay;
	}

	/* Check if the module is initialized */
	//if(!display->isInitialized)
	//	return FVID2_EFAIL;

	/* Return current screen resolution */
	*width = display->planeCfg.width;
	*height = display->planeCfg.height;

	return FVID2_SOK;
}

Int32 Display_getGlobalAlpha(Display display, UInt8 *alpha)
{
	/* Check input parameters */
  if ((NULL == display) || (NULL == alpha))
    return FVID2_EBADARGS;

	/* Check if the module is initialized */
	if(!display->isInitialized)
		return FVID2_EFAIL;

	/* Return current screen resolution */
	*alpha = display->globalAlpha;

	return FVID2_SOK;
}

Int32 Display_setGlobalAlpha(Display display, UInt8 alpha)
{
	Int32 retVal;

	LOG_PRINT_INFO(DEBUG_DISPLAY, "%s(): alpha = %d\r\n", __FUNCTION__, alpha);
  /* Check input parameters */
  if ((NULL == display))
    return FVID2_EBADARGS;

	/* Check if the module is initialized */
	if(!display->isInitialized)
		return FVID2_EFAIL;

	/* Store new alpha value */
	display->globalAlpha = alpha;

	/* Apply new alpha */
	retVal = display_updatePipelineParams(display);

	return retVal;
}
