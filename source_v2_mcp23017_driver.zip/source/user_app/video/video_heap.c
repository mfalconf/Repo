/******************************************************************************
 *
 * \file    video_heap.c
 *
 * \brief   Video Heap module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    11 Jun 2022
 *
 *****************************************************************************/

#include <standard.h>

#include "video_heap.h"
#include <console.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/heaps/HeapMem.h>

#include <ti/drv/vps/include/vps.h>

/**
 * @addtogroup VideoHeap
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
// #define VIDEO_HEAP_MAX_SIZE   ((34 + 6 + 5) * 1024 * 1024)
#define VIDEO_HEAP_MAX_SIZE   (52 * 1024 * 1024)

#define VIDEO_HEAP_MAX_ALLOCATED_BUFFERS  (32)

#define DEBUG_VIDEO_HEAP 0

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
typedef struct video_heap_type {
	bool_t isInitialized;
	/**< Flag to detect if the module is initialized or not */

	HeapMem_Struct heapStruct;
	/**< Heap base object */

	HeapMem_Handle handle;
	/**< Heap controller handler */

	Ptr buffers[VIDEO_HEAP_MAX_ALLOCATED_BUFFERS];
	/**< Allocated buffers tracking */

	UInt32 sizes[VIDEO_HEAP_MAX_ALLOCATED_BUFFERS];
	/**< Allocated buffer sizes */

	UInt32 numBuffers;
	/**< Number of allocated buffers */

} VideoHeapType;

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
#pragma DATA_ALIGN(gVideoHeapBuf, VPS_BUFFER_ALIGNMENT_RECOMMENDED)
#pragma DATA_SECTION(gVideoHeapBuf, ".bss:frameBuffer");
/**
 * Memory area that will be used as video heap 
 */
static UInt8 gVideoHeapBuf[VIDEO_HEAP_MAX_SIZE];

/** 
 * Video Heap base object
 */
//static HeapMem_Struct gVideoHeapStruct;

/**
 * Video Heap memory handler
 */
//static HeapMem_Handle gVideoHeapHandle = NULL;

static VideoHeapType gVideoHeap = {
	/** isInitialized */
	FALSE,
};

/******************************************************************************
 * Functions implementation
 *****************************************************************************/


static void videoHeap_dump(void)
{
  Memory_Stats stats;
  HeapMem_getStats(gVideoHeap.handle, &stats);
  LOG_PRINT_INFO(DEBUG_VIDEO_HEAP, "%s(): Stats: totalSize=%d, totalFreeSize=%d, largestFreeSize=%d\r\n", 
      __FUNCTION__, stats.totalSize, stats.totalFreeSize, stats.largestFreeSize);
}

Int32 VideoHeap_init()
{
  HeapMem_Params heapMemPrm;

	/* Initialize data members */
	gVideoHeap.isInitialized = FALSE;
	gVideoHeap.numBuffers = 0;

  /* Initialize heap memory parameters */
  HeapMem_Params_init(&heapMemPrm);
  heapMemPrm.buf = &gVideoHeapBuf;
  heapMemPrm.size = VIDEO_HEAP_MAX_SIZE;

  /* Create heap memory instance */
  HeapMem_construct(&gVideoHeap.heapStruct, &heapMemPrm);

  /* Store heap memory handler */
  gVideoHeap.handle = HeapMem_handle(&gVideoHeap.heapStruct);
  if (NULL == gVideoHeap.handle)
  {
    LOG_PRINT_ERR(DEBUG_VIDEO_HEAP, "%s(): Invalid Video Heap handler!!\r\n", __FUNCTION__);
    return E_ERROR;
  }

	/* we are now initialized */
	gVideoHeap.isInitialized = TRUE;

  LOG_PRINT_INFO(DEBUG_VIDEO_HEAP, "%s(): Initialization complete\r\n", __FUNCTION__);
  videoHeap_dump();
  return E_OK;
}

Ptr VideoHeap_alloc(UInt32 size, UInt32 align)
{
  Ptr addr;

	/* Check if the module is initialized */
	if (!gVideoHeap.isInitialized)
	{
		/* The module is not initialized. do nothing */
		return NULL;
	}

	/* Check if we can allocate a buffer */
	if (VIDEO_HEAP_MAX_ALLOCATED_BUFFERS <= gVideoHeap.numBuffers)
	{
		/* we can't allocate it */
		LOG_PRINT_ERR(DEBUG_VIDEO_HEAP, "(%s) [%d]: Max amount of buffers allocated, cannot allocate!\r\n", __FUNCTION__, __LINE__);
		return NULL;
	}

	LOG_PRINT_INFO(DEBUG_VIDEO_HEAP, "%s(): Allocating size %d\r\n", __FUNCTION__, size);

	/* allocate buffer */
  addr = HeapMem_alloc(gVideoHeap.handle, size, align, NULL);

  LOG_PRINT_INFO(DEBUG_VIDEO_HEAP, "%s(): Allocation complete %p\r\n", __FUNCTION__, addr);
  videoHeap_dump();

	/* add new buffer to our list */
	gVideoHeap.buffers[gVideoHeap.numBuffers] = addr;
	gVideoHeap.sizes[gVideoHeap.numBuffers] = size;

	/* update number of buffers allocated */
	gVideoHeap.numBuffers++;

  return addr;
}

Int32 VideoHeap_free(Ptr ptr)
{
	UInt32 i;

	/* Check if the module is initialized */
	if (!gVideoHeap.isInitialized)
	{
		/* The module is not initialized. do nothing */
		return E_ERROR;
	}

	/* Check if the given pointer was allocated by this module */
	for (i = 0; i < gVideoHeap.numBuffers; i++)
	{
		if (gVideoHeap.buffers[i] == ptr)
		{
			/* we found it! */
			break;
		}
	}

	/* if we went thru all buffers, it means that we didn't find it */
	if (i == gVideoHeap.numBuffers)
	{
		/* The given pointer was not allocated by us */
		return E_ERROR;
	}

	LOG_PRINT_INFO(DEBUG_VIDEO_HEAP, "%s(): Freeing buffer %p with size %d\r\n", __FUNCTION__, ptr, gVideoHeap.sizes[i]);

	/* if we reach here is because we find it, so we free it */
	HeapMem_free(gVideoHeap.handle, ptr, gVideoHeap.sizes[i]);

	/* Remove buffer from our list */
	while (i < (gVideoHeap.numBuffers - 1))
	{
		gVideoHeap.buffers[i] = gVideoHeap.buffers[i+1];
		i++;
	}

	/* Update number of buffers */
	gVideoHeap.numBuffers--;

	videoHeap_dump();

  return E_OK;
}

Ptr VideoHeap_allocFrame(UInt32 width, UInt32 height, UInt32 bpp)
{
	Ptr addr;
	UInt32 bufSize;

	/* Calculate frame size */
	bufSize = VpsUtils_align(width, VPS_BUFFER_ALIGNMENT) * height * bpp;
	
	/* Allocate the corresponding buffer */
	addr = VideoHeap_alloc(bufSize, VPS_BUFFER_ALIGNMENT);

	return addr;
}

Int32 VideoHeap_isValidPtr(Ptr ptr)
{
	return ((UInt8*)ptr >= gVideoHeapBuf) && ((UInt8*)ptr < (gVideoHeapBuf + VIDEO_HEAP_MAX_SIZE));
}

Int32 VideoHeap_getHeapHandle(HeapMem_Handle *handle)
{
	if (NULL == handle)
	{
		return E_ERROR;
	}

	if (!gVideoHeap.isInitialized)
		return E_ERROR;

	*handle = gVideoHeap.handle;
	return E_OK;
}

/**
 * Close doxygen group
 * @}
 */

