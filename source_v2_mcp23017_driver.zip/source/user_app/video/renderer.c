/******************************************************************************
 *
 * \file    renderer.c
 *
 * \brief   Renderer module source file
 *
 * \author  Esteban Pupillo
 *
 * \date    25 Jun 2022
 *
 *****************************************************************************/

#include <standard.h>
#include "console.h"
#include <xdc/std.h>
#include "lv_hal_disp.h"
#include "lv_obj_pos.h"
#include "renderer.h"
#include "video_heap.h"
#include "video_dma.h"
#include "fsm.h"
#include "assets/assets.h"

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/hal/Cache.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <ti/csl/soc.h>
#include <ti/csl/hw_types.h>
#include <ti/csl/cslr_dss.h>

#include <ti/drv/vps/include/vps.h>

#include <ti/drv/vps/include/common/bsp_utilsQue.h>

#include "gfx_queue.h"
#include "display.h"

/**
 * @addtogroup Renderer
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DEBUG_RENDERER   0

#define RENDERER_TASK_STACK_SIZE           (0x1000)

#define RENDERER_GRAPHICS_UPDATE_PERIOD_MS (30)
#define RENDERER_SENSORS_UPDATE_PERIOD_MS  (100)

#undef X
#define X(id, numAssets, posX, posY, width, height) id,
typedef enum layoutId_tag {
	LAYOUTS
	LAYOUTS_NUM
} LayoutID;

#undef X
#define SENSOR_DEFINITION \
	X(SENSOR_FRONT) \
	X(SENSOR_REAR) 

#undef X
#define SENSOR_CH_DEFINITION \
	X(SENSOR_CH_L, 4) \
	X(SENSOR_CH_ML, 8) \
	X(SENSOR_CH_MR, 8) \
	X(SENSOR_CH_R, 4)

#undef X
#define LAYOUTS_DEFINITION \
  RVC_AND_PDC_LAYOUT_DEFINITION \
  PDC_ONLY_LAYOUT_DEFINITION

#define RENDERER_MAX_OUT_BUFFERS      (2)
#define RENDERER_USE_DMA              (1)
#define RENDERER_OUTPUT_FRAME_BPP     (4)
#define RENDERER_OUTPUT_FRAME_STRIDE  (gRenderer.outputFrameWidth * RENDERER_OUTPUT_FRAME_BPP)

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
typedef struct asset_tag {
	lv_obj_t *obj;
	UInt32 xPos;
	UInt32 yPos;
	UInt32 visible;
} Asset;

typedef struct layout_tag {
	Asset  *assests;
	UInt32 numAssets;
	UInt32 posX;
	UInt32 posY;
	UInt32 width;
	UInt32 height;
} Layout;

#undef X
#define X(layout, rname, name, x, y, w, h, v) R_ ## layout ## _ ## rname,
typedef enum resourceId_tag {
  LAYOUTS_DEFINITION
	RESOURCE_NUM
} ResourceID;

#undef X
#define X(chname, max) chname,
typedef enum sensorChId_tag {
	SENSOR_CH_DEFINITION
	SENSOR_CH_NUM
} SensorChID;

#undef X
#define X(sensor) sensor,
typedef enum sensorId_tag {
	SENSOR_DEFINITION
	SENSOR_NUM
} SensorID;

#undef X
#define X(layout, rname, name, x, y, w, h, v) {.xpos=x, .ypos=y, .width=w, .height=h},
static ResourceGeometry_t resourceGeometries[RESOURCE_NUM] = {
	LAYOUTS_DEFINITION
};

struct renderer_tag {
  bool_t isInitialized;
	RendererCbParam cbParam;
	Task_Handle procHandle;
  lv_disp_draw_buf_t drawBuf;
  lv_disp_drv_t dispDrv;
	UInt8 *dispBuf;
	LayoutID currentLayout;
	LayoutID newLayout;
	UInt32 frontSensorFlags;
	UInt32 rearSensorFlags;
	bool_t isFrameReady;
	bool_t isStarted;

	GfxQueue outQueue;

	RendererFrame outFrameCfg;

	Semaphore_Handle busySem;

	UInt32 lastRefreshTime;

  UInt32 outputFrameWidth;
  UInt32 outputFrameHeight;

	bool_t touchAvailable;
	bool_t rvcStatus;

	RendererCar car;
	bool_t pdcAvailable;
	Language_en language;
	bool_t switchOn;
	bool_t frontParkingSensorsAvailable;
	bool_t rearParkingSensorsAvailable;
};

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/
static void renderer_getSensorChBaseAddr(Renderer r, UInt32 sensorId, Asset *chBaseAddr[]);
static void renderer_refreshSensorChannels(Renderer r);
static void renderer_updateSensorChannels(Renderer r, Asset *chBaseAddr[], UInt32 *newSensorFlags, UInt32 *oldSensorFlags);
static Int32 renderer_updateSensorInfo(Renderer r, UInt32 *inFrontSensorFlags, UInt32 *inRearSensorFlags);
static void renderer_processTask(UArg arg0, UArg arg1);
static Int32 renderer_createProcessTask(Renderer r);
static void renderer_lvgDisplayMonitor(lv_disp_drv_t *disp, uint32_t time, uint32_t px);
static void renderer_lvglLogger(const char *buf);
static Int32 renderer_initLayouts(Renderer r);
static void renderer_updateButtonLayouts(Renderer r);
static void renderer_updateCarLayouts(Renderer r);
static void renderer_updateAlertLayout(Renderer r);
static void renderer_updateFrontParkingSensors(Renderer r);
static void renderer_updateRearParkingSensors(Renderer r);

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/
#undef X
#define X(ID, numAssets, posX, posY, width, height) {NULL, numAssets, posX, posY, width, height},
static Layout gLayouts[] = {
	LAYOUTS
};

#undef X
#define X(layout, rname, name, x, y, w, h, v) LV_IMG_DECLARE(name);
LAYOUTS_DEFINITION

#undef X
#define X(layout, rname, name, x, y, w, h, v) { NULL, x, y, v},
static Asset gAssets[] = {
	LAYOUTS_DEFINITION
};

#undef X
#define X(chname, max) max,
static UInt32 gSensorChLimit[] = {
	SENSOR_CH_DEFINITION
};

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static struct renderer_tag gRenderer = {
  /* isInitialized */
  FALSE,
};

static uint8_t stack[RENDERER_TASK_STACK_SIZE];

/******************************************************************************
 * Functions implementation
 *****************************************************************************/
static void renderer_getSensorChBaseAddr(Renderer r, UInt32 sensorId, Asset *chBaseAddr[])
{
	if ((UInt32) SENSOR_FRONT == sensorId)
	{
		if (RVC_AND_PDC_LAYOUT == r->currentLayout)
		{
  		chBaseAddr[SENSOR_CH_L] = &gAssets[R_RVC_AND_PDC_LAYOUT_FS_L_1];
			chBaseAddr[SENSOR_CH_ML] = &gAssets[R_RVC_AND_PDC_LAYOUT_FS_ML_1];
			chBaseAddr[SENSOR_CH_MR] = &gAssets[R_RVC_AND_PDC_LAYOUT_FS_MR_1];
			chBaseAddr[SENSOR_CH_R] = &gAssets[R_RVC_AND_PDC_LAYOUT_FS_R_1];
		}
		else
		{
  		chBaseAddr[SENSOR_CH_L] = &gAssets[R_PDC_ONLY_LAYOUT_FS_L_1];
			chBaseAddr[SENSOR_CH_ML] = &gAssets[R_PDC_ONLY_LAYOUT_FS_ML_1];
			chBaseAddr[SENSOR_CH_MR] = &gAssets[R_PDC_ONLY_LAYOUT_FS_MR_1];
			chBaseAddr[SENSOR_CH_R] = &gAssets[R_PDC_ONLY_LAYOUT_FS_R_1];	
		}
	}
	else
	{
		if (RVC_AND_PDC_LAYOUT == r->currentLayout)
		{
  		chBaseAddr[SENSOR_CH_L] = &gAssets[R_RVC_AND_PDC_LAYOUT_RS_L_1];
			chBaseAddr[SENSOR_CH_ML] = &gAssets[R_RVC_AND_PDC_LAYOUT_RS_ML_1];
			chBaseAddr[SENSOR_CH_MR] = &gAssets[R_RVC_AND_PDC_LAYOUT_RS_MR_1];
			chBaseAddr[SENSOR_CH_R] = &gAssets[R_RVC_AND_PDC_LAYOUT_RS_R_1];
		}
		else
		{
  		chBaseAddr[SENSOR_CH_L] = &gAssets[R_PDC_ONLY_LAYOUT_RS_L_1];
			chBaseAddr[SENSOR_CH_ML] = &gAssets[R_PDC_ONLY_LAYOUT_RS_ML_1];
			chBaseAddr[SENSOR_CH_MR] = &gAssets[R_PDC_ONLY_LAYOUT_RS_MR_1];
			chBaseAddr[SENSOR_CH_R] = &gAssets[R_PDC_ONLY_LAYOUT_RS_R_1];	
		}
	}
}

static void renderer_refreshSensorChannels(Renderer r)
{
	UInt32 sensorIdx, chIdx;
	Asset *chBaseAddr[4] = {0};

	/* refresh all sensors */
	for(sensorIdx = 0; sensorIdx < SENSOR_NUM; sensorIdx++)
	{
		/* Retrieve sensor asset base addresses */
		renderer_getSensorChBaseAddr(r, sensorIdx, &chBaseAddr[0]);

		/* refresh all sensor channels */
		for (chIdx = 0; chIdx < (UInt32) SENSOR_CH_NUM; chIdx++)
		{
			Asset *changedAsset;
			UInt32 chValue, seg;
			UInt32 mask;
			UInt32 sensorFlags;

			sensorFlags = ((UInt32) SENSOR_FRONT == sensorIdx) ? r->frontSensorFlags : r->rearSensorFlags;

			/* calculate sensor channel mask */
			mask = 0xFF << chIdx * 8;

			/* get sensor channel value */
			chValue = (sensorFlags & mask) >> chIdx * 8;

			/* clear all segments */
			for(seg = 0; seg < gSensorChLimit[chIdx]; seg++)
			{
				changedAsset = chBaseAddr[chIdx] + seg;
				lv_obj_add_flag(changedAsset->obj, LV_OBJ_FLAG_HIDDEN);
			}

			/* make segment visible */
			if (chValue)
			{
				changedAsset = chBaseAddr[chIdx] + chValue - 1;
				lv_obj_clear_flag(changedAsset->obj, LV_OBJ_FLAG_HIDDEN);
			}
		}
	}
}

static void renderer_updateSensorChannels(Renderer r, Asset *chBaseAddr[], UInt32 *newSensorFlags, UInt32 *oldSensorFlags)
{
	UInt32 chIdx;

	for (chIdx = 0; chIdx < SENSOR_CH_NUM; chIdx++)
	{
		Asset *changedAsset;
		UInt32 chValueOld, chValueNew;
		UInt32 mask;

		/* calculate sensor channel mask */
		mask = 0xFF << chIdx * 8;
		
		/* get new and old sensor channel value */
		chValueOld = (*oldSensorFlags & mask) >> chIdx * 8;
		chValueNew = (*newSensorFlags & mask) >> chIdx * 8;

		/* check channel bounds */
		if (chValueNew > gSensorChLimit[chIdx])
		{
			/* The new channel value is higher than what we can represent */
			LOG_PRINT_SVER(DEBUG_RENDERER, "%s(): Invalid channel value. ch = %d, value = %d, limit = %d\r\n", __FUNCTION__, chIdx, chValueNew, gSensorChLimit[chIdx]);
			*newSensorFlags &= ~mask;
			chValueNew = 0;
		}
		
		LOG_PRINT_SVER(DEBUG_RENDERER, "%s(): chBaseAddr = %p, oldValue = %d, newValue = %d\r\n", __FUNCTION__, chBaseAddr[chIdx], chValueOld, chValueNew);

		/* if the new value is different from old one, update asset */
		if (chValueNew != chValueOld)
		{
			/* hide old segment */
			if (chValueOld) 
			{
				changedAsset = chBaseAddr[chIdx] + chValueOld - 1;
				lv_obj_add_flag(changedAsset->obj, LV_OBJ_FLAG_HIDDEN);
			}

			/* show new segment*/
			if (chValueNew)
			{
				changedAsset = chBaseAddr[chIdx] + chValueNew - 1;
				lv_obj_clear_flag(changedAsset->obj, LV_OBJ_FLAG_HIDDEN);
			}
		}
	}
}


static Int32 renderer_updateSensorInfo(Renderer r, UInt32 *inFrontSensorFlags, UInt32 *inRearSensorFlags)
{
	Int32 retVal = E_OK;
	Asset *chBaseAddr[4] = {0};
	UInt32 frontSensorFlags, rearSensorFlags;
	UInt32 sensorIdx;

	LOG_PRINT_INFO(DEBUG_RENDERER, "%s(): Updating...\r\n",__FUNCTION__);

	/* if we don't have valid sensors information, used the callback mechanism */
	if ((NULL == inFrontSensorFlags) && (NULL == inRearSensorFlags))
	{
		/* check if we have a valid callback function */
		if (r->cbParam.sensorRefreshCbFxn)
		{
			/* ask parent module to update sensors information */
			retVal = (*r->cbParam.sensorRefreshCbFxn)(r->cbParam.appData, &frontSensorFlags, &rearSensorFlags);
		}
	}
	else
	{
		frontSensorFlags = *inFrontSensorFlags;
		rearSensorFlags = *inRearSensorFlags;
	}
	
	for (sensorIdx = 0; sensorIdx < SENSOR_NUM; sensorIdx++)
	{
		UInt32 *newFlags, *oldFlags;

		/* get new and old sensor flags */
		newFlags = (SENSOR_FRONT == sensorIdx)? &frontSensorFlags : &rearSensorFlags;
		oldFlags = (SENSOR_FRONT == sensorIdx)? &r->frontSensorFlags : &r->rearSensorFlags;

		/* Retrieve sensor channel base addresses */
		renderer_getSensorChBaseAddr(r, sensorIdx, &chBaseAddr[0]);
		
		/* Update sensor channels */
		renderer_updateSensorChannels(r, chBaseAddr, newFlags, oldFlags);
	}

	/* save current flags */
	r->frontSensorFlags= frontSensorFlags;
	r->rearSensorFlags = rearSensorFlags;

	return retVal;
}

static void renderer_processTask(UArg arg0, UArg arg1)
{
  UInt32 exit = FALSE;
  Renderer r = (Renderer) arg0;
  LOG_PRINT_INFO(DEBUG_RENDERER, "Starting Renderer taks\r\n");
  bool_t firstFrame = TRUE;

  while (!exit) 
  {
		/* Update graphic engine */
		lv_timer_handler();

		Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);

		if (r->isStarted) 
		{
			/* Check if we need to change layout */
			if (r->currentLayout != r->newLayout)
			{
				/* change to new layout */
				r->currentLayout = r->newLayout;

				/* force a refresh of sensor segments */
				renderer_refreshSensorChannels(r);
			}

			/* Check if we have any invalidated area */
			lv_disp_t *disp = lv_disp_get_default();
      if (firstFrame)
			{
				/* There are no invalidated areas.
				 * We force a 1 pixel invalidation to generate
				 * a new output frame even when the internal
				 * graphic content didn't change
				 */
				lv_area_t invArea;
				invArea.x1 = 0;
				invArea.x2 = 0;
				invArea.y1 = 0;
				invArea.y2 = 0;

				/* force invalidation */
				_lv_inv_area(disp, &invArea);
        firstFrame = FALSE;
			}

      /* Invalidate display */
	    _lv_disp_refr_timer(NULL);
		}

		Semaphore_post(r->busySem);

		Task_sleep_ms(RENDERER_GRAPHICS_UPDATE_PERIOD_MS);
  }
}

static Int32 renderer_createProcessTask(Renderer r)
{
  Error_Block eb;
  Task_Params taskParams;
  Task_Handle taskHandle;

  Error_init(&eb);

  /* create main thread (interrupts not enabled in main on BIOS) */
  Task_Params_init(&taskParams);
  taskParams.instance->name = "renderproc";
  taskParams.arg0 = (xdc_UArg) r;
  taskParams.stackSize = RENDERER_TASK_STACK_SIZE;
  taskParams.stack = stack;
  taskParams.affinity = VIDEO_CORE_NUM;
 
  taskHandle = Task_create(renderer_processTask, &taskParams, &eb);
  if (NULL == taskHandle)
  {
    LOG_PRINT_ERR(DEBUG_RENDERER, "Couldn't create Renderer processing task\n");
    return E_ERROR;
  }
  
  LOG_PRINT_INFO(DEBUG_RENDERER, "Rendering processing task created successfully\n");
  r->procHandle = taskHandle;

  return E_OK;
}

static void renderer_lvgDisplayMonitor(lv_disp_drv_t *disp, uint32_t time, uint32_t px)
{
	Renderer r = (Renderer) disp->user_data;

  LOG_PRINT_INFO(DEBUG_RENDERER, "%s(): %d pixels refreshed in %d ms\r\n", __FUNCTION__, px, time);
	
	if (!r->isFrameReady)
		r->isFrameReady = TRUE;
}

void renderer_lvglDisplayFlush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p)
{
	Int32 retVal;
  uint32_t width, height;
  uint32_t t1, t2;
	Renderer r = (Renderer) disp->user_data;
  UInt32 y;

  t1 = Clock_getTicks();

  LOG_PRINT_INFO(DEBUG_RENDERER, "%s(): buffer = %p, x1 = %d, x2 = %d, y1 = %d, y2 = %d\r\n", 
      __FUNCTION__, color_p, area->x1, area->x2, area->y1, area->y2);

  width = area->x2 - area->x1 + 1;
  height = area->y2 - area->y1 + 1;

#if RENDERER_USE_DMA == 1

	Cache_wbInv(color_p, width * height * RENDERER_OUTPUT_FRAME_BPP, Cache_Type_ALL, TRUE);

	VideoDMA_copyFrame(r->dispBuf + area->y1 * RENDERER_OUTPUT_FRAME_STRIDE + area->x1 * RENDERER_OUTPUT_FRAME_BPP, 
			               RENDERER_OUTPUT_FRAME_BPP, 
										 RENDERER_OUTPUT_FRAME_STRIDE, 
										 color_p, 
										 RENDERER_OUTPUT_FRAME_BPP, 
										 width * RENDERER_OUTPUT_FRAME_BPP, 
										 width, 
										 height); 
#else
  for (y = 0; y < height; y++)
  {
    memcpy((void *)(r->dispBuf + (area->y1 + y) * RENDERER_OUTPUT_FRAME_STRIDE + area->x1 * RENDERER_OUTPUT_FRAME_BPP), 
				   color_p + y * width, 
					 width * RENDERER_OUTPUT_FRAME_BPP);
  }
#endif
	
	
	if(lv_disp_flush_is_last(disp))
	{
		Fvid2_Frame *doneFrm;

		retVal = GfxQueue_dequeue(r->outQueue, &doneFrm);
		if (BSP_SOK == retVal)
		{
			LOG_PRINT_INFO(DEBUG_RENDERER, "%s(): filling frame at %p with addr[0][0] = %p\r\n", __FUNCTION__, doneFrm, doneFrm->addr[0][0]);
			/* Make sure that the source buffer is available at physical RAM */
			Cache_wbInv(r->dispBuf, gRenderer.outputFrameWidth * gRenderer.outputFrameHeight * RENDERER_OUTPUT_FRAME_BPP, Cache_Type_ALL, TRUE);

			VideoDMA_copyFrame(PHY_TO_DA_ADDR((UInt8 *) doneFrm->addr[0][0]),
                         RENDERER_OUTPUT_FRAME_BPP,
                         RENDERER_OUTPUT_FRAME_STRIDE, 
					               r->dispBuf,
                         RENDERER_OUTPUT_FRAME_BPP,
                         RENDERER_OUTPUT_FRAME_STRIDE,
												 gRenderer.outputFrameWidth,
												 gRenderer.outputFrameHeight);

			retVal = GfxQueue_queue(r->outQueue, doneFrm);
			if (BSP_SOK != retVal)
			{
				LOG_PRINT_ERR(DEBUG_RENDERER, "%s(): Unable to queue done frame to done queue\r\n", __FUNCTION__);
			}
		
			/* Update refresh time */
			r->lastRefreshTime = Clock_getTicks();

			/* check if we have a valid callback function */
			if (r->cbParam.frameUpdateCbFxn)
			{
				retVal = (*r->cbParam.frameUpdateCbFxn)(NULL, r->cbParam.appData, NULL);
			}
		}
		else
		{
			LOG_PRINT_ERR(DEBUG_RENDERER, "%s(): No ready buffer available!\r\n", __FUNCTION__);
		}

	}

	t2 = Clock_getTicks();

  LOG_PRINT_INFO(DEBUG_RENDERER, "%s(): t1 = %d, t2 = %d, diff = %d\r\n", 
      __FUNCTION__, t1, t2, t2-t1);

	lv_disp_flush_ready(disp);

}

static void renderer_lvglLogger(const char *buf)
{
	LOG_PRINT_INFO(DEBUG_RENDERER, "%s", buf);
}

static Int32 renderer_initLayouts(Renderer r)
{
	UInt32 idx;

  /* Check input parameters */
  if (NULL == r)
    return E_ERROR;

	/* Create layouts */
	idx = 0;
#undef X
#define X(layout, rname, name, x, y, w, h, v) \
	if (NULL == gLayouts[layout].assests) \
	  gLayouts[layout].assests = &gAssets[idx]; \
	gAssets[idx].obj = lv_img_create(lv_scr_act()); \
	lv_img_set_src(gAssets[idx].obj, &name); \
	lv_obj_set_pos(gAssets[idx].obj, gLayouts[layout].posX + x, gLayouts[layout].posY + y);\
	if (0 == v) \
    lv_obj_add_flag(gAssets[idx].obj, LV_OBJ_FLAG_HIDDEN); \
	idx++; 

	LAYOUTS_DEFINITION;

	/* Initialize all necessary assets */
	renderer_updateCarLayouts(r);
	renderer_updateAlertLayout(r);
	renderer_updateButtonLayouts(r);

	return E_OK;
}

static void renderer_updateButtonLayouts(Renderer r)
{
	if (r->touchAvailable)
	{
		if (r->switchOn)
		{
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_EXIT_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_EXIT_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_EXIT_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_EXIT_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
		}
		else
		{
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_EXIT_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_EXIT_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_EXIT_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_EXIT_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
		}

		if (!r->pdcAvailable)
		{
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_SWITCH_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_SWITCH_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
		}
		else
		{
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_SWITCH_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_SWITCH_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
		}

		if (r->rvcStatus)
		{
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_SWITCH_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_SWITCH_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
		}
		else
		{
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_SWITCH_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_SWITCH_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
		}
	}
	else
	{
		lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_EXIT_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_SWITCH_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_EXIT_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_EXIT_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_SWITCH_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_EXIT_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);

		if (!r->pdcAvailable)
		{
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_SWITCH_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_SWITCH_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
		}
		else
		{
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_SWITCH_ENABLED].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_SWITCH_DISABLED].obj, LV_OBJ_FLAG_HIDDEN);
		}
	}
}

static void renderer_updateCarLayouts(Renderer r)
{
	switch (r->car)
	{
		case CAR_MODEL_VW_POLO:
		{
			static const UInt32 frontSensorsZero[4] = { 0, 0, 0, 0 };
			static const UInt32 rearSensorsZero[4] = { 0, 0, 0, 0 };

			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_AMAROK].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_SAVEIRO].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_AMAROK].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO_DOUBLE].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_BACKGROUND].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_BACKGROUND_NO_PDC].obj, LV_OBJ_FLAG_HIDDEN);

			/* Hide all the parking sensors assets */
			renderer_updateSensorInfo(r, frontSensorsZero, rearSensorsZero);

			break;
		}

		case CAR_MODEL_VW_SAVEIRO:
		case CAR_MODEL_VW_SAVEIRO_DOUBLE_CABIN:
		{
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_AMAROK].obj, LV_OBJ_FLAG_HIDDEN);
			
			if (r->car != CAR_MODEL_VW_SAVEIRO_DOUBLE_CABIN)
			{
				lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_SAVEIRO].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_SAVEIRO_DOUBLE].obj, LV_OBJ_FLAG_HIDDEN);
			}
			else
			{
				lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_SAVEIRO_DOUBLE].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_SAVEIRO].obj, LV_OBJ_FLAG_HIDDEN);
			}
			
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_AMAROK].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_BACKGROUND_NO_PDC].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_BACKGROUND].obj, LV_OBJ_FLAG_HIDDEN);
			
			if (r->frontParkingSensorsAvailable)
			{
				lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			}
			else
			{
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			}

			if (r->rearParkingSensorsAvailable)
			{
				lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			}
			else
			{
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			}
			
			if (r->car != CAR_MODEL_VW_SAVEIRO_DOUBLE_CABIN)
			{
				lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO_DOUBLE].obj, LV_OBJ_FLAG_HIDDEN);
			}
			else
			{
				lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO_DOUBLE].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO].obj, LV_OBJ_FLAG_HIDDEN);
			}
			
			break;
		}

		case CAR_MODEL_VW_AMAROK:
		{
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_SAVEIRO].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_SAVEIRO_DOUBLE].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_CAR_AMAROK].obj, LV_OBJ_FLAG_HIDDEN);
			
			if (r->frontParkingSensorsAvailable)
			{
				lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			}
			else
			{
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			}

			if (r->rearParkingSensorsAvailable)
			{
				lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			}
			else
			{
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			}

			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO_DOUBLE].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_BACKGROUND_NO_PDC].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_BACKGROUND].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_AMAROK].obj, LV_OBJ_FLAG_HIDDEN);

			break;
		}

		default:
		{
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_AMAROK].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_CAR_SAVEIRO_DOUBLE].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_BACKGROUND_NO_PDC].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);

			break;
		}
	}
}

static void renderer_updateAlertLayout(Renderer r)
{
	if (r->pdcAvailable || (r->car == CAR_MODEL_INVALID))
	{
		/* If PDC is available or no valid car is available, hide all alerts from no PDC layout */
		lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);
	}
	else
	{
		/* If PDC is not available, then enable the necessary PDC alert message in that particular layout based on the language */
		switch(r->language)
		{
			case RENDERER_LANGUAGE_SPANISH:
			{
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);
				break;
			}

			case RENDERER_LANGUAGE_PORTUGUESE:
			{
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);
				break;
			}

			case RENDERER_LANGUAGE_ENGLISH:
			default:
			{
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);
				lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_NO_PDC_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);
				break;
			}
		}
	}

	switch (r->language)
	{
		case RENDERER_LANGUAGE_SPANISH:
		{
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_ALERT_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_ALERT_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);

			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);

			lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_ALERT_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);

			break;
		}

		case RENDERER_LANGUAGE_PORTUGUESE:
		{
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_ALERT_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_ALERT_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);

			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);

			lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_ALERT_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);

			break;
		}

		case RENDERER_LANGUAGE_ENGLISH:
		default:
		{
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_ALERT_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_ALERT_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);

			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_SPANISH].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_PORTUGUESE].obj, LV_OBJ_FLAG_HIDDEN);

			lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_ALERT_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);
			lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_ALERT_ENGLISH].obj, LV_OBJ_FLAG_HIDDEN);

			break;
		}
	}
}

static void renderer_updateFrontParkingSensors(Renderer r)
{
	if (r->frontParkingSensorsAvailable && ((r->car != CAR_MODEL_INVALID) && (r->car != CAR_MODEL_VW_POLO)))
	{
		lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
	}
	else
	{
		lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_F_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
	}
}

static void renderer_updateRearParkingSensors(Renderer r)
{
	if (r->rearParkingSensorsAvailable && ((r->car != CAR_MODEL_INVALID) && (r->car != CAR_MODEL_VW_POLO)))
	{
		lv_obj_clear_flag(gAssets[R_PDC_ONLY_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_clear_flag(gAssets[R_RVC_AND_PDC_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
	}
	else
	{
		lv_obj_add_flag(gAssets[R_PDC_ONLY_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(gAssets[R_RVC_AND_PDC_LAYOUT_R_SENSOR_AREA].obj, LV_OBJ_FLAG_HIDDEN);
	}
}

Int32 Renderer_init(Renderer *r, RendererCbParam callback)
{
  Int32 retVal = E_ERROR;
	UInt8 *drawBufAddr;
	UInt32 drawBufSize;
	Semaphore_Params semPrms;
	UInt32 displayWidth, displayHeight;

  LOG_PRINT_INFO(DEBUG_RENDERER, "%s()\r\n", __FUNCTION__);

  /* Check for input parameter */
  if (NULL == r) 
    return E_ERROR;

  /* return current object instance */
  *r = &gRenderer;

  /* Initialize internal variables */
  gRenderer.isInitialized = FALSE;
	gRenderer.cbParam = callback;

	gRenderer.frontParkingSensorsAvailable = FALSE;
	gRenderer.rearParkingSensorsAvailable = FALSE;

  // NOTE: As the renderer has a unique buffer in which it draws the big car in fullscreen + the small car in RVC mode
  // the output frame width is internally larger than the display width
	Display_getResolution(NULL, &displayWidth, &displayHeight);
	gRenderer.outputFrameWidth = displayWidth * 2;
  gRenderer.outputFrameHeight = displayHeight;

	/* Initialize lvgl library */
  lv_init();

  /* Register logger */
  lv_log_register_print_cb(renderer_lvglLogger);
  
  /* Calculate draw buffer size */
  drawBufSize = VpsUtils_align(gRenderer.outputFrameWidth, VPS_BUFFER_ALIGNMENT) * gRenderer.outputFrameHeight * RENDERER_OUTPUT_FRAME_BPP;

	/* Create Graphic queue for output frames */
	GfxQueueParams qParams;
	GfxQueueParams_init(&qParams);
	qParams.maxSize = RENDERER_MAX_OUT_BUFFERS;
	qParams.frameWidth = gRenderer.outputFrameWidth;
	qParams.frameHeight = gRenderer.outputFrameHeight;
	qParams.frameBytePerPixel = RENDERER_OUTPUT_FRAME_BPP;

	retVal = GfxQueue_create(&gRenderer.outQueue, &qParams);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_RENDERER, "%s(): Unable to create graphic queue\r\n", __FUNCTION__);
		return E_ERROR;
	}

	/* Enable graphic queue */
	GfxQueue_setEnableState(gRenderer.outQueue, TRUE);

	/* Allocate virtual display buffer */
	gRenderer.dispBuf = (UInt8 *) VideoHeap_alloc(drawBufSize, VPS_BUFFER_ALIGNMENT);
	if (NULL == gRenderer.dispBuf)
	{
		LOG_PRINT_ERR(DEBUG_RENDERER, "%s(): Unable to allocate output buffer\r\n", __FUNCTION__);
		return E_ERROR;
	}

	/* Allocate draw buffer */
	drawBufAddr = (Uint8 *) VideoHeap_alloc(drawBufSize, VPS_BUFFER_ALIGNMENT);
	if (NULL == drawBufAddr)
	{
		LOG_PRINT_ERR(DEBUG_RENDERER, "%s(): Unable to allocate draw buffer\r\n", __FUNCTION__);
		return E_ERROR;
	}

	/* Initialize draw buffer */
  lv_disp_draw_buf_init(&gRenderer.drawBuf, (lv_color_t*)drawBufAddr, NULL, gRenderer.outputFrameWidth * gRenderer.outputFrameHeight);
  
  /* Initialize display object */
  lv_disp_drv_init(&gRenderer.dispDrv);
  gRenderer.dispDrv.hor_res = gRenderer.outputFrameWidth;
  gRenderer.dispDrv.ver_res = gRenderer.outputFrameHeight;
  gRenderer.dispDrv.flush_cb = renderer_lvglDisplayFlush;
  gRenderer.dispDrv.monitor_cb = renderer_lvgDisplayMonitor;
  gRenderer.dispDrv.draw_buf = &gRenderer.drawBuf;
	gRenderer.dispDrv.user_data = &gRenderer;
  lv_disp_t *disp = lv_disp_drv_register(&gRenderer.dispDrv);

	/* Don't perform autorefresh */
	lv_timer_del(disp->refr_timer);
	disp->refr_timer = NULL;

	/* Initialize internal members to an invalid car */
	gRenderer.car = CAR_MODEL_INVALID;
	gRenderer.pdcAvailable = FALSE;
	gRenderer.language = RENDERER_LANGUAGE_INVALID;
	gRenderer.switchOn = FALSE;

	/* Initialize layouts */
  retVal = renderer_initLayouts(*r);

	/* Set initial layout */
	gRenderer.currentLayout = (LayoutID) 0;
	gRenderer.newLayout = (LayoutID) 0;

	gRenderer.frontSensorFlags = 0;
	gRenderer.rearSensorFlags = 0;

	/* Crete busy semaphore */
	Semaphore_Params_init(&semPrms);
  gRenderer.busySem = Semaphore_create(1, &semPrms, NULL);
  if (NULL == gRenderer.busySem)
  {
    LOG_PRINT_ERR(DEBUG_RENDERER, "%s(): Busy semaphore creation failed!!\r\n", __FUNCTION__);
    return E_ERROR;
  }

	gRenderer.isFrameReady = FALSE;
	gRenderer.isStarted = FALSE;
	gRenderer.lastRefreshTime = 0;
	gRenderer.isInitialized = TRUE;
	gRenderer.touchAvailable = FALSE;
	gRenderer.rvcStatus = FALSE;

  /* Create process task */
  retVal = renderer_createProcessTask(*r);
  if (E_OK != retVal)
  {
    LOG_PRINT_ERR(DEBUG_RENDERER, "%s():Renderer Task initialization failed!!\r\n", __FUNCTION__);
    return retVal;
  }

	return retVal;
}

Int32 Renderer_start(Renderer r)
{
	/* Check input parameters */
  if (NULL == r)
    return E_ERROR;

  /* Check if the module is initialized */
  if (!r->isInitialized)
    return E_ERROR;

	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);

	if (!r->isStarted)
	{
		/* Force a refresh of sensor segments */
		renderer_refreshSensorChannels(r);
		r->isStarted = TRUE;
	}

	Semaphore_post(r->busySem);

  return E_OK;
}

Int32 Renderer_stop(Renderer r)
{
	/* Check input parameters */
  if (NULL == r)
    return E_ERROR;

  /* Check if the module is initialized */
  if (!r->isInitialized)
    return E_ERROR;

	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);

	if(r->isStarted)
	{
		r->isStarted = FALSE;
	}

	Semaphore_post(r->busySem);

	return E_OK;
}

Int32 Renderer_setLayout(Renderer r, UInt32 id)
{
  /* Check input parameters */
  if (NULL == r)
    return E_ERROR;

  /* Check if the module is initialized */
  if (!r->isInitialized)
    return E_ERROR;

	/* Check layout array boundaries */
	if (LAYOUTS_NUM <= id)
		return E_ERROR;

	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);

	if (r->isStarted)
	{
		/* schedule a layout change on next refresh */
		r->newLayout = (LayoutID) id;
	}
	else
	{
		/* change layout now */
		r->newLayout = (LayoutID) id;
		r->currentLayout = (LayoutID) id;
	}

	Semaphore_post(r->busySem);

	return E_OK;

}

// TODO: AJS Why does this method do nothing?
Int32 Renderer_queueBuffer(Renderer r, Fvid2_FrameList *frameList)
{
	return E_OK;
}

Int32 Renderer_getInstance(Renderer *r)
{
	/* Check if the module is initialized */
	if (!gRenderer.isInitialized)
	{
		/* The module is not initialized. Can't return instance */
		return E_ERROR;
	}

	/* return current instance */
	*r = &gRenderer;

	return E_OK;
}

Int32 Renderer_acquireViewFrame(Renderer r, UInt32 layoutId, RendererFrame *frame)
{
	Int32 retVal = E_OK;
	Fvid2_Frame *outFrame;
	UInt8 *srcAddr;

	/* Check input parameters */
	if ((NULL == r) || (LAYOUTS_NUM <= layoutId) || (NULL == frame))
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	if (r->currentLayout != layoutId)
	{
		return E_ERROR;
	}

	/* acquire a output buffer */
	retVal = GfxQueue_acquire(r->outQueue, &outFrame);
	if (E_OK != retVal)
	{
		/* There is no output frame available */
		LOG_PRINT_ERR(DEBUG_RENDERER, "%s(): Unable to aquire frame\r\n", __FUNCTION__);
		return retVal;
	}

	srcAddr = outFrame->addr[0][0] + gLayouts[layoutId].posX * RENDERER_OUTPUT_FRAME_BPP;

	frame->reserved = outFrame;
	frame->addr = srcAddr;
	frame->width = gLayouts[layoutId].width;
	frame->height = gLayouts[layoutId].height;
	frame->stride = RENDERER_OUTPUT_FRAME_STRIDE;
	frame->bpp = RENDERER_OUTPUT_FRAME_BPP;
	

	return retVal;
}

Int32 Renderer_releaseViewFrame(Renderer r, UInt32 layoutId, RendererFrame *frame)
{
	Int32 retVal = E_OK;

	/* Check input parameters */
	if ((NULL == r) || (LAYOUTS_NUM <= layoutId) || (NULL == frame))
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* release output buffer */
	retVal = GfxQueue_release(r->outQueue, frame->reserved);
	if (E_OK != retVal)
	{
		LOG_PRINT_ERR(DEBUG_RENDERER, "%s(): Unable to release frame\r\n", __FUNCTION__);
		return retVal;
	}

	return retVal;
}

Int32 Renderer_updateSensors(Renderer r, UInt32 *frontSensorFlags, UInt32 *rearSensorFlags)
{
	/* Check input parameters */
	if (NULL == r)
	{
		/* Invalid parameters */
		return E_ERROR;
	}

	/* acquire lock */
	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);

	/* update sensor information */
	if (r->pdcAvailable)
	{
		renderer_updateSensorInfo(r, frontSensorFlags, rearSensorFlags);
	}
	else
	{
		LOG_PRINT_ERR(DEBUG_RENDERER, "(%s) [%d]: Parking sensor module not available. Not doing anything.\r\n", __FUNCTION__, __LINE__);
	}

	/* release lock */
	Semaphore_post(r->busySem);

	return E_OK;
}

Int32 Renderer_updateTouchAvailable(Renderer r, bool_t touchAvailable)
{
	if (NULL == r)
		return E_ERROR;
	
	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);

	r->touchAvailable = touchAvailable;
	renderer_updateButtonLayouts(r);

	Semaphore_post(r->busySem);

	return E_OK;
}

Int32 Renderer_updateRvcStatus(Renderer r, bool_t rvcStatus)
{
	if (NULL == r)
		return E_ERROR;

	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);
	
	r->rvcStatus = rvcStatus;
	renderer_updateButtonLayouts(r);
	
	Semaphore_post(r->busySem);

	return E_OK;
}

Int32 Renderer_updateCar(Renderer r, RendererCar car, bool_t pdcAvailable)
{
	if (NULL == r)
		return E_ERROR;
	
	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);
	
	r->car = car;
	r->pdcAvailable = pdcAvailable;
	renderer_updateCarLayouts(r);
	renderer_updateButtonLayouts(r);
	renderer_updateAlertLayout(r);
	
	Semaphore_post(r->busySem);

	return E_OK;
}

Int32 Renderer_updateLanguage(Renderer r, Language_en language)
{
	if (NULL == r)
		return E_ERROR;

	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);
	
	r->language = language;
	renderer_updateAlertLayout(r);
	
	Semaphore_post(r->busySem);

	return E_OK;
}

Int32 Renderer_updateSwitchOn(Renderer r, bool_t switchOn)
{
	if (NULL == r)
		return E_ERROR;
	
	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);
	
	r->switchOn = switchOn;
	renderer_updateButtonLayouts(r);

	Semaphore_post(r->busySem);

	return E_OK;
}

Int32 Renderer_updateFrontPdcSensorsAvailable(Renderer r, bool_t sensorsAvailable)
{
	if (NULL == r)
		return E_ERROR;

	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);

	r->frontParkingSensorsAvailable = sensorsAvailable;
	renderer_updateFrontParkingSensors(r);

	Semaphore_post(r->busySem);

	return E_OK;
}

Int32 Renderer_updateRearPdcSensorsAvailable(Renderer r, bool_t sensorsAvailable)
{
	if (NULL == r)
		return E_ERROR;

	Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);

	r->rearParkingSensorsAvailable = sensorsAvailable;
	renderer_updateRearParkingSensors(r);

	Semaphore_post(r->busySem);

	return E_OK;
}

UInt32 Renderer_getRvcAndPdcLayout(void)
{
  return RVC_AND_PDC_LAYOUT_INDEX;
}

UInt32 Renderer_getPdcOnlyLayout(void)
{
  return PDC_ONLY_LAYOUT_INDEX;
}

int Renderer_getCurrentLayout(Renderer r, UInt32 *current_layout)
{
  /* Check input parameters */
  if (NULL == r)
    return E_ERROR;

  /* Check if the module is initialized */
  if (!r->isInitialized)
    return E_ERROR;

  Semaphore_pend(r->busySem, BIOS_WAIT_FOREVER);
  *current_layout = r->currentLayout;
  Semaphore_post(r->busySem);

  return E_OK;
}

Int32 Renderer_getPdcExitButtonGeometry(ResourceGeometry_t *geometry)
{
	if (NULL == geometry)
		return E_ERROR;
	
	memcpy(geometry, &resourceGeometries[R_PDC_ONLY_LAYOUT_EXIT_ENABLED], sizeof(*geometry));

	return E_OK;
}

Int32 Renderer_getPdcSwitchButtonGeometry(ResourceGeometry_t *geometry)
{
	if (NULL == geometry)
		return E_ERROR;
	
	memcpy(geometry, &resourceGeometries[R_PDC_ONLY_LAYOUT_SWITCH_ENABLED], sizeof(*geometry));

	return E_OK;
}

Int32 Renderer_getPdcCarButtonGeometry(ResourceGeometry_t *geometry)
{
	if (NULL == geometry)
		return E_ERROR;
	
	memcpy(geometry, &resourceGeometries[R_PDC_ONLY_LAYOUT_CAR_AMAROK], sizeof(*geometry));

	return E_OK;
}

Int32 Renderer_getRvcExitButtonGeometry(ResourceGeometry_t *geometry)
{
	if (NULL == geometry)
		return E_ERROR;
	
	memcpy(geometry, &resourceGeometries[R_RVC_AND_PDC_LAYOUT_EXIT_ENABLED], sizeof(*geometry));

	return E_OK;
}

Int32 Renderer_getRvcSwitchButtonGeometry(ResourceGeometry_t *geometry)
{
	if (NULL == geometry)
		return E_ERROR;
	
	memcpy(geometry, &resourceGeometries[R_RVC_AND_PDC_LAYOUT_SWITCH_ENABLED], sizeof(*geometry));

	return E_OK;
}

Int32 Renderer_getRvcCarButtonGeometry(ResourceGeometry_t *geometry)
{
	if (NULL == geometry)
		return E_ERROR;
	
	memcpy(geometry, &resourceGeometries[R_RVC_AND_PDC_LAYOUT_CAR_AMAROK], sizeof(*geometry));

	return E_OK;
}

Int32 Renderer_getRvcBackgroundGeometry(ResourceGeometry_t *geometry)
{
	if (NULL == geometry)
		return E_ERROR;
	
	memcpy(geometry, &resourceGeometries[R_RVC_AND_PDC_LAYOUT_BACKGROUND], sizeof(*geometry));

	return E_OK;
}

Int32 Renderer_getRvcAlertBackgroundGeometry(ResourceGeometry_t *geometry)
{
	if (NULL == geometry)
		return E_ERROR;
	
	memcpy(geometry, &resourceGeometries[R_RVC_AND_PDC_LAYOUT_ALERT_BACKGROUND], sizeof(*geometry));

	return E_OK;
}
