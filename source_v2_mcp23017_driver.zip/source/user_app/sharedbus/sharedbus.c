/*===========================================================================*/
/**
 * @file sharedbus.c
 *
 * SharedBus
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#include <crc.h>
#include <sharedbus.h>
#include <sharedbus_cfg.h>
#include <console.h>

#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>

#include <ti/ipc/remoteproc/Resource.h>
#include <ti/ipc/remoteproc/rsc_types.h>
#include <ti/ipc/ipcmgr/IpcMgr.h>


#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *==========================================================================*/
#define DEBUG_EN

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef struct SBMsg
{
   MessageQ_MsgHeader header;     // Required
   uint32_t crc32;
   char srcName[SB_MAX_NAME_LENGTH];
   uint32_t data_length;
   uint8_t data[];
} SBMsg;

/*===========================================================================*
 * External Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
/***************************************************************************//**
* @fn           sb_PrepareMsg
* @brief        Prepare the Message
* @param [in]   src_name - Source queue's name
* @param [in]   dst_name - Destination queue's name
* @param [in]   sbMsgId - Message ID
* @param [in]   data - Pointer to data buffer
* @param [in]   length - Data length
* @retval       Pointer to the allocated memory or NULL on error
******************************************************************************/
SBMsg* sb_PrepareMsg(String srcName, uint32_t sbMsgId,
                     uint8_t* data, uint32_t length);

/***************************************************************************//**
* @fn           sb_MsgQNameValid
* @brief        Verify if MessageQ with that name already exist
* @retval       0 - Success
* @retval       -1 - MessageQ already exist
******************************************************************************/
int32_t sb_MsgQNameValid(String Name);
/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
int32_t SB_OpenMsgQ(String name)
{
   int32_t status=(-1);
   uint32_t i;
   uint32_t sbConnectQEntries;
   SBConnectQId* sbConnectQId;

   SBCbk_GetConnectInfo(&sbConnectQId, &sbConnectQEntries);

   LOG_PRINT(DEBUG_SB, "Looking for MessageQ clients to link\n");

   if((NULL != name) && ('\0' != name[0])){
      if(0 == sb_MsgQNameValid(name)){
         for(i = 0; i < sbConnectQEntries; i++){
            if(0 == sbConnectQId[i].connectQId){
               if(MessageQ_S_SUCCESS ==
                  MessageQ_open(name, &sbConnectQId[i].connectQId)){

                  strncpy(sbConnectQId[i].name, name, SB_MAX_NAME_LENGTH);
                  sbConnectQId[i].timeout = SB_CONNECTION_TIMEOUT;
                  status = 0;
                  break;
                }
            }
         }
      }
   }

   return(status);
}

int32_t SB_CloseMsgQ(String name)
{
   int32_t status = (-1);
   uint32_t i;
   uint32_t sbConnectQEntries;
   SBConnectQId* sbConnectQId;

   SBCbk_GetConnectInfo(&sbConnectQId, &sbConnectQEntries);

   LOG_PRINT(DEBUG_SB, "Looking for MessageQ clients to close\n");

   if(name != NULL){
      for(i = 0; i < sbConnectQEntries; i++){
         if(0 == strncmp(sbConnectQId[i].name, name, SB_MAX_NAME_LENGTH)){
            sbConnectQId[i].connectQId=0;
            memset(sbConnectQId[i].name, 0, SB_MAX_NAME_LENGTH);
            sbConnectQId[i].timeout=0;
            status=0;
            break;
         }
      }
   }

   return(status);
}

int32_t SB_CloseAllMsgQ(void)
{
   int32_t status = 0;
   uint32_t sbConnectQEntries;
   SBConnectQId* sbConnectQId;

   SBCbk_GetConnectInfo(&sbConnectQId, &sbConnectQEntries);

   LOG_PRINT(DEBUG_SB, "Closing MessageQ clients\n");

   memset(sbConnectQId, 0, (sizeof(SBConnectQId)*sbConnectQEntries));

   return(status);
}

int32_t SB_UpdateTimeout(String name)
{
   int32_t status = (-1);
   uint32_t i;
   uint32_t sbConnectQEntries;
   SBConnectQId* sbConnectQId;

   SBCbk_GetConnectInfo(&sbConnectQId, &sbConnectQEntries);

   LOG_PRINT(DEBUG_SB, "Looking for MessageQ clients to update timer\n");

   if(NULL != name){
      for(i = 0; i < sbConnectQEntries; i++){
         if (0 == strncmp((String)sbConnectQId[i].name, name, SB_MAX_NAME_LENGTH)){
            sbConnectQId[i].timeout = SB_CONNECTION_TIMEOUT;
            status = 0;
            break;
         }
      }
   }

   return(status);
}

MessageQ_Handle SB_CreateMsgQ(String name)
{
   LOG_PRINT(DEBUG_SB, "Creating MessageQ\n");

   MessageQ_Params msgQParams;
   MessageQ_Params_init(&msgQParams);

   return(MessageQ_create(name, &msgQParams));
}

int32_t SB_DeleteMsgQ(MessageQ_Handle* pMessageQ_Handle)
{
   LOG_PRINT(DEBUG_SB, "Deleting MessageQ\n");
   return(MessageQ_delete(pMessageQ_Handle));
}

int32_t SB_AllocateHeap (uint16_t heapId)
{
   LOG_PRINT(DEBUG_SB, "Allocating heap:%d\n", heapId);
   return(MessageQ_registerHeap(NULL, heapId));
}

int32_t SB_FreeHeap(uint16_t heapId)
{
   LOG_PRINT(DEBUG_SB, "Freeing heap %d\n", heapId);
   return(MessageQ_unregisterHeap(heapId));
}

SBMsg* sb_PrepareMsg(String srcName, uint32_t sbMsgId, 
                     uint8_t* data, uint32_t length)
{
   uint16_t heapId;
   SBMsg *pTxMsg = NULL;

   if((NULL != srcName) && ('\0' != srcName[0])){
      SBCbk_GetHeapId(&heapId);
      if (NULL == (pTxMsg = (SBMsg*)MessageQ_alloc(heapId,
                                                sizeof(MessageQ_MsgHeader) +
                                                sizeof(pTxMsg->crc32) +
                                                SB_MAX_NAME_LENGTH +
                                                sizeof(pTxMsg->data_length) +
                                                length))){
         LOG_PRINT_ERR(DEBUG_SB, "Can not allocate MessageQ for heap:%d\n", heapId);
         pTxMsg = NULL;
         }
      else{
          LOG_PRINT(DEBUG_SB, "Preparing message for: %s\n", pTxMsg->srcName);
          /*MessageQ_setMsgId(pTxMsg->header, sbMsgId);*/
          pTxMsg->header.msgId=(uint16_t)sbMsgId;
          pTxMsg->data_length = length;
          strncpy(pTxMsg->srcName, srcName, SB_MAX_NAME_LENGTH);

          pTxMsg->crc32=crc32(0, pTxMsg->srcName, strlen(pTxMsg->srcName));
          pTxMsg->crc32=crc32(pTxMsg->crc32, &(pTxMsg->data_length),
                               sizeof(pTxMsg->data_length));

          if(0 < pTxMsg->data_length){
             memcpy(pTxMsg->data, data, pTxMsg->data_length);
             pTxMsg->crc32=crc32(pTxMsg->crc32, pTxMsg->data, pTxMsg->data_length);
          }
      }
   }

   return(pTxMsg);
}

int32_t SB_Send(String srcName, String dstName, uint32_t sbMsgId, 
               uint8_t* data, uint32_t length)
{
   int32_t status = (-1);
   uint32_t i;
   uint32_t sbConnectQEntries;
   SBMsg *pTxMsg = NULL;
   SBConnectQId* sbConnectQId;

   SBCbk_GetConnectInfo(&sbConnectQId, &sbConnectQEntries);

   if(NULL != srcName){
      if(NULL == dstName){
         LOG_PRINT(DEBUG_SB, "Sending message to all [%d] clients\n",
                   sbConnectQEntries);
         for(i = 0; i < sbConnectQEntries; i++){
            LOG_PRINT(DEBUG_SB,"Looking for available QId %d [index=%d]\n",
                      sbConnectQId[i].connectQId, i);
            if(0 != sbConnectQId[i].connectQId){
               if(NULL != (pTxMsg = sb_PrepareMsg(srcName, sbMsgId,
                                                            data, length))){
                  if(0 == MessageQ_put(sbConnectQId[i].connectQId,
                                       (MessageQ_Msg)pTxMsg)){
                     status = (0);
                     LOG_PRINT(DEBUG_SB, "Message delivered to %d[index=%d]\n",
                               sbConnectQId[i].connectQId, i);
                  }
                  else{
                     MessageQ_free((MessageQ_Msg)pTxMsg);
                     pTxMsg = NULL;
                     LOG_PRINT_ERR(DEBUG_SB,"Delivery to %d fails, sender stopped\n",
                                   sbConnectQId[i].connectQId);
                     break;
                  }
               }
               else{
                  LOG_PRINT_ERR(DEBUG_SB,"Allocation for %d fails, allocator stopped\n",
                                sbConnectQId[i].connectQId);
                  break;
               }
            }
            else{
                LOG_PRINT_INFO(DEBUG_SB,"Q[%d] unavailable to receive data\n", i);
            }
         }
      }
      else{
         if('\0' != dstName[0]){
            for(i = 0; i < sbConnectQEntries; i++){
               if(0 != sbConnectQId[i].connectQId){
                  if(0 !=
                     strncmp(sbConnectQId[i].name, dstName, SB_MAX_NAME_LENGTH)){
                     LOG_PRINT(DEBUG_SB,"Sending message to QId client:%d\n",
                              sbConnectQId[i].connectQId);
                     if(NULL != (pTxMsg = sb_PrepareMsg(srcName, sbMsgId,
                                                        data, length))){
                        if(0 == MessageQ_put(sbConnectQId[i].connectQId,
                                             (MessageQ_Msg)pTxMsg)){
                           status = (0);
                        }
                        else{
                           MessageQ_free((MessageQ_Msg)pTxMsg);
                           pTxMsg = NULL;
                           LOG_PRINT_ERR(DEBUG_SB,"Delivery to %d fails,"
                                         "sender stopped\n",
                                         sbConnectQId[i].connectQId);
                        }
                     }
                     else{
                        LOG_PRINT_ERR(DEBUG_SB,"Allocation for %d fails,"
                                      "allocator stopped\n",
                                      sbConnectQId[i].connectQId);
                     }
                     break;
                  }
               }
               else{
                   LOG_PRINT_ERR(DEBUG_SB,"%s unavailable to receive data\n",
                                 dstName);
               }
            }
         }
         LOG_PRINT_ERR(DEBUG_SB, "Invalid destination name\n");
      }
   }
   else{
      LOG_PRINT_ERR(DEBUG_SB, "Invalid source name\n");
   }

   return(status);
}

int32_t SB_Receive(MessageQ_Handle msgQHandle, uint32_t timeout, 
                  SBMsgHandler *sbMsgHandler, uint32_t sbNumMsg)
{
   SBMsg *pRxMsg = NULL;
   char *rcvName = NULL;
   Bits16 rcvMsgId;
   Bits32 rcvMsgSize;
   uint8_t *rcvData = NULL;
   uint32_t crc = 0;
   uint32_t rcvLen = 0;
   int32_t status = MessageQ_get(msgQHandle, (MessageQ_Msg*)&pRxMsg, timeout);

   switch(status)
   {
      case MessageQ_S_SUCCESS:
         /*rcvMsgId = MessageQ_getMsgId(MessageQ_Msg(pRxMsg->header));
         rcvMsgSize = MessageQ_getMsgSize(pRxMsg->header);*/
         rcvMsgId = pRxMsg->header.msgId;
         rcvMsgSize = pRxMsg->header.msgSize;

         crc = crc32(0, pRxMsg->srcName, strlen(pRxMsg->srcName));
         crc = crc32(crc, &(pRxMsg->data_length), sizeof(pRxMsg->data_length));
         if(rcvMsgSize > (sizeof(MessageQ_MsgHeader) + sizeof(pRxMsg->crc32) +
                          SB_MAX_NAME_LENGTH + sizeof(pRxMsg->data_length))){
            crc = crc32(crc, pRxMsg->data, pRxMsg->data_length);
         };

         if((pRxMsg->crc32 == crc) &&
            (rcvMsgId < sbNumMsg) &&
            ('\0' != pRxMsg->srcName[0])){

            rcvName = malloc(SB_MAX_NAME_LENGTH*sizeof(rcvName));
            strncpy(rcvName, pRxMsg->srcName, SB_MAX_NAME_LENGTH);

            if(0 < pRxMsg->data_length){
               rcvLen = pRxMsg->data_length;
               rcvData = malloc(pRxMsg->data_length);
               memcpy(rcvData, pRxMsg->data, rcvLen);
            }

            /* First of all is necessary to release the resources
             * in case we need to send a message from a handler! */
            if(0 != MessageQ_free((MessageQ_Msg)pRxMsg)){
               LOG_PRINT_ERR(DEBUG_SB,"Message free fails\n");
               status = (-1);
            }
            else{
               pRxMsg = NULL;

               /* Call to the process message handler */
               (*sbMsgHandler[rcvMsgId])((String)rcvName, rcvData, rcvLen);

               status = (0);
            }

            free(rcvName);
            rcvName=NULL;

            if(0 < rcvLen){
               free(rcvData);
               rcvData=NULL;
            }

            LOG_PRINT_INFO(DEBUG_SB,"Message successfully received\n");
         }
         else{
            LOG_PRINT_ERR(DEBUG_SB,"Message invalid Id:[0x%x?<0x%x] Name:[%s?]"
                           " crc:[0x%x?=0x%x}]\n", rcvMsgId, sbNumMsg,
                           pRxMsg->srcName, pRxMsg->crc32, crc);
            MessageQ_free((MessageQ_Msg)pRxMsg);
            status = (-1);
         }
         break;
      case MessageQ_E_FAIL:
      case MessageQ_E_TIMEOUT:
      case MessageQ_E_UNBLOCKED:
      default:
         LOG_PRINT_ERR(DEBUG_SB,"Message receiver fails [%d]]\n", status);
         status = (-1);
         break;
   }
   return(status);
}

void SB_EvalConnectTimeouts(void)
{
   uint32_t i;
   uint32_t sbConnectQEntries;
   SBConnectQId* sbConnectQId;

   SBCbk_GetConnectInfo(&sbConnectQId, &sbConnectQEntries);

   for(i = 0; i < sbConnectQEntries; i++){
      if(sbConnectQId[i].connectQId != 0){
         LOG_PRINT(DEBUG_SB,"[Id%d.%d]TimeOut:%d\n",
                  sbConnectQId[i].connectQId, i, sbConnectQId[i].timeout);
         if(0 < sbConnectQId[i].timeout){
            sbConnectQId[i].timeout--;
         }
         else{
            SB_CloseMsgQ(sbConnectQId[i].name);
         }
      }
   }
}

void SB_Init(void)
{
   uint32_t sbConnectQEntries;
   SBConnectQId* sbConnectQId;

   SBCbk_GetConnectInfo(&sbConnectQId, &sbConnectQEntries);

   LOG_PRINT_INFO(DEBUG_SB, "Initializing %d QEntries", sbConnectQEntries);
   memset(sbConnectQId, 0, (sizeof(SBConnectQId)*sbConnectQEntries));
}

int32_t sb_MsgQNameValid(String Name)
{
   int32_t status=(0);
   uint32_t i;
   uint32_t sbConnectQEntries;
   SBConnectQId* sbConnectQId;

   SBCbk_GetConnectInfo(&sbConnectQId, &sbConnectQEntries);

   for(i = 0; i < sbConnectQEntries; i++){
      if(0 == strncmp(sbConnectQId[i].name, Name, SB_MAX_NAME_LENGTH)){
         LOG_PRINT(DEBUG_SB, "MessageQ %s exist!\n", sbConnectQId[i].name);
         status = (-1);
         break;
      }
   }

   return(status);
}
