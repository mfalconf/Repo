#ifndef SHAREDBUS_H_
#define SHAREDBUS_H_
/*===========================================================================*/
/**
 * @file sharedbus.h
 *
 * Function definitions for the SharedBus module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2018 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <xdc/std.h>
#include <ti/ipc/MessageQ.h>
#include "sharedbus_cfg.h"

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define SB_MS_TIME(msec) (((msec*1000) / Clock_tickPeriod))

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef struct SBConnectQId
{
   MessageQ_QueueId  connectQId;
   char              name[SB_MAX_NAME_LENGTH];
   uint32_t          timeout;
}SBConnectQId;

typedef void (*SBMsgHandler) (String name, uint8_t *data, uint32_t length);

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/***************************************************************************//**
* @fn          SB_OpenMsgQ
* @brief       Open a MessageQ TI IPC to enable the communication between cores
* @param [in]  name - The name to identify the connection
* @retval      0 - Success
* @retval      1 - no room to open a new connectQ
******************************************************************************/
int32_t SB_OpenMsgQ(String name);

/***************************************************************************//**
* @fn          SB_CloseMsgQ
* @brief       Close the MessageQ TI IPC
* @param [in]  name - The name to identify the connection
* @retval      0 - Success
* @retval      -1 - The connectQ was not found
******************************************************************************/
int32_t SB_CloseMsgQ(String name);

/***************************************************************************//**
* @fn       SB_CloseAllMsgQ
* @brief    Close ALL the opened MessageQ TI IPC
* @param    void
* @retval   0 - Success
* @retval   -1 - The connectQ was not found
******************************************************************************/
int32_t SB_CloseAllMsgQ(void);

/***************************************************************************//**
* @fn          SB_UpdateTimeout
* @brief       Update the connection timeout
* @param [in]  name - The name to identify the connection
* @retval      0 - Success
* @retval      -1 - The connectQ was not found
******************************************************************************/
int32_t SB_UpdateTimeout(String name);

/***************************************************************************//**
* @fn          SB_CreateMsgQ
* @brief       Create a MessageQ TI IPC
* @param [in]  name - The name to identify the queue to create
* @retval      MessageQ_Handle - The handle to manage the created queue
* @retval      MessageQ_E_FAIL - The operation failed
******************************************************************************/
MessageQ_Handle SB_CreateMsgQ(String name);

/***************************************************************************//**
* @fn          SB_DeleteMsgQ
* @brief       Delete a MessageQ TI IPC
* @param [in]  pMessageQ_Handle - A pointer to the MessageQ_Handle obtained
*              during the create operation
* @retval      MessageQ_S_SUCCESS - The MessageQ was deleted successfully
* @retval      MessageQ_E_FAIL - The operation failed
******************************************************************************/
int32_t SB_DeleteMsgQ(MessageQ_Handle* pMessageQ_Handle);

/***************************************************************************//**
* @fn          SB_AllocateHeap
* @brief       Allocate the heap to be used during the malloc operations
* @param [in]  heapId - The heap to allocate
* @retval      MessageQ_S_SUCCESS - The heap was allocated successfully
* @retval      MessageQ_E_ALREADYEXISTS - The requested heap is already in use
******************************************************************************/
int32_t SB_AllocateHeap(uint16_t heapId);

/***************************************************************************//**
* @fn          SB_FreeHeap
* @brief       Free the heap used during the malloc operations
* @param [in]  heapId - The heap to free
* @retval      MessageQ_S_SUCCESS - The heap was free successfully
* @retval      MessageQ_E_NOTFOUND - The requested heap is not in use
******************************************************************************/
int32_t SB_FreeHeap(uint16_t heapId);

/***************************************************************************//**
* @fn           SB_Receive
* @brief       Receive a message using the MessageQ TI IPC
* @param [in]  msgQHandle - The handle of the messageQ to receive
* @param [in]  timeout - The timing to wait for an incoming message [x100us]
* @param [in]  sbMsgHandler - A pointer to a vector of handlers
* @param [in]  sbNumMsg - The maximum number of available messages
* @retval      MessageQ_S_SUCCESS - The message was received and processed successfully
* @retval      MessageQ_E_TIMEOUT - The timeout elapse without receiving any message
* @retval      MessageQ_E_FAIL - CRC error or unsuccessful reception
******************************************************************************/
int32_t SB_Receive(MessageQ_Handle msgQHandle, uint32_t timeout,
                   SBMsgHandler *sbMsgHandler, uint32_t sbNumMsg);

/***************************************************************************//**
* @fn          SB_Send
* @brief       Send a message using the MessageQ TI IPC
* @param [in]  srcName - The name of the Source of the message
*              (if NULL will be replaced by UNKNOWN)
* @param [in]  dstName - The name of the Destination of the message
*              (NULL to send in broadcast)
* @param [in]  sbMsgQId - The id of the messageQ to use to send
* @param [in]  sb_MsgId - The id of the message to send
* @param [in]  data - A pointer to the data to send
* @param [in]  length - The length of the data field
* @retval      0 - The message was send successfully
* @retval      -1 - The memory allocation or the send using the messageQ was
*              unsuccessful
******************************************************************************/
int32_t SB_Send(String src_name, String dst_name, uint32_t sbMsgId,
                uint8_t* data, uint32_t length);

/***************************************************************************//**
* @fn       SB_EvalConnectTimeoutst
* @brief    This function shall be called every 1second to verify the timeout
*           elapse for every connection
* @param    void
* @return   void
******************************************************************************/
void SB_EvalConnectTimeouts(void);

/***************************************************************************//**
* @fn       SB_Init
* @brief    Initialize the module (mainly for local variables)
* @param    void
* @return   void
******************************************************************************/
void SB_Init(void);

/* THESE FUNCTIONS ARE CALLBACK AND SHALL BE IMPLEMENTED IN THE MAIN MODULE */
extern void SBCbk_GetConnectInfo(SBConnectQId** sbConnectQId,
                                 uint32_t* sbConnectQEntries);
extern void SBCbk_GetHeapId(uint16_t* heapId);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
#endif /* SHAREDBUS_H_ */
