#ifndef CRC_H
#   define CRC_H
/*===========================================================================*/
/**
 * @file crc.h
 *
 * CRC calc
 *
 * %full_filespec:definiti.h~1:incl:kok_basa#31 %
 * @version %version:1 %
 * @author  %derived_by:tz74ph %
 * @date    %date_modified:Thu Jun  6 16:38:14 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2016 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 * Global defines of miscellaneous useful stuff.
 * Author: Dan Carman
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup myApp Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/
uint32_t crc32 (uint32_t crc, const void *buf, size_t size);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file crc.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 23-sep-2016 Pablo Luis Joaquim
 *   - Created initial file.
 *
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* CRC_C */
