/******************************************************************************
 *
 * \file    zip_memory_file.h
 *
 * \brief   ZIP Memory file header file
 *
 * \author  Esteban Pupillo
 *
 * \date    23 Sep 2022
 *
 *****************************************************************************/
#ifndef __ZIP_MEMORY_FILE_H__
#define __ZIP_MEMORY_FILE_H__

/**
 * @addtogroup ZipMemoryFile
 * @{
 */
#include <standard.h>
#include <xdc/std.h>
#include <libs/junzip/junzip.h>

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Creates a ZIP Memory file handler
 *
 * @param baseAddress memory address where the file starts
 * @param size the size of the file
 * 
 * @return NULL on error
 */
JZFile* ZipMemoryFile_create(UInt32 *baseAddress, UInt32 size);

/**
 * @brief destroy a ZIP Memory file handler
 *
 * @param file pointer to file handler to destroy
 * 
 * @return #E_OK on success
 */
Int32 ZipMemoryFile_destroy(JZFile *file);

/**
 * Close doxygen group
 * @}
 */

#endif //__ZIP_MEMORY_FILE_H__
