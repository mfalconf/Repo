/*===========================================================================*/
/**
 * @file bit_utils.c
 *
 *
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#include <standard.h>
#include <console.h>
#include <xdc/runtime/System.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <bit_utils.h>

/*===========================================================================*\
 * Local Preprocessor #define Constants
\*===========================================================================*/


/*===========================================================================*\
 * Local Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Local Type Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Object Definitions
\*===========================================================================*/

static const uint8_t Mod37BitPosition[] = /* map a bit value mod 37 to its position */
{
  32, 0, 1, 26, 2, 23, 27, 0, 3, 16, 24, 30, 28, 11, 0, 13, 4,
  7, 17, 0, 25, 22, 31, 15, 29, 10, 12, 6, 0, 21, 14, 9, 5,
  20, 8, 19, 18
};


/*===========================================================================*\
 * Local Function Prototypes
\*===========================================================================*/

/*===========================================================================*\
 * Local Inline Function Definitions and Function-Like Macros
\*===========================================================================*/

/*===========================================================================*\
 * Function Definitions
\*===========================================================================*/
/***************************************************************************//**
 *
 * @fn         BitUtils_Get_TrailingZeros
 *
 * @brief      Count the consecutive zero bits (trailing) on the right
 *             of a 32 bit number using with modulus division
 *             and a lookup table
 *
 * @param [in] uint32_t - number to find the number of trailing zeros
 *
 * @return     uint8_t - number of trailing zeros
 *
 ******************************************************************************/
uint8_t BitUtils_CountTrailingZeros32(uint32_t v)
{
    return (Mod37BitPosition[(-v & v) % 37]);
}

/***************************************************************************//**
 *
 * @fn         BitUtils_Get_TrailingZeros64
 *
 * @brief      Count the consecutive zero bits (trailing) on the right
 *             of a 64 bit number using binary search with modulus division
 *             and a lookup table
 *
 * @param [in] uint64_t data - number to find the number of trailing zeros
 *
 * @return     uint8_t - number of trailing zeros
 *
 ******************************************************************************/
uint8_t BitUtils_CountTrailingZeros64(uint64_t v)
{
    uint8_t z; //Number of zero bits on the right
    uint32_t const bitmask = 0xffffffff;
    uint32_t lsw = 0;
    uint32_t msw = 0;

    lsw = v & bitmask;
    msw = (v >> 32) & bitmask;

    if(lsw)
    {
        z = BitUtils_CountTrailingZeros32(lsw);
    }
    else
    {
        z = 32;
        z += BitUtils_CountTrailingZeros32(msw);
    }

    return z;
}
