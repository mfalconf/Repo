/*===========================================================================*/
/**
 * @file clock_utils.c
 *
 *
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#include "standard.h"
#include <xdc/runtime/System.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>

#include "clock_utils.h"

/*===========================================================================*\
 * Local Preprocessor #define Constants
\*===========================================================================*/


/*===========================================================================*\
 * Local Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Local Type Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Object Definitions
\*===========================================================================*/

static Semaphore_Handle cu_sem = NULL;
static uint32_t cu_accumulatedTimeMs;
static bool_t cu_initialized = false;

/*===========================================================================*\
 * Local Function Prototypes
\*===========================================================================*/

/*===========================================================================*\
 * Local Inline Function Definitions and Function-Like Macros
\*===========================================================================*/

/*===========================================================================*\
 * Function Definitions
\*===========================================================================*/
/***************************************************************************//**
 *
 * @fn         ClockUtils_Get_Time
 *
 * @brief      Returns since system startup in milli-seconds
 *
 * @param [in] void
 *
 * @return     void
 *
 ******************************************************************************/
uint32_t ClockUtils_Get_Time(void)
{
    Semaphore_pend(cu_sem, BIOS_WAIT_FOREVER);

    uint32_t msSec = 0;

    msSec = cu_accumulatedTimeMs;

    Semaphore_post(cu_sem);

    return(msSec);
}

/***************************************************************************//**
 *
 * @fn         ClockUtils_Elapsed_Time
 *
 * @brief      Returns elapsed time since timestamp in milli-seconds
 *
 * @param [in] uint32_t timeStampMs
 *
 * @return     void
 *
 ******************************************************************************/
uint32_t ClockUtils_Elapsed_Time(uint32_t timeStampMs)
{
    Semaphore_pend(cu_sem, BIOS_WAIT_FOREVER);

    uint32_t msSec = 0;

    msSec = (cu_accumulatedTimeMs - timeStampMs);

    Semaphore_post(cu_sem);

    return(msSec);
}

/***************************************************************************//**
 *
 * @fn         ClockUtil_Update
 *
 * @brief      Increment the local counter by an ammount of milli-seconds
 *
 * @param [in] uint32_t msIncrease - the number of milli-seconds to increase
 *                                   the counter
 *
 * @return     void
 *
 ******************************************************************************/
void ClockUtil_Update(uint32_t msIncrease)
{
    Semaphore_pend(cu_sem, BIOS_WAIT_FOREVER);

    cu_accumulatedTimeMs += msIncrease;

    Semaphore_post(cu_sem);
}

/***************************************************************************//**
 *
 * @fn         ClockUtil_Init
 *
 * @brief      Init the Clock
 *
 * @param [in]
 *
 * @return     void
 *
 ******************************************************************************/
void ClockUtil_Init()
{
    if (false == cu_initialized) {
        cu_initialized = true;
        cu_sem = Semaphore_create(1, NULL, NULL);
        cu_accumulatedTimeMs = 0;
    }
}

/*===========================================================================*/
/*!
 * @file clock_utils.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 17-Jul-2018 Pablo Daniel Folino
 *   - Created initial file.
 *
\*===========================================================================*/
