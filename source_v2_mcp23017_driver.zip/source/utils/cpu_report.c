#include <cpu_report.h>

#include <xdc/std.h>
#include <xdc/runtime/Error.h>

#include <ti/sysbios/knl/Task.h>

#include <ti/sysbios/utils/Load.h>

#include <console.h>

#define DEBUG_CPU_REPORT              (1)

#define CPU_REPORT_TASK_STACK_SIZE    (0x1000)

#define CPU_REPORT_TIME_MS            (20000)

static uint8_t cpuReportStack[CPU_REPORT_TASK_STACK_SIZE];

/** Print the current CPU load report */
static void CpuReport_getAndPrintCpuReport() 
{
	UInt load;
	Load_Stat stat;
	Task_Handle idleTskHandle;
	idleTskHandle = Task_getIdleTaskHandle(0);
	Load_getTaskLoad(idleTskHandle, &stat);
	load = Load_calculateLoad(&stat);

  System_printf("v-------------------v\n");
	System_printf("| Load CPU-0 = %d%s%s  |\n", (100-load), (100-load) < 10 ? " " : "", (100-load) < 100 ? " " : "");

  idleTskHandle = Task_getIdleTaskHandle(1);
	Load_getTaskLoad(idleTskHandle, &stat);
	load = Load_calculateLoad(&stat);
  System_printf("+-------------------+\n");
	System_printf("| Load CPU-1 = %d%s%s  |\n", (100-load), (100-load) < 10 ? " " : "", (100-load) < 100 ? " " : "");
  System_printf("^-------------------^\n");
}

/**
 * @brief Task to periodically print the CPU load
 * 
 * @param arg0 NULL in this case
 * @param arg1 NULL in this case
 */
static void CpuReport_task(UArg arg0, UArg arg1)
{
  LOG_PRINT_INFO(DEBUG_CPU_REPORT, "%s(): Starting task...\r\n", __FUNCTION__);

  while (1)
  {
    CpuReport_getAndPrintCpuReport();
		Task_sleep(CPU_REPORT_TIME_MS);
  }
}

void CpuReport_Init(void)
{
  Error_Block eb;
  Task_Params taskParams;
  Task_Handle task_h;

  Error_init(&eb);

  Task_Params_init(&taskParams);
  taskParams.instance->name = "CpuReport";
  taskParams.arg0 = NULL;
  taskParams.arg1 = NULL;
  taskParams.stack = cpuReportStack;
  taskParams.stackSize = sizeof(cpuReportStack) / sizeof(cpuReportStack[0]);
  taskParams.affinity = APP_CORE_NUM;
 
  task_h = Task_create(CpuReport_task, &taskParams, &eb);

  if (NULL == task_h)
  {
    LOG_PRINT_ERR(DEBUG_CPU_REPORT, "Couldn't create CPU report task!\r\n");
  }
}
