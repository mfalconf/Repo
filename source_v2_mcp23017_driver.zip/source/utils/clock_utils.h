#ifndef CLOCK_UTILS_H
#   define CLOCK_UTILS_H
/*===========================================================================*/
/**
 * @file clock_utils.h
 *
  */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#include <standard.h>

#include <ti/sysbios/knl/Clock.h>
//#include <ti/sysbios/hal/Seconds.h>


#   ifdef __cplusplus
extern "C"
{

#   endif                       /* __cplusplus */

/*===========================================================================*\
 * Exported Preprocessor #define Constants
\*===========================================================================*/

/*===========================================================================*\
 * Exported Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Exported Type Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Function Prototypes
\*===========================================================================*/
extern uint32_t ClockUtils_Get_Time(void);
uint32_t ClockUtils_Elapsed_Time(uint32_t timeStampMs);
extern void ClockUtil_Update(uint32_t msIncrease);
extern void ClockUtil_Init();


/*===========================================================================*\
 * Exported Inline Function Definitions and #define Function-Like Macros
\*===========================================================================*/


#   ifdef __cplusplus
}
#   endif                       /* __cplusplus */
/*===========================================================================*/
/*!
 * @file clock_utils.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 17-Jul-2018 Pablo Daniel Folino
 *   - Created initial file.
 *
\*===========================================================================*/
/** @} doxygen end group */
#endif                          /* CONVERSIONS_H */
