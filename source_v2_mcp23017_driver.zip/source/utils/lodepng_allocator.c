/******************************************************************************
 *
 * \file    lodepng_allocator.c
 *
 * \brief   Memory allocator used for lodepng
 *
 * \author  Esteban Pupillo
 *
 * \date    23 Jun 2022
 *
 *****************************************************************************/
//#define LOG_DEBUG_SUPER_VERBOSE

#include <lodepng_allocator.h>

#include <standard.h>
#include "console.h"
#include <xdc/std.h>

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>
#include <xdc/runtime/IHeap.h>

#include <ti/sysbios/hal/Cache.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/heaps/HeapMem.h>

#include "libs/lodepng/lodepng.h"
#include "video_heap.h"

/**
 * @addtogroup LodepngAllocator
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/
#define DEBUG_LODEPNG_ALLOCATOR 0

#define LODEPNG_ALLOCATOR_MAX_ENTRIES    (32)
// #define LODEPNG_ALLOCATOR_USE_DMA

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
typedef struct lodepng_allocator_entry_tag {
	Ptr ptr;
	UInt32 size;
} LodepngAllocatorEntry;

typedef struct lodepng_allocator_type {
	LodepngAllocatorEntry entries[LODEPNG_ALLOCATOR_MAX_ENTRIES];
	UInt32 numEntries;
	HeapMem_Handle heapHandle;
} LodepngAllocator;

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/
static LodepngAllocator gLodepngAllocator = {
	{ 0 },
	0
};

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

void lodepng_allocator_init(void)
{
	VideoHeap_getHeapHandle(&gLodepngAllocator.heapHandle);
}

void* lodepng_malloc(size_t size)
{
	LodepngAllocatorEntry *entry;

  LOG_PRINT_SVER(DEBUG_LODEPNG_ALLOCATOR, "%s(): trying to allocate buffer of size %d. numEntries = %d\r\n", __FUNCTION__, size, gLodepngAllocator.numEntries);

	if (LODEPNG_ALLOCATOR_MAX_ENTRIES <= gLodepngAllocator.numEntries)
	{
		return NULL;
	}
	entry = &gLodepngAllocator.entries[gLodepngAllocator.numEntries];

	size = (size + 4 - 1) / 4 * 4;

	entry->ptr = Memory_alloc((IHeap_Handle)gLodepngAllocator.heapHandle, size, 0, NULL);
	if (NULL == entry->ptr)
		return NULL;

	entry->size = size;

	LOG_PRINT_SVER(DEBUG_LODEPNG_ALLOCATOR, "%s(): New entry. ptr = %p, size = %d\r\n", __FUNCTION__, entry->ptr, entry->size);
	
	gLodepngAllocator.numEntries++;

	return entry->ptr;
}

void* lodepng_realloc(void* ptr, size_t newSize)
{
	UInt32 oldSize, i;
	Ptr oldPtr, newPtr;

	newPtr = NULL;

	LOG_PRINT_SVER(DEBUG_LODEPNG_ALLOCATOR, "%s(): trying to reallocate ptr = %p to new size = %d\r\n", __FUNCTION__, ptr, newSize);

	if (NULL == ptr)
	{
		return lodepng_malloc(newSize);
	}

	for(i=0; i < gLodepngAllocator.numEntries; i++)
	{
		if (gLodepngAllocator.entries[i].ptr == ptr)
		{
			/* we found the pointer */
			oldPtr = gLodepngAllocator.entries[i].ptr;
			oldSize = gLodepngAllocator.entries[i].size;

			LOG_PRINT_SVER(DEBUG_LODEPNG_ALLOCATOR, "%s(): old allocation of pointer %p found with size of %d\r\n", __FUNCTION__, oldPtr, oldSize);

			/* allocate new pointer */
			newSize = (newSize + 4 - 1) / 4 * 4;

			newPtr = Memory_alloc((IHeap_Handle)gLodepngAllocator.heapHandle, newSize, 0, NULL);
			if (NULL != newPtr)
			{
				/* copy content */
#ifndef LODEPNG_ALLOCATOR_USE_DMA
				memcpy(newPtr, oldPtr, (newSize > oldSize)? oldSize : newSize);
#else
				Cache_wbInv(oldPtr, oldSize, Cache_Type_ALL, TRUE);
				VideoDMA_copy(newPtr, oldPtr, (newSize > oldSize)? oldSize : newSize);
				Cache_inv(newPtr, newSize, Cache_Type_ALL, TRUE);

#endif
				/* free old allocation */
				Memory_free((IHeap_Handle)gLodepngAllocator.heapHandle, oldPtr, oldSize);

				/* update entry */
				gLodepngAllocator.entries[i].ptr = newPtr;
				gLodepngAllocator.entries[i].size = newSize;

				LOG_PRINT_SVER(DEBUG_LODEPNG_ALLOCATOR, "%s(): new allocation of pointer %p done with size of %d\r\n", __FUNCTION__, newPtr, newSize);
			}
			/* we are done */
			break;
		}
	}
	
	return newPtr;
}

void lodepng_free(void* ptr)
{
	UInt32 size, i;

	LOG_PRINT_SVER(DEBUG_LODEPNG_ALLOCATOR, "%s(): trying to free ptr %p\r\n", __FUNCTION__, ptr);

	for(i=0; i < gLodepngAllocator.numEntries; i++)
	{
		if (gLodepngAllocator.entries[i].ptr == ptr)
		{
			/* we found the pointer */
			size = gLodepngAllocator.entries[i].size;

			LOG_PRINT_SVER(DEBUG_LODEPNG_ALLOCATOR, "%s(): old allocation of pointer %p found with size of %d\r\n", __FUNCTION__, ptr, size);

			/* free old allocation */
			Memory_free((IHeap_Handle)gLodepngAllocator.heapHandle, ptr, size);

			/* we are done */
			break;
		}
	}

	if (i < gLodepngAllocator.numEntries)
	{
		for( ; i < (gLodepngAllocator.numEntries - 1); i++)
		{
			gLodepngAllocator.entries[i] = gLodepngAllocator.entries[i+1];
		}
		gLodepngAllocator.numEntries--;
	}

}

/**
 * Close doxygen group
 * @}
 */