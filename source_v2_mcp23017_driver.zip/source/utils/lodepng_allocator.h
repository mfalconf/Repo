#ifndef __LODEPNG_ALLOCATOR_HPP__
#define __LODEPNG_ALLOCATOR_HPP__

#include <stddef.h>

void lodepng_allocator_init(void);

void* lodepng_malloc(size_t size);

void* lodepng_realloc(void* ptr, size_t newSize);

void lodepng_free(void* ptr);

#endif // __LODEPNG_ALLOCATOR_HPP__
