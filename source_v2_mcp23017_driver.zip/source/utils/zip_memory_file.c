/******************************************************************************
 *
 * \file    zip_memory_file.c
 *
 * \brief   ZIP Memory File source file
 *
 * \author  Esteban Pupillo
 *
 * \date    23 Sep 2022
 *
 *****************************************************************************/

#include <standard.h>

#include "zip_memory_file.h"

#include <console.h>
#include <xdc/std.h>
#include <xdc/runtime/Memory.h>

#include "video_dma.h"

/**
 * @addtogroup ZipMemoryFile
 * @{
 */

/******************************************************************************
 * Constant and Macro definitions using #define
 *****************************************************************************/

/******************************************************************************
 * Enumerations, Structures and Typedefs
 *****************************************************************************/
typedef struct zip_memory_file_type {
	JZFile nativeHandle;
	/**< JZFile native handler */

	UInt32 baseAddress;
	/**< Zip file base memory address */

	UInt32 size;
	/**< Zip file size */

	UInt32 offset;
	/**< Current read offset */
} ZipMemoryFile;

/******************************************************************************
 * Function prototypes for private functions with file level scope
 *****************************************************************************/

/******************************************************************************
 * ROM const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Static variables and const variables with file level scope
 *****************************************************************************/

/******************************************************************************
 * Functions implementation
 *****************************************************************************/

static size_t zipMemoryFile_read(JZFile *file, void *buf, size_t size)
{
	ZipMemoryFile *zipFile;
	UInt8 *readPtr;

	/* Check input parameters */
	if ((NULL == file) || (NULL == buf) || (0 == size))
	{
		return 0;
	}

	/* Get out internal file handle */
	zipFile = (ZipMemoryFile *) file;

	/* Calculate read pointer */
	readPtr = (UInt8 *) zipFile->baseAddress + zipFile->offset;
	
	memcpy(buf, readPtr, size);
	
	//retVal = VideoDMA_copy(buf, readPtr, size);
	//if (E_OK != retVal)
	//{
	//	return 0;
	//}

	LOG_PRINT_INFO(DEBUG_ZIP_MEM_FILE, "%s(): %d bytes read from offset %d\r\n", __FUNCTION__, size, zipFile->offset);

	/* Update curret offset */
	zipFile->offset += size;

	/* return the number of bytes read */
	return size;
}

static size_t zipMemoryFile_tell(JZFile *file)
{
	ZipMemoryFile *zipFile;

	/* Check input parameters */
	if (NULL == file)
	{
		return 0;
	}

	/* Get out internal file handle */
	zipFile = (ZipMemoryFile *) file;

	LOG_PRINT_INFO(DEBUG_ZIP_MEM_FILE, "%s(): current offset = %d\r\n", __FUNCTION__, zipFile->offset);

	/* Return current offset */
	return zipFile->offset;
}

static int zipMemoryFile_seek(JZFile *file, size_t offset, int whence)
{
	ZipMemoryFile *zipFile;

	/* Check input parameters */
	if (NULL == file)
	{
		return -1;
	}

	/* Get out internal file handle */
	zipFile = (ZipMemoryFile *) file;

	/* Calculate new offset */
	switch (whence)
	{
		case SEEK_SET:
			{
				/* offset relative to start of the file */
				if (offset >= zipFile->size)
				{
					return -1;
				}
				else
				{
					zipFile->offset = offset;
				}
				break;
			}
		case SEEK_CUR:
			{
				/* offset relative to current position */
				if ((zipFile->offset + offset) >= zipFile->size)
				{
					/* out of file bounds */
					return -1;
				}
				else
				{
					/* update offset based on current position */
					zipFile->offset += offset;
				}
				break;
			}
		case SEEK_END:
			{
				/* offset relative to end of the file */
				if ((0 < offset) || (-offset) >= zipFile->size)
				{
					return -1;
				}
				else
				{
					zipFile->offset = zipFile->size - offset;
				}

				break;
			}
		default:
			return -1;
	}

	LOG_PRINT_INFO(DEBUG_ZIP_MEM_FILE, "%s(): new offset = %d\r\n", __FUNCTION__, zipFile->offset);

	return 0;
}

static int zipMemoryFile_error(JZFile *file)
{
	return E_OK;	
}

static void zipMemoryFile_close(JZFile *file)
{
	/* Check input parameters */
	if (NULL == file)
	{
		return;
	}

	ZipMemoryFile_destroy(file);
}

JZFile* ZipMemoryFile_create(UInt32 *baseAddress, UInt32 size)
{
	ZipMemoryFile *newFile;

	/* Check input parameters */
	if (0 == baseAddress)
	{
		return NULL;
	}

	/* Allocate new file handler */
	newFile = (ZipMemoryFile *) Memory_alloc(NULL, sizeof(ZipMemoryFile), 0, NULL);
	if (NULL == newFile)
	{
		/* we couldn't allocate a new file object */
		return NULL;
	}

	/* Initialize handler */
	newFile->baseAddress = (UInt32) baseAddress; //PHY_TO_DA_ADDR(0x8BF80004); (UInt32) baseAddress;
	newFile->size = size;
	newFile->offset = 0;

	/* Initialize native handler */
	newFile->nativeHandle.read = zipMemoryFile_read;
	newFile->nativeHandle.tell = zipMemoryFile_tell;
	newFile->nativeHandle.seek = zipMemoryFile_seek;
	newFile->nativeHandle.error = zipMemoryFile_error;
	newFile->nativeHandle.close = zipMemoryFile_close;

	LOG_PRINT_INFO(DEBUG_ZIP_MEM_FILE, "%s(): ZipMemoryFile handler %p created\r\n", __FUNCTION__, newFile);

	return (JZFile *) newFile;
}

Int32 ZipMemoryFile_destroy(JZFile *file)
{
	/* check input parameters */
	if (NULL == file)
	{
		return E_ERROR;
	}

	/* free animator memory */
	Memory_free(NULL, file, sizeof(ZipMemoryFile));

	LOG_PRINT_INFO(DEBUG_ZIP_MEM_FILE, "%s(): ZipMemoryFile handler %p destroyed\r\n", __FUNCTION__, file);

	return E_OK;
}

/**
 * Close doxygen group
 * @}
 */

