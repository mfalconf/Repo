#ifndef __CPU_REPORT_HPP__
#define __CPU_REPORT_HPP__

/** Initialize periodic CPU report */
void CpuReport_Init(void);

#endif // __CPU_REPORT_HPP__
