#ifndef CONSOLE_H_
#define CONSOLE_H_
/*===========================================================================*/
/**
 * @file CONSOLE.h
 *
 * Function definitions for the Console logs module.
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <standard.h>

#ifdef CORE_M4
#include <xdc/runtime/System.h>
#endif

#ifdef CORE_A15
#include <cutils/log.h>
#endif

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#define DEBUG_ANTPWR            0
#define DEBUG_PM                0
#define DEBUG_PM_QUEUE          0
#define DEBUG_MICBIAS           0
#define DEBUG_SB                0
#define DEBUG_DIMMING           0
#define DEBUG_ES                0
#define DEBUG_SHADOW            0
#define DEBUG_CAN               0
#define DEBUG_BOARD             0
#define DEBUG_TD                0
#define DEBUG_AUX               0
#define DEBUG_ASWC              0
#define DEBUG_AUDIOREP          0
#define DEBUG_GFX_BLENDER       0
#define DEBUG_GFX_ANIMATOR      0
#define DEBUG_PDC_VIEW          0
#define DEBUG_ZIP_MEM_FILE      0
#define DEBUG_BAP               0
#define ERROR_BAP               0
#define DEBUG_WD                0
#define DEBUG_TRANSPORT_MODE    0
#define DEBUG_VALIDATION_TONE   0
#define DEBUG_COMM_PROTOCOL     0
#define DEBUG_PMIC              0
#define DEBUG_BM_RAW_COUNTS     0
#define DEBUG_BM                0
#define DEBUG_MIF               1
//#define LOG_DEBUG_NO_LOGS
//#define LOG_DEBUG_SUPER_VERBOSE

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#ifdef CORE_M4
#define LOG_PORT_E	System_printf
#define LOG_PORT_I	System_printf
#define LOG_PORT_V	System_printf
#define LOG_PORT_SV	System_printf
#define LOG_PORT_D	System_printf
#elif CORE_A15
#define LOG_PORT_E	ALOGE
#define LOG_PORT_I	ALOGE
#define LOG_PORT_V	ALOGE
#define LOG_PORT_SV	ALOGE
#define LOG_PORT_D	ALOGE
#else
#define LOG_PORT_E
#define LOG_PORT_I
#define LOG_PORT_V
#define LOG_PORT_SV
#define LOG_PORT_D
#endif

 #define LOG_PRINT(enable, fmt, arg...)  do                                  \
                                        {                                   \
                                           if ( enable )                    \
                                           {                                \
                                               LOG_DEBUG(fmt , ##arg);      \
                                           }                                \
                                        } while(0)

#define LOG_PRINT_ERR(enable, fmt, arg...)  do                                  \
                                            {                                   \
                                               if ( enable )                    \
                                               {                                \
                                                   LOG_DEBUG_ERR(fmt , ##arg);  \
                                               }                                \
                                            } while(0)

#define LOG_PRINT_INFO(enable, fmt, arg...)  do                                 \
                                            {                                   \
                                               if ( enable )                    \
                                               {                                \
                                                   LOG_DEBUG_INFO(fmt , ##arg); \
                                               }                                \
                                            } while(0)

#define LOG_PRINT_VER(enable, fmt, arg...)  do                                  \
                                            {                                   \
                                               if ( enable )                    \
                                               {                                \
                                                   LOG_DEBUG_VER(fmt , ##arg);  \
                                               }                                \
                                            } while(0)

#define LOG_PRINT_START_FUNC(enable)        do                                  \
                                            {                                   \
                                               if ( enable )                    \
                                               {                                \
                                                   LOG_DEBUG_START_FUNC();      \
                                               }                                \
                                            } while(0)

#define LOG_PRINT_SVER(enable, fmt, arg...) do                                  \
                                            {                                   \
                                               if ( enable )                    \
                                               {                                \
                                                   LOG_DEBUG_SVER(fmt , ##arg); \
                                               }                                \
                                            } while(0)

#define LOG_DEBUG(fmt, arg...)  LOG_PORT_D(fmt , ##arg)

#if defined(LOG_DEBUG_NO_LOGS)
    #define LOG_ERR(fmt, arg...)
    #define LOG_INFO(fmt, arg...)
    #define LOG_VER(fmt, arg...)
    #define LOG_START_FUNC()
    #define LOG_SVER(fmt, arg...)
#else
    #define LOG_DEBUG_ERR(fmt, arg...)  LOG_PORT_E(fmt , ##arg)
    #define LOG_DEBUG_INFO(fmt, arg...) LOG_PORT_I(fmt , ##arg)
    #define LOG_DEBUG_VER(fmt, arg...)  LOG_PORT_V(fmt , ##arg)
    #if defined(LOG_DEBUG_SUPER_VERBOSE)
        #define LOG_DEBUG_START_FUNC()      LOG_PORT_SV("Entering %s\r\n", __FUNCTION__)
        #define LOG_DEBUG_SVER(fmt, arg...) LOG_PORT_SV(fmt , ##arg)
    #else
        #define LOG_DEBUG_START_FUNC()
        #define LOG_DEBUG_SVER(fmt, arg...)
    #endif
#endif

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/


#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file CONSOLE.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 06-Jul-2018 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
#endif /* CONSOLE_H_ */
