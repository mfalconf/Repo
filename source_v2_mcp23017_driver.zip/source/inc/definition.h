#ifndef DEFINITION_H
#   define DEFINITION_H
/*===========================================================================*/
/**
 * @file definition.h
 *
 * Global defines of miscellaneous useful stuff.
 *
 * %full_filespec:definiti.h~1:incl:kok_basa#31 %
 * @version %version:1 %
 * @author  %derived_by:tz74ph %
 * @date    %date_modified:Thu Jun  6 16:38:14 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2016 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 * Global defines of miscellaneous useful stuff.
 * Author: Dan Carman
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup myApp Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
 /*---------------------------------------------------------------------------*
 * Standard boolean labels
 *---------------------------------------------------------------------------*/
#ifndef  UP
#define  DOWN           false
#define  UP             !DOWN
#endif

#ifndef  OFF
#define  OFF             false
#define  ON              !OFF
#endif

#ifndef  CLEARED
#define  CLEARED         false
#define  SET             !CLEARED
#endif

#ifndef  DISABLE
#define  DISABLE         false
#define  ENABLE          !DISABLE
#endif

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * macros to append symbols together
 *---------------------------------------------------------------------------*/
#define  To_Boolean(bit)            ((bit) ? true : false)                 /* convert bit/logical to normalized boolean */
#define  Bit_Copy(target, source)   (target = ((source) ? true : false))   /* set target equal to source */
#define  Bit_Toggle(target)         (target = ((target) ? false : true))   /* toggle target              */
#define  FOREVER                    while(1)

#define icat(x, y) x ## y
#define iins(x, y, z) x ## y ## z
#define cat(x, y)  icat(x,y)

#define Num_Elems(array)    (sizeof(array)/sizeof(array[0]))

#define Task_sleep_ms(x)	  Task_sleep(((x) * 1000) / Clock_tickPeriod)
#define Task_sleep_us(x)    Task_sleep((x) / Clock_tickPeriod)
#define MS_TO_TICKS(x)      (((x) * 1000) / Clock_tickPeriod)
#define US_TO_TICKS(x)      ((x) / Clock_tickPeriod)
#define TICKS_TO_MS(x)      ((x) * Clock_tickPeriod / 1000)
#define TICKS_TO_US(x)      ((x) * Clock_tickPeriod)



/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum   Status_Type_Tag      /* Return status from RTOS functions */
   {
      E_OK             =  0,        /* NO Error, successful */
      E_ERROR,                      /* General Error        */
      E_OS_ACCESS,
      E_OS_CALLEVEL,
      E_OS_ID,
      E_OS_LIMIT,
      E_OS_NOFUNC,
      E_OS_RESOURCE,
      E_OS_STATE,
      E_OS_VALUE,
      E_COM_NOMSG,
      E_COM_LOCKED,
      E_TASK_SUSPENDED,
      E_TIMEOUT,                    /* Error due to timeout */
      E_OUT_OF_RANGE,               /* Error due to parameter out of range */
      E_INVALID_CONDITION           /* Error due to invalid conditions */
   } Status_Type;

//typedef unsigned char uint8_t;
//typedef unsigned short uint16_t;
//typedef unsigned int uint32_t;
//typedef short int16_t;
//typedef int int32_t;
//typedef uint8_t bool_t;
//
//typedef void (*void_fptr) (void);                 /* void void Function pointer typedef */
//typedef bool_t (*bool_fptr) (void);                 /* boolean void function typedef */
//typedef void (*void_int16_fptr) (int16_t data);   /* void funtion taking 16 bit integer */

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file definiti.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 23-sep-2016 Pablo Luis Joaquim
 *   - Created initial file.
 *
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* DEFINITION_H */
