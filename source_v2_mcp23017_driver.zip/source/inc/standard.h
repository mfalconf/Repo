#ifndef STANDARD_H
#   define STANDARD_H
/*===========================================================================*/
/**
 * @file standard.inc
 *
 * This file contains all standard include statements
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2017 Famar Confidential, All Rights Reserved.
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Compiler / Part Specific Defines
 *===========================================================================*/

/*===========================================================================*
 * Standard C Library
 *===========================================================================*/


/*===========================================================================*
 *  Includes of System setup header
 *===========================================================================*/

/*===========================================================================*
 * Includes of standard C definitions (Compiler / micro independent)
 *===========================================================================*/
#include "definition.h"
#include "project_def.h"
#include "types.h"

/*===========================================================================*
 * Includes of I/O assignments 
 *===========================================================================*/

/*===========================================================================*
 * General System includes
 *===========================================================================*/

/*===========================================================================*
 * Application specific Header files
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file standard.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 05-Sept-2017 Pablo Luis Joaquim
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* STANDARD_H */
