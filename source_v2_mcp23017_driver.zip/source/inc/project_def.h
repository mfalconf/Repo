/*
 * project_def.h
 *
 *  Created on: May 24, 2018
 *      Author: ggabriel
 */

#ifndef SOURCE_INC_PROJECT_DEF_H_
#define SOURCE_INC_PROJECT_DEF_H_

#define CORE_M4     1

/** IPU device address where RAM starts */
#define IPU_RAM_BASE_ADDR   (0x80000000U)
/** Physical address where RAM starts */
#define PHY_RAM_BASE_ADDR   (0x9D300000U+0x600000U)

/** RAM offset between device addresses and physical addresses */
#define DA_TO_PHY_OFFSET    (PHY_RAM_BASE_ADDR - IPU_RAM_BASE_ADDR)

/** Convert a device address to a physical address */
#define DA_TO_PHY_ADDR(x)   ((void*)((x) + DA_TO_PHY_OFFSET))

/** Convert a physical address to a device address */
#define PHY_TO_DA_ADDR(x)   ((void*)((x) - DA_TO_PHY_OFFSET))

/** L4 address offset based on the AMMU configuration */
#define L4_REGISTER_ADDRESS_OFFSET    (0x20000000)

#define APP_CORE_NUM                    (1)
#define VIDEO_CORE_NUM                  (0)

#undef PRODUCT_DEFINED

#ifdef PRODUCT_MOPAR
#define PRODUCT_DEFINED                 1
#define USE_DIMMING_MOPAR               1
#define USE_CAN                         1
#define USE_CAN_MOPAR                   1
#endif

#ifdef PRODUCT_SENTION
#define PRODUCT_DEFINED                 1
#define USE_DIMMING_AFTER               1
#define USE_ASWC                        1
#define USE_ASWC_BENCH                  1
#define USE_EXTERNAL_SIGNALS            1
/* Ignore discrete dimming line since the PWM measurement is not implemented */
//#define IGNORE_DISCRETE_DIMMING_LINE    1
/* Ignore external mic diagnostic for after products since the user could use any mic */
//#define IGNORE_MIC_DIAGNOSTIC           1
//#define IGNORE_ANTPWR_GPS_DIAGNOSTIC    1
#endif

#ifdef PRODUCT_TOYOTA
#define PRODUCT_DEFINED                 1
#define USE_DIMMING_AFTER               1
#define USE_ASWC                        1
#define USE_ASWC_TOYOTA                 1
#define USE_EXTERNAL_SIGNALS            1
#endif

#ifdef PRODUCT_NISSAN
#define PRODUCT_DEFINED                 1
#define USE_DIMMING_AFTER               1
#define USE_ASWC                        1
#define USE_ASWC_NISSAN                 1
#define USE_EXTERNAL_SIGNALS            1
#endif

#ifdef PRODUCT_VOLKSWAGEN
#define PRODUCT_DEFINED                 1
#define USE_DIMMING_AFTER               1
#define USE_CAN                         1
#define USE_CAN_VOLKSWAGEN              1
#define USE_BAP                         1
#define ENABLE_CAN_TX                   1
#define USE_EXTERNAL_SIGNALS            0
#define USE_TOUCHSCREEN_AS_PWRBTN       0
#define USE_ASWC                        0
#endif

#ifndef PRODUCT_DEFINED
#error "No product defined! Please select a product in products.mak file!"
#endif

#endif /* SOURCE_INC_PROJECT_DEF_H_ */
