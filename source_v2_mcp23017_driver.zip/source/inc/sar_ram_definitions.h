/*
 * shared_ram_memory.h
 *
 *  Created on: Aug 27, 2019
 *      Author: ggabriel
 */

#ifndef SOURCE_INC_SAR_RAM_DEFINITIONS_H_
#define SOURCE_INC_SAR_RAM_DEFINITIONS_H_

/* SAR RAM base address */
#define DRA7XX_SAR_RAM_BASE                     0x4AE26000

/* SAR RAM register offset*/

/*
 * RVC information. Used with the A15 to ensure that the RVC
 * is set in the fastest time possible. Using the normal
 * IPC queue takes much more time.
 */
#define SAR_RAM_OFFSET_RVC                      0x00000004

/*
 * PM information from recovery console to ipu1, used to bypass the
 * pm state machine when flashing by OTA
 */
#define SAR_RAM_OFFSET_PM                       0x00000008



#endif /* SOURCE_INC_SAR_RAM_DEFINITIONS_H_ */
