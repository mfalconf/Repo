#ifndef TYPES_H_
#define TYPES_H_ 0

#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef uint8_t bool_t;

#undef FALSE
#define FALSE 0

#undef TRUE
#define TRUE 1

#endif /* TYPES_H_ */
