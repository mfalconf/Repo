//********************************************************************
//
//   Title                : fsm.h
//
//   Description          : This is the header file a FSM implementation
//
//   Author               : Esteban G. Pupillo
//
//   Created              : <24 Mar 2016>
//
//********************************************************************

#ifndef _FSM_H
#define _FSM_H

//********************************************************************
// Constant and Macro Definitions using #define
//********************************************************************
#define FSM_ENTRY_SIG    (0)
#define FSM_EXIT_SIG     (1)
#define FSM_TICK_SIG     (2)
#define FSM_USER_SIG     (3)

/* "inlined" methods of Fsm class */
#define FsmCtor(me_, init_)			((me_)->state__ = (FsmState * )(init_))
#define FsmInit(me_, e_)     		((me_)->state__->handler((Fsm *)(me_), (const FsmEvent *)(e_)))
#define FsmDispatch(me_, e_) 		((me_)->state__->handler((Fsm *)(me_), (const FsmEvent *)(e_)))
#define FsmTran(me_, targ_) 		do { FsmDispatch(me_,&FsmEvtExit); \
                                  ((me_)->state__ = (FsmState *)(targ_)); \
                                  FsmDispatch(me_,&FsmEvtEntry); \
                                } while(0)
#define FsmGetCurrStateId(me_)  ((me_)->state__->id)

#define FSM_FIELDS FsmState *state__
#define FSM_EVENT_FIELDS FsmSignal sig


//********************************************************************
// Enumerations and Structures and Typedefs
//********************************************************************
typedef uint32_t FsmSignal;
typedef struct FsmEvent FsmEvent;
typedef struct Fsm Fsm;
typedef int32_t (*StateHandler)(Fsm *, FsmEvent const *);

typedef struct {
	uint32_t id;
	StateHandler handler;
} FsmState;

/* Event base class */
struct FsmEvent
{
   FSM_EVENT_FIELDS;
};

/* Finite State Machine base class */
struct Fsm
{
   FSM_FIELDS; /* the current state */
};

//********************************************************************
// Global Variable extern Declarations
//********************************************************************
static FsmEvent const FsmEvtEntry = { FSM_ENTRY_SIG };
static FsmEvent const FsmEvtExit = { FSM_EXIT_SIG };
static FsmEvent const FsmEvtTick = { FSM_TICK_SIG };

//********************************************************************
// Function Prototypes
//********************************************************************


#endif // _FSM_H
//********************************************************************
//
// Modification Record
//
//********************************************************************
//
//
//
//********************************************************************
